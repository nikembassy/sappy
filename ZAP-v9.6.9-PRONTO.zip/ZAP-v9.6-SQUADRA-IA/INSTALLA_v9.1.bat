@echo off
rem ===========================================================================
rem  INSTALLA_v9.1.bat  -  doppio clic e basta.
rem  Trova ZAP da solo, fa il backup, applica la patch v9.1, rimette le chiavi,
rem  imposta GHOST su APERTO, esegue i test e avvia ZAP.
rem  Se i test falliscono, ripristina tutto da solo.
rem  Per vedere cosa farebbe senza toccare niente:  INSTALLA_v9.1.bat -Prova
rem ===========================================================================
setlocal
cd /d "%~dp0"

echo.
echo  ==============================================
echo   ZAP-Gemini v9.1 - installazione automatica
echo  ==============================================
echo.

where powershell >nul 2>&1
if errorlevel 1 (
    echo  ERRORE: PowerShell non trovato. Serve Windows con PowerShell.
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA_v9.1.ps1" %*
set RC=%ERRORLEVEL%

echo.
if "%RC%"=="0" (
    echo  Fatto. Se ZAP non si e' aperto da solo, avvia AVVIA.bat.
) else if "%RC%"=="4" (
    echo  I test hanno trovato un problema: ho ripristinato la versione precedente.
    echo  Leggi INSTALLAZIONE_v9.1.log nella cartella per capire cosa non andava.
) else (
    echo  Installazione non completata [codice %RC%].
    echo  Leggi INSTALLAZIONE_v9.1.log nella cartella: c'e' scritto dove si e' fermata.
)
echo.
pause
exit /b %RC%
