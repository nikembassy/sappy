@echo off
rem ===========================================================================
rem  ZAP - RACCOGLI STRUMENTI
rem  Guarda quali programmi di pentest hai su questo PC e scrive un file
rem  da consegnare a ZAP. Non installa niente, non tocca la rete, non serve admin.
rem  La finestra resta aperta alla fine.
rem ===========================================================================
setlocal
cd /d "%~dp0"
title ZAP - raccolta strumenti

where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ZAP] ERRORE: PowerShell non trovato su questo PC.
  echo.
  pause
  exit /b 1
)

if not exist "%~dp0RACCOGLI_STRUMENTI.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca RACCOGLI_STRUMENTI.ps1 accanto a questo file.
  echo  Cartella: %~dp0
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RACCOGLI_STRUMENTI.ps1"

echo.
echo  ------------------------------------------------
echo  Fatto. Il file da consegnare e:
echo    documentazione\strumenti.json
echo  Puoi chiudere questa finestra.
echo  ------------------------------------------------
pause
exit /b 0
