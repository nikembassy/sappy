@echo off
rem ===========================================================================
rem  PREPARA_STRUMENTI_v9.1.bat
rem  Installa e verifica: Wireshark, Metasploit, sqlmap, hydra, aircrack-ng,
rem  nikto, gobuster, dirb (+ nmap, ffuf, whatweb, wafw00f, nuclei, wordlists).
rem  Chiede i permessi di amministratore da solo. La prima volta serve tempo:
rem  Kali pesa 2-3 GB e Metasploit circa 1 GB.
rem
rem  Solo controllo, senza installare:   PREPARA_STRUMENTI_v9.1.bat -Verifica
rem  Solo Wireshark:                     PREPARA_STRUMENTI_v9.1.bat -SoloWireshark
rem  Senza gli strumenti extra:          PREPARA_STRUMENTI_v9.1.bat -SenzaExtra
rem ===========================================================================
setlocal
cd /d "%~dp0"

echo.
echo  ============================================================
echo   ZAP - preparazione strumenti di pentest
echo  ============================================================
echo.

where powershell >nul 2>&1
if errorlevel 1 (
    echo  ERRORE: PowerShell non trovato.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PREPARA_STRUMENTI_v9.1.ps1" %*
set RC=%ERRORLEVEL%

echo.
if "%RC%"=="0" (
    echo  Fatto. Apri ZAP e scrivi /strumenti verifica.
) else (
    echo  Qualcosa non e' andato [codice %RC%].
    echo  Leggi PREPARA_STRUMENTI.log nella cartella: c'e' scritto dove si e' fermato.
)
echo.
pause
exit /b %RC%
