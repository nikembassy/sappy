@echo off
rem ===========================================================================
rem  ZAP - AVVIO SICURO
rem  Controlla, ripara se puo', avvia ZAP. Questa finestra NON si chiude da sola:
rem  resta aperta con il rapporto, cosi' si legge sempre cosa e' successo.
rem ===========================================================================
setlocal
cd /d "%~dp0"
title ZAP - avvio sicuro (la finestra resta aperta)

where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ZAP] ERRORE: PowerShell non trovato su questo PC.
  echo.
  pause
  exit /b 1
)

if not exist "%~dp0AVVIO_SICURO.ps1" (
  echo.
  echo  [ZAP] ERRORE: manca AVVIO_SICURO.ps1 accanto a questo file.
  echo  Cartella: %~dp0
  echo  Estrai di nuovo lo ZIP per intero.
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0AVVIO_SICURO.ps1"

echo.
echo  ------------------------------------------------
echo  Rapporto completo: logs\avvio-sicuro.log
echo  Premi un tasto per chiudere.
echo  ------------------------------------------------
pause
exit /b 0
