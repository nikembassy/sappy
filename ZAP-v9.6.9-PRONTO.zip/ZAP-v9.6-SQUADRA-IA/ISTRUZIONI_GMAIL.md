# Posta con Gmail: configurazione (ZAP v9)

ZAP puo' preparare e inviare email dal tuo account Gmail. **Di default prepara solo la bozza**
e non invia niente: l'invio lo autorizzi tu.

## Perche' non basta la password di Gmail

Google blocca l'accesso SMTP con la password normale dell'account (errore `5.7.8`).
Serve una **password per le app**: 16 caratteri, generata da Google, che vale solo per
quel programma e che puoi revocare in qualsiasi momento senza cambiare la password vera.

## Passi (5 minuti, una volta sola)

1. Attiva la **verifica in due passaggi** sul tuo account Google:
   https://myaccount.google.com/security  (senza questa, Google non mostra le password per le app)

2. Crea la password per le app:
   https://myaccount.google.com/apppasswords
   - Nome: `ZAP`
   - Copia i 16 caratteri che compaiono (togli gli spazi: `abcd efgh ijkl mnop` -> `abcdefghijklmnop`)

3. Mettila in `config.local.json` **solo dentro `gmail.password`**:

```json
{
    "provider_ai": { "...": "..." },
    "gmail": {
        "password": "abcdefghijklmnop"
    }
}
```

4. Metti il tuo indirizzo in `config.json` (questo file e' pubblico, la password no):

```json
"gmail": {
    "mittente": "iltuoindirizzo@gmail.com",
    "nome": "Mario Rossi",
    "password": "",
    "smtp": "smtp.gmail.com",
    "porta": 587,
    "ssl": true,
    "firma": "Mario Rossi - Studio XYZ",
    "solo_bozze": true
}
```

5. Verifica da ZAP: chiedi **"controlla la posta"** (strumento `email`, azione `stato`).

## Come si usa

| Cosa chiedi a ZAP | Cosa succede |
|---|---|
| "prepara una mail a mario@example.com oggetto Preventivo" | bozza salvata in `Ezappero\email\` |
| "mandala" / "inviala" | invio reale (solo se `solo_bozze` e' `false` o se lo chiedi esplicitamente) |
| "allega la fattura" | allega il PDF creato da ZAP |

Per l'invio diretto senza chiedere ogni volta: `"solo_bozze": false` in `config.json`.

## Se qualcosa non funziona

| Errore | Significato | Rimedio |
|---|---|---|
| `5.7.8` / `Authentication` | stai usando la password normale dell'account | crea la password per le app (punto 2) |
| `5.7.14` | Google ha bloccato l'accesso per sicurezza | accedi da browser, controlla gli avvisi di sicurezza, riprova |
| timeout | firewall/rete | prova dalla rete di casa; la porta 587 deve essere libera |
| `manca il mittente` | `gmail.mittente` vuoto | compila il punto 4 |

Nota: la password per le app vale come una password. Non metterla in `config.json`, non
incollarla in chat e, se la perdi, revocala dalla stessa pagina del punto 2.
