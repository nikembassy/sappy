﻿# ==========================================================================
#  ticker_news.ps1  -  ZAP! v9.3  "NASTRO NOTIZIE"
#  Pannello bianco a tutta larghezza: notizie dal mondo + quotazioni di borsa
#  che scorrono da destra a sinistra, subito sotto la barra del titolo.
#
#   * download ASINCRONO (WebClient + Task): la grafica non si blocca mai
#   * feed RSS/Atom generici + Yahoo Finance per i prezzi (nessuna API key)
#   * il nastro si ferma col mouse sopra, clic = articolo nel browser
#   * se la rete cade resta l'ultimo contenuto buono
#   * configurazione in ui\ticker.json
#
#  Si carica da AVVIA.ps1 con:  . (Join-Path $base 'ui\ticker_news.ps1')
# ==========================================================================

$script:ZapTickDir = $PSScriptRoot

$script:ZapTick = @{
    Attivo        = $false
    Visibile      = $false     # v9.4.4: spento finche' non lo accendi
    HandlersFatti = $false     # v9.4: i gestori del mouse si registrano UNA volta
    Pausa         = $false
    PausaMouse    = $true
    Velocita      = 62.0
    Altezza       = 48.0
    Shift         = 0.0
    Larghezza     = 1.0
    UltimoMs      = 0.0
    Secondo       = -1
    Timer         = $null
    Pump          = $null
    Cronometro    = $null
    Scarichi      = @()
    Feed          = @()
    Simboli       = @()
    NotizieGrezze = @()
    Notizie       = @()
    Quotazioni    = @()
    QuoteMap      = @{}
    Sporco        = $false
    UltimoFeed    = [datetime]::MinValue
    UltimoQuote   = [datetime]::MinValue
    IntervalloFeedSec  = 480
    IntervalloQuoteSec = 60
    MaxNotizie    = 26
    Barra         = $null
    Binario       = $null
    Items         = $null
    Clone         = $null
    Traslazione   = $null
    Bollo         = $null
    Orologio      = $null
    DataOra       = $null
    RigaTicker    = $null
    RigaContenuto = $null
    Area          = $null
}

$script:ZapTickPennelli = @{}

# --------------------------------------------------------------------------
#  PENNELLI (cache: gli stessi colori non si ricreano mille volte)
# --------------------------------------------------------------------------
function Get-ZapTickPennello {
    param([string]$Hex)
    if ($script:ZapTickPennelli.ContainsKey($Hex)) { return $script:ZapTickPennelli[$Hex] }
    $b = New-Object System.Windows.Media.SolidColorBrush
    try { $b.Color = [System.Windows.Media.ColorConverter]::ConvertFromString($Hex) } catch { $b.Color = [System.Windows.Media.Colors]::Gray }
    try { $b.Freeze() } catch { }
    $script:ZapTickPennelli[$Hex] = $b
    return $b
}

# --------------------------------------------------------------------------
#  CONFIGURAZIONE (ui\ticker.json, con valori di riserva sensati)
# --------------------------------------------------------------------------
function Get-ZapTickConfig {
    param([string]$Base)
    $d = [ordered]@{}
    $d.attivo                 = $true
    $d.visibile               = $false   # v9.4.4: il nastro parte SPENTO (si accende con F8)
    $d.altezza                = 48
    $d.velocita               = 62
    $d.posizione              = 'alto'
    $d.pausa_al_mouse         = $true
    $d.aggiorna_notizie_sec   = 480
    $d.aggiorna_quotazioni_sec = 60
    $d.max_notizie            = 26
    $d.feed = @(
        [pscustomobject]@{ nome = 'ANSA';          url = 'https://www.ansa.it/sito/notizie/topnews/topnews_rss.xml' },
        [pscustomobject]@{ nome = 'ANSA ECONOMIA'; url = 'https://www.ansa.it/sito/notizie/economia/economia_rss.xml' },
        [pscustomobject]@{ nome = 'ANSA MONDO';    url = 'https://www.ansa.it/sito/notizie/mondo/mondo_rss.xml' },
        [pscustomobject]@{ nome = 'SOLE 24 ORE';   url = 'https://www.ilsole24ore.com/rss/italia.xml' },
        [pscustomobject]@{ nome = 'CORRIERE';      url = 'https://www.corriere.it/rss/homepage.xml' },
        [pscustomobject]@{ nome = 'CNBC MARKETS';  url = 'https://www.cnbc.com/id/100003114/device/rss/rss.html' },
        [pscustomobject]@{ nome = 'WSJ MARKETS';   url = 'https://feeds.a.dj.com/rss/RSSMarketsMain.xml' },
        [pscustomobject]@{ nome = 'GOOGLE NEWS';   url = 'https://news.google.com/rss?hl=it&gl=IT&ceid=IT:it' }
    )
    $d.simboli = @(
        [pscustomobject]@{ simbolo = 'FTSEMIB.MI'; nome = 'FTSE MIB' },
        [pscustomobject]@{ simbolo = '^GSPC';      nome = 'S&P 500' },
        [pscustomobject]@{ simbolo = '^IXIC';      nome = 'NASDAQ' },
        [pscustomobject]@{ simbolo = '^GDAXI';     nome = 'DAX' },
        [pscustomobject]@{ simbolo = 'EURUSD=X';   nome = 'EUR/USD' },
        [pscustomobject]@{ simbolo = 'BTC-USD';    nome = 'BITCOIN' },
        [pscustomobject]@{ simbolo = 'GC=F';       nome = 'ORO' },
        [pscustomobject]@{ simbolo = 'ENI.MI';     nome = 'ENI' },
        [pscustomobject]@{ simbolo = 'ENEL.MI';    nome = 'ENEL' },
        [pscustomobject]@{ simbolo = 'ISP.MI';     nome = 'INTESA' },
        [pscustomobject]@{ simbolo = 'UCG.MI';     nome = 'UNICREDIT' },
        [pscustomobject]@{ simbolo = 'NVDA';       nome = 'NVIDIA' }
    )
    $p = ''
    try { if ($Base) { $p = Join-Path $Base 'ui\ticker.json' } } catch { $p = '' }
    if ($p -and (Test-Path -LiteralPath $p)) {
        try {
            $j = Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($k in @('attivo','visibile','altezza','velocita','posizione','pausa_al_mouse','aggiorna_notizie_sec','aggiorna_quotazioni_sec','max_notizie')) {
                $v = $null
                try { $v = $j.$k } catch { $v = $null }
                if ($null -ne $v) { $d[$k] = $v }
            }
            if (@($j.feed).Count -gt 0)    { $d.feed = @($j.feed) }
            if (@($j.simboli).Count -gt 0) { $d.simboli = @($j.simboli) }
        } catch { }
    }
    return [pscustomobject]$d
}

function Get-ZapTickElencoFeed {
    param($Elenco)
    $out = New-Object System.Collections.ArrayList
    foreach ($f in @($Elenco)) {
        $url = ''
        $nome = ''
        if ($f -is [string]) { $url = [string]$f }
        else {
            try { $url = [string]$f.url } catch { $url = '' }
            try { $nome = [string]$f.nome } catch { $nome = '' }
        }
        $url = $url.Trim()
        if (-not $url) { continue }
        if (-not $nome) {
            try { $nome = ([System.Uri]$url).Host -replace '^www\.', '' } catch { $nome = 'NEWS' }
        }
        [void]$out.Add([pscustomobject]@{ Nome = $nome.ToUpper(); Url = $url })
    }
    return @($out)
}

function Get-ZapTickElencoSimboli {
    param($Elenco)
    $out = New-Object System.Collections.ArrayList
    foreach ($s in @($Elenco)) {
        $sim = ''
        $nome = ''
        if ($s -is [string]) { $sim = [string]$s }
        else {
            try { $sim = [string]$s.simbolo } catch { $sim = '' }
            try { $nome = [string]$s.nome } catch { $nome = '' }
        }
        $sim = $sim.Trim()
        if (-not $sim) { continue }
        if (-not $nome) { $nome = $sim }
        $url = 'https://query1.finance.yahoo.com/v8/finance/chart/' + [System.Uri]::EscapeDataString($sim) + '?interval=1d&range=1d'
        [void]$out.Add([pscustomobject]@{ Simbolo = $sim; Nome = $nome; Url = $url })
    }
    return @($out)
}

# --------------------------------------------------------------------------
#  TESTO: decodifica robusta (UTF-8, altrimenti Windows-1252)
# --------------------------------------------------------------------------
function Get-ZapTickTesto {
    param([byte[]]$Byte)
    if (-not $Byte -or $Byte.Length -eq 0) { return '' }
    try {
        $strict = [System.Text.UTF8Encoding]::new($false, $true)
        return $strict.GetString($Byte)
    } catch { }
    try { return [System.Text.Encoding]::GetEncoding(1252).GetString($Byte) } catch { }
    try { return [System.Text.Encoding]::UTF8.GetString($Byte) } catch { }
    return ''
}

function Limit-ZapTickTesto {
    param([string]$Testo, [int]$Max = 120)
    if (-not $Testo) { return '' }
    $t = ($Testo -replace '<[^>]+>', ' ')
    $t = ($t -replace '\s+', ' ').Trim()
    if ($t.Length -gt $Max) { $t = $t.Substring(0, $Max - 1).TrimEnd() + [string][char]0x2026 }
    return $t
}

# --------------------------------------------------------------------------
#  SCARICHI ASINCRONI
# --------------------------------------------------------------------------
function Start-ZapTickScarico {
    param([string]$Url, [string]$Tipo, $Extra)
    if (-not $Url) { return }
    try {
        $wc = New-Object System.Net.WebClient
        try { $wc.Headers.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ZAP-Ticker/9.3') } catch { }
        $task = $wc.DownloadDataTaskAsync($Url)
        $script:ZapTick.Scarichi += [pscustomobject]@{
            Url = $Url; Tipo = $Tipo; Extra = $Extra
            Task = $task; Client = $wc; Inizio = (Get-Date)
        }
    } catch {
        try { if ($wc) { $wc.Dispose() } } catch { }
    }
}

function Update-ZapTickScarichi {
    $t = $script:ZapTick
    if (@($t.Scarichi).Count -eq 0) { return }
    $resta = New-Object System.Collections.ArrayList
    $nuovo = $false
    foreach ($r in @($t.Scarichi)) {
        $fatto = $false
        try { $fatto = [bool]$r.Task.IsCompleted } catch { $fatto = $true }
        $scaduto = $false
        try { if (((Get-Date) - $r.Inizio).TotalSeconds -gt 25) { $scaduto = $true } } catch { }
        if (-not $fatto -and -not $scaduto) { [void]$resta.Add($r); continue }
        $byte = $null
        if ($fatto) {
            try { if ($r.Task.Status -eq 'RanToCompletion') { $byte = $r.Task.Result } } catch { $byte = $null }
        }
        try { $r.Client.Dispose() } catch { }
        if ($byte -and $byte.Length -gt 0) {
            if ($r.Tipo -eq 'feed') {
                if (Add-ZapTickNotizie -Byte $byte -Fonte $r.Extra) { $nuovo = $true }
            } else {
                if (Add-ZapTickQuotazione -Byte $byte -Voce $r.Extra) { $nuovo = $true }
            }
        }
    }
    $t.Scarichi = @($resta)
    if ($nuovo) { $t.Sporco = $true }
}

# --------------------------------------------------------------------------
#  PARSING
# --------------------------------------------------------------------------
function Add-ZapTickQuotazione {
    param([byte[]]$Byte, $Voce)
    try {
        $testo = Get-ZapTickTesto $Byte
        if (-not $testo) { return $false }
        $d = $testo | ConvertFrom-Json
        $ris = @($d.chart.result)
        if ($ris.Count -eq 0) { return $false }
        $m = $ris[0].meta
        if (-not $m) { return $false }
        $prezzo = 0.0
        try { $prezzo = [double]$m.regularMarketPrice } catch { $prezzo = 0.0 }
        if ($prezzo -le 0) { return $false }
        $prec = 0.0
        try { $prec = [double]$m.chartPreviousClose } catch { $prec = 0.0 }
        if ($prec -le 0) { try { $prec = [double]$m.previousClose } catch { $prec = 0.0 } }
        $pct = 0.0
        if ($prec -gt 0) { $pct = (($prezzo - $prec) / $prec) * 100.0 }

        # 4 decimali solo per i valori "da cambio" (sotto 5), altrimenti 2
        $prezzoTxt = ''
        if ([Math]::Abs($prezzo) -lt 5) { $prezzoTxt = $prezzo.ToString('N4') } else { $prezzoTxt = $prezzo.ToString('N2') }
        $varTxt = $pct.ToString('+0.00;-0.00;0.00') + '%'

        $sim = ''
        try { $sim = [string]$Voce.Simbolo } catch { $sim = '' }
        if (-not $sim) { $sim = [string]$m.symbol }

        $script:ZapTick.QuoteMap[$sim] = [pscustomobject]@{
            Simbolo        = $sim
            Nome           = [string]$Voce.Nome
            Prezzo         = $prezzoTxt
            Variazione     = [double]$pct
            VariazioneTesto = $varTxt
            Url            = 'https://finance.yahoo.com/quote/' + [System.Uri]::EscapeDataString($sim)
        }
        return $true
    } catch { return $false }
}

function Add-ZapTickNotizie {
    param([byte[]]$Byte, [string]$Fonte)
    try {
        $testo = Get-ZapTickTesto $Byte
        if (-not $testo) { return $false }
        $doc = New-Object System.Xml.XmlDocument
        try { $doc.XmlResolver = $null } catch { }
        $doc.LoadXml($testo)
        $nodi = @($doc.SelectNodes("//*[local-name()='item']"))
        if ($nodi.Count -eq 0) { $nodi = @($doc.SelectNodes("//*[local-name()='entry']")) }
        if ($nodi.Count -eq 0) { return $false }

        $prese = 0
        foreach ($n in $nodi) {
            if ($prese -ge 10) { break }
            $tn = $n.SelectSingleNode("*[local-name()='title']")
            if (-not $tn) { continue }
            $titolo = Limit-ZapTickTesto -Testo ([string]$tn.InnerText) -Max 128
            if (-not $titolo) { continue }

            $url = ''
            $ln = $n.SelectSingleNode("*[local-name()='link']")
            if ($ln) {
                if ([string]$ln.InnerText -and ([string]$ln.InnerText).Trim()) { $url = ([string]$ln.InnerText).Trim() }
                else { try { $url = [string]$ln.GetAttribute('href') } catch { $url = '' } }
            }
            $quando = Get-Date
            $dn = $n.SelectSingleNode("*[local-name()='pubDate']")
            if (-not $dn) { $dn = $n.SelectSingleNode("*[local-name()='date']") }
            if ($dn) {
                $grezzo = ([string]$dn.InnerText).Trim()
                if ($grezzo) {
                    try {
                        $quando = [datetime]::Parse($grezzo, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AdjustToUniversal).ToLocalTime()
                    } catch { }
                }
            }
            $fresca = $false
            try { if (((Get-Date) - $quando).TotalMinutes -lt 90) { $fresca = $true } } catch { }

            $script:ZapTick.NotizieGrezze = @($script:ZapTick.NotizieGrezze) + @(
                [pscustomobject]@{ Fonte = $Fonte; Titolo = $titolo; Url = $url; Quando = $quando; Nuovo = $fresca }
            )
            $prese++
        }

        # memoria sotto controllo: tengo solo le 240 notizie piu' recenti
        $tutte = @($script:ZapTick.NotizieGrezze)
        if ($tutte.Count -gt 240) {
            $script:ZapTick.NotizieGrezze = @($tutte[($tutte.Count - 240)..($tutte.Count - 1)])
        }
        return ($prese -gt 0)
    } catch { return $false }
}

function Get-ZapTickNotiziePulite {
    # toglie i doppioni e alterna le fonti (ANSA, CORRIERE, CNBC...) invece di
    # incollare 10 titoli dello stesso giornale di fila
    $t = $script:ZapTick
    $viste = @{}
    $perFonte = [ordered]@{}
    $ordine = New-Object System.Collections.ArrayList

    foreach ($n in @($t.NotizieGrezze)) {
        $k = ([string]$n.Titolo).ToLower()
        $k = ($k -replace '[^a-z0-9 ]', '').Trim()
        if ($k.Length -gt 55) { $k = $k.Substring(0, 55) }
        if (-not $k) { continue }
        if ($viste.ContainsKey($k)) { continue }
        $viste[$k] = 1
        $f = [string]$n.Fonte
        if (-not $perFonte.Contains($f)) {
            $perFonte[$f] = New-Object System.Collections.ArrayList
            [void]$ordine.Add($f)
        }
        [void]$perFonte[$f].Add($n)
    }

    $out = New-Object System.Collections.ArrayList
    $giro = 0
    $aggiunto = $true
    while ($aggiunto -and $out.Count -lt [int]$t.MaxNotizie) {
        $aggiunto = $false
        foreach ($f in $ordine) {
            $lista = $perFonte[$f]
            if ($giro -lt $lista.Count) {
                [void]$out.Add($lista[$giro])
                $aggiunto = $true
                if ($out.Count -ge [int]$t.MaxNotizie) { break }
            }
        }
        $giro++
    }
    return @($out)
}

# --------------------------------------------------------------------------
#  COSTRUZIONE DELLE VOCI DEL NASTRO
# --------------------------------------------------------------------------
function New-ZapTickTesto {
    param([string]$Testo, [double]$Dim = 13, [string]$Colore = '#FF12161C', [switch]$Grassetto, [double]$Dx = 0)
    $tb = New-Object System.Windows.Controls.TextBlock
    $tb.Text = $Testo
    $tb.FontSize = $Dim
    if ($Grassetto) { $tb.FontWeight = [System.Windows.FontWeights]::SemiBold } else { $tb.FontWeight = [System.Windows.FontWeights]::Normal }
    $tb.Foreground = Get-ZapTickPennello $Colore
    $tb.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
    $tb.Margin = [System.Windows.Thickness]::new(0, 0, $Dx, 0)
    return $tb
}

function Set-ZapTickClic {
    param($Elemento, [string]$Url)
    if (-not $Elemento -or -not $Url) { return }
    $Elemento.Tag = $Url
    $Elemento.Cursor = [System.Windows.Input.Cursors]::Hand
    $Elemento.ToolTip = 'Apri questo articolo nel browser'
    $Elemento.Add_MouseLeftButtonUp({
        param($mittente, $evento)
        $u = ''
        try { $u = [string]$mittente.Tag } catch { $u = '' }
        if (-not $u) { try { $u = [string]$this.Tag } catch { $u = '' } }
        if ($u) {
            try { Start-Process $u } catch { try { Start-Process -FilePath 'explorer.exe' -ArgumentList $u } catch { } }
        }
        try { $evento.Handled = $true } catch { }
    })
}

function New-ZapTickVoce {
    param($Spec)
    $t = $script:ZapTick
    $h = 48.0
    try { if ([double]$t.Altezza -ge 30) { $h = [double]$t.Altezza } } catch { }

    $bordo = New-Object System.Windows.Controls.Border
    $bordo.Background = Get-ZapTickPennello '#00FFFFFF'
    $bordo.Height = $h
    $bordo.Padding = [System.Windows.Thickness]::new(16, 0, 0, 0)
    $bordo.Cursor = [System.Windows.Input.Cursors]::Arrow

    $riga = New-Object System.Windows.Controls.StackPanel
    $riga.Orientation = [System.Windows.Controls.Orientation]::Horizontal
    $riga.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
    $bordo.Child = $riga

    if ($Spec.Tipo -eq 'quote') {
        $e = $Spec.Elemento
        $var = 0.0
        try { $var = [double]$e.Variazione } catch { $var = 0.0 }
        $colore = '#FF6B7280'
        $freccia = [string][char]0x2022
        if ($var -gt 0.004)      { $colore = '#FF0E8A4F'; $freccia = [string][char]0x25B2 }
        elseif ($var -lt -0.004) { $colore = '#FFB03A2E'; $freccia = [string][char]0x25BC }

        [void]$riga.Children.Add((New-ZapTickTesto -Testo ([string]$e.Nome) -Dim 12.5 -Colore '#FF12161C' -Grassetto -Dx 9))
        [void]$riga.Children.Add((New-ZapTickTesto -Testo ([string]$e.Prezzo) -Dim 13 -Colore '#FF12161C' -Grassetto -Dx 8))
        [void]$riga.Children.Add((New-ZapTickTesto -Testo ($freccia + ' ' + [string]$e.VariazioneTesto) -Dim 12.5 -Colore $colore -Grassetto))
        if ($e.Url) { Set-ZapTickClic -Elemento $bordo -Url ([string]$e.Url) }
    }
    else {
        $e = $Spec.Elemento
        $fonte = [string]$e.Fonte
        if ($fonte) {
            [void]$riga.Children.Add((New-ZapTickTesto -Testo $fonte.ToUpper() -Dim 9.8 -Colore '#FFB8912B' -Grassetto -Dx 9))
        }
        [void]$riga.Children.Add((New-ZapTickTesto -Testo ([string]$e.Titolo) -Dim 13 -Colore '#FF1A1F26'))
        if ($e.Nuovo) {
            $punto = New-Object System.Windows.Shapes.Ellipse
            $punto.Width = 6
            $punto.Height = 6
            $punto.Fill = Get-ZapTickPennello '#FFE0A020'
            $punto.Margin = [System.Windows.Thickness]::new(9, 0, 0, 0)
            $punto.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
            [void]$riga.Children.Add($punto)
        }
        if ($e.Url) { Set-ZapTickClic -Elemento $bordo -Url ([string]$e.Url) }
    }

    $sep = New-Object System.Windows.Shapes.Rectangle
    $sep.Width = 1
    $sep.Height = 18
    $sep.Fill = Get-ZapTickPennello '#FFE6DFC9'
    $sep.Margin = [System.Windows.Thickness]::new(18, 0, 0, 0)
    $sep.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
    [void]$riga.Children.Add($sep)

    return $bordo
}

function Build-ZapTickSpec {
    $t = $script:ZapTick
    $q = @($t.Quotazioni)
    $n = @($t.Notizie)
    $out = New-Object System.Collections.ArrayList
    $i = 0
    $j = 0
    while ($i -lt $q.Count -or $j -lt $n.Count) {
        if ($i -lt $q.Count) {
            [void]$out.Add([pscustomobject]@{ Tipo = 'quote'; Elemento = $q[$i] })
            $i++
        }
        for ($k = 0; $k -lt 2; $k++) {
            if ($j -lt $n.Count) {
                [void]$out.Add([pscustomobject]@{ Tipo = 'news'; Elemento = $n[$j] })
                $j++
            }
        }
    }
    return @($out)
}

function Update-ZapTickVista {
    param([switch]$Forza)
    $t = $script:ZapTick
    if (-not $t.Items -or -not $t.Clone) { return }
    if (-not $Forza -and -not $t.Sporco) { return }

    $t.Quotazioni = @(@($t.Simboli) | ForEach-Object {
        $s = $_
        if ($t.QuoteMap.ContainsKey($s.Simbolo)) { $t.QuoteMap[$s.Simbolo] }
    })
    $t.Notizie = @(Get-ZapTickNotiziePulite)

    $spec = @(Build-ZapTickSpec)
    if ($spec.Count -eq 0) {
        $spec = @([pscustomobject]@{ Tipo = 'news'; Elemento = [pscustomobject]@{
            Fonte = 'ZAP'; Titolo = 'Collegamento alle notizie in corso...'; Url = ''; Nuovo = $false } })
    }

    try { $t.Items.Children.Clear() } catch { }
    try { $t.Clone.Children.Clear() } catch { }
    foreach ($s in $spec) {
        $el = New-ZapTickVoce -Spec $s
        if ($el) { [void]$t.Items.Children.Add($el) }
    }
    foreach ($s in $spec) {
        $el = New-ZapTickVoce -Spec $s
        if ($el) { [void]$t.Clone.Children.Add($el) }
    }

    $t.Shift = 0.0
    try { $t.Traslazione.X = 0.0 } catch { }
    $t.Sporco = $false
    try {
        $t.Items.Measure([System.Windows.Size]::new([double]::PositiveInfinity, [double]::PositiveInfinity))
        $w = [double]$t.Items.DesiredSize.Width
        if ($w -le 1) { $w = 1 }
        $t.Larghezza = $w
    } catch { $t.Larghezza = 1.0 }
}

# --------------------------------------------------------------------------
#  TIMER
# --------------------------------------------------------------------------
function Step-ZapTick {
    $t = $script:ZapTick
    if (-not $t.Attivo) { return }

    Update-ZapTickScarichi

    $ora = Get-Date
    $pendQ = 0
    $pendF = 0
    foreach ($r in @($t.Scarichi)) {
        if ($r.Tipo -eq 'quote') { $pendQ++ } else { $pendF++ }
    }

    if ($pendQ -eq 0 -and (($ora - $t.UltimoQuote).TotalSeconds -ge [double]$t.IntervalloQuoteSec)) {
        $t.UltimoQuote = $ora
        foreach ($s in @($t.Simboli)) { Start-ZapTickScarico -Url $s.Url -Tipo 'quote' -Extra $s }
    }
    if ($pendF -eq 0 -and (($ora - $t.UltimoFeed).TotalSeconds -ge [double]$t.IntervalloFeedSec)) {
        $t.UltimoFeed = $ora
        foreach ($f in @($t.Feed)) { Start-ZapTickScarico -Url $f.Url -Tipo 'feed' -Extra $f.Nome }
    }

    Update-ZapTickVista
}

function Animate-ZapTick {
    $t = $script:ZapTick
    if (-not $t.Attivo) { return }

    $adesso = 0.0
    try { $adesso = $t.Cronometro.Elapsed.TotalMilliseconds } catch { $adesso = 0.0 }
    $dt = ($adesso - [double]$t.UltimoMs) / 1000.0
    if ($dt -le 0 -or $dt -gt 0.5) { $dt = 0.02 }
    $t.UltimoMs = $adesso

    if (-not $t.Pausa -and [double]$t.Larghezza -gt 0) {
        $t.Shift = [double]$t.Shift - ([double]$t.Velocita * $dt)
        if ($t.Shift -le (0.0 - [double]$t.Larghezza)) { $t.Shift = [double]$t.Shift + [double]$t.Larghezza }
        try { $t.Traslazione.X = [double]$t.Shift } catch { }
    }

    if ($t.Bollo) {
        try { $t.Bollo.Opacity = 0.35 + (0.65 * [Math]::Abs([Math]::Sin($adesso / 430.0))) } catch { }
    }

    try {
        if ($t.Orologio -and ((Get-Date).Second -ne [int]$t.Secondo)) {
            $ora = Get-Date
            $t.Secondo = $ora.Second
            $t.Orologio.Text = $ora.ToString('HH:mm:ss')
            if ($t.DataOra) {
                $cultura = [System.Globalization.CultureInfo]::GetCultureInfo('it-IT')
                $t.DataOra.Text = ($ora.ToString('ddd d MMM', $cultura)).ToUpper()
            }
        }
    } catch { }
}

# --------------------------------------------------------------------------
#  AVVIO / ARRESTO
# --------------------------------------------------------------------------
function Start-ZapTicker {
    param($Window, [string]$Base)
    try {
        if (-not $Window) { return }
        $t = $script:ZapTick
        if ($t.Attivo) { return }

        $cfg = Get-ZapTickConfig -Base $Base
        if (-not [bool]$cfg.attivo) { return }

        # v9.4: se il nastro era spento resta spento anche dopo il riavvio di ZAP.
        $t.Visibile = $true
        try { if ($null -ne $cfg.visibile) { $t.Visibile = [bool]$cfg.visibile } } catch { }
        if (-not $t.Visibile) {
            try { $b0 = $Window.FindName('TickerBar'); if ($b0) { $b0.Visibility = 'Collapsed' } } catch { }
            return
        }

        $t.Feed    = @(Get-ZapTickElencoFeed    -Elenco $cfg.feed)
        $t.Simboli = @(Get-ZapTickElencoSimboli -Elenco $cfg.simboli)
        $t.Velocita           = [double]$cfg.velocita
        $t.Altezza            = [double]$cfg.altezza
        $t.IntervalloFeedSec  = [int]$cfg.aggiorna_notizie_sec
        $t.IntervalloQuoteSec = [int]$cfg.aggiorna_quotazioni_sec
        $t.MaxNotizie         = [int]$cfg.max_notizie
        $t.PausaMouse         = [bool]$cfg.pausa_al_mouse

        $t.Barra         = $Window.FindName('TickerBar')
        $t.Binario       = $Window.FindName('TickerCanvas')
        $t.Items         = $Window.FindName('TickerItems')
        $t.Clone         = $Window.FindName('TickerClone')
        $t.Traslazione   = $Window.FindName('TickerShift')
        $t.Bollo         = $Window.FindName('TickerPulse')
        $t.Orologio      = $Window.FindName('TickerClock')
        $t.DataOra       = $Window.FindName('TickerDate')
        $t.RigaTicker    = $Window.FindName('RigaTicker')
        $t.RigaContenuto = $Window.FindName('RigaContenuto')
        $t.Area          = $Window.FindName('AreaContenuto')

        if (-not $t.Items -or -not $t.Clone -or -not $t.Barra) { return }

        if (-not $t.Traslazione) {
            try {
                $tf = $t.Items.Parent.RenderTransform
                if ($tf -is [System.Windows.Media.TranslateTransform]) { $t.Traslazione = $tf }
            } catch { }
        }
        if (-not $t.Traslazione) {
            try {
                $tf = New-Object System.Windows.Media.TranslateTransform
                $t.Items.Parent.RenderTransform = $tf
                $t.Traslazione = $tf
            } catch { }
        }

        # altezza e posizione (alto / basso) dalla configurazione
        try {
            if ([double]$t.Altezza -ge 34 -and [double]$t.Altezza -le 96) {
                $t.Barra.Height = [double]$t.Altezza
                $t.Items.Height = [double]$t.Altezza
                $t.Clone.Height = [double]$t.Altezza
            }
        } catch { }
        try {
            if ([string]$cfg.posizione -eq 'basso' -and $t.Area) {
                [void][System.Windows.Controls.Grid]::SetRow($t.Barra, 2)
                [void][System.Windows.Controls.Grid]::SetRow($t.Area, 1)
                if ($t.RigaTicker)    { $t.RigaTicker.Height = [System.Windows.GridLength]::Auto }
                if ($t.RigaContenuto) { $t.RigaContenuto.Height = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star) }
            }
        } catch { }

        # TLS 1.2: senza questo, su Windows vecchi i download falliscono
        try { [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12 } catch { }

        # pausa col mouse sopra
        if ($t.PausaMouse -and -not $t.HandlersFatti) {
            $t.HandlersFatti = $true
            try { $t.Barra.Add_MouseEnter({ try { $script:ZapTick.Pausa = $true } catch { } }) } catch { }
            try { $t.Barra.Add_MouseLeave({ try { $script:ZapTick.Pausa = $false } catch { } }) } catch { }
        }

        $t.Cronometro = [System.Diagnostics.Stopwatch]::StartNew()
        $t.UltimoMs = 0.0

        $t.Timer = New-Object System.Windows.Threading.DispatcherTimer
        $t.Timer.Interval = [TimeSpan]::FromMilliseconds(20)
        $t.Timer.Add_Tick({ try { Animate-ZapTick } catch { } })
        $t.Timer.Start()

        $t.Pump = New-Object System.Windows.Threading.DispatcherTimer
        $t.Pump.Interval = [TimeSpan]::FromMilliseconds(500)
        $t.Pump.Add_Tick({ try { Step-ZapTick } catch { } })
        $t.Pump.Start()

        $t.Attivo = $true

        Update-ZapTickVista -Forza
        Step-ZapTick

        try { $Window.Add_Closed({ try { Stop-ZapTicker } catch { } }) } catch { }
        try { Write-Fase ('nastro notizie attivo: ' + @($t.Feed).Count + ' feed, ' + @($t.Simboli).Count + ' quotazioni') } catch { }
    } catch {
        try { Write-Fase ('nastro notizie NON avviato: ' + $_.Exception.Message) } catch { }
    }
}

function Stop-ZapTicker {
    $t = $script:ZapTick
    $t.Attivo = $false
    try { if ($t.Timer) { $t.Timer.Stop() } } catch { }
    try { if ($t.Pump)  { $t.Pump.Stop() } } catch { }
    foreach ($r in @($t.Scarichi)) { try { $r.Client.Dispose() } catch { } }
    $t.Scarichi = @()
}

# --------------------------------------------------------------------------
# v9.4 -- NASTRO ON/OFF
#   tasto tondo accanto alla foto  |  F8  |  /nastro  |  strumento 'nastro_notizie'
#   Quando e' nascosto il motore viene FERMATO (niente rete, niente CPU) e la
#   scelta resta scritta in ui\ticker.json, cosi' vale anche al prossimo avvio.
# --------------------------------------------------------------------------

function Get-ZapTickFileConfig {
    param([string]$Base)
    if (-not $Base) { try { $Base = (Get-Location).Path } catch { } }
    return (Join-Path $Base 'ui\ticker.json')
}

function Save-ZapTickVisibile {
    param([string]$Base, [bool]$Visibile)
    try {
        $f = Get-ZapTickFileConfig $Base
        if (-not (Test-Path -LiteralPath $f)) { return }
        $obj = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
        $obj | Add-Member -NotePropertyName 'visibile' -NotePropertyValue ([bool]$Visibile) -Force
        $json = $obj | ConvertTo-Json -Depth 8
        [System.IO.File]::WriteAllText($f, $json, (New-Object System.Text.UTF8Encoding($false)))
    } catch { }
}

function Update-ZapTickTasto {
    param($Window, [bool]$Visibile)
    try {
        if (-not $Window) { return }
        $lbl = $Window.FindName('BtnNastroText')
        if ($lbl) {
            if ($Visibile) { $lbl.Text = "nastro`nON" } else { $lbl.Text = "nastro`nOFF" }
        }
        $btn = $Window.FindName('BtnNastro')
        if ($btn) {
            if ($Visibile) { $btn.Opacity = 1.0 } else { $btn.Opacity = 0.55 }
        }
    } catch { }
}

function Set-ZapTickerVisibile {
    param($Window, [bool]$Visibile, [string]$Base, [switch]$NoSave)
    $t = $script:ZapTick
    $t.Visibile = [bool]$Visibile

    # 1) salvo PRIMA: cosi' Start-ZapTicker legge il valore nuovo
    if (-not $NoSave) { Save-ZapTickVisibile -Base $Base -Visibile $Visibile }

    # 2) barra grafica
    try {
        if ($Window) {
            $bar = $Window.FindName('TickerBar')
            if ($bar) {
                if ($Visibile) { $bar.Visibility = 'Visible' } else { $bar.Visibility = 'Collapsed' }
            }
        }
    } catch { }

    # 3) motore: spento = nessun download, nessun timer
    if ($Visibile) {
        try { if (-not $t.Attivo -and $Window) { Start-ZapTicker -Window $Window -Base $Base } } catch { }
    } else {
        try { Stop-ZapTicker } catch { }
    }

    Update-ZapTickTasto -Window $Window -Visibile $Visibile
    try { Write-Fase ('nastro notizie: ' + $(if ($Visibile) { 'VISIBILE' } else { 'NASCOSTO (motore fermo)' })) } catch { }
    return [bool]$Visibile
}

function Toggle-ZapTicker {
    param($Window, [string]$Base)
    $nuovo = -not [bool]$script:ZapTick.Visibile
    return (Set-ZapTickerVisibile -Window $Window -Base $Base -Visibile $nuovo)
}
