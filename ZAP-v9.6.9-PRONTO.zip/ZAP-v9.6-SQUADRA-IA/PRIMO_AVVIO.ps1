﻿# PRIMO_AVVIO.ps1 -- CONFIGURAZIONE AUTOMATICA DI ZAP v9 (un solo doppio clic).
#
# Fa da solo, in ordine, tutto quello che prima si doveva leggere nel LEGGIMI:
#   1. copia di sicurezza di config.json (prima di toccarlo)
#   2. completa config.json con le sezioni nuove (ezappero, traccia, verita, documenti, gmail)
#      senza MAI sovrascrivere quello che hai gia' scritto
#   3. crea le cartelle che servono (Ezappero con tutta la sua struttura, appunti, memory, logs...)
#   4. verifica l'integrita della memoria e, se e' rotta, la ripristina dallo specchio
#   5. fa la prima copia specchio fuori dal progetto
#   6. applica la protezione (attributi sempre; ACL che nega la cancellazione se sei admin)
#   7. registra le automazioni pianificate (verifica memoria, backup, riepilogo, promemoria)
#   8. controlla che la chiave DeepSeek risponda (senza stamparla)
#   9. controlla la sintassi di tutti gli script del progetto
#  10. (se lo chiedi) ti fa compilare dati fatture e indirizzo Gmail
#  11. scrive il rapporto in Ezappero\primo-avvio.log e un evento nel registro
#
# E' IDEMPOTENTE: puoi rieseguirlo quante volte vuoi, non duplica niente e non cancella nulla.
#
# Uso normale:      doppio clic su PRIMO_AVVIO.bat  (chiede i privilegi una volta)
# Uso da terminale: powershell -ExecutionPolicy Bypass -File .\PRIMO_AVVIO.ps1
# Solo controllo:   powershell -ExecutionPolicy Bypass -File .\PRIMO_AVVIO.ps1 -SoloVerifica
# Silenzioso:       ... -NonInterattivo   (usato da ZAP stesso al primo avvio)

[CmdletBinding()]
param(
    [string]$Cartella = '',
    [switch]$ConAdmin,
    [switch]$Elevato,
    [switch]$NonInterattivo,
    [switch]$SoloVerifica,
    [switch]$NoTask,
    [switch]$NoRete,
    [switch]$Silenzioso,
    [switch]$Avvia
)

$script:Esiti = New-Object System.Collections.ArrayList
$script:SuWindows = $true
$script:Silenzioso = [bool]$Silenzioso
$script:BaseEff = ''
try { if (Test-Path variable:IsWindows) { $script:SuWindows = [bool]$IsWindows } } catch { }

# ---------------------------------------------------------------------------
# Utilita' di base
# ---------------------------------------------------------------------------

function Write-Passo {
    param([string]$Titolo)
    if (-not $script:Silenzioso) {
        Write-Host ''
        Write-Host ('==> ' + $Titolo) -ForegroundColor Cyan
    }
}

function Add-Esito {
    param([string]$Nome, [string]$Stato, [string]$Dettaglio = '')
    [void]$script:Esiti.Add([pscustomobject]@{ Nome = $Nome; Stato = $Stato; Dettaglio = $Dettaglio })
    if (-not $script:Silenzioso) {
        $colore = 'Gray'
        if ($Stato -eq 'OK') { $colore = 'Green' }
        elseif ($Stato -eq 'ATTENZIONE') { $colore = 'Yellow' }
        elseif ($Stato -eq 'ERRORE') { $colore = 'Red' }
        $riga = '  [' + $Stato + '] ' + $Nome
        if ($Dettaglio) { $riga = $riga + '  -- ' + $Dettaglio }
        Write-Host $riga -ForegroundColor $colore
    }
}

function Test-SonoAdmin {
    try {
        if (-not $script:SuWindows) { return $false }
        $identita = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $principale = New-Object System.Security.Principal.WindowsPrincipal($identita)
        return $principale.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function ConvertTo-HashtableProfondo {
    # Serve per modificare config.json senza perdere nulla.
    param($Oggetto)
    if ($null -eq $Oggetto) { return $null }
    if ($Oggetto -is [string]) { return $Oggetto }
    if ($Oggetto -is [System.Collections.IDictionary]) {
        $h = @{}
        foreach ($k in @($Oggetto.Keys)) { $h[$k] = ConvertTo-HashtableProfondo $Oggetto[$k] }
        return $h
    }
    if ($Oggetto -is [pscustomobject]) {
        $h = @{}
        foreach ($p in @($Oggetto.PSObject.Properties)) { $h[$p.Name] = ConvertTo-HashtableProfondo $p.Value }
        return $h
    }
    if ($Oggetto -is [System.Collections.IEnumerable]) {
        $a = @()
        foreach ($x in $Oggetto) { $a += ,(ConvertTo-HashtableProfondo $x) }
        return $a
    }
    return $Oggetto
}

function Save-JsonNoBom {
    param([string]$Percorso, $Oggetto, [int]$Profondita = 12)
    $testo = (ConvertTo-Json -InputObject $Oggetto -Depth $Profondita)
    # controllo di sicurezza: se il JSON prodotto non si rilegge, NON scrivo
    $null = $testo | ConvertFrom-Json
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Percorso, $testo, $enc)
    return $testo
}

function Get-SezioniNuove {
    # I valori di default della v9 (gli stessi che usa ZAP se mancano).
    return @{
        ezappero = @{
            cartella = 'Ezappero'; specchio = ''; proteggi = $true
            snapshot_ore = 6; max_righe_prompt = 18
        }
        traccia = @{ attiva = $false; intervallo = 15; scatti = $false; ogni_scatti = 120 }
        verita  = @{ attivo = $true; controllo = $true; severita = 'media'; max_avvisi = 3 }
        documenti = @{
            mittente = @{ nome = ''; piva = ''; cf = ''; indirizzo = ''; cap = ''; citta = ''; email = ''; telefono = ''; iban = '' }
            iva_default = 22
            prefisso_fattura = 'FATT'
            prefisso_busta = 'BUSTA'
            busta = @{
                inps_dipendente = 9.19
                irpef = @(@(28000, 23), @(50000, 35), @(1000000000, 43))
                detrazione_mensile = 0
            }
        }
        gmail = @{
            mittente = ''; nome = ''; password = ''
            smtp = 'smtp.gmail.com'; porta = 587; ssl = $true
            firma = ''; solo_bozze = $true
        }
    }
}

# ---------------------------------------------------------------------------
# Passi della configurazione
# ---------------------------------------------------------------------------

function Step-Config {
    param([string]$Base)
    $p = Join-Path $Base 'config.json'
    if (-not (Test-Path -LiteralPath $p)) {
        Add-Esito 'config.json' 'ERRORE' 'file assente: non posso configurare ZAP'
        return $null
    }
    $originale = $null
    try { $originale = Get-Content -LiteralPath $p -Raw -Encoding UTF8 } catch {
        Add-Esito 'config.json' 'ERRORE' ('illeggibile: ' + $_.Exception.Message)
        return $null
    }
    $cfg = $null
    try { $cfg = ConvertTo-HashtableProfondo ($originale | ConvertFrom-Json) } catch {
        Add-Esito 'config.json' 'ERRORE' 'JSON non valido: non tocco niente'
        return $null
    }
    if (-not $cfg) { $cfg = @{} }

    # copia di sicurezza prima di qualsiasi modifica
    try {
        $bdir = Join-Path (Join-Path $Base 'Ezappero') 'backup-config'
        if (-not (Test-Path -LiteralPath $bdir)) { New-Item -ItemType Directory -Path $bdir -Force | Out-Null }
        $bkp = Join-Path $bdir ('config-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($bkp, $originale, $enc)
        Add-Esito 'Copia di sicurezza di config.json' 'OK' (Split-Path -Leaf $bkp)
    } catch {
        Add-Esito 'Copia di sicurezza di config.json' 'ATTENZIONE' $_.Exception.Message
    }

    $nuove = Get-SezioniNuove
    $aggiunte = @()
    foreach ($sez in @('ezappero', 'traccia', 'verita', 'documenti', 'gmail')) {
        if (-not $cfg.ContainsKey($sez) -or $null -eq $cfg[$sez]) {
            $cfg[$sez] = $nuove[$sez]
            $aggiunte += $sez
        } elseif ($cfg[$sez] -is [System.Collections.IDictionary]) {
            # se la sezione esiste ma mancano dei campi, li completo senza toccare i tuoi
            foreach ($campo in @($nuove[$sez].Keys)) {
                if (-not $cfg[$sez].ContainsKey($campo)) {
                    $cfg[$sez][$campo] = $nuove[$sez][$campo]
                    $aggiunte += ($sez + '.' + $campo)
                }
            }
        }
    }

    # DeepSeek: abilitato e con un modello reale
    try {
        if (-not $cfg.ContainsKey('provider_ai') -or -not $cfg['provider_ai']) { $cfg['provider_ai'] = @{} }
        if (-not $cfg['provider_ai'].ContainsKey('deepseek')) { $cfg['provider_ai']['deepseek'] = @{} }
        $ds = $cfg['provider_ai']['deepseek']
        if (-not $ds.ContainsKey('abilitato') -or $ds['abilitato'] -eq $false) { $ds['abilitato'] = $true; $aggiunte += 'provider_ai.deepseek.abilitato' }
        if (-not [string]$ds['modello']) { $ds['modello'] = 'deepseek-v4-pro'; $aggiunte += 'provider_ai.deepseek.modello' }
        if (-not $ds.ContainsKey('compiti') -or -not $ds['compiti']) { $ds['compiti'] = @('codice', 'testo', 'veloce'); $aggiunte += 'provider_ai.deepseek.compiti' }
    } catch { }

    if ($aggiunte.Count -eq 0) {
        Add-Esito 'config.json' 'OK' 'gia completo, nessuna modifica'
        return $cfg
    }
    try {
        [void](Save-JsonNoBom $p $cfg)
        Add-Esito 'config.json completato' 'OK' (($aggiunte | Select-Object -First 4) -join ', ') + $(if ($aggiunte.Count -gt 4) { ' (+altri)' } else { '' })
    } catch {
        Add-Esito 'config.json completato' 'ERRORE' $_.Exception.Message
    }
    return $cfg
}

function Step-Cartelle {
    param([string]$Base)
    # percorsi costruiti con Join-Path annidato: funziona su Windows e anche in prova su altri sistemi
    $cartelle = @(
        @('appunti'),
        @('memory'),
        @('logs'),
        @('programmi'),
        @('dati'),
        @('dati', 'tasks')
    )
    $creati = 0
    foreach ($c in $cartelle) {
        $p = $Base
        foreach ($pezzo in $c) { $p = Join-Path $p $pezzo }
        if (-not (Test-Path -LiteralPath $p)) {
            try { New-Item -ItemType Directory -Path $p -Force | Out-Null; $creati++ } catch { }
        }
    }
    # file che devono esistere (altrimenti alcune funzioni si lamentano)
    foreach ($f in @(@{ p = @('memory', 'notes.md'); c = '# memoria storica di ZAP (append-only)' },
                     @{ p = @('appunti', 'appunti.txt'); c = '' })) {
        $full = $Base
        foreach ($pezzo in $f.p) { $full = Join-Path $full $pezzo }
        if (-not (Test-Path -LiteralPath $full)) {
            try {
                $d = Split-Path -Parent $full
                if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
                $enc = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($full, $f.c, $enc)
                $creati++
            } catch { }
        }
    }
    Add-Esito 'Cartelle di lavoro' 'OK' ("$creati elementi creati")
}

function Step-Memoria {
    param([string]$Base, $Cfg)
    $sync = @{ Base = $Base; Config = $Cfg }
    try { [void](Initialize-Ezappero $sync) } catch {
        Add-Esito 'Struttura Ezappero' 'ERRORE' $_.Exception.Message
        return $sync
    }
    $st = Get-EzapperoStato $sync
    Add-Esito 'Struttura Ezappero' 'OK' ('cartella: ' + $st.cartella)

    if ($st.eventi -gt 0) {
        $rep = Test-ZapIntegrita $sync
        if ($rep.ok) {
            Add-Esito 'Integrita memoria' 'OK' $rep.messaggio
        } else {
            $fix = Repair-ZapDaSpecchio $sync
            Add-Esito 'Integrita memoria' 'ATTENZIONE' ('trovata rotta -> ' + $fix)
            $rep2 = Test-ZapIntegrita $sync
            if (-not $rep2.ok) { Add-Esito 'Integrita memoria' 'ERRORE' 'ripristino non riuscito: controlla lo specchio' }
        }
    } else {
        Add-Esito 'Integrita memoria' 'OK' 'registro nuovo (primo avvio)'
    }
    return $sync
}

function Step-Specchio {
    param($Sync)
    try {
        $msg = Sync-EzapperoSpecchio $Sync
        Add-Esito 'Copia specchio (fuori dal progetto)' 'OK' $msg
    } catch {
        Add-Esito 'Copia specchio (fuori dal progetto)' 'ATTENZIONE' $_.Exception.Message
    }
}

function Step-Protezione {
    param($Sync, [bool]$SonoAdmin)
    if (-not $script:SuWindows) { Add-Esito 'Protezione Ezappero' 'ATTENZIONE' 'solo Windows: qui non si applica'; return }
    if (-not $SonoAdmin) {
        Add-Esito 'Protezione Ezappero' 'ATTENZIONE' 'serve amministratore: rilancia PRIMO_AVVIO.bat'
        return
    }
    try {
        $msg = Protect-Ezappero $Sync
        $prima = ([string]$msg).Split("`n")[0]
        Add-Esito 'Protezione Ezappero' 'OK' $prima
    } catch {
        Add-Esito 'Protezione Ezappero' 'ATTENZIONE' $_.Exception.Message
    }
}

function Register-ZapTask {
    # Registra un'attivita' pianificata. Prima con l'API di Windows, poi con schtasks.
    param([string]$Base, [string]$Nome, [string]$Comando, [string]$Classe = 'DAILY', [string]$Orario = '08:00', [int]$GiornoSett = 0)
    $cli = Join-Path $Base 'ZAP-CLI.ps1'
    $argomenti = '-NoProfile -ExecutionPolicy Bypass -File "' + $cli + '" ' + $Comando

    # 1) API nativa (nessun problema di virgolette)
    try {
        $svc = New-Object -ComObject Schedule.Service
        $svc.Connect()
        $cartella = $null
        try { $cartella = $svc.GetFolder('\ZAP') } catch {
            try { $cartella = $svc.GetFolder('\').CreateFolder('ZAP') } catch { $cartella = $svc.GetFolder('\') }
        }
        $def = $svc.NewTask(0)
        $def.RegistrationInfo.Description = 'ZAP v9 - ' + $Nome
        $def.Settings.Enabled = $true
        $def.Settings.StartWhenAvailable = $true
        $def.Settings.DisallowStartIfOnBatteries = $false
        $def.Settings.StopIfGoingOnBatteries = $false
        $def.Settings.ExecutionTimeLimit = 'PT10M'
        if ($Classe -eq 'WEEKLY') {
            $trg = $def.Triggers.Create(3)
            $trg.DaysOfWeek = $GiornoSett
        } else {
            $trg = $def.Triggers.Create(2)
            $trg.DaysInterval = 1
        }
        $trg.StartBoundary = (Get-Date -Format 'yyyy-MM-dd') + 'T' + $Orario + ':00'
        $az = $def.Actions.Create(0)
        $az.Path = 'powershell.exe'
        $az.Arguments = $argomenti
        $az.WorkingDirectory = $Base
        $null = $cartella.RegisterTaskDefinition($Nome, $def, 6, $null, $null, 3)
        return 'API Windows'
    } catch { }

    # 2) ripiego: un .cmd nella cartella del progetto + schtasks
    try {
        $dir = Join-Path (Join-Path $Base 'dati') 'tasks'
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $cmd = Join-Path $dir ($Nome + '.cmd')
        $contenuto = '@echo off' + "`r`n" + 'powershell.exe ' + $argomenti + "`r`n"
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($cmd, $contenuto, $enc)
        $tr = '"' + $cmd + '"'
        if ($Classe -eq 'WEEKLY') {
            $giornoTxt = 'FRI'
            if ($GiornoSett -eq 2) { $giornoTxt = 'MON' } elseif ($GiornoSett -eq 1) { $giornoTxt = 'SUN' }
            & schtasks.exe /Create /TN ('ZAP\' + $Nome) /TR $tr /SC WEEKLY /D $giornoTxt /ST $Orario /F | Out-Null
        } else {
            & schtasks.exe /Create /TN ('ZAP\' + $Nome) /TR $tr /SC DAILY /ST $Orario /F | Out-Null
        }
        if ($LASTEXITCODE -eq 0) { return 'schtasks' }
    } catch { }
    return ''
}

function Step-Automazioni {
    param([string]$Base, [bool]$SonoAdmin)
    if (-not $script:SuWindows) { Add-Esito 'Automazioni pianificate' 'ATTENZIONE' 'solo Windows: qui non si applicano'; return }
    if ($script:OpzNoTask) { Add-Esito 'Automazioni pianificate' 'ATTENZIONE' 'saltate (-NoTask)'; return }
    if (-not $SonoAdmin) { Add-Esito 'Automazioni pianificate' 'ATTENZIONE' 'serve amministratore: rilancia PRIMO_AVVIO.bat'; return }

    $elenco = @(
        @{ n = 'verifica_memoria';   c = 'memoria-integra';   t = 'DAILY';  o = '08:00'; d = 0 },
        @{ n = 'riepilogo_giornata'; c = 'riepilogo-giornata'; t = 'DAILY';  o = '19:00'; d = 0 },
        @{ n = 'backup_ezappero';    c = 'backup-ezappero';   t = 'DAILY';  o = '20:00'; d = 0 },
        @{ n = 'promemoria_fatture'; c = 'fatture-settimana'; t = 'WEEKLY'; o = '17:30'; d = 32 }
    )
    $fatti = 0; $modo = ''
    foreach ($a in $elenco) {
        $r = Register-ZapTask -Base $Base -Nome $a.n -Comando $a.c -Classe $a.t -Orario $a.o -GiornoSett $a.d
        if ($r) { $fatti++; $modo = $r }
    }
    if ($fatti -gt 0) {
        Add-Esito 'Automazioni pianificate' 'OK' ("$fatti create (via $modo): verifica memoria 08:00, riepilogo 19:00, backup 20:00, promemoria venerdi 17:30")
    } else {
        Add-Esito 'Automazioni pianificate' 'ATTENZIONE' 'non sono riuscito a crearle (permessi?)'
    }
}

function Step-ChiaveDeepSeek {
    param([string]$Base, $Cfg)
    if ($script:OpzNoRete) { Add-Esito 'Collegamento DeepSeek' 'ATTENZIONE' 'controllo rete saltato (-NoRete)'; return }

    $chiave = ''
    try {
        $lp = Join-Path $Base 'config.local.json'
        if (Test-Path -LiteralPath $lp) {
            $loc = Get-Content -LiteralPath $lp -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($loc.provider_ai -and $loc.provider_ai.deepseek) { $chiave = [string]$loc.provider_ai.deepseek.chiave }
        }
    } catch { }
    if (-not $chiave) {
        try { $chiave = [string]$Cfg.provider_ai.deepseek.chiave } catch { }
    }
    if (-not $chiave) {
        Add-Esito 'Collegamento DeepSeek' 'ATTENZIONE' 'nessuna chiave in config.local.json'
        return
    }
    try {
        $h = @{ Authorization = 'Bearer ' + $chiave }
        $r = Invoke-RestMethod -Uri 'https://api.deepseek.com/models' -Headers $h -Method Get -TimeoutSec 12
        $modelli = @($r.data | ForEach-Object { [string]$_.id })
        $haPro = ($modelli -contains 'deepseek-v4-pro')
        if ($haPro) {
            Add-Esito 'Collegamento DeepSeek' 'OK' ('chiave valida; modelli: ' + ($modelli -join ', '))
        } else {
            Add-Esito 'Collegamento DeepSeek' 'ATTENZIONE' ('chiave valida ma il modello deepseek-v4-pro non risulta. Disponibili: ' + ($modelli -join ', '))
        }
    } catch {
        $m = $_.Exception.Message
        if ($m.Length -gt 160) { $m = $m.Substring(0, 160) + '...' }
        Add-Esito 'Collegamento DeepSeek' 'ERRORE' ('la chiave non risponde: ' + $m)
    }
}

function Step-Sintassi {
    param([string]$Base)
    $file = @(Get-ChildItem -LiteralPath $Base -Recurse -Filter *.ps1 -ErrorAction SilentlyContinue)
    $rotti = 0
    foreach ($f in $file) {
        $tok = $null; $err = $null
        try {
            [void][System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tok, [ref]$err)
            if ($err -and $err.Count -gt 0) { $rotti++ }
        } catch { $rotti++ }
    }
    if ($rotti -eq 0) {
        Add-Esito 'Sintassi degli script' 'OK' ($file.Count.ToString() + ' file compilano')
    } else {
        Add-Esito 'Sintassi degli script' 'ERRORE' ($rotti.ToString() + ' file con errori su ' + $file.Count.ToString())
    }
}

function Step-Guidata {
    param([string]$Base, $Cfg)
    if ($script:OpzNonInterattivo -or $script:Silenzioso) { return $null }
    if (-not $Cfg) { return $null }
    Write-Passo 'Dati per i documenti (facoltativo)'
    Write-Host '  Premi INVIO per lasciare vuoto e compilare piu avanti in config.json.' -ForegroundColor DarkGray
    $fai = Read-Host '  Vuoi compilare adesso i dati per le fatture e la posta? (s/N)'
    if ($fai -notmatch '^(s|si|si|y|yes)$') {
        Add-Esito 'Dati fatture e posta' 'ATTENZIONE' 'saltato: compilali quando vuoi in config.json'
        return $Cfg
    }
    $m = @{}
    try { $m = $Cfg['documenti']['mittente'] } catch { $m = @{} }
    $campi = @(
        @{ k = 'nome';      t = 'Nome o ragione sociale' },
        @{ k = 'piva';      t = 'Partita IVA' },
        @{ k = 'cf';        t = 'Codice fiscale' },
        @{ k = 'indirizzo'; t = 'Indirizzo' },
        @{ k = 'cap';       t = 'CAP' },
        @{ k = 'citta';     t = 'Citta' },
        @{ k = 'iban';      t = 'IBAN' },
        @{ k = 'email';     t = 'Email' },
        @{ k = 'telefono';  t = 'Telefono' }
    )
    foreach ($c in $campi) {
        $attuale = ''
        try { $attuale = [string]$m[$c.k] } catch { }
        $suggerimento = ''
        if ($attuale) { $suggerimento = ' [' + $attuale + ']' }
        $v = Read-Host ('  ' + $c.t + $suggerimento)
        if ($v) { $m[$c.k] = $v }
    }
    if (-not $Cfg.ContainsKey('documenti')) { $Cfg['documenti'] = @{} }
    $Cfg['documenti']['mittente'] = $m

    $g = @{}
    try { $g = $Cfg['gmail'] } catch { $g = @{} }
    $ind = Read-Host '  Indirizzo Gmail per la posta (INVIO per saltare)'
    if ($ind) { $g['mittente'] = $ind }
    $nm = Read-Host '  Nome che compare nelle email (INVIO per saltare)'
    if ($nm) { $g['nome'] = $nm }
    $Cfg['gmail'] = $g

    try {
        [void](Save-JsonNoBom (Join-Path $Base 'config.json') $Cfg)
        Add-Esito 'Dati fatture e posta' 'OK' 'salvati in config.json'
    } catch {
        Add-Esito 'Dati fatture e posta' 'ERRORE' $_.Exception.Message
    }
    return $Cfg
}

# ---------------------------------------------------------------------------
# Motore
# ---------------------------------------------------------------------------

function Start-PrimoAvvio {
    # Parametri ESPLICITI: cosi' la funzione funziona sia richiamata dal file sia
    # richiamata da ZAP (che la chiama in modo silenzioso al primo avvio).
    param(
        [string]$Cartella = '',
        [switch]$NonInterattivo,
        [switch]$Silenzioso,
        [switch]$NoTask,
        [switch]$NoRete,
        [switch]$SoloVerifica,
        [switch]$Avvia
    )

    # le funzioni Step-* leggono queste variabili di script
    $script:OpzNonInterattivo = [bool]$NonInterattivo
    $script:OpzSilenzioso     = [bool]$Silenzioso
    $script:OpzNoTask         = [bool]$NoTask
    $script:OpzNoRete         = [bool]$NoRete
    $script:OpzSoloVerifica   = [bool]$SoloVerifica
    $script:OpzAvvia          = [bool]$Avvia
    $script:Silenzioso        = [bool]$Silenzioso

    $script:Esiti.Clear()
    if (-not $Cartella) { $Cartella = $PSScriptRoot }
    if (-not $Cartella) { $Cartella = (Get-Location).Path }
    $script:BaseEff = $Cartella

    if (-not $script:Silenzioso) {
        Write-Host ''
        Write-Host '============================================================' -ForegroundColor Yellow
        Write-Host '  ZAP v9 -- PRIMO AVVIO: configurazione automatica' -ForegroundColor Yellow
        Write-Host '============================================================' -ForegroundColor Yellow
        Write-Host ('  cartella: ' + $Cartella)
    }

    $sonoAdmin = Test-SonoAdmin

    # --- moduli ---
    try {
        if (-not (Get-Command Get-EzapperoDir -ErrorAction SilentlyContinue)) {
            $mod = Join-Path (Join-Path $Cartella 'brain') 'memoria_v9.ps1'
            if (Test-Path -LiteralPath $mod) { . $mod }
        }
        if (-not (Get-Command Get-PsLibreriaDir -ErrorAction SilentlyContinue)) {
            $mod = Join-Path (Join-Path $Cartella 'brain') 'ps_libreria.ps1'
            if (Test-Path -LiteralPath $mod) { . $mod }
        }
    } catch {
        Add-Esito 'Caricamento moduli' 'ERRORE' $_.Exception.Message
    }

    Write-Passo 'Configurazione'
    $cfg = Step-Config -Base $Cartella

    if ($script:OpzSoloVerifica) {
        Write-Passo 'Controlli (solo verifica: non modifico niente)'
        if ($cfg) {
            $syncV = @{ Base = $Cartella; Config = $cfg }
            try {
                $stv = Get-EzapperoStato $syncV
                Add-Esito 'Stato memoria' 'OK' ('eventi: ' + $stv.eventi + ' - ' + $stv.messaggio)
            } catch { }
        }
        Step-ChiaveDeepSeek -Base $Cartella -Cfg $cfg
        Step-Sintassi -Base $Cartella
        Show-Rapporto -Base $Cartella
        return 0
    }

    Write-Passo 'Cartelle di lavoro'
    Step-Cartelle -Base $Cartella

    Write-Passo 'Memoria indelebile (Ezappero)'
    $sync = Step-Memoria -Base $Cartella -Cfg $cfg

    Write-Passo 'Copia fuori dal progetto'
    Step-Specchio -Sync $sync

    Write-Passo 'Protezione della memoria'
    Step-Protezione -Sync $sync -SonoAdmin $sonoAdmin

    Write-Passo 'Automazioni pianificate'
    Step-Automazioni -Base $Cartella -SonoAdmin $sonoAdmin

    Write-Passo 'Collegamento DeepSeek'
    Step-ChiaveDeepSeek -Base $Cartella -Cfg $cfg

    Write-Passo 'Controllo della sintassi'
    Step-Sintassi -Base $Cartella

    $cfg = Step-Guidata -Base $Cartella -Cfg $cfg

    # marcatore: da qui in poi ZAP sa che il primo avvio e' stato fatto
    try {
        $marker = Join-Path (Get-EzapperoDir $sync) 'primo-avvio.ok'
        $info = @{
            data = (Get-Date -Format 'o')
            amministratore = $sonoAdmin
            esiti = @($script:Esiti)
        }
        Save-JsonNoBom $marker $info | Out-Null
        Add-Esito 'Marcatore primo avvio' 'OK' 'primo-avvio.ok nella cartella Ezappero'
    } catch {
        Add-Esito 'Marcatore primo avvio' 'ATTENZIONE' $_.Exception.Message
    }

    # registro indelebile
    try {
        $err = @($script:Esiti | Where-Object { $_.Stato -eq 'ERRORE' }).Count
        $att = @($script:Esiti | Where-Object { $_.Stato -eq 'ATTENZIONE' }).Count
        [void](Add-ZapLedgerEvento $sync 'sistema' ('Primo avvio completato. Controlli: ' + $script:Esiti.Count + ' - errori: ' + $err + ' - avvisi: ' + $att) 'primo-avvio' $false)
    } catch { }

    Show-Rapporto -Base $Cartella

    if ($script:OpzAvvia) {
        $bat = Join-Path $Cartella 'AVVIA.bat'
        if (Test-Path -LiteralPath $bat) {
            Write-Host ''
            Write-Host '  Avvio ZAP...' -ForegroundColor Cyan
            try { Start-Process -FilePath $bat | Out-Null } catch { }
        }
    }

    if (-not $script:OpzNonInterattivo -and -not $script:Silenzioso) {
        Write-Host ''
        Write-Host '  Premi INVIO per chiudere.' -ForegroundColor DarkGray
        [void](Read-Host)
    }
    return 0
}

function Show-Rapporto {
    param([string]$Base)
    $errori = @($script:Esiti | Where-Object { $_.Stato -eq 'ERRORE' })
    $avvisi = @($script:Esiti | Where-Object { $_.Stato -eq 'ATTENZIONE' })
    $ok = @($script:Esiti | Where-Object { $_.Stato -eq 'OK' })

    if (-not $script:Silenzioso) {
        Write-Host ''
        Write-Host '============================================================' -ForegroundColor Yellow
        Write-Host ('  RAPPORTO: ' + $ok.Count + ' ok, ' + $avvisi.Count + ' avvisi, ' + $errori.Count + ' errori') -ForegroundColor Yellow
        Write-Host '============================================================' -ForegroundColor Yellow
        if ($errori.Count -gt 0) {
            Write-Host '  Da sistemare:' -ForegroundColor Red
            foreach ($e in $errori) { Write-Host ('   - ' + $e.Nome + ': ' + $e.Dettaglio) -ForegroundColor Red }
        }
        if ($avvisi.Count -gt 0) {
            Write-Host '  Note (non bloccanti):' -ForegroundColor Yellow
            foreach ($a in $avvisi) { Write-Host ('   - ' + $a.Nome + ': ' + $a.Dettaglio) -ForegroundColor Yellow }
        }
        if ($errori.Count -eq 0) {
            Write-Host ''
            Write-Host '  Fatto. Ora apri ZAP con AVVIA.bat: il pannello MEMORIA deve dire "Memoria integra".' -ForegroundColor Green
        }
        Write-Host ''
    }

    # rapporto su file (sempre, anche silenzioso)
    try {
        $dir = Join-Path $Base 'Ezappero'
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $log = Join-Path $dir 'primo-avvio.log'
        $righe = @()
        $righe += '=== ' + (Get-Date -Format 'dd/MM/yyyy HH:mm:ss') + ' -- primo avvio ==='
        foreach ($e in @($script:Esiti)) { $righe += ('[' + $e.Stato + '] ' + $e.Nome + ' -- ' + $e.Dettaglio) }
        $righe += ''
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::AppendAllText($log, (($righe -join "`r`n") + "`r`n"), $enc)
    } catch { }
}

# ---------------------------------------------------------------------------
# Avvio diretto (se il file viene eseguito e non caricato con ".")
# ---------------------------------------------------------------------------
if ($MyInvocation.InvocationName -ne '.') {

    # elevazione: solo se richiesta (-Admin) e non gia' elevati
    if ($ConAdmin -and -not $Elevato -and -not (Test-SonoAdmin) -and $script:SuWindows) {
        Write-Host ''
        Write-Host '  Chiedo i privilegi di amministratore (una volta sola)...' -ForegroundColor Yellow
        $ps = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        if (-not (Test-Path -LiteralPath $ps)) { $ps = 'powershell.exe' }
        $arg = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -ConAdmin -Elevato'
        if ($NonInterattivo) { $arg = $arg + ' -NonInterattivo -Silenzioso' }
        if ($NoTask) { $arg = $arg + ' -NoTask' }
        if ($Avvia) { $arg = $arg + ' -Avvia' }
        try {
            Start-Process -FilePath $ps -ArgumentList $arg -Verb RunAs | Out-Null
            Write-Host '  Fatto: continua nella finestra appena aperta.' -ForegroundColor Green
            exit 0
        } catch {
            Write-Host '  Privilegi non concessi: continuo senza (protezione e automazioni ridotte).' -ForegroundColor Yellow
        }
    }

    $codice = 0
    try {
        $codice = Start-PrimoAvvio -Cartella $Cartella `
            -NonInterattivo:$NonInterattivo -Silenzioso:$Silenzioso `
            -NoTask:$NoTask -NoRete:$NoRete -SoloVerifica:$SoloVerifica -Avvia:$Avvia
    } catch {
        Write-Host ('ERRORE: ' + $_.Exception.Message) -ForegroundColor Red
        $codice = 1
    }
    exit $codice
}
