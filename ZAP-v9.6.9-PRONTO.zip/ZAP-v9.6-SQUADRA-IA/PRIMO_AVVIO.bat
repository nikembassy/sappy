@echo off
rem ============================================================================
rem  ZAP v9 -- PRIMO AVVIO: un solo doppio clic.
rem  Prepara tutto da solo: cartelle, memoria indelebile, copia di sicurezza,
rem  protezione, automazioni pianificate, controllo della chiave DeepSeek.
rem  Chiede i privilegi di amministratore una volta sola (serve per l'ACL che
rem  impedisce di cancellare la cartella Ezappero).
rem ============================================================================
setlocal
cd /d "%~dp0"

echo.
echo  ============================================================
echo    ZAP v9 -- configurazione automatica del primo avvio
echo  ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PRIMO_AVVIO.ps1" -ConAdmin -Avvia

if errorlevel 1 (
  echo.
  echo  Qualcosa non e' andato a buon fine. Il rapporto completo e' in:
  echo    %~dp0Ezappero\primo-avvio.log
  echo.
  pause
)
exit /b 0
