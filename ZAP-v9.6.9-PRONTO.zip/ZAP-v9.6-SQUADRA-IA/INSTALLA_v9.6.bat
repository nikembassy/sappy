@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ZAP v9.6 - installazione
color 07

echo.
echo   ZAP v9.6  --  installazione
echo   ===========================
echo.

if not exist "%~dp0APPLICA_v9.6.ps1" goto manca_script
if not exist "%~dp0brain\llm.ps1"    goto manca_brain

where powershell >nul 2>&1
if errorlevel 1 goto manca_ps

echo   Aggiorno la tua copia di ZAP.
echo   Prima faccio un backup completo, poi sostituisco solo il codice.
echo   Le chiavi API e la memoria restano dove sono.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLICA_v9.6.ps1"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" goto fatto
echo   ---------------------------------------------------------------
echo   L'installazione si e' fermata (codice %RC%).
echo   Non e' successo niente di irreparabile: la versione precedente
echo   e' stata rimessa a posto da sola.
echo   ---------------------------------------------------------------
goto chiudi

:fatto
echo   ---------------------------------------------------------------
echo   Fatto. Ora chiudi ZAP se e' aperto e rilancialo con AVVIA.bat.
echo   ---------------------------------------------------------------
goto chiudi

:manca_script
echo   ERRORE: manca APPLICA_v9.6.ps1 accanto a questo file.
echo   Hai estratto TUTTO lo ZIP? (tasto destro sullo zip - Estrai tutto)
goto chiudi

:manca_brain
echo   ERRORE: manca la cartella "brain" accanto a questo file.
echo   Hai estratto TUTTO lo ZIP? (tasto destro sullo zip - Estrai tutto)
goto chiudi

:manca_ps
echo   ERRORE: PowerShell non trovato su questo PC.
echo   Serve Windows PowerShell 5.1 (e' gia' incluso in Windows 10 e 11).
goto chiudi

:chiudi
echo.
echo   Premi un tasto per chiudere questa finestra.
pause >nul
endlocal
