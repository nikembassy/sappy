﻿# ZAP-CLI.ps1 -- strumento da riga di comando per la memoria, la libreria e i documenti (v9).
#
# Serve a due cose:
#   1) far girare le automazioni di Windows (Task Scheduler) SENZA aprire l'interfaccia di ZAP;
#   2) darti un modo rapido da terminale per controllare che la memoria sia integra.
#
# Esempi:
#   powershell -ExecutionPolicy Bypass -File .\ZAP-CLI.ps1 stato
#   powershell -ExecutionPolicy Bypass -File .\ZAP-CLI.ps1 memoria-integra
#   powershell -ExecutionPolicy Bypass -File .\ZAP-CLI.ps1 riepilogo-giornata
#   powershell -ExecutionPolicy Bypass -File .\ZAP-CLI.ps1 salva-script .\mio.ps1 "Mio script"

[CmdletBinding()]
param(
    [Parameter(Position = 0)][string]$Comando = 'stato',
    [Parameter(Position = 1)][string]$Arg1 = '',
    [Parameter(Position = 2)][string]$Arg2 = ''
)

$ErrorActionPreference = 'Continue'
$base = $PSScriptRoot
$script:ExitCode = 0

# --- configurazione minima (senza interfaccia grafica) ---
function Get-CliConfig {
    $cfg = @{
        nome     = 'ZAP'
        ezappero = @{ cartella = 'Ezappero'; proteggi = $true; max_righe_prompt = 18 }
        traccia  = @{ attiva = $false; intervallo = 15 }
        verita   = @{ attivo = $true; controllo = $true; severita = 'media'; max_avvisi = 3 }
        documenti = @{ iva_default = 22 }
        gmail    = @{}
    }
    foreach ($file in @('config.json', 'config.local.json')) {
        $p = Join-Path $base $file
        if (-not (Test-Path -LiteralPath $p)) { continue }
        try {
            $j = Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($sez in @('ezappero', 'traccia', 'verita', 'documenti', 'gmail')) {
                $blk = $null
                try { $blk = $j.$sez } catch { $blk = $null }
                if ($blk) {
                    foreach ($pr in @($blk.PSObject.Properties)) {
                        $cfg[$sez][[string]$pr.Name] = $pr.Value
                    }
                }
            }
        } catch { }
    }
    return $cfg
}

$sync = @{ Base = $base; Config = (Get-CliConfig) }
foreach ($m in @('memoria_v9.ps1', 'ps_libreria.ps1', 'verita.ps1', 'traccia.ps1', 'office.ps1', 'email_gmail.ps1')) {
    $p = Join-Path (Join-Path $base 'brain') $m
    if (Test-Path -LiteralPath $p) { . $p }
}
[void](Initialize-Ezappero $sync)

function Write-Titolo { param([string]$T) Write-Host ''; Write-Host $T -ForegroundColor Cyan }

switch ($Comando.ToLowerInvariant()) {

    'stato' {
        $st = Get-EzapperoStato $sync
        Write-Titolo 'ZAP - stato memoria e libreria'
        Write-Host ("  cartella Ezappero : " + $st.cartella)
        Write-Host ("  copia specchio    : " + $st.specchio)
        Write-Host ("  eventi registrati : " + $st.eventi)
        Write-Host ("  script archiviati : " + $st.script)
        Write-Host ("  sessioni salvate  : " + $st.sessioni)
        if ($st.integrita) { Write-Host ("  integrita         : OK - " + $st.messaggio) -ForegroundColor Green }
        else { Write-Host ("  integrita         : PROBLEMA - " + $st.messaggio) -ForegroundColor Red; $script:ExitCode = 2 }
        Write-Host ("  guardia anti-bugia: " + (Get-VeritaStato $sync))
    }

    'memoria-integra' {
        $rep = Test-ZapIntegrita $sync
        if ($rep.ok) {
            Write-Host ("Memoria integra: " + $rep.totale + ' eventi, catena di hash valida.') -ForegroundColor Green
        } else {
            Write-Host ('MEMORIA MANOMESSA: ' + $rep.messaggio) -ForegroundColor Red
            $fix = Repair-ZapDaSpecchio $sync
            Write-Host ('Ripristino: ' + $fix) -ForegroundColor Yellow
            $rep2 = Test-ZapIntegrita $sync
            if ($rep2.ok) { Write-Host 'Ripristinata e verificata.' -ForegroundColor Green }
            else { $script:ExitCode = 2 }
        }
    }

    'backup-ezappero' {
        Write-Host (Sync-EzapperoSpecchio $sync)
        $rep = Test-ZapIntegrita $sync
        if (-not $rep.ok) { $script:ExitCode = 2 }
    }

    'riepilogo-giornata' {
        Write-Titolo 'Diario di oggi'
        Write-Host (Get-ZapDiario $sync)
        Write-Titolo 'Cosa hai fatto (modalita traccia)'
        Write-Host (Get-TracciaRiassunto $sync '')
    }

    'fatture-settimana' {
        $limite = (Get-Date).AddDays(-7)
        $ev = @(Read-ZapLedger $sync 500 | Where-Object { [string]$_.tipo -eq 'documento' })
        $recenti = @()
        foreach ($e in $ev) {
            $d = $null
            try { $d = [datetime]$e.t } catch { $d = $null }
            if ($d -and $d -ge $limite) { $recenti += $e }
        }
        Write-Titolo 'Documenti creati negli ultimi 7 giorni'
        if ($recenti.Count -eq 0) { Write-Host '  nessuno' }
        foreach ($e in $recenti) { Write-Host ('  - ' + (Format-ZapEvento $e)) }
    }

    'salva-script' {
        if (-not $Arg1) { Write-Host 'Uso: ZAP-CLI.ps1 salva-script <file.ps1> ["titolo"]' -ForegroundColor Yellow; $script:ExitCode = 1; break }
        if (-not (Test-Path -LiteralPath $Arg1)) { Write-Host ('File non trovato: ' + $Arg1) -ForegroundColor Red; $script:ExitCode = 1; break }
        $codice = [System.IO.File]::ReadAllText((Resolve-Path -LiteralPath $Arg1))
        $r = Save-PsScriptArchivio $sync $codice $Arg2 'manuale' '' '' $false
        Write-Host ([string]$r.messaggio)
        if (-not $r.ok) { $script:ExitCode = 1 }
    }

    'cerca-script' {
        $v = Find-PsScriptArchivio $sync $Arg1 '' 20
        Write-Host (Format-PsScriptElenco $sync $v)
    }

    'verifica' {
        $t = Join-Path $base 'tests\test_v9.ps1'
        if (Test-Path -LiteralPath $t) { & $t } else { Write-Host 'tests\test_v9.ps1 non trovato.' -ForegroundColor Red; $script:ExitCode = 1 }
    }

    default {
        Write-Host ''
        Write-Host 'ZAP-CLI -- comandi disponibili:' -ForegroundColor Cyan
        Write-Host '  stato              stato memoria, libreria e guardia anti-bugia'
        Write-Host '  memoria-integra    verifica la catena di hash e ripristina se serve'
        Write-Host '  backup-ezappero    aggiorna la copia specchio fuori dal progetto'
        Write-Host '  riepilogo-giornata diario + cosa hai fatto oggi'
        Write-Host '  fatture-settimana  documenti creati negli ultimi 7 giorni'
        Write-Host '  salva-script FILE ["titolo"]   archivia uno script nella libreria'
        Write-Host '  cerca-script PAROLA            cerca nella libreria'
        Write-Host '  verifica           esegue i test automatici'
        $script:ExitCode = 1
    }
}

exit $script:ExitCode
