@echo off
echo Controllo della versione di ZAP in questa cartella...
echo.
findstr /C:"PATCH-GEMINI" "%~dp0brain\llm.ps1" >nul 2>nul
if %errorlevel%==0 (
  echo   VERSIONE CORRETTA: la correzione di Gemini c'e'.
  echo   Avvia con AVVIA.bat
) else (
  echo   VERSIONE VECCHIA: manca la correzione di Gemini.
  echo   Stai usando una cartella sbagliata: usa quella appena scompattata.
)
echo.
pause
