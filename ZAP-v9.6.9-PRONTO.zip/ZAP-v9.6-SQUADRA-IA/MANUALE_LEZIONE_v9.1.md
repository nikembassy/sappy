# Manuale della lezione — ZAP v9.1

Come usare GHOST e la Cabina di Regia in classe, senza sorprese.
Tempo totale: 90 minuti, diviso in due parti da 45.

---

## Prima di entrare in aula (10 minuti, da solo)

0. **La prima volta**: doppio clic su `PREPARA_STRUMENTI_v9.1.bat` e lascia lavorare.
   Installa Wireshark e gli strumenti Kali (sqlmap, hydra, nikto, gobuster, dirb,
   Metasploit, aircrack-ng) e li verifica uno per uno. Dura 10-40 minuti, si fa una
   volta sola. Poi, ogni volta che vuoi, `-Verifica` per la tabella aggiornata.
   *Nota per la lezione sul wireless:* aircrack-ng parte ma in WSL2 non vede la
   scheda WiFi — usa Wireshark su Windows per la pratica, o un Kali live.

1. Apri ZAP. In alto a destra premi **GHOST**: deve essere **ROSSO** (`GHOST: APERTO`).
   Se è verde o dorato, cambia dal menu in basso: `APERTO`.
2. Nella casella **Bersagli autorizzati** scrivi i tuoi siti, uno per riga:

```
miosito.it
*.miosito.it
192.168.1.0/24
lab.local
```

   Premi **SALVA ELENCO**. Da questo momento, in qualunque modo tu sia,
   quei bersagli non vengono mai bloccati.
3. Scrivi in chat `/aula kit`. Ti crea la cartella `aula\<data>\` con tutto il
   materiale: perimetro, scenari, checklist, difese, scheda studenti.
4. Apri il sito di laboratorio su cui farai la demo e lascia ZAP sulla seconda
   scrivania (o su un monitor proiettato).
5. Scrivi in chat `/ghost test nmap -sV miosito.it` davanti a te stesso:
   deve rispondere `PASSEREBBE (modo aperto)`. Se risponde `BLOCCATO`,
   l'indirizzo che hai scritto non è quello che stai usando: ricontrolla.

> Nel modo **APERTO** ogni comando che esce dall'elenco finisce comunque nella
> scatola nera con bersaglio e orario. Non è un freno: è la tua difesa se un
> alunno ti chiede "prof, ma è legale?".

---

## Parte 1 — Cosa vede un attaccante (45 min)

### 0. La regola della lezione (2 min)

Proietta `/ghost stato`. Leggi ad alta voce:

> "Questo è il perimetro: i bersagli sono i nostri. Il file di registro dice
> ogni comando, con l'ora. Un test senza autorizzazione scritta non è
> un test, è un reato (art. 615-ter c.p.). Oggi facciamo la cosa noiosa e
> giusta: proviamo i NOSTRI sistemi e scriviamo cosa va chiuso."

### 1. Ricognizione passiva (5 min) — scenario `robots`, `headers`

```powershell
curl -s https://IL-TUO-SITO/robots.txt
curl -s -I https://IL-TUO-SITO
```

Chiedi alla classe: *quante informazioni abbiamo già senza aver toccato nulla?*
Poi `/pentest copertura` per mostrare quante categorie esistono.

### 2. Header e cookie (8 min) — scenario `header`, `cookie`

```powershell
curl -s -I https://IL-TUO-SITO
```

Alla lavagna, tre colonne:

| Manca | Cosa abilita | Come si chiude |
|---|---|---|
| `Content-Security-Policy` | XSS | header CSP lato server |
| `X-Frame-Options` | clickjacking | `DENY` |
| `Set-Cookie` senza `HttpOnly` | furto di sessione | `HttpOnly; Secure; SameSite=Lax` |

**Momento chiave**: apri gli strumenti sviluppatore, mostra il cookie,
poi apri la console e prova `document.cookie`. Se il cookie non c'è,
`HttpOnly` sta funzionando. Se c'è, hai appena mostrato perché serve.

### 3. TLS (8 min) — scenario `tls`

```powershell
testssl https://IL-TUO-SITO
openssl s_client -connect IL-TUO-SITO:443 -tls1_1 -brief
```

Domanda: *"il lucchetto dice che il sito è sicuro?"*
Risposta: dice che il traffico è cifrato. Non dice **con che cosa**.
Se TLS 1.1 è ancora accettato, il lucchetto è vero ma vecchio.

### 4. File che non dovrebbero esserci (8 min) — scenario `file-esposti`

```powershell
curl -s -o /dev/null -w "%{http_code}" https://IL-TUO-SITO/.git/config
curl -s -o /dev/null -w "%{http_code}" https://IL-TUO-SITO/.env
ffuf -u https://IL-TUO-SITO/FUZZ -w /usr/share/wordlists/dirb/common.txt -mc 200,301,403
```

Se esce `200` su `.env`, fermati e chiedi: *"quante aziende sono state bucate
così, senza nessun exploit?"*. Poi mostra la difesa (deny + fuori webroot).

### 5. Un'ora di controllo: la Cabina (8 min)

Premi **AGENTI**. Mentre la squadra lavora, proietta la cabina:

- ogni agente ha uno stato colorato e un "passo 2/3";
- il log sotto scorre: chi ha fatto cosa, a che ora;
- premi **FERMA** su un agente: si ferma al passo successivo;
- premi **FERMA TUTTO**: la squadra si ferma e il pulsante diventa RIPRISTINA.

Frase da dire: *"un agente che lavora senza che io veda cosa fa è un rischio,
non un aiutante. Il controllo non è sfiducia: è la differenza tra usare uno
strumento e subirlo."*

Poi mostra il watchdog: spiega che oltre 4 minuti su un passo, o 3 comandi
uguali di fila, l'agente viene fermato da solo. È il "limite di sicurezza"
che si mette sempre quando si lascia qualcosa di autonomo.

### 6. Chiusura (6 min)

```powershell
/ghost stato
/audit
```

Leggi il registro ad alta voce. Poi chiedi: *"cosa avremmo dovuto fare
prima di iniziare?"* (risposta: autorizzazione scritta, elenco bersagli,
finestra temporale, log). Sono le stesse tre cose che ZAP ti ha chiesto.

---

## Parte 2 — Come si difende (45 min)

### 1. Dalla vulnerabilità alla contromisura (15 min)

`/aula difese`: per ogni scenario, la riga di difesa. Prendi i tre casi
trovati nella parte 1 e chiudi il cerchio:

- header mancanti → li aggiungi sulla configurazione del server;
- TLS 1.1 → lo disabiliti;
- `.env` esposto → lo sposti fuori dalla webroot e **ruoti le chiavi**
  (spiega: cambiare la password non basta se la chiave è già stata letta).

### 2. Rifare il test dopo la correzione (10 min)

Stesso comando, stesso bersaglio, output diverso. Questo è il punto:
**la sicurezza si misura, non si dichiara**.

```powershell
/pentest report web https://IL-TUO-SITO
```

Il resoconto finisce in `report\pentest\<data>\resoconto.md` con output,
significato e difesa. È il documento che si consegna a chi gestisce il sito.

### 3. Injection e XSS: perché il filtro non basta (12 min)

Con `/pentest intrusivo on`, su un form del **tuo** laboratorio:

```powershell
sqlmap -u "https://IL-TUO-SITO/prodotto?id=1" --batch --level 1 --risk 1
dalfox url "https://IL-TUO-SITO/cerca?q=test"
```

Poi la difesa, con il codice: query parametrizzate, encoding in uscita, CSP.
Frase da dire: *"il filtro in ingresso è la parte che si aggira. La difesa
vera sta dove il dato viene usato."*

### 4. La scheda studente (8 min)

`04-SCHEDA-STUDENTE.md`: per ogni scenario, tre righe — cosa ho visto,
perché succede, come lo chiudo. Si compila durante la demo, non dopo.
Serve a fissare il metodo: osservazione → causa → contromisura.

---

## Dopo la lezione (5 min)

1. `/ghost modo aula`: da qui in poi il perimetro resta chiuso tranne i tuoi
   siti dichiarati e i comandi passivi.
2. Conserva `aula\<data>\` e `report\pentest\<data>\`: sono la traccia di cosa
   hai fatto, quando e su cosa.
3. Se un alunno chiede "posso provarlo su un sito qualsiasi?", la risposta è
   il modo AULA: `curl -I` e `dig` su qualunque sito sono letture pubbliche;
   tutto il resto richiede autorizzazione.

---

## Tabella dei comandi utili

| Comando | Cosa fa |
|---|---|
| `/ghost stato` | modo attuale, bersagli, consenso, registrazione |
| `/ghost modo aperto` | nessun blocco (tutto registrato, HUD rosso) |
| `/ghost modo aula` | blocco attivo, passivi sempre permessi |
| `/ghost modo chiuso` | solo bersagli dichiarati |
| `/ghost aggiungi a.it, b.it` | aggiunge uno o più bersagli |
| `/ghost togli a.it` | rimuove un bersaglio |
| `/ghost file` | importa `perimetro.txt` |
| `/ghost test <comando>` | verdetto senza eseguire |
| `/ghost kit` | crea il kit della lezione |
| `/agenti` | cabina di regia (testuale + finestra) |
| `/ferma-agente zeus` | ferma un agente |
| `/aula elenco` | i 14 scenari |
| `/aula checklist` | copertura in 14 categorie |
| `/aula difese` | le contromisure |
| `/pentest copertura` | 45+ strumenti per categoria |
| `/pentest report web <host>` | esegue e scrive il resoconto |
| `/audit` | cosa è stato fatto, con data e ora |
| `/strumenti` | tabella degli strumenti: pronto / manca, con versione |
| `/strumenti installa` | apre l'installazione guidata (Wireshark + Kali) |
