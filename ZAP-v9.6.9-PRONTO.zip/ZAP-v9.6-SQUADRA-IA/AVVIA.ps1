﻿# AVVIA.ps1 - ZAP! Assistente Desktop (grafica AURA oro/argento, upload foto/video/PDF) - v6.3
# Avvio:  powershell -ExecutionPolicy Bypass -File .\AVVIA.ps1
# Funziona con Windows PowerShell 5.1 (viene rilanciato automaticamente da pwsh 7).
[CmdletBinding()]
param(
    [switch]$NoVoice,
    [switch]$Admin
)

# --- Su pwsh (PowerShell 7) rilancia con Windows PowerShell 5.1 in STA (serve per WPF + voce) ---
if ($PSVersionTable.PSEdition -eq 'Core') {
    $psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $psExe)) { $psExe = 'powershell.exe' }
    $argList = @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath)
    if ($NoVoice) { $argList += '-NoVoice' }
    if ($Admin) { $argList += '-Admin' }
    Start-Process $psExe -ArgumentList $argList
    return
}

# --- se qualcosa va storto, MOSTRALO (finestra + logs\errore.log) ---
trap {
    $testo = ($_ | Out-String)
    try {
        $logDir = Join-Path $PSScriptRoot 'logs'
        if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
        $rigaErr = (Get-Date -Format 'o') + [Environment]::NewLine + $testo
        if (Get-Command Add-FileLineSafe -ErrorAction SilentlyContinue) {
            [void](Add-FileLineSafe (Join-Path $logDir 'errore.log') $rigaErr)
        } else {
            Add-Content -Path (Join-Path $logDir 'errore.log') -Value $rigaErr -Encoding UTF8 -ErrorAction SilentlyContinue
        }
    } catch { }
    Write-Host $testo -ForegroundColor Red
    try { [System.Windows.MessageBox]::Show($testo, 'ZAP - errore', 'OK', 'Error') | Out-Null } catch { }
    exit 1
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName WindowsBase
try { Add-Type -AssemblyName System.Speech } catch { }   # se manca il motore vocale, ZAP parte lo stesso

$base = $PSScriptRoot
foreach ($d in 'logs', 'memory', 'skills', 'brain', 'voice', 'ui', 'ui\avatar', 'programmi', 'appunti') {
    $p = Join-Path $base $d
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null }
}

# v9.6.1 -- un modulo che non si carica NON deve impedire a ZAP di partire:
# si annota il motivo in logs\avvio.log e si continua (si perde solo quella funzione).
function Write-ModuloNonCaricato {
    param([string]$Modulo, [string]$Motivo)
    try {
        $d = Join-Path $base 'logs'
        if (-not (Test-Path $d)) { [void][System.IO.Directory]::CreateDirectory($d) }
        [System.IO.File]::AppendAllText((Join-Path $d 'avvio.log'),
            ((Get-Date -Format 'HH:mm:ss') + '  [modulo] ' + $Modulo + ' NON caricato: ' + $Motivo + "`r`n"),
            (New-Object System.Text.UTF8Encoding($false)))
    } catch { }
    Write-Host ('[ZAP avvio] modulo non caricato: ' + $Modulo + ' -> ' + $Motivo) -ForegroundColor Yellow
}

# v5: i moduli nuovi vengono caricati SUBITO (servono anche a Get-DefaultConfig)
foreach ($__m in @('brain\log.ps1', 'brain\audit.ps1', 'brain\policy.ps1', 'brain\sandbox.ps1', 'brain\pentest.ps1', 'brain\provider_ai.ps1', 'brain\tema.ps1', 'brain\tema_foto.ps1', 'brain\modalita.ps1', 'brain\autonomia.ps1', 'brain\programmi.ps1', 'brain\pc_controllo.ps1', 'brain\osint.ps1', 'brain\mini_agenti.ps1', 'brain\agenti.ps1', 'brain\cinema.ps1', 'brain\cinema_ai.ps1', 'brain\cinema_ffmpeg.ps1', 'brain\whatsapp.ps1')) {
    $__p = Join-Path $base $__m
    if (-not (Test-Path $__p)) { continue }
    try { . $__p } catch { Write-ModuloNonCaricato $__m $_.Exception.Message }
}

# v9: i moduli nuovi si caricano ognuno per conto suo. Se uno non si carica, ZAP parte
# lo stesso (perde solo quella funzione) e il motivo finisce in logs\avvio.log.
foreach ($__m in @('brain\memoria_v9.ps1', 'brain\ps_libreria.ps1', 'brain\verita.ps1', 'brain\traccia.ps1', 'brain\office.ps1', 'brain\email_gmail.ps1', 'brain\ghost.ps1', 'brain\pentest_tools.ps1', 'brain\aula.ps1', 'brain\telemetria.ps1', 'brain\pentest_ext.ps1', 'brain\strumenti.ps1', 'brain\orchestra.ps1', 'brain\intelligenze_ui.ps1')) {
    $__p = Join-Path $base $__m
    if (-not (Test-Path $__p)) { continue }
    try { . $__p } catch { Write-ModuloNonCaricato $__m $_.Exception.Message }
}

# v5: traccia delle fasi di avvio. Se ZAP non parte, logs\avvio.log dice FIN DOVE e' arrivato.
function Write-Fase {
    param([string]$Testo)
    # v8: scrittura "gentile" del log. avvio.log puo' essere aperto in quel
    # momento da antivirus, OneDrive o da un'altra istanza di ZAP: si apre in
    # condivisione, si riprova e in caso estremo si scrive su un file
    # alternativo. Non deve MAI comparire un errore rosso all'avvio.
    try {
        $d = Join-Path $base 'logs'
        if (-not (Test-Path $d)) { [void][System.IO.Directory]::CreateDirectory($d) }
        $riga = (Get-Date -Format 'HH:mm:ss') + '  [avvio] ' + $Testo
        $scritto = $false
        if (Get-Command Add-FileLineSafe -ErrorAction SilentlyContinue) {
            $scritto = Add-FileLineSafe (Join-Path $d 'avvio.log') $riga
        }
        if (-not $scritto) {
            $alt = Join-Path $d ('avvio-' + $PID + '.log')
            if (Get-Command Add-FileLineSafe -ErrorAction SilentlyContinue) {
                [void](Add-FileLineSafe $alt $riga)
            }
        }
    } catch { }
    Write-Host ('[ZAP avvio] ' + $Testo)
}
Write-Fase '1/6 moduli caricati'

# --------------------------------------------------------------------------
# v6.5 -- Motore della palette: applica dal vivo i colori/il carattere scelti
# --------------------------------------------------------------------------
function ConvertTo-Colore {
    param([string]$Hex)
    try {
        $h = ([string]$Hex).Trim().TrimStart('#')
        if ($h.Length -eq 3) { $h = ($h[0] + $h[0] + $h[1] + $h[1] + $h[2] + $h[2]) }
        if ($h.Length -eq 6) { $h = 'FF' + $h }
        return [System.Windows.Media.Color]::FromArgb(
            [Convert]::ToByte($h.Substring(0,2),16), [Convert]::ToByte($h.Substring(2,2),16),
            [Convert]::ToByte($h.Substring(4,2),16), [Convert]::ToByte($h.Substring(6,2),16))
    } catch { return [System.Windows.Media.Colors]::Gray }
}

function ConvertTo-HexNorm {
    param([string]$h)
    $h = ([string]$h).Trim()
    if (-not $h.StartsWith('#')) { $h = '#' + $h }
    if ($h.Length -eq 7) { $h = '#FF' + $h.Substring(1) }
    return $h.ToUpper()
}

function New-PaletteMappa {
    param($vecchia, $nuova)
    $m = @{}
    foreach ($k in @($vecchia.Keys)) {
        if ($k -eq 'font' -or $k -eq 'fontSize' -or $k -eq 'preset' -or $k -eq 'sfondoImmagine') { continue }
        $o = ConvertTo-HexNorm $vecchia[$k]
        $n = ConvertTo-HexNorm $nuova[$k]
        if ($o -and $n -and ($o -ne $n)) { $m[$o] = $n }
    }
    return $m
}

function Send-Palette {
    param($el, $mappa, [double]$ratio)
    if ($null -eq $el) { return }
    foreach ($prop in @('Background','Foreground','BorderBrush','Fill','Stroke','CaretBrush','SelectionBrush')) {
        try {
            $v = $el.$prop
            if ($v -is [System.Windows.Media.SolidColorBrush]) {
                $key = '#FF' + $v.Color.ToString().Substring(2)
                if ($mappa.ContainsKey($key)) {
                    $nb = New-Object System.Windows.Media.SolidColorBrush((ConvertTo-Colore $mappa[$key]))
                    $nb.Freeze()
                    $el.$prop = $nb
                }
            }
        } catch { }
    }
    if ($ratio -ne 1.0) {
        try { $fs = [double]$el.FontSize; if ($fs -gt 0) { $el.FontSize = [Math]::Round($fs * $ratio, 1) } } catch { }
    }
    try {
        if ($el -is [System.Windows.Controls.Panel]) { foreach ($c in $el.Children) { Send-Palette $c $mappa $ratio } }
        elseif ($el -is [System.Windows.Controls.Decorator]) { Send-Palette $el.Child $mappa $ratio }
        elseif ($el -is [System.Windows.Controls.ContentControl]) { if ($el.Content -is [System.Windows.UIElement]) { Send-Palette $el.Content $mappa $ratio } }
    } catch { }
}

function Applica-Palette {
    param($sync, $radice, $nuova)
    if (-not $radice -or -not $nuova) { return }
    $vecchia = $null
    try { $vecchia = $sync.PaletteCorr } catch { }
    if (-not $vecchia) { $vecchia = Get-PaletteDefault }
    $mappa = New-PaletteMappa $vecchia $nuova
    $ratio = 1.0
    try {
        $of = [double]$vecchia.fontSize; $nf = [double]$nuova.fontSize
        if ($of -gt 0 -and $nf -gt 0) { $ratio = $nf / $of }
    } catch { }
    Send-Palette $radice $mappa $ratio
    try { $radice.FontFamily = [System.Windows.Media.FontFamily]::new([string]$nuova.font) } catch { }
    try { $sync.Palette = $nuova; $sync.PaletteCorr = $nuova } catch { }
}

# --------------------------------------------------------------------------
# v7.9.3 -- SFONDO DALLA FOTO: usa una tua foto come sfondo del pannello sinistro
# (con un velo scuro, cosi' logo e avatar restano leggibili). Senza foto: torna
# allo sfondo normale a puntini.
# --------------------------------------------------------------------------
function Asp-ApplicaSfondo {
    param($sync, [string]$Percorso)
    if (-not $PannelloSinistro) { return }
    if ($Percorso -and (Test-Path $Percorso)) {
        try {
            $bi = New-Object System.Windows.Media.Imaging.BitmapImage
            $bi.BeginInit()
            $bi.CacheOption = 'OnLoad'
            $bi.UriSource  = New-Object System.Uri($Percorso)
            $bi.EndInit()
            $bi.Freeze()
            $br = New-Object System.Windows.Media.ImageBrush($bi)
            $br.Stretch = 'UniformToFill'
            $br.Opacity = 0.55
            $br.Freeze()
            $PannelloSinistro.Background = $br
            return
        } catch { }
    }
    try {
        $orig = $Window.FindResource('Halftone')
        if ($orig) { $PannelloSinistro.Background = $orig }
    } catch { }
}

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

function Get-DefaultConfig {
    return @{
        nome      = 'ZAP'
        api_base  = ''
        api_key   = ''
        modello   = 'gemini-3.1-flash-lite'
        provider  = 'gemini'
        gemini_model_fallbacks = @('gemini-3.6-flash', 'gemini-flash-lite-latest')
        modalita_ai = 'auto'   # v9.6.2: parte Gemini; se non risponde risponde DeepSeek (dichiarato)
        provider_ai = (Get-DefaultProviderAi)
        # v9.5: squadra IA (tutte le intelligenze insieme)
        orchestrazione = $(if (Get-Command Get-OrchestraDefault -ErrorAction SilentlyContinue) { Get-OrchestraDefault } else { @{ attivo = $false; min_modelli = 2; timeout_sec = 75 } })
        sicurezza = 'smart'
        browser   = 'yandex'
        browser_fallbacks = @('yandex', 'thorium')
        motore_ricerca = 'duckduckgo'
        tema      = 'oro'
        browser_paths = @{}
        cartella_lavoro = ''
        timeout_powershell_sec = 30
        # v9.6.1: questi tre blocchi erano in config.json ma non venivano MAI caricati,
        # quindi le loro impostazioni non avevano alcun effetto.
        motore = @{ primario = 'gemini'; secondario = 'deepseek'; stretto = $true
                    ripiego_solo_su_errore = $true; etichetta_ripiego = $true
                    blocca_locale = $true }
        memoria = @{ salvataggio = 'manuale'; salva_fine_turno = $false; consolidamento_automatico = $false }
        gemini_sicurezza = @{ attivo = $true; soglia = 'BLOCK_ONLY_HIGH'
                              categorie = @('HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_DANGEROUS_CONTENT') }
        # v7.9.4
        simulazione = $false
        audit     = $true
        policy    = (Get-PolicyDefault)
        sandbox   = (Get-SandboxDefault)
        pentest   = (Get-PentestDefault)
        osint     = (Get-OsintDefault)
        miniagenti = (Get-MiniAgentiDefault)
        hacker    = (Get-HackerDefault)
        voce = @{
            risposte_ad_alta_voce = $true
            ascolto_lingua  = 'it-IT'
            ascolto_secondi = 6
            velocita = 1
            volume   = 100
            telecomando = $true
        }
        programmi     = (Get-DefaultProgrammiConfig)
        # --- v9: memoria indelebile, traccia, guardia anti-bugia, documenti, posta ---
        ezappero = @{
            cartella         = 'Ezappero'
            specchio         = ''
            proteggi         = $true
            snapshot_ore     = 6
            max_righe_prompt = 18
        }
        traccia = @{
            attiva      = $false
            intervallo  = 15
            scatti      = $false
            ogni_scatti = 120
        }
        # inline di proposito: se brain\verita.ps1 non fosse caricato, ZAP deve partire lo stesso
        verita = @{
            attivo     = $true
            controllo  = $true
            severita   = 'media'
            max_avvisi = 3
        }
        documenti = @{
            mittente = @{ nome = ''; piva = ''; cf = ''; indirizzo = ''; cap = ''; citta = ''; email = ''; telefono = ''; iban = '' }
            iva_default = 22
            prefisso_fattura = 'FATT'
            prefisso_busta = 'BUSTA'
            busta = @{
                inps_dipendente = 9.19
                irpef = @(@(28000, 23), @(50000, 35), @(1000000000, 43))
                detrazione_mensile = 0
            }
        }
        gmail = @{ mittente = ''; nome = ''; password = ''; smtp = 'smtp.gmail.com'; porta = 587; ssl = $true; firma = ''; solo_bozze = $true }
        ghost = @{
            attivo              = $false
            consenso            = $false
            ambiti              = @()
            modo                = 'aperto'
            blocca_fuori_ambito = $false
            consenti_privati    = $true
            registra_tutto      = $true
            aula_passivi        = $true
        }
        sicurezza_agenti = @{
            max_secondi_step = 240
            max_silenzio     = 120
            max_ripetizioni  = 3
            max_chiamate     = 40
            max_errori       = 3
        }
    }
}

function Write-Utf8NoBom {
    # Scrive SEMPRE UTF-8 senza BOM (Windows PowerShell 5.1 con -Encoding UTF8 lo aggiungerebbe,
    # e il BOM in testa a config.json faceva fallire ConvertFrom-Json su altri lettori).
    param([string]$Path, [string]$Testo)
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Testo, $enc)
}

function Split-ConfigSegreti {
    # Divide la configurazione in: parte pubblica (va in config.json) e parte segreta
    # (va SOLO in config.local.json, che .gitignore ignora).
    param($Config)
    $copia = @{}
    foreach ($k in @($Config.Keys)) { $copia[$k] = $Config[$k] }
    $copia['api_key'] = ''
    $paPub = @{}
    $paSeg = @{}
    foreach ($k in @($Config.provider_ai.Keys)) {
        $blk = $Config.provider_ai[$k]
        $pub = @{}
        foreach ($f in @($blk.Keys)) { if ($f -ne 'chiave') { $pub[$f] = $blk[$f] } }
        $pub['chiave'] = ''
        $paPub[$k] = $pub
        if (([string]$blk['chiave']).Trim()) { $paSeg[$k] = @{ chiave = [string]$blk['chiave'] } }
    }
    $copia['provider_ai'] = $paPub
    $segreti = @{ provider_ai = $paSeg }
    # v9: la password per le app di Gmail resta SOLO in config.local.json
    try {
        if ($Config.gmail) {
            $gp = @{}
            foreach ($f in @($Config.gmail.Keys)) { if ($f -ne 'password') { $gp[$f] = $Config.gmail[$f] } }
            $gp['password'] = ''
            $copia['gmail'] = $gp
            if (([string]$Config.gmail['password']).Trim()) {
                $segreti['gmail'] = @{ password = [string]$Config.gmail['password'] }
            }
        }
    } catch { }
    return @{ Pubblica = $copia; Segreti = $segreti }
}

function Save-Config {
    param($sync)
    try {
        $d = Split-ConfigSegreti $sync.Config
        Write-Utf8NoBom $sync.CfgPath (($d.Pubblica | ConvertTo-Json -Depth 6))
        if ($d.Segreti.Count -gt 0) {
            $lp = Join-Path $sync.Base 'config.local.json'
            Write-Utf8NoBom $lp (($d.Segreti | ConvertTo-Json -Depth 6))
        }
    } catch { }
}

$cfgPath = Join-Path $base 'config.json'
$config = Get-DefaultConfig
if (Test-Path $cfgPath) {
    try {
        $loaded = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @('nome','provider','api_base','api_key','modello','gemini_model_fallbacks','sicurezza','browser','browser_fallbacks','motore_ricerca','tema','aspetto','gemini_model_scelto','cartella_lavoro','timeout_powershell_sec','modalita_ai','simulazione','audit','pentest','osint','miniagenti','hacker')) {
            if ($null -ne $loaded.$k) { $config[$k] = $loaded.$k }
        }
        if ($loaded.browser_paths) { $config.browser_paths = $loaded.browser_paths }
        if ($loaded.voce) {
            foreach ($k in @('risposte_ad_alta_voce','ascolto_lingua','ascolto_secondi','velocita','volume','telecomando')) {
                if ($null -ne $loaded.voce.$k) { $config.voce[$k] = $loaded.voce.$k }
            }
        }
        if ($loaded.policy) {
            $pl = Get-PolicyDefault
            foreach ($k in @('attivo','cartelle_consentite','cartelle_protette','conferma_eliminazione','conferma_scritture_esterne')) {
                if ($null -ne $loaded.policy.$k) { $pl[$k] = $loaded.policy.$k }
            }
            $config.policy = $pl
        }
        if ($loaded.sandbox) {
            $sbb = Get-SandboxDefault
            foreach ($k in @('attivo','memoria_mb','cpu_sec','max_processi')) {
                if ($null -ne $loaded.sandbox.$k) { $sbb[$k] = $loaded.sandbox.$k }
            }
            $config.sandbox = $sbb
        }
        if ($loaded.programmi) {
            if ($loaded.programmi.cartella) { $config.programmi.cartella = [string]$loaded.programmi.cartella }
            if ($null -ne $loaded.programmi.voci) { $config.programmi.voci = @($loaded.programmi.voci) }
        }
        if ($loaded.provider_ai) {
            $pa = @{}
            foreach ($p in @($loaded.provider_ai.PSObject.Properties)) {
                $ee = @{}
                foreach ($f in @('chiave','endpoint','modello','abilitato')) {
                    $vv = $p.Value.$f
                    if ($null -ne $vv) { $ee[$f] = $vv }
                }
                if ($p.Value.compiti) { $ee['compiti'] = @($p.Value.compiti) }
                $pa[[string]$p.Name] = $ee
            }
            foreach ($k in @($pa.Keys)) {
                if (-not $config.provider_ai.ContainsKey($k)) { $config.provider_ai[$k] = @{} }
                foreach ($f in @($pa[$k].Keys)) { $config.provider_ai[$k][$f] = $pa[$k][$f] }
            }
        }
    } catch { }
}
$cfgLocalPath = Join-Path $base 'config.local.json'
if (Test-Path $cfgLocalPath) {
    try {
        $loc = Get-Content $cfgLocalPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @('provider','api_base','api_key','modello')) {
            if ($null -ne $loc.$k -and (([string]$loc.$k).Trim())) { $config[$k] = $loc.$k }
        }
        if ($loc.provider_ai) {
            foreach ($p in @($loc.provider_ai.PSObject.Properties)) {
                $id = [string]$p.Name
                if (-not $config.provider_ai.ContainsKey($id)) { continue }
                foreach ($f in @('chiave','endpoint','modello','abilitato')) {
                    $vv = $p.Value.$f
                    if ($null -ne $vv -and (([string]$vv).Trim() -or $f -eq 'abilitato')) { $config.provider_ai[$id][$f] = $vv }
                }
                if ($p.Value.compiti) { $config.provider_ai[$id]['compiti'] = @($p.Value.compiti) }
            }
        }
        try {
            if ($loc.gmail -and $loc.gmail.password) {
                if (-not $config.ContainsKey('gmail')) { $config['gmail'] = @{} }
                $config['gmail']['password'] = [string]$loc.gmail.password
            }
        } catch { }
        Write-Fase '2b/6 segreti locali letti (config.local.json)'
    } catch { Write-Fase '2b/6 config.local.json illeggibile: uso config.json' }
}
# --- v9: sezioni nuove (Ezappero, traccia, verita, documenti, gmail, automazioni) ---
if ($loaded) {
    foreach ($sez in @('ezappero', 'traccia', 'verita', 'documenti', 'gmail', 'ghost', 'sicurezza_agenti', 'orchestrazione', 'motore', 'memoria', 'gemini_sicurezza')) {
        $blk = $null
        try { $blk = $loaded.$sez } catch { $blk = $null }
        if ($blk) {
            if (-not $config.ContainsKey($sez) -or $null -eq $config[$sez]) { $config[$sez] = @{} }
            foreach ($pr in @($blk.PSObject.Properties)) {
                $config[$sez][[string]$pr.Name] = $pr.Value
            }
        }
    }
}
if ($NoVoice) { $config.voce.risposte_ad_alta_voce = $false }
# v7.9: AVVIA_ADMIN.bat avvia ZAP NON elevato (per non rompere il trascinamento dei
# file) e mette questo flag: i comandi che richiedono i privilegi vengono rieseguiti
# elevati al momento del bisogno.
$config.admin_su_richiesta = [bool]$Admin
if ((Get-ModalitaSequenza) -notcontains [string]$config.sicurezza) { $config.sicurezza = 'smart' }
Write-Fase '2/6 configurazione letta'

# --------------------------------------------------------------------------
# Stato condiviso (tutti i passaggi tra UI e agente avvengono SOLO via dati)
# --------------------------------------------------------------------------

$sync = [hashtable]::Synchronized(@{})
$sync.Base       = $base
$sync.CfgPath    = $cfgPath
$sync.Config     = $config
$sync.UiQueue    = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
$sync.InputQueue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[string]'
$sync.Quit       = $false
$sync.AvatarState  = 'neutro'
$sync.SpeakingTicks = 0
$sync.Listening  = $false
$sync.CurrentExec  = $null
$sync.Tts          = $null
$sync.Avatars      = @{}
$sync.ListenShell  = $null
$sync.ListenRunspace = $null
$sync.ListenHandle = $null
$sync.ListenStato  = 'spento'
$sync.ListenLivello = 0
$sync.ListenResult = $null
$sync.ListenStop   = $false
$sync.MicAttivo    = $false
$sync.MicEngine    = $null
$sync.MicTesto     = ''
$sync.MicInizio    = (Get-Date)
$sync.MicUltimoSuono = (Get-Date)
$sync.MicTimeout   = 12
$sync.MicSidLevel  = ''
$sync.MicSidDet    = ''
$sync.MicSidRec    = ''
$sync.MicModo      = 'spento'
$sync.MicFase      = ''
$sync.MicOperazione = $null
$sync.MicErrWinRT  = ''
$sync.MicErrLegacy = ''
$sync.AiActive     = $null
$sync.Allegati     = New-Object System.Collections.ArrayList
$sync.ConfirmRequest = $null
$sync.ConfirmResult  = $false
$sync.ConfirmDone    = $null

# --- v8: squadra di agenti + motore cinema (code verso i runspace) ---
$sync.AgenteQueue  = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
# v9.2: leggo subito gli agenti accesi da memory\agenti.json, cosi' il pannello
# a sinistra e il pulsante AGENTI in alto partono con lo STESSO numero.
try { $sync.AgentiAttivi = @(Import-AgentiAttivi $base) } catch { $sync.AgentiAttivi = @() }
$sync.SquadraStop  = $false
$sync.CineQueue    = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
$sync.CineStop     = $false

try { . (Join-Path $base 'brain\tools.ps1') } catch { Write-ModuloNonCaricato 'brain\tools.ps1' $_.Exception.Message }
try { . (Join-Path $base 'voice\tts.ps1') } catch { Write-ModuloNonCaricato 'voice\tts.ps1' $_.Exception.Message }
try { . (Join-Path $base 'voice\stt.ps1') } catch { Write-ModuloNonCaricato 'voice\stt.ps1' $_.Exception.Message }
try { . (Join-Path $base 'brain\llm.ps1') } catch { Write-ModuloNonCaricato 'brain\llm.ps1' $_.Exception.Message }
# v9.3: motore del nastro notizie (borsa + mondo)
try { . (Join-Path $base 'ui\ticker_news.ps1') } catch { Write-ModuloNonCaricato 'ui\ticker_news.ps1' $_.Exception.Message }
# v9.4: motore delle interfacce (skin)
try { . (Join-Path $base 'brain\skins.ps1') } catch { Write-ModuloNonCaricato 'brain\skins.ps1' $_.Exception.Message }

# --------------------------------------------------------------------------
# Finestra
# --------------------------------------------------------------------------

# v5: Get-TemaXaml ora vive in brain\tema.ps1, cosi' i test possono verificarla.

$temaAvvio = 'oro'   # grafica unica: scura con accenti oro
$xaml = Get-Content (Join-Path $base 'ui\window.xaml') -Raw -Encoding UTF8
$xaml = Get-TemaXaml $xaml $temaAvvio
try {
    $Window = [Windows.Markup.XamlReader]::Parse($xaml)
} catch {
    Write-Fase ('ERRORE nel caricare l''interfaccia ui\window.xaml: ' + $_.Exception.Message)
    throw
}
Write-Fase '3/6 interfaccia caricata'

$Avatar        = $Window.FindName('Avatar')
$OnomaText     = $Window.FindName('OnomaText')
$StatusText    = $Window.FindName('StatusText')
$ChatScroll    = $Window.FindName('ChatScroll')
$ChatPanel     = $Window.FindName('ChatPanel')
$InputBox      = $Window.FindName('InputBox')
$BtnInvia      = $Window.FindName('BtnInvia')
$BtnParla      = $Window.FindName('BtnParla')
$BtnInsegna    = $Window.FindName('BtnInsegna')
$BtnModo       = $Window.FindName('BtnModo')
$BtnImpostazioni = $Window.FindName('BtnImpostazioni')
$BtnFerma      = $Window.FindName('BtnFerma')
$SettingsPanel = $Window.FindName('SettingsPanel')
$TeachPanel    = $Window.FindName('TeachPanel')
$CfgNome       = $Window.FindName('CfgNome')
$CfgApiBase    = $Window.FindName('CfgApiBase')
$CfgApiKey     = $Window.FindName('CfgApiKey')
$CfgModello    = $Window.FindName('CfgModello')
$CfgBrowser    = $Window.FindName('CfgBrowser')
$CfgMotore     = $Window.FindName('CfgMotore')
$ModelInfo     = $Window.FindName('ModelInfo')
$BtnScaricaModello = $Window.FindName('BtnScaricaModello')
$CfgCartella   = $Window.FindName('CfgCartella')
$CfgVoce       = $Window.FindName('CfgVoce')
$BtnSalvaCfg   = $Window.FindName('BtnSalvaCfg')
$BtnChiudiCfg  = $Window.FindName('BtnChiudiCfg')
$TeachNome     = $Window.FindName('TeachNome')
$TeachQuando   = $Window.FindName('TeachQuando')
$TeachCodice   = $Window.FindName('TeachCodice')
$BtnSalvaTeach = $Window.FindName('BtnSalvaTeach')
$BtnChiudiTeach = $Window.FindName('BtnChiudiTeach')
# --- v5 ---
$BtnProgrammi   = $Window.FindName('BtnProgrammi')
$BtnAppunti     = $Window.FindName('BtnAppunti')
$AppuntiPanel   = $Window.FindName('AppuntiPanel')
$AppuntiBox     = $Window.FindName('AppuntiBox')
$BtnAppuntiSalva = $Window.FindName('BtnAppuntiSalva')
$BtnAppuntiChiudi = $Window.FindName('BtnAppuntiChiudi')
# (i pannelli v9 vengono creati piu' sotto, fuori da window.xaml)
$BtnAspetto     = $Window.FindName('BtnAspetto')
$AspettoPanel   = $Window.FindName('AspettoPanel')
$BtnTemaFoto    = $Window.FindName('BtnTemaFoto')
$PannelloSinistro = $Window.FindName('PannelloSinistro')
$AspSfondo      = $Window.FindName('AspSfondo')
$AspSuperficie  = $Window.FindName('AspSuperficie')
$AspCampo       = $Window.FindName('AspCampo')
$AspPill        = $Window.FindName('AspPill')
$AspAccento     = $Window.FindName('AspAccento')
$AspAccentoChiaro = $Window.FindName('AspAccentoChiaro')
$AspAccentoScuro  = $Window.FindName('AspAccentoScuro')
$AspArgento     = $Window.FindName('AspArgento')
$AspArgentoScuro = $Window.FindName('AspArgentoScuro')
$AspTesto       = $Window.FindName('AspTesto')
$AspTestoSuAccento = $Window.FindName('AspTestoSuAccento')
$AspBordo       = $Window.FindName('AspBordo')
$AspFont        = $Window.FindName('AspFont')
$AspSize        = $Window.FindName('AspSize')
$BtnAspApplica  = $Window.FindName('BtnAspApplica')
$BtnAspRipristina = $Window.FindName('BtnAspRipristina')
$BtnAspChiudi   = $Window.FindName('BtnAspChiudi')
$BtnTemaAura    = $Window.FindName('BtnTemaAura')
# v9.4: tasti accanto alla foto (nastro) e al suo fianco (skin)
$BtnNastro      = $Window.FindName('BtnNastro')
$BtnNastroText  = $Window.FindName('BtnNastroText')
$BtnSkin        = $Window.FindName('BtnSkin')
$BtnTemaNotte   = $Window.FindName('BtnTemaNotte')
$BtnTemaSmeraldo = $Window.FindName('BtnTemaSmeraldo')
$BtnTemaViola   = $Window.FindName('BtnTemaViola')
$BtnTemaChiaro  = $Window.FindName('BtnTemaChiaro')
$BtnAi          = $Window.FindName('BtnAi')
$AiPanel        = $Window.FindName('AiPanel')
$AiList         = $Window.FindName('AiList')
$AiIntro        = $Window.FindName('AiIntro')
$AiSel          = $Window.FindName('AiSel')
$BtnChiudiAi    = $Window.FindName('BtnChiudiAi')
$BtnAiSalvaTutti = $Window.FindName('BtnAiSalvaTutti')
$BtnAiAiutoChiavi = $Window.FindName('BtnAiAiutoChiavi')
$ProgrammiPanel = $Window.FindName('ProgrammiPanel')
$ProgElenco     = $Window.FindName('ProgElenco')
$ProgCombo      = $Window.FindName('ProgCombo')
$ProgInfo       = $Window.FindName('ProgInfo')
$BtnProgAvvia   = $Window.FindName('BtnProgAvvia')
$BtnProgAggiorna= $Window.FindName('BtnProgAggiorna')
$BtnProgCartella= $Window.FindName('BtnProgCartella')
$BtnChiudiProg  = $Window.FindName('BtnChiudiProg')
$MicLevel       = $Window.FindName('MicLevel')
$MicText        = $Window.FindName('MicText')
# --- upload / allegati ---
$BtnAllegati    = $Window.FindName('BtnAllegati')
$BtnFoto        = $Window.FindName('BtnFoto')
$BtnVideo       = $Window.FindName('BtnVideo')
$AllegatiBar    = $Window.FindName('AllegatiBar')
$AllegatiInfo   = $Window.FindName('AllegatiInfo')
$Trasparenza      = $Window.FindName('Trasparenza')
$TrasparenzaLabel = $Window.FindName('TrasparenzaLabel')
$TitleBarDrag     = $Window.FindName('TitleBarDrag')
$BtnWinMin        = $Window.FindName('BtnWinMin')
$BtnWinMax        = $Window.FindName('BtnWinMax')
$BtnWinClose      = $Window.FindName('BtnWinClose')
$BtnAutomazioni   = $Window.FindName('BtnAutomazioni')
$AutomazioniPanel = $Window.FindName('AutomazioniPanel')
$AutoList         = $Window.FindName('AutoList')
$AutoDescr        = $Window.FindName('AutoDescr')
$BtnAutoCrea      = $Window.FindName('BtnAutoCrea')
$BtnAutoAggiorna  = $Window.FindName('BtnAutoAggiorna')
$BtnAutoChiudi    = $Window.FindName('BtnAutoChiudi')
$BtnKali          = $Window.FindName('BtnKali')
$KaliPanel        = $Window.FindName('KaliPanel')
$KaliStatus       = $Window.FindName('KaliStatus')
$KaliOut          = $Window.FindName('KaliOut')
$KaliCmd          = $Window.FindName('KaliCmd')
$BtnKaliEsegui    = $Window.FindName('BtnKaliEsegui')
$KaliTools        = $Window.FindName('KaliTools')
$BtnKaliInstalla  = $Window.FindName('BtnKaliInstalla')
$BtnKaliSetup     = $Window.FindName('BtnKaliSetup')
$BtnKaliAggiorna  = $Window.FindName('BtnKaliAggiorna')
$BtnKaliChiudi    = $Window.FindName('BtnKaliChiudi')

# ============================================================
# v8.1 - MODALITA' ICONA (MINI): finestra compatta agganciata a destra
# Portata dalla v7.9.10 senza toccare squadra di agenti e motore CINEMA.
# ============================================================
$BtnMini        = $Window.FindName('BtnMini')
$BtnPin         = $Window.FindName('BtnPin')
$ColSinistro    = $Window.FindName('ColSinistro')
$LogoZap        = $Window.FindName('LogoZap')
$TopComandi     = $Window.FindName('TopComandi')
$RigaAllegati   = $Window.FindName('RigaAllegati')
$RigaExtra      = $Window.FindName('RigaExtra')
$TrasparenzaBox = $Window.FindName('TrasparenzaBox')

$script:MiniOn    = $false
$script:MiniPin   = $true
$script:MiniStato = $null

function Set-ColSinistro {
    param([double]$Larghezza)
    try {
        if ($ColSinistro) { $ColSinistro.Width = [System.Windows.GridLength]::new([double]$Larghezza); return }
        if ($PannelloSinistro -and $PannelloSinistro.Parent -and ($PannelloSinistro.Parent.ColumnDefinitions.Count -ge 1)) {
            $PannelloSinistro.Parent.ColumnDefinitions[0].Width = [System.Windows.GridLength]::new([double]$Larghezza)
        }
    } catch { }
}

function Aggiorna-BtnPin {
    if ($BtnPin) {
        if ($script:MiniPin) { $BtnPin.Content = 'PIN: ON' } else { $BtnPin.Content = 'PIN: OFF' }
    }
}

function Set-MiniMode {
    param([bool]$Attiva)
    if ($Attiva) {
        $script:MiniStato = @{
            Left    = [double]$Window.Left
            Top     = [double]$Window.Top
            Width   = [double]$Window.Width
            Height  = [double]$Window.Height
            Stato   = [string]$Window.WindowState
            Topmost = [bool]$Window.Topmost
        }
        if ($Window.WindowState -eq 'Maximized') { $Window.WindowState = 'Normal' }
        $wa = [System.Windows.SystemParameters]::WorkArea
        $larg = [int][Math]::Round($wa.Width * 0.22)
        if ($larg -lt 340) { $larg = 340 }
        if ($larg -gt 560) { $larg = 560 }
        $Window.MinWidth  = 320
        $Window.MinHeight = 360
        $Window.Width  = [double]$larg
        $Window.Height = [double]$wa.Height
        $Window.Left   = [double]($wa.Right - $larg)
        $Window.Top    = [double]$wa.Top
        $script:MiniPin = $true
        $Window.Topmost = $true
        Aggiorna-BtnPin
        Set-ColSinistro 0
        if ($PannelloSinistro) { $PannelloSinistro.Visibility = 'Collapsed' }
        if ($LogoZap) { $LogoZap.Visibility = 'Collapsed' }
        if ($TopComandi) {
            foreach ($el in $TopComandi.Children) {
                if (($el -eq $BtnMini) -or ($el -eq $BtnPin)) { $el.Visibility = 'Visible' }
                else { $el.Visibility = 'Collapsed' }
            }
        }
        if ($BtnPin) { $BtnPin.Visibility = 'Visible' }
        if ($RigaAllegati) { $RigaAllegati.Visibility = 'Collapsed' }
        if ($RigaExtra)    { $RigaExtra.Visibility = 'Collapsed' }
        if ($AllegatiBar)  { $AllegatiBar.Visibility = 'Collapsed' }
        if ($TrasparenzaBox) { $TrasparenzaBox.Visibility = 'Collapsed' }
        if ($BtnMini) { $BtnMini.Content = 'APRI' }
        $script:MiniOn = $true
        try { Add-Activity '- modalita icona: finestra compatta a destra -' } catch { }
    } else {
        Set-ColSinistro 340
        if ($PannelloSinistro) { $PannelloSinistro.Visibility = 'Visible' }
        if ($LogoZap) { $LogoZap.Visibility = 'Visible' }
        if ($TopComandi) { foreach ($el in $TopComandi.Children) { $el.Visibility = 'Visible' } }
        if ($BtnPin) { $BtnPin.Visibility = 'Collapsed' }
        if ($RigaAllegati) { $RigaAllegati.Visibility = 'Visible' }
        if ($RigaExtra)    { $RigaExtra.Visibility = 'Visible' }
        if ($TrasparenzaBox) { $TrasparenzaBox.Visibility = 'Visible' }
        $Window.MinWidth  = 820
        $Window.MinHeight = 620
        $st = $script:MiniStato
        if ($st) {
            $Window.Width   = $st.Width
            $Window.Height  = $st.Height
            $Window.Left    = $st.Left
            $Window.Top     = $st.Top
            $Window.Topmost = $st.Topmost
            if ($st.Stato -eq 'Maximized') { $Window.WindowState = 'Maximized' }
        }
        if ($BtnMini) { $BtnMini.Content = 'MINI' }
        $script:MiniOn = $false
    }
}

function Toggle-MiniMode { Set-MiniMode (-not [bool]$script:MiniOn) }

if ($BtnMini) { $BtnMini.Add_Click({ try { Toggle-MiniMode } catch { } }) }
if ($BtnPin)  { $BtnPin.Add_Click({ $script:MiniPin = -not [bool]$script:MiniPin; $Window.Topmost = [bool]$script:MiniPin; Aggiorna-BtnPin }) }
Aggiorna-BtnPin
# ============================================================

Write-Fase '4/6 controlli collegati'

# v6.5: palette (tema/colori) salvata dall'utente -> la applico subito alla finestra
$sync.PaletteCorr = Get-PaletteDefault
$sync.Palette     = Merge-Palette $sync.Config.aspetto
try { Applica-Palette $sync $Window $sync.Palette } catch { }
try { Asp-ApplicaSfondo $sync ([string]$sync.Palette.sfondoImmagine) } catch { }
# v8.1: se lo schermo e' piccolo la finestra si apre gia' adatta (non a tutto schermo)
try {
    $wa0 = [System.Windows.SystemParameters]::WorkArea
    if ($Window.Width  -gt ($wa0.Width  - 40)) { $Window.Width  = [double][Math]::Max(820, ($wa0.Width  - 40)) }
    if ($Window.Height -gt ($wa0.Height - 60)) { $Window.Height = [double][Math]::Max(560, ($wa0.Height - 60)) }
} catch { }

# v6.6: riprendo il modello che ha gia' funzionato -> nessuna caccia ai modelli ad ogni messaggio
try { $sync.ModelloOk = Get-ModelloSalvato $sync } catch { }

$scale = New-Object System.Windows.Media.ScaleTransform
$Avatar.RenderTransform = $scale

# Immagini avatar
$imgMap = @{ neutro = 'robot.png'; parla = 'robot_parla.png'; pensa = 'robot_pensa.png' }
foreach ($k in $imgMap.Keys) {
    $imgPath = Join-Path $base ('ui\avatar\' + $imgMap[$k])
    if (Test-Path $imgPath) {
        try {
            $bi = New-Object System.Windows.Media.Imaging.BitmapImage
            $bi.BeginInit()
            $bi.UriSource = New-Object System.Uri($imgPath)
            $bi.CacheOption = 'OnLoad'
            $bi.EndInit()
            $bi.Freeze()
            $sync.Avatars[$k] = $bi
        } catch { }
    }
}

# --------------------------------------------------------------------------
# Funzioni UI (solo sul thread grafico)
# --------------------------------------------------------------------------

function Set-AvatarState {
    param([string]$State)
    if ($State -eq 'ok') { $State = 'neutro' }
    if (-not $sync.Avatars.ContainsKey($State)) { $State = 'neutro' }
    $sync.AvatarState = $State
    if ($sync.Avatars[$State]) { $Avatar.Source = $sync.Avatars[$State] }

    $da = New-Object System.Windows.Media.Animation.DoubleAnimation
    $da.From = 0.9
    $da.To = 1.0
    $da.Duration = New-Object System.Windows.Duration([TimeSpan]::FromMilliseconds(220))
    $scale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleXProperty, $da)
    $scale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleYProperty, $da.Clone())
}

function Add-MenuVoce {
    param($menu, [string]$testo, $comando)
    $mi = New-Object System.Windows.Controls.MenuItem
    $mi.Header = $testo
    $mi.Command = $comando
    [void]$menu.Items.Add($mi)
}

function Set-TextBoxCopyMenu {
    # v6: sulle risposte di ZAP si puo' selezionare e copiare (menu tasto destro).
    param($tb)
    $menu = New-Object System.Windows.Controls.ContextMenu
    Add-MenuVoce $menu 'Copia' ([System.Windows.Input.ApplicationCommands]::Copy)
    Add-MenuVoce $menu 'Seleziona tutto' ([System.Windows.Input.ApplicationCommands]::SelectAll)
    $tb.ContextMenu = $menu
}

function Set-InputTextMenu {
    # v6: copia/incolla espliciti sul campo dove scrivi (oltre a Ctrl+C / Ctrl+V nativi).
    param($tb)
    $menu = New-Object System.Windows.Controls.ContextMenu
    Add-MenuVoce $menu 'Taglia' ([System.Windows.Input.ApplicationCommands]::Cut)
    Add-MenuVoce $menu 'Copia' ([System.Windows.Input.ApplicationCommands]::Copy)
    Add-MenuVoce $menu 'Incolla' ([System.Windows.Input.ApplicationCommands]::Paste)
    Add-MenuVoce $menu 'Seleziona tutto' ([System.Windows.Input.ApplicationCommands]::SelectAll)
    $tb.ContextMenu = $menu
}

$script:LiveBorder = $null
$script:LiveText   = $null

function Get-LiveBubble {
    # Bolla temporanea in cui si scrive il testo mentre arriva (streaming). Viene
    # tolta e sostituita dalla bolla definitiva quando la risposta e' completa.
    param($Pal)
    if ($script:LiveBorder) { return $script:LiveBorder }
    $b = New-Object System.Windows.Controls.Border
    $b.CornerRadius = '14'
    $b.BorderThickness = '1.5'
    $b.BorderBrush = [string]$Pal.accentoScuro
    $b.Background = [string]$Pal.accentoChiaro
    $b.Padding = '12,8,12,8'
    $b.MaxWidth = 640
    $b.HorizontalAlignment = 'Left'
    $b.Margin = '0,6,60,6'
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.TextWrapping = 'Wrap'
    $tb.FontSize = 14
    $tb.IsReadOnly = $true
    $tb.BorderThickness = '0'
    $tb.Background = 'Transparent'
    $tb.Padding = '0'
    $tb.Margin = '0'
    $tb.IsTabStop = $false
    $tb.VerticalScrollBarVisibility = 'Disabled'
    $tb.HorizontalScrollBarVisibility = 'Disabled'
    $tb.Foreground = [string]$Pal.testoSuAccento
    Set-TextBoxCopyMenu $tb
    $b.Child = $tb
    [void]$ChatPanel.Children.Add($b)
    $script:LiveBorder = $b
    $script:LiveText = $tb
    return $b
}

function Add-LiveBubble {
    param([string]$Text)
    $pal = $sync.Palette
    if (-not $pal) { $pal = Get-PaletteDefault }
    [void](Get-LiveBubble $pal)
    if ($script:LiveText) { $script:LiveText.Text = $Text }
}

function Clear-LiveBubble {
    if ($script:LiveBorder) {
        try { [void]$ChatPanel.Children.Remove($script:LiveBorder) } catch { }
    }
    $script:LiveBorder = $null
    $script:LiveText = $null
}

function Add-Bubble {
    param([string]$Who, [string]$Text)
    if (-not $Text) { return }
    $pal = $sync.Palette
    if (-not $pal) { $pal = Get-PaletteDefault }

    $b = New-Object System.Windows.Controls.Border
    $b.CornerRadius = '14'
    $b.BorderThickness = '1.5'
    # v9.4.2: colore validato prima di arrivare a WPF (era il crash all'avvio)
    $colBordo = ([string]$pal.bordo).Trim()
    if ($colBordo -notmatch '^#[0-9A-Fa-f]{6}$') { $colBordo = '#2A323D' }
    $b.BorderBrush = $colBordo
    $b.Padding = '12,8,12,8'
    $b.MaxWidth = 640

    # v6: era un TextBlock (non copiabile). Ora e' un campo di testo in sola lettura:
    # si seleziona e si copia (Ctrl+C oppure tasto destro -> Copia).
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = $Text
    $tb.TextWrapping = 'Wrap'
    $tb.FontSize = 14
    $tb.IsReadOnly = $true
    $tb.BorderThickness = '0'
    $tb.Background = 'Transparent'
    $tb.Padding = '0'
    $tb.Margin = '0'
    $tb.IsTabStop = $false
    $tb.VerticalScrollBarVisibility = 'Disabled'
    $tb.HorizontalScrollBarVisibility = 'Disabled'
    Set-TextBoxCopyMenu $tb

    if ($Who -eq 'utente') {
        # bolla utente: grigio-antracite, testo chiaro (contrasto alto = sempre leggibile)
        $b.Background = [string]$pal.pill
        # v9.4.2: colore validato prima di arrivare a WPF (era il crash all'avvio)
    $colBordo = ([string]$pal.bordo).Trim()
    if ($colBordo -notmatch '^#[0-9A-Fa-f]{6}$') { $colBordo = '#2A323D' }
    $b.BorderBrush = $colBordo
        $b.HorizontalAlignment = 'Left'
        $b.Margin = '12,6,80,6'
        $tb.Foreground = [string]$pal.testo
        $tb.FontWeight = 'SemiBold'
        $b.Child = $tb
        [void]$ChatPanel.Children.Add($b)
    }
    else {
        # bolla ZAP: ORO con testo SCURO (nero su oro = leggibilita' massima), preceduta dal clown
        $b.Background = [string]$pal.accentoChiaro
        $b.BorderBrush = [string]$pal.accentoScuro
        $b.HorizontalAlignment = 'Left'
        $b.Margin = '0,6,60,6'
        $tb.Foreground = [string]$pal.testoSuAccento
        $b.Child = $tb
        $riga = New-Object System.Windows.Controls.Grid
        $riga.Margin = '0'
        $c0 = New-Object System.Windows.Controls.ColumnDefinition
        $c0.Width = 'Auto'
        $c1 = New-Object System.Windows.Controls.ColumnDefinition
        $c1.Width = '*'
        [void]$riga.ColumnDefinitions.Add($c0)
        [void]$riga.ColumnDefinitions.Add($c1)
        $av = New-Object System.Windows.Controls.Image
        $av.Width = 34
        $av.Height = 34
        $av.Stretch = 'UniformToFill'
        $av.VerticalAlignment = 'Top'
        $av.Margin = '12,6,8,0'
        if ($sync.Avatars -and $sync.Avatars['neutro']) { $av.Source = $sync.Avatars['neutro'] }
        $clip = New-Object System.Windows.Media.EllipseGeometry
        $clip.Center = [System.Windows.Point]::new(17.0, 17.0)
        $clip.RadiusX = 17.0
        $clip.RadiusY = 17.0
        $av.Clip = $clip
        [System.Windows.Controls.Grid]::SetColumn($av, 0)
        [System.Windows.Controls.Grid]::SetColumn($b, 1)
        [void]$riga.Children.Add($av)
        [void]$riga.Children.Add($b)
        [void]$ChatPanel.Children.Add($riga)
    }
    $ChatScroll.ScrollToEnd()
}

function Add-Activity {
    param([string]$Text)
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = $Text
    $tb.FontSize = 11
    $tb.FontStyle = 'Italic'
    $tb.Foreground = [string]$sync.Palette.argentoScuro
    $tb.TextWrapping = 'Wrap'
    $tb.Margin = '18,2,18,2'
    $tb.IsReadOnly = $true
    $tb.BorderThickness = '0'
    $tb.Background = 'Transparent'
    $tb.Padding = '0'
    $tb.IsTabStop = $false
    $tb.VerticalScrollBarVisibility = 'Disabled'
    $tb.HorizontalScrollBarVisibility = 'Disabled'
    Set-TextBoxCopyMenu $tb
    [void]$ChatPanel.Children.Add($tb)
    $ChatScroll.ScrollToEnd()
}

function Show-Onomatopea {
    param([string]$Word)
    if (-not $Word) {
        $Word = @('POW!', 'ZAP!', 'BAM!', 'WHAM!', 'BOOM!', 'CLICK!', 'TAP!') | Get-Random
    }
    $OnomaText.Text = $Word
    $OnomaText.Opacity = 1.0
    $fade = New-Object System.Windows.Media.Animation.DoubleAnimation
    $fade.From = 1.0
    $fade.To = 0.0
    $fade.BeginTime = [TimeSpan]::FromMilliseconds(500)
    $fade.Duration = New-Object System.Windows.Duration([TimeSpan]::FromMilliseconds(1300))
    $OnomaText.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $fade)
}

function Update-MicLabel {
    # v6.1: indicatore del microfono. Con il motore MODERNO di Windows non esiste un
    # livello da mostrare: si legge lo stato (il motore moderno non espone il volume).
    if (-not $MicText) { return }
    if ($sync.Listening) {
        $st = ''
        try { $st = [string]$sync.ListenStato } catch { }
        if (-not $st) { $st = 'ascolto...' }
        $modo = ''
        try { $modo = [string]$sync.MicModo } catch { }
        if ($modo -eq 'winrt') { $st = $st + '  (motore moderno)' }
        elseif ($modo -eq 'storico') { $st = $st + '  (motore storico)' }
        $MicText.Text = ('MICROFONO: ' + $st)
        if ($MicLevel) {
            $lv = 0
            try { $lv = [int]$sync.ListenLivello } catch { }
            if ($lv -lt 0) { $lv = 0 }
            $MicLevel.Value = [Math]::Min(100, [Math]::Max(0, $lv))
        }
    } else {
        $MicText.Text = 'MICROFONO: spento'
        if ($MicLevel) { $MicLevel.Value = 0 }
    }
}

function Update-ModeButton {
    $m = [string]$sync.Config.sicurezza
    if ((Get-ModalitaSequenza) -notcontains $m) { $m = 'smart' }
    $sync.Config.sicurezza = $m
    $BtnModo.Content = (Get-ModalitaEtichetta $m)
    $BtnModo.ToolTip = ('Modalita: ' + (Get-ModalitaEtichetta $m) + ' - clicca per cambiare')
    $BtnModo.Background = (Get-ModalitaColore $m)
    switch ($m) {
        'prudente'      { $BtnModo.Foreground = '#F0E9D8' }
        'libera'        { $BtnModo.Foreground = '#F0E9D8' }
        'sviluppatore'  { $BtnModo.Foreground = '#F0E9D8' }
        'hacker'        { $BtnModo.Foreground = '#39FF14' }
        'ghost'         { $BtnModo.Foreground = '#0A0A0A' }
        default         { $BtnModo.Foreground = '#1A1408' }
    }
    $InputBox.ToolTip = ''
    try { Update-MicLabel } catch { }
}

function Set-Mode {
    param([string]$M, [string]$Pin = '')
    $M = ([string]$M).Trim().ToLower()
    if ((Get-ModalitaSequenza) -notcontains $M) { $M = 'smart' }
    $sync.Config.sicurezza = $M
    Update-ModeButton
    Save-Config $sync
    Add-Bubble 'zap' (Get-ModalitaDescrizione $M)
    if ($m -eq 'sviluppatore')  { Add-Activity '- sviluppatore: autonomia piena, retry sui rifiuti -' }
    if ($m -eq 'hacker')        { Add-Activity '- hacker: nessun limite, pentest+OSINT (solo sistemi tuoi) -' }
}

function Switch-Mode {
    $seq = Get-ModalitaSequenza
    $cur = [string]$sync.Config.sicurezza
    $i = [array]::IndexOf($seq, $cur)
    if ($i -lt 0) { $i = 1 }
    $next = $seq[($i + 1) % $seq.Count]
    Set-Mode $next
}

function Test-DomandaIdentita {
    # v9.6.8 -- chiede "con che modello parlo?" -> risposta LOCALE, senza chiamare l'IA.
    # Motivo: al modello veniva chiesto di leggere i file, e finiva per rispondere
    # "non lo so" oppure per cercare in disco (spendendo token). Il dato ce l'ha ZAP.
    param([string]$Testo)
    if (-not $Testo) { return $false }
    $t = $Testo.Trim().ToLower()
    if ($t.Length -gt 140) { return $false }
    # se chiede di FARE qualcosa, non e' una domanda sull'identita'
    if ($t -match '\b(crea|creami|scrivi|scrivimi|fai|fammi|genera|apri|cerca|cercami|traduci|spiega|riassumi|installa|configura)\b') { return $false }
    # forme dirette e brevi: "chi sei?", "chi mi sta rispondendo?", "sei gemini o claude?"
    if ($t -match '^\s*chi\s+(sei|parla|mi\s+sta|mi\s+risponde|ti\s+ha)') { return $true }
    if ($t -match '^\s*con\s+chi\b') { return $true }
    if ($t -match '^\s*(sei|ma\s+sei)\s+(tu\s+)?(un\s+)?(gemini|claude|deepseek|perplexity|qwen|openai)') { return $true }
    if ($t -match '\bsei\s+(gemini|claude|deepseek|perplexity|qwen)\b') { return $true }
    if ($t -match '^\s*(che|quale)\s+(ia|intelligenza)\b') { return $true }
    $chi = ($t -match 'modello|intelligenz|\bservizio\b|\bprovider\b|\bia\b|gemini|deepseek|claude|anthropic|perplexity|qwen|ollama|rispond|interloc')
    $domanda = ($t -match 'con che|con quale|quale|chi sei|chi sta|chi mi|stai usando|sto parlando|parlando con|interagendo|dimmi|sai|dirmi')
    if (-not ($chi -and $domanda)) { return $false }
    return $true
}

function Format-IdentitaAttiva {
    # Risposta pronta, calcolata dai file di ZAP. Nessun token speso.
    $ia = Get-AiAttiva $sync
    $riga = 'Stai parlando con ' + [string]$ia.nome
    if ($ia.modello) { $riga = $riga + ' — modello ' + [string]$ia.modello }
    $riga = $riga + '.'
    $modo = 'AUTOMATICO (ZAP sceglie: prima Gemini, poi DeepSeek)'
    try {
        $m = [string]$sync.Config.modalita_ai
        if ($m -and $m.Trim().ToLower() -ne 'auto') { $modo = 'scelta fissa: ' + $m.Trim() }
    } catch { }
    $riga = $riga + [Environment]::NewLine + 'Selezione: ' + $modo + '.'
    # controllo dei motori locali: Ollama non e' contattabile
    $locali = @()
    try {
        foreach ($k in @($sync.Config.provider_ai.Keys)) {
            $ep = [string]$sync.Config.provider_ai[$k]['endpoint']
            if ($ep -and (Get-Command Test-MotoreLocale -ErrorAction SilentlyContinue)) {
                if (Test-MotoreLocale $ep) { $locali += [string]$k }
            }
        }
    } catch { }
    if ($locali.Count -gt 0) {
        $riga = $riga + [Environment]::NewLine + 'ATTENZIONE: motore locale bloccato per: ' + ($locali -join ', ') + '.'
    } else {
        $riga = $riga + [Environment]::NewLine + 'Ollama (motore locale): disattivato, non viene contattato.'
    }
    $pronti = @()
    try { $pronti = @(Get-AiPronti $sync) } catch { }
    if ($pronti.Count -gt 0) {
        $riga = $riga + [Environment]::NewLine + 'Servizi pronti: ' + ($pronti -join ', ') + '.'
    }
    return $riga
}

function Send-UserText {
    param([string]$Text)
    if (-not $Text) { return }
    $t = $Text.Trim()
    if (-not $t) { return }

    if ($t.StartsWith('/')) {
        Handle-Command $t
        return
    }

    Add-Bubble 'utente' $t

    # v9.6.8 -- DOMANDA SU CHI STA PARLANDO: risponde ZAP, non il modello.
    # Nessun token speso, nessuna attesa, e la risposta non puo' essere sbagliata.
    if (Test-DomandaIdentita $t) {
        Add-Bubble 'zap' (Format-IdentitaAttiva)
        return
    }

    # v7.9.3: se hai allegato una FOTO e mi chiedi un tema/look, creo il tema dai suoi colori.
    $chiedeTema = ($t -match '(?i)\b(tema|aspetto|look)\b') -or (($t -match '(?i)\b(crea|creami|fai|famme|cambia|cambiami|fammi)\b') -and ($t -match '(?i)\bcolori?\b'))
    if ($chiedeTema) {
        $foto = ''
        foreach ($a in @($sync.Allegati)) {
            $pp = ''
            try { $pp = [string]$a.Percorso } catch { }
            if ($pp -and (Test-Path $pp) -and ((Get-TipoAllegato $pp) -eq 'immagine')) { $foto = $pp; break }
        }
        if ($foto) { Asp-TemaDaFoto $foto; return }
    }

    # ---- v8: la SQUADRA DI AGENTI -------------------------------------
    try {
        $ia = Test-IntentoAgenti $t @($sync.AgentiAttivi)
        if ($ia.Gestito) {
            if ($ia.Tipo -eq 'toggle') {
                $attiva = ($ia.Messaggio -eq 'attivo')
                $nomiFatti = @()
                foreach ($idAg in @($ia.Agenti)) {
                    $ag = Get-AgenteById $idAg
                    if (-not $ag) { continue }
                    Set-AgenteStatoUI $ag.id $attiva
                    $nomiFatti += $ag.nome
                }
                if ($nomiFatti.Count -gt 0) {
                    $elenco = ($nomiFatti -join ', ')
                    if ($attiva) {
                        Add-Bubble 'zap' ('Squadra: ' + $elenco + ' ATTIVI. Da adesso lavorano con te.')
                    } else {
                        Add-Bubble 'zap' ('Squadra: ' + $elenco + ' spenti.')
                    }
                    $StatusText.Text = 'SQUADRA AGGIORNATA'
                }
                return
            }
            if ($ia.Tipo -eq 'run') {
                $avviata = Start-SquadraAgenti -sync $sync -Testo $t -Agenti $ia.Agenti -Base $base
                if ($avviata) {
                    $parole = @()
                    foreach ($idAg in @($ia.Agenti)) {
                        $ag = Get-AgenteById $idAg
                        if ($ag) { $parole += $ag.nome }
                    }
                    Add-Activity ('- squadra al lavoro: ' + ($parole -join ' - ') + ' -')
                    $StatusText.Text = 'SQUADRA AL LAVORO...'
                    Set-AvatarState 'pensa'
                    return
                }
            }
        }
    } catch {
        Add-Activity ('- squadra non disponibile: ' + $_.Exception.Message + ' -')
    }

    # v5: comandi diretti (apri/chiudi/scrivi/lancia/cerca) eseguiti SUBITO, senza giro sull'IA.
    try {
        $dc = Invoke-ComandoDiretto -sync $sync -Testo $t
        if ($dc.Gestito) {
            if ($dc.Messaggio) { Add-Bubble 'zap' ([string]$dc.Messaggio) }
            try { $sync.UiQueue.Enqueue(@{ Type = 'speak'; Data = [string]$dc.Messaggio }) } catch { }
            $StatusText.Text = 'FATTO!'
            Set-AvatarState 'ok'
            return
        }
    } catch {
        Add-Activity ('- comando diretto non riuscito: ' + $_.Exception.Message + ' -')
    }

    # v6.1: gli allegati vengono letti (e le immagini guardate) e passati allo ZAP.
    $extra = ''
    try { $extra = Get-AllegatiPerIA $sync } catch { }
    if ($extra) {
        Add-Activity ('- allegati passati allo ZAP (' + $sync.Allegati.Count + ') -')
        Svuota-Allegati $sync
    }
    $sync.InputQueue.Enqueue($t + $extra)
    $StatusText.Text = 'HO RICEVUTO! PENSO...'
}

function Handle-Command {
    param([string]$Cmd)
    $parts = $Cmd -split '\s+', 2
    switch ($parts[0].ToLower()) {
        '/aiuto' {
            $h = @()
            $h += 'COMANDI RAPIDI'
            $h += '/skills - elenco delle cose che ho imparato'
            $h += '/insegna - insegnami una cosa nuova'
            $h += '/mode - cambia modalita (prudente, smart, libera, sviluppatore, enterprise, hacker)'
            $h += '/simula - SIMULAZIONE: non eseguo, ti mostro solo cosa farei (dry-run)'
            $h += '/audit - ultime azioni registrate (scatola nera);  /audit verifica - controlla che il registro non sia stato manomesso'
            $h += '/policy - permessi granulari (proteggi cartelle, consenti cartelle) e stato'
            $h += '/sandbox - modalita isolata (sandbox di sistema: limiti + chiusura garantita) on|off'
            $h += '/allegati - scegli uno o piu file da guardare ed elaborare (foto, video, PDF, documenti)'
            $h += '/foto - scegli una o piu immagini'
            $h += '/video - scegli uno o piu video'
            $h += '/allegati-vuota - togli tutti gli allegati'
            $h += '/appunti - apri il blocco appunti (resta salvato)'
            $h += '/impara-schermo - imparo guardando lo schermo'
            $h += '/migliorati - trucchi e opzioni per rendermi migliore'
            $h += '/admin - permessi di amministratore'
            $h += '/tema - apri il pannello tema e colori'
            $h += '/tema-foto - crea il tema dai colori di una FOTO che alleghi'
            $h += '/programmi - i tuoi programmi, da lanciare con un clic'
            $h += '/automazioni - elenco di cose da far fare a ZAP da solo'
            $h += '/kali - console e strumenti Kali Linux (ethical hacking)'
            $h += '/hacker - modalita HACKER: nessun limite, pentest + OSINT (solo su TUOI sistemi)'
            $h += '/osint <dominio|ip|email|username|metadati> <bersaglio> - ricognizione passiva da fonti pubbliche'
            $h += '/mini <compito> - crea un mini-agente PowerShell leggero (bassa RAM)'
            $h += '/mic - diagnostica del microfono'
            $h += '/ai auto|stato|<servizio> - quale cervello IA usare (es. /ai openai)'
            $h += '/squadra on|off|stato - tutte le intelligenze insieme in una sola risposta'
            $h += '/ps - libreria PowerShell (il pulsante in alto e stato tolto)'
            $h += '/ghost - modalita GHOST: stato, modo chiuso|aula|aperto, aggiungi <sito>, file, test <comando>'
            $h += '/agenti - VERIFICA LAVORO AGENTI: cabina di regia in tempo reale'
            $h += '/ferma-agente <nome> - ferma un solo agente (dalla cabina o da qui)'
            $h += '/strumenti - stato degli strumenti di pentest; /strumenti installa per metterli in piedi'
            $h += '/aula - kit didattico: scenari, checklist, difese (aulakit)'
            $h += '/pentest copertura - tutti gli strumenti disponibili per categoria'
            $h += '/ferma - ferma tutto'
            $h += '/vuota - svuota la chat'
            $h += ''
            $h += 'A voce o per scritto: "chiudi questa pagina", "aprimi il blocco note", "lancia il mio backup", "apri WhatsApp e scrivi a Mario: ci vediamo alle 8".'
            Add-Bubble 'zap' ($h -join "`n")
        }
        '/skills' {
            Add-Bubble 'zap' (Format-SkillList $sync)
        }
        '/insegna' {
            $TeachPanel.Visibility = 'Visible'
            $TeachNome.Focus()
        }
        '/ps' {
            # v9.5: il pulsante PS non e' piu in alto; il pannello si apre da qui
            try {
                if ($PsPanel) { $PsPanel.Visibility = 'Visible'; Ps-Ricarica '' }
                else { Add-Bubble 'zap' 'Pannello PowerShell non disponibile in questa versione.' }
            } catch { Add-Bubble 'zap' ('Pannello PowerShell: ' + $_.Exception.Message) }
        }
        '/squadra' {
            # v9.5: tutte le intelligenze insieme, accese o spente
            $p = ''
            if ($parts.Count -gt 1) { $p = ([string]$parts[1]).Trim().ToLower() }
            if ($p -eq 'on' -or $p -eq 'accesa' -or $p -eq 'acceso') {
                [void](Set-OrchestraAttiva $sync $true)
                Add-Bubble 'zap' ('SQUADRA IA ACCESA.' + "`n`n" + (Format-OrchestraStato $sync))
            }
            elseif ($p -eq 'off' -or $p -eq 'spenta' -or $p -eq 'spento') {
                [void](Set-OrchestraAttiva $sync $false)
                Add-Bubble 'zap' 'SQUADRA IA SPENTA: risponde una sola intelligenza (quella scelta da ZAP).'
            }
            else {
                Add-Bubble 'zap' (Format-OrchestraStato $sync)
            }
            try { Update-IntelligenzePadrone } catch { }
        }
        '/chi' {
            Add-Bubble 'zap' (Format-IdentitaAttiva)
            return
        }
        '/motore' {
            Add-Bubble 'zap' (Format-IdentitaAttiva)
            return
        }
        '/ai' {
            $p = ''
            if ($parts.Count -gt 1) { $p = [string]$parts[1] }
            $p = $p.Trim().ToLower()
            if (-not $p -or $p -eq 'auto') {
                $sync.Config.modalita_ai = 'auto'
                Save-Config $sync
                Aggiorna-AiCombo
                Add-Bubble 'zap' ('IA in AUTOMATICO: scelgo io il servizio in base al lavoro.' + "`n`n" + (Get-AiRouterText $sync))
            }
            elseif ($p -eq 'stato') {
                Add-Bubble 'zap' (Get-AiRouterText $sync)
            }
            elseif (Get-ProviderById $p) {
                $sync.Config.modalita_ai = $p
                Save-Config $sync
                Aggiorna-AiCombo
                Add-Bubble 'zap' ('IA fissata su ' + $p + '. ' + (Get-ProviderStato $sync $p))
            }
            else {
                Add-Bubble 'zap' ('Servizio sconosciuto: ' + $p + '. Usa /ai stato per l elenco.')
            }
        }
        '/simula' {
            $on = -not [bool]$sync.Config.simulazione
            $sync.Config.simulazione = $on
            Save-Config $sync
            if ($on) {
                Add-Bubble 'zap' ('MODALITA SIMULAZIONE: ON. Da ora NON eseguo nulla: ti mostro solo cosa farei (anteprima del comando). Scrivi /simula di nuovo per tornare a eseguire davvero.')
                try { $StatusText.Text = 'SIMULAZIONE ON' } catch { }
            } else {
                Add-Bubble 'zap' 'MODALITA SIMULAZIONE: OFF. Torno a eseguire i comandi davvero.'
                try { $StatusText.Text = 'PRONTO!' } catch { }
            }
            Set-AvatarState 'ok'
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('simulazione ' + $(if ($on) { 'ON' } else { 'OFF' })) -Esito 'ok' } catch { }
        }
        '/audit' {
            $sub = [string]$parts[1]
            if ($sub -match '(?i)verifica|integrit') { Add-Bubble 'zap' (Test-AuditIntegrita $sync) }
            else { Add-Bubble 'zap' (Format-AuditUltimi $sync 20) }
        }
        '/policy' {
            $sub = [string]$parts[1]
            if ($sub -match '(?i)^consenti\s+(.+)$') {
                $cart = $Matches[1].Trim()
                $pl = $sync.Config.policy
                $pl['cartelle_consentite'] = @(@($pl.cartelle_consentite) + $cart | Select-Object -Unique)
                Save-Config $sync
                Add-Bubble 'zap' ('Aggiunta alle cartelle consentite (scrittura libera): ' + $cart)
            } elseif ($sub -match '(?i)^protetta\s+(.+)$') {
                $cart = $Matches[1].Trim()
                $pl = $sync.Config.policy
                $pl['cartelle_protette'] = @(@($pl.cartelle_protette) + $cart | Select-Object -Unique)
                Save-Config $sync
                Add-Bubble 'zap' ('Aggiunta alle cartelle PROTTETE: ' + $cart)
            } elseif ($sub -match '(?i)^(on|off)$') {
                $pl = $sync.Config.policy
                $pl['attivo'] = ($Matches[1].ToLower() -eq 'on')
                Save-Config $sync
                Add-Bubble 'zap' ('Permessi granulari: ' + $Matches[1].ToUpper())
            } else {
                Add-Bubble 'zap' (Format-PolicyInfo $sync)
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('policy ' + $sub) -Esito 'ok' } catch { }
        }
        '/sandbox' {
            $sub = [string]$parts[1]
            if ($sub -match '(?i)^(on|off)$') {
                if (-not $sync.Config.sandbox) { $sync.Config.sandbox = Get-SandboxDefault }
                $sync.Config.sandbox['attivo'] = ($Matches[1].ToLower() -eq 'on')
                Save-Config $sync
                Add-Bubble 'zap' ('Modalita isolata (sandbox di sistema): ' + $Matches[1].ToUpper() + '. I comandi girano in un processo separato con limiti di memoria/tempo/processi e chiusura garantita allo scadere del timeout.')
            } else {
                Add-Bubble 'zap' (Get-SandboxInfo $sync)
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('sandbox ' + $sub) -Esito 'ok' } catch { }
        }
                '/pentest' {
            $sub = ''
            if ($parts.Count -gt 1) { $sub = [string]$parts[1] }
            $resto = ''
            if ($parts.Count -gt 2) { $resto = ([string]::Join(' ', $parts[2..($parts.Count-1)])).Trim() }
            if (-not $sync.Config.pentest) { $sync.Config.pentest = Get-PentestDefault }
            $pe = $sync.Config.pentest
            switch -regex ($sub) {
                '(?i)^(on|off)$'             { $pe['attivo'] = ($sub.ToLower() -eq 'on'); Save-Config $sync; Add-Bubble 'zap' (Format-PentestInfo $sync) }
                '(?i)^scope$'                { if (-not $resto) { Add-Bubble 'zap' 'Uso: /pentest scope <host|*.dominio|CIDR>' } else { $t = ($resto -split '\s+')[0]; $pe['scope'] = @(@($pe.scope) | Where-Object { $_ -and ($_ -ne $t) }) + $t; Save-Config $sync; Add-Bubble 'zap' ('Scope pentest: ' + (@($pe.scope) -join ' | ')) } }
                '(?i)^dimentica$'            { if ($resto) { $t = ($resto -split '\s+')[0]; $pe['scope'] = @(@($pe.scope) | Where-Object { $_ -and ($_ -ne $t) }); Save-Config $sync }; Add-Bubble 'zap' (Format-PentestInfo $sync) }
                '(?i)^autorizza$'            { $pe['autorizzazione'] = $resto; Save-Config $sync; Add-Bubble 'zap' ('Autorizzazione registrata: ' + $(if ($resto) { $resto } else { '(vuota)' })) }
                '(?i)^scadenza$'             { $pe['scadenza'] = $resto; Save-Config $sync; Add-Bubble 'zap' ('Scadenza scope: ' + $(if ($resto) { $resto } else { '(nessuna)' })) }
                '(?i)^intrusivo\s+(on|off)$' { $pe['consenti_intrusive'] = ($Matches[1].ToLower() -eq 'on'); Save-Config $sync; Add-Bubble 'zap' ('Strumenti intrusivi: ' + $(if ($pe.consenti_intrusive) { 'ABILITATI (solo se autorizzato)' } else { 'disattivati' })) }
                '(?i)^demo\s+(on|off)$'      { $pe['dimostrazione'] = ($Matches[1].ToLower() -eq 'on'); Save-Config $sync; Add-Bubble 'zap' ('Modalita dimostrativa: ' + $(if ($pe.dimostrazione) { 'SI (pianifica e mostra, non esegue)' } else { 'no' })) }
                '(?i)^piano'                 { $f = 'ricognizione'; $tt = ''; if ($parts.Count -gt 2) { $f = [string]$parts[2] }; if ($parts.Count -gt 3) { $tt = [string]$parts[3] }; Add-Bubble 'zap' (Format-PentestPianoInfo $sync (New-PentestPiano $sync $f $tt) $f $tt) }
                '(?i)^esegui'                { $f = 'ricognizione'; $tt = ''; if ($parts.Count -gt 2) { $f = [string]$parts[2] }; if ($parts.Count -gt 3) { $tt = [string]$parts[3] }; Add-Bubble 'zap' (Invoke-PentestPiano $sync $f $tt) }
                '(?i)^copertura'             { Add-Bubble 'zap' (Format-PentestCopertura $sync) }
                '(?i)^report'                {
                    $f = 'ricognizione'; $tt = ''
                    if ($parts.Count -gt 2) { $f = [string]$parts[2] }
                    if ($parts.Count -gt 3) { $tt = [string]$parts[3] }
                    $rapp = Invoke-PentestPiano $sync $f $tt
                    Add-Bubble 'zap' $rapp
                    try { Add-Bubble 'zap' (New-PentestReport $sync $tt $f $rapp '') } catch { }
                }
                default                      { Add-Bubble 'zap' (Format-PentestInfo $sync) }
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('pentest ' + $sub + ' ' + $resto) -Esito 'ok' } catch { }
        }
        '/ghost' {
            # v9.1: comandi perimetri dalla chat (stessa cosa che fai dalla cabina).
            $sub = ''
            $resto = ''
            if ($parts.Count -gt 1) {
                $pz = @(([string]$parts[1]).Trim() -split '\s+', 2)
                $sub = [string]$pz[0]
                if ($pz.Count -gt 1) { $resto = [string]$pz[1] }
            }
            $out = ''
            switch -regex ($sub) {
                '^(?i)(stato|)$'           { $out = (Get-GhostStato $sync) + [Environment]::NewLine + (Format-GhostPerimetro $sync) }
                '^(?i)modo$'               { $out = Set-GhostPerimetro $sync $null $resto '' }
                '^(?i)(on|chiuso)$'        { $out = Set-GhostPerimetro $sync $null 'chiuso' '' }
                '^(?i)(off|aperto)$'       { $out = Set-GhostPerimetro $sync $null 'aperto' 'comando utente' }
                '^(?i)aula$'               { $out = Set-GhostPerimetro $sync $null 'aula' '' }
                '^(?i)aggiungi$'           { $out = Add-GhostAmbito $sync $resto }
                '^(?i)togli$'              { $out = Remove-GhostAmbito $sync $resto }
                '^(?i)(elenco|perimetro)$' { $out = Format-GhostPerimetro $sync }
                '^(?i)(file|perimetro-file)$' { $out = Import-GhostPerimetroFile $sync }
                '^(?i)consenti$'           { $out = Set-GhostConsenso $sync $true }
                '^(?i)kit$'                { $out = New-AulaKit $sync }
                '^(?i)attiva$'             { try { $sync.Config.sicurezza = 'ghost'; Save-Config $sync } catch { }; $out = 'Modalita GHOST attiva. ' + (Get-GhostHud $sync).testo }
                '^(?i)test$'               {
                    if (-not $resto) { $out = 'Uso: /ghost test <comando>  (mostra se passerebbe, senza eseguirlo)' }
                    else {
                        $g = Test-GhostConsentito $sync $resto
                        if ($g.ok) {
                            $out = 'PASSEREBBE (modo ' + [string]$g.modo + ')'
                            if ($g.avviso) { $out = $out + ' - ' + [string]$g.avviso }
                        } else {
                            $out = 'BLOCCATO (modo ' + [string]$g.modo + '): ' + [string]$g.motivo
                        }
                    }
                }
                default                    { $out = 'Uso: /ghost stato | modo chiuso|aula|aperto | aggiungi <sito1, sito2> | togli <sito> | file | consenti | test <comando> | kit' }
            }
            Add-Bubble 'zap' $out
            try { Ghost-AggiornaHud } catch { }
            try { if ($script:CabinaPronta) { Cabina-GhostRicarica } } catch { }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('ghost ' + $sub + ' ' + $resto) -Esito 'ok' } catch { }
        }
        '/agenti' {
            # v9.1: la cabina di regia, anche in versione testuale.
            try { Add-Bubble 'zap' (Format-TelemetriaCabina $base) } catch { Add-Bubble 'zap' 'Cabina non disponibile in questa sessione.' }
            try { Cabina-Apri } catch { }
        }
        '/cabina' {
            try { Cabina-Apri } catch { Add-Bubble 'zap' 'Cabina non disponibile: controlla ui\cabina.xaml.' }
        }
        '/ferma-agente' {
            $n = ''
            if ($parts.Count -gt 1) { $n = ([string]$parts[1]).Trim().ToLowerInvariant() }
            if (-not $n) {
                Add-Bubble 'zap' 'Uso: /ferma-agente <aurelio|serafina|leonardo|vittoria|dante|orione|zeus>'
            } else {
                try { Cabina-FermaAgente $n; Add-Bubble 'zap' ('Agente fermato: ' + $n.ToUpperInvariant() + '. Si ferma al prossimo passo (non posso interrompere una chiamata al modello a meta).') } catch { Add-Bubble 'zap' 'Non ho potuto fermare quell agente.' }
            }
        }
        '/strumenti' {
            # v9.1: l'officina - cosa c'e', cosa manca, e l'installazione guidata.
            $sub = ''
            if ($parts.Count -gt 1) { $sub = ([string]$parts[1]).Trim().ToLowerInvariant() }
            switch ($sub) {
                'verifica'  { Add-Bubble 'zap' (Format-StrumentiStato $sync -ConNote) }
                'wireshark' { Add-Bubble 'zap' (Installa-WiresharkWindows -Rumoroso) }
                'installa'  {
                    $bat = Join-Path $base 'PREPARA_STRUMENTI_v9.1.bat'
                    if (Test-Path -LiteralPath $bat) {
                        try { Start-Process -FilePath $bat -WorkingDirectory $base | Out-Null } catch { }
                        Add-Bubble 'zap' ('Ho aperto la finestra di installazione. Ti chiedera i permessi di amministratore: e normale, servono a WSL.' + [Environment]::NewLine + 'Nel frattempo puoi continuare a usarmi.')
                    } else {
                        Add-Bubble 'zap' (Installa-StrumentiTutti $sync -Rumoroso)
                    }
                }
                default     { Add-Bubble 'zap' (Format-StrumentiStato $sync) }
            }
        }
        '/aula' {
            # v9.1: materiale della lezione.
            $sub = ''
            if ($parts.Count -gt 1) { $sub = ([string]$parts[1]).Trim().ToLowerInvariant() }
            switch ($sub) {
                'kit'       { Add-Bubble 'zap' (New-AulaKit $sync) }
                'elenco'    { Add-Bubble 'zap' (Format-AulaScenari) }
                'checklist' { Add-Bubble 'zap' (Format-AulaChecklist) }
                'difese'    {
                    $d = @()
                    foreach ($s in (Get-AulaScenari)) { $d += ('- ' + $s.titolo + ': ' + $s.difesa) }
                    Add-Bubble 'zap' ($d -join "`n")
                }
                default     { Add-Bubble 'zap' (Format-AulaInfo $sync) }
            }
        }
        '/hacker' {
            $rest = ''
            if ($parts.Count -gt 1) { $rest = ([string]$parts[1]).Trim() }
            $sub = ''
            if ($rest) { $sub = ([string](($rest -split '\s+')[0])).ToLower() }
            if (-not $sync.Config.hacker) { $sync.Config.hacker = (Get-HackerDefault) }
            switch -regex ($sub) {
                '^(on|attiva|attivo)$' { $sync.Config.hacker.attivo = $true; Set-Mode 'hacker'; Save-Config $sync; Add-Bubble 'zap' (Format-HackerInfo $sync) }
                '^(off|disattiva)$'    { $sync.Config.hacker.attivo = $false; if ([string]$sync.Config.sicurezza -eq 'hacker') { Set-Mode 'smart' }; Save-Config $sync; Add-Bubble 'zap' 'Modalita HACKER disattivata.' }
                '^scope$' {
                    $tk = @($rest -split '\s+')
                    $t = ''
                    if ($tk.Count -gt 1) { $t = [string]$tk[1] }
                    if ($t) { $sync.Config.hacker.scope = @(@($sync.Config.hacker.scope) | Where-Object { $_ -and ($_ -ne $t) }) + $t; Save-Config $sync; Add-Bubble 'zap' ('Scope hacker: ' + (@($sync.Config.hacker.scope) -join ' | ')) }
                    else { Add-Bubble 'zap' 'Uso: /hacker scope <host|*.dominio|CIDR>' }
                }
                default                { Add-Bubble 'zap' (Format-HackerInfo $sync) }
            }
            try { Add-AuditEvent -sync $sync -Tipo 'sistema' -Azione ('hacker ' + $rest) -Esito 'ok' } catch { }
        }
        '/osint' {
            $rest = ''
            if ($parts.Count -gt 1) { $rest = ([string]$parts[1]).Trim() }
            $tk = @($rest -split '\s+' | Where-Object { $_ })
            if ($tk.Count -eq 0) { Add-Bubble 'zap' (Tool-OsintCatalogo) }
            else {
                $tipo = [string]$tk[0]; $target = ''; $extra = ''
                if ($tk.Count -gt 1) { $target = [string]$tk[1] }
                if ($tk.Count -gt 2) { $extra = [string]$tk[2] }
                Add-Bubble 'zap' (Tool-OsintRicerca $base $sync $tipo $target $extra)
            }
        }
        '/mini' {
            $rest = ''
            if ($parts.Count -gt 1) { $rest = [string]$parts[1] }
            if (-not $rest) { Add-Bubble 'zap' (Format-MiniAgentiStato $sync) }
            else { Add-Bubble 'zap' (Tool-MiniAgente $sync '' $rest $true 120) }
        }
        '/mode' { Switch-Mode }
        '/sviluppatore' { Set-Mode 'sviluppatore' }
        '/allegati' {
            Apri-SceltaFile $sync 'tutto'
            Add-Bubble 'zap' ('Allegati pronti: ' + $sync.Allegati.Count + '. Scrivi cosa vuoi che ne faccia, poi premi INVIA.')
        }
        '/foto' {
            Apri-SceltaFile $sync 'foto'
            Add-Bubble 'zap' ('Immagini pronte: ' + $sync.Allegati.Count + '. Scrivi cosa vuoi sapere, poi premi INVIA.')
        }
        '/video' {
            Apri-SceltaFile $sync 'video'
            Add-Bubble 'zap' ('Video pronti: ' + $sync.Allegati.Count + '. Scrivi cosa vuoi sapere, poi premi INVIA.')
        }
        '/appunti' {
            try { $AppuntiBox.Text = Get-AppuntiText $sync } catch { $AppuntiBox.Text = '' }
            $AppuntiPanel.Visibility = 'Visible'
            $AppuntiBox.Focus()
        }
        '/impara-schermo' {
            $q = ''
            if ($parts.Count -gt 1) { $q = [string]$parts[1] }
            Add-Bubble 'zap' 'Guardo lo schermo e imparo...'
            $ris = ''
            try { $ris = [string](Invoke-ImparaDalloSchermo $sync $q) } catch { $ris = ('Errore: ' + $_.Exception.Message) }
            Add-Bubble 'zap' $ris
        }
        '/migliorati' {
            $a = ''
            if ($parts.Count -gt 1) { $a = [string]$parts[1] }
            $ris = ''
            try { $ris = [string](Invoke-ConsigliMiglioramento $sync $a) } catch { $ris = ('Errore: ' + $_.Exception.Message) }
            Add-Bubble 'zap' $ris
        }
        '/admin' {
            Add-Bubble 'zap' (Get-AdminStatus)
        }
        '/tema-foto' {
            Asp-TemaDaFoto ([string]$parts[1])
        }
        '/tema' {
            $AspettoPanel.Visibility = 'Visible'
            Asp-Ricarica
        }
        '/aspetto' {
            $AspettoPanel.Visibility = 'Visible'
            Asp-Ricarica
        }
        '/allegati-vuota' {
            Svuota-Allegati $sync
            Add-Bubble 'zap' 'Allegati tolti.'
        }
        '/agenti' {
            $elencoAg = Format-SquadraElenco @($sync.AgentiAttivi)
            Add-Bubble 'zap' ("SQUADRA ZAP`n" + $elencoAg + "`n`nPer usarla scrivi, per esempio:`n- 'Aurelio e Vittoria, scrivete un preventivo per un cliente'`n- 'lavora con gli agenti: analizza questa foto'`n- 'attiva Dante' / 'disattiva Serafina' / 'attiva tutti'`n`nI resoconti finiscono in report\agenti.")
        }
        '/cinema' { Show-CinemaPanel $Window }
        '/gif' { Show-CinemaPanel $Window }
        '/programmi' { if ($ProgrammiPanel) { $ProgrammiPanel.Visibility = 'Visible'; Aggiorna-PannelloProgrammi } }
        '/automazioni' { if ($AutomazioniPanel) { Aggiorna-PannelloAutomazioni; $AutomazioniPanel.Visibility = 'Visible' } }
        '/nastro'     { $v = Toggle-ZapTicker -Window $Window -Base $base; Add-Bubble 'zap' ('Nastro notizie: ' + $(if ($v) { 'VISIBILE' } else { 'NASCOSTO' })) }
        '/skin'       {
            if ($parts.Count -lt 2 -or -not ([string]$parts[1]).Trim()) { Add-Bubble 'zap' (Get-SkinElencoTesto -Base $base) }
            else { Add-Bubble 'zap' (Set-Skin -Window $Window -Base $base -Nome ([string]$parts[1]).Trim()) }
        }
        '/skin-diag'  {
            $d = New-Object System.Collections.ArrayList
            [void]$d.Add('=== DIAGNOSI INTERFACCE ===')
            try {
                $defs = @(Get-SkinDefinizioni)
                [void]$d.Add('definizioni lette: ' + $defs.Count)
                [void]$d.Add('nomi: ' + (($defs | ForEach-Object { [string]$_.nome }) -join ', '))
            } catch { [void]$d.Add('definizioni: ERRORE ' + $_.Exception.Message) }
            try { [void]$d.Add('skin attiva: ' + (Get-SkinAttuale -Base $base)) } catch { }
            try { [void]$d.Add('cartella ui\skins presente: ' + [bool](Test-Path -LiteralPath (Join-Path $base 'ui\skins'))) } catch { }
            try {
                $sp = $Window.FindName('SkinPanel')
                $sl = $Window.FindName('SkinLayer')
                if ($sp) { [void]$d.Add('SkinPanel: presente, ' + [int]$sp.ActualWidth + 'x' + [int]$sp.ActualHeight + ' pixel') }
                else { [void]$d.Add('SkinPanel: ASSENTE (window.xaml vecchio?)') }
                if ($sl) { [void]$d.Add('SkinLayer: presente') } else { [void]$d.Add('SkinLayer: ASSENTE') }
            } catch { }
            try { [void]$d.Add('Applica-Palette disponibile: ' + [bool](Get-Command Applica-Palette -ErrorAction SilentlyContinue)) } catch { }
            try { if ($script:SkinUltimoErrore) { [void]$d.Add('ultimo errore: ' + [string]$script:SkinUltimoErrore) } } catch { }
            [void]$d.Add('diario completo: ui\skin_log.txt')
            Add-Bubble 'zap' ($d -join "`n")
        }
        '/skin-ai'    { Add-Bubble 'zap' (New-SkinDaAI -sync $sync -Window $Window -Base $base -Testo ([string]$parts[1])) }
        '/skin-scarica' { Add-Bubble 'zap' (Import-SkinDaUrl -sync $sync -Window $Window -Base $base -Url ([string]$parts[1]).Trim()) }
        '/auto'       {
            $on = $true
            if ($parts.Count -gt 1 -and ([string]$parts[1]).Trim()) { $on = (([string]$parts[1]).Trim().ToLower() -ne 'off') }
            [void](Set-CfgBool $sync.Config 'autopilota' $on)
            try { Save-Config $sync } catch { }
            Add-Bubble 'zap' ('AUTOPILOTA PowerShell: ' + $(if ($on) { 'ACCESO - eseguo subito, non ti chiedo il permesso. Ogni comando resta nel registro (scatola nera).' } else { 'spento - sui comandi rischiosi ti chiedo conferma.' }))
        }
        '/pulito'     {
            $on = $true
            if ($parts.Count -gt 1 -and ([string]$parts[1]).Trim()) { $on = (([string]$parts[1]).Trim().ToLower() -ne 'off') }
            [void](Set-CfgBool $sync.Config 'chat_silenziosa' $on)
            try { Save-Config $sync } catch { }
            Add-Bubble 'zap' ('Chat: ' + $(if ($on) { 'mostro SOLO la risposta finale (consigliato).' } else { 'mostro anche i passaggi mentre lavoro.' }))
        }
        '/comandi'    {
            Add-Bubble 'zap' ("COMANDI v9.4`n/skin  - elenco interfacce; /skin astronave per cambiarla`n/skin-ai <descrizione> - l'IA inventa una nuova interfaccia`n/skin-scarica <url> - installa una skin da internet`n/nastro - mostra/nasconde il nastro notizie (o F8)`n/auto on|off - PowerShell automatico senza conferme`n/pulito on|off - chat con la sola risposta finale")
        }
        '/kali' { Aggiorna-PannelloKali; $KaliPanel.Visibility = 'Visible' }
        '/mic' { Add-Bubble 'zap' (Get-SpeechDiagnostica) }
        '/ferma' { Do-Stop }
        '/vuota' {
            $ChatPanel.Children.Clear()
            Add-Activity '- chat svuotata -'
        }
        default {
            Add-Bubble 'zap' "Comando sconosciuto: $($parts[0]). Prova /aiuto."
        }
    }
}

function Do-Stop {
    # v8: FERMA blocca anche la squadra di agenti e il disegno della GIF
    try { $sync.CineStop = $true } catch { }
    try { $sync.SquadraStop = $true } catch { }
    Stop-Listen $sync
    $sync.Listening = $false
    $BtnParla.Content = 'PARLA'
    Stop-Speak $sync
    if ($sync.CurrentExec) {
        try { $sync.CurrentExec.Stop() } catch { }
    }
    $StatusText.Text = 'INTERROTTO!'
    Show-Onomatopea 'WHAM!'
    Add-Activity '- tutto fermato -'
}

function Aggiorna-PannelloProgrammi {
    $dir = Get-ProgrammiDir $sync
    if (-not (Test-Path $dir)) { try { New-Item -ItemType Directory -Path $dir | Out-Null } catch { } }
    $voci = @(Get-ProgrammiScansionati $dir)
    $ProgElenco.Text = (Format-ProgrammiElenco $sync)
    $ProgCombo.Items.Clear()
    foreach ($v in $voci) { [void]$ProgCombo.Items.Add($v.nome) }
    if ($ProgCombo.Items.Count -gt 0) { $ProgCombo.SelectedIndex = 0 }
    $ProgInfo.Text = ('Cartella: ' + $dir + '   (' + $voci.Count + ' programmi)')
}

# --------------------------------------------------------------------------
# Pulsanti
# --------------------------------------------------------------------------

$BtnInvia.Add_Click({
    Send-UserText $InputBox.Text
    $InputBox.Text = ''
})

$InputBox.Add_PreviewKeyDown({
    param($s, $e)
    if ($e.Key -eq 'Return' -and -not ([System.Windows.Input.Keyboard]::Modifiers -band [System.Windows.Input.ModifierKeys]::Shift)) {
        $e.Handled = $true
        Send-UserText $InputBox.Text
        $InputBox.Text = ''
        $InputBox.CaretIndex = 0
    }
})

# v6: copia/incolla garantiti nel campo dove scrivi (Ctrl+C/Ctrl+V nativi + menu tasto destro).
Set-InputTextMenu $InputBox

$BtnParla.Add_Click({
    if ($sync.Listening) {
        Stop-Listen $sync
        $sync.Listening = $false
        $BtnParla.Content = 'PARLA'
        Set-AvatarState 'neutro'
        $StatusText.Text = 'ASCOLTO ANNULLATO'
        return
    }
    if (-not (Test-SpeechAvailable)) {
        [System.Windows.MessageBox]::Show($Window,
            "Nessun motore vocale disponibile su Windows.`n`nAggiungi il pacchetto italiano: Impostazioni -> Data e ora e lingua -> Lingua e area -> Italiano -> Opzioni -> Riconoscimento vocale.`nControlla anche: Impostazioni -> Privacy e sicurezza -> Microfono (attiva anche per le app desktop).`n`nNel frattempo puoi scrivere nella chat!",
            'ZAP! Microfono', 'OK', 'Warning') | Out-Null
        Add-Bubble 'zap' (Get-SpeechDiagnostica)
        return
    }
    Stop-Speak $sync
    $lingua = [string]$sync.Config.voce.ascolto_lingua
    $sec = 12
    try { $sec = [int]$sync.Config.voce.ascolto_secondi } catch { }
    Start-Listen -sync $sync -Culture $lingua -TimeoutSec $sec
    $sync.Listening = $true
    $BtnParla.Content = 'ASCOLTO...'
    $StatusText.Text = 'TI ASCOLTO... PARLA PURE!'
    Set-AvatarState 'pensa'
    Show-Onomatopea 'TAP!'
})

$BtnInsegna.Add_Click({
    $TeachPanel.Visibility = 'Visible'
    $TeachNome.Focus()
})

$BtnModo.Add_Click({ Switch-Mode })

# v9.2: la voce PROGRAMMI e' stata tolta dal menu in alto (resta il comando /programmi)
if ($BtnProgrammi -and $ProgrammiPanel) {
    $BtnProgrammi.Add_Click({
        $ProgrammiPanel.Visibility = 'Visible'
        Aggiorna-PannelloProgrammi
    })
}

$BtnAi.Add_Click({
    Aggiorna-AiList
    $AiPanel.Visibility = 'Visible'
})

$BtnChiudiAi.Add_Click({ $AiPanel.Visibility = 'Collapsed' })

# v9.5: interruttore generale della squadra anche dentro il pannello IA
$BtnAiSquadra = $null
try { $BtnAiSquadra = $Window.FindName('BtnAiSquadra') } catch { $BtnAiSquadra = $null }
if ($BtnAiSquadra) {
    $BtnAiSquadra.Add_Click({
        try {
            Toggle-OrchestraDaUI
            if (Test-OrchestraAttiva $sync) { $BtnAiSquadra.Content = 'TUTTE INSIEME: ON' }
            else { $BtnAiSquadra.Content = 'TUTTE INSIEME: OFF' }
            Aggiorna-AiList
        } catch { }
    })
}

$BtnAiSalvaTutti.Add_Click({
    Save-AiPanel
    Aggiorna-AiList
    Aggiorna-AiCombo
    Add-Bubble 'zap' ('Servizi IA salvati. ' + (Get-AiRouterText $sync))
    Show-Onomatopea 'ZAP!'
})

$BtnAiAiutoChiavi.Add_Click({
    $p = Join-Path $sync.Base 'ISTRUZIONI_API_KEY.md'
    try { Start-Process 'notepad.exe' $p } catch { }
    Add-Bubble 'zap' ('Le chiavi le ottieni dai siti ufficiali (io non posso procurartele). Ho aperto ISTRUZIONI_API_KEY.md:' + "`n" +
        'per ogni servizio c e il link della pagina da cui copiare la chiave. Poi la incolli qui e premi SALVA QUESTO SERVIZIO.' + "`n`n" +
        'Nota: il motore gira in cloud (Gemini, DeepSeek, ecc.): nessun modello sul tuo PC, la RAM resta libera.')
})

if ($AiSel) { $AiSel.Add_SelectionChanged({ Set-AiDaCombo }) }

$BtnAllegati.Add_Click({ Apri-SceltaFile $sync 'tutto' })
$BtnFoto.Add_Click({ Apri-SceltaFile $sync 'foto' })
$BtnVideo.Add_Click({ Apri-SceltaFile $sync 'video' })

# v7.9: TRASPARENZA VERA. La finestra e' dichiarata trasparente in ui\window.xaml
# (WindowStyle=None + AllowsTransparency=True + sfondo trasparente): ora abbassare
# l'opacita' rende DAVVERO la finestra semitrasparente (si vede il desktop dietro),
# invece di limitarsi a scurire il contenuto come faceva la vecchia versione.
function Set-OpacitaFinestra {
    param([double]$Percento)
    $a = [Math]::Max(0.25, [Math]::Min(1.0, $Percento / 100.0))
    $Window.Opacity = $a
    if ($TrasparenzaLabel) { $TrasparenzaLabel.Text = ([int][Math]::Round($Percento)).ToString() + '%' }
}
$Window.AllowDrop = $true
if ($Trasparenza) {
    $Trasparenza.Add_ValueChanged({
        param($s, $e)
        Set-OpacitaFinestra ([double]$Trasparenza.Value)
    })
}
Set-OpacitaFinestra ([double]$(if ($Trasparenza) { $Trasparenza.Value } else { 100 }))

# v7.9.2: SPOSTARE e RIDIMENSIONARE la finestra anche senza i bordi di Windows.
# WPF (DragMove) su una finestra trasparente NON la sposta e non la ridimensiona:
# allora mando alla finestra un "clic sul titolo/bordo" (WM_NCLBUTTONDOWN) e lascio
# fare a Windows, che la trascina e la ridimensiona come una finestra normale.
# (Cosi' funzionano anche il doppio clic per ingrandire e l'aggancio ai lati.)
if (-not ('ZapDrag' -as [type])) {
    try {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ZapDrag {
    [DllImport("user32.dll")] public static extern bool ReleaseCapture();
    [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
}
'@
    } catch { }
}
$script:ZapHwnd = [IntPtr]::Zero
function Get-ZapHwnd {
    if ($script:ZapHwnd -eq [IntPtr]::Zero) {
        try { $script:ZapHwnd = (New-Object System.Windows.Interop.WindowInteropHelper($Window)).Handle } catch { }
    }
    return $script:ZapHwnd
}
function Start-ZapMossa {
    param([int]$Hit)
    try {
        $h = Get-ZapHwnd
        if ($h -eq [IntPtr]::Zero) { return }
        [void][ZapDrag]::ReleaseCapture()
        [void][ZapDrag]::SendMessage($h, 0xA1, [IntPtr]$Hit, [IntPtr]::Zero)
    } catch { }
}
# 1) TRASCINA la finestra dalla barra del titolo (doppio clic = ingrandisci/ripristina: lo fa Windows)
$barra = $TitleBarDrag
if (-not $barra) { try { $barra = $Window.FindName('TitleBar') } catch { } }
if ($barra) {
    $barra.Add_MouseLeftButtonDown({
        param($s, $e)
        $src = $e.OriginalSource
        if ($src -is [System.Windows.Controls.Button]) { return }
        if ($src -and $src.TemplatedParent -is [System.Windows.Controls.Button]) { return }
        Start-ZapMossa 2
    })
}
# 2) RIDIMENSIONA afferrando i bordi (7 pixel attorno alla finestra). I bottoni restano cliccabili.
$script:ZapBordo = 7
$Window.Add_PreviewMouseLeftButtonDown({
    param($s, $e)
    try {
        if ($Window.WindowState -eq 'Maximized') { return }
        $src = $e.OriginalSource
        if ($src -is [System.Windows.Controls.Button]) { return }
        if ($src -and $src.TemplatedParent -is [System.Windows.Controls.Button]) { return }
        $p = $e.GetPosition($Window)
        $b = $script:ZapBordo
        $w = $Window.ActualWidth; $hh = $Window.ActualHeight
        $L = ($p.X -lt $b); $R = ($p.X -gt ($w - $b)); $T = ($p.Y -lt $b); $B = ($p.Y -gt ($hh - $b))
        $hit = 0
        if ($T -and $L) { $hit = 13 }
        elseif ($T -and $R) { $hit = 14 }
        elseif ($B -and $L) { $hit = 16 }
        elseif ($B -and $R) { $hit = 17 }
        elseif ($L) { $hit = 10 }
        elseif ($R) { $hit = 11 }
        elseif ($T) { $hit = 12 }
        elseif ($B) { $hit = 15 }
        if ($hit -ne 0) { Start-ZapMossa $hit; $e.Handled = $true }
    } catch { }
})
if ($BtnWinMin)   { $BtnWinMin.Add_Click({ $Window.WindowState = 'Minimized' }) }
if ($BtnWinMax)   { $BtnWinMax.Add_Click({ if ($Window.WindowState -eq 'Maximized') { $Window.WindowState = 'Normal' } else { $Window.WindowState = 'Maximized' } }) }
if ($BtnWinClose) { $BtnWinClose.Add_Click({ $Window.Close() }) }

# v7.6: TRASCINA i file dentro la finestra per allegarli (foto, video, PDF, documenti)
$Window.AllowDrop = $true
$Window.Add_PreviewDragOver({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $e.Effects = [System.Windows.DragDropEffects]::Copy
    } else {
        $e.Effects = [System.Windows.DragDropEffects]::None
    }
    $e.Handled = $true
})
$Window.Add_PreviewDrop({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $files = @($e.Data.GetData([System.Windows.DataFormats]::FileDrop))
        foreach ($f in $files) { if ($f) { Aggiungi-Allegato $sync ([string]$f) } }
        $StatusText.Text = ('ALLEGATI: ' + $sync.Allegati.Count + ' pronti (trascinati)')
        Set-AvatarState 'pensa'
        Show-Onomatopea 'PRESO!'
        $e.Handled = $true
    }
})

$BtnFerma.Add_Click({ Do-Stop })

$BtnImpostazioni.Add_Click({
    $CfgNome.Text         = [string]$sync.Config.nome
    $CfgApiBase.Text      = [string]$sync.Config.api_base
    $CfgApiKey.Text       = [string]$sync.Config.api_key
    $CfgModello.Text      = [string]$sync.Config.modello
    $CfgBrowser.Text      = [string]$sync.Config.browser
    if ($CfgMotore.Items.Contains([string]$sync.Config.motore_ricerca)) { $CfgMotore.SelectedItem = [string]$sync.Config.motore_ricerca }
    $CfgCartella.Text     = [string]$sync.Config.cartella_lavoro
    $CfgVoce.IsChecked    = [bool]$sync.Config.voce.risposte_ad_alta_voce
    try { $ModelInfo.Text = Get-ModelStatusText $sync } catch { }
    $SettingsPanel.Visibility = 'Visible'
})

$BtnChiudiCfg.Add_Click({ $SettingsPanel.Visibility = 'Collapsed' })

$BtnSalvaCfg.Add_Click({
    $sync.Config.nome  = $CfgNome.Text.Trim()
    if (-not $sync.Config.nome) { $sync.Config.nome = 'ZAP' }
    $sync.Config.api_base = $CfgApiBase.Text.Trim()
    $sync.Config.api_key  = $CfgApiKey.Text.Trim()
    $sync.Config.modello  = $CfgModello.Text.Trim()
    $sync.Config.browser  = $CfgBrowser.Text.Trim()
    if (-not $sync.Config.browser) { $sync.Config.browser = 'thorium' }
    if ($CfgMotore.SelectedItem) { $sync.Config.motore_ricerca = [string]$CfgMotore.SelectedItem }
    $sync.Config.cartella_lavoro = $CfgCartella.Text.Trim()
    $sync.Config.voce.risposte_ad_alta_voce = [bool]$CfgVoce.IsChecked
    Save-Config $sync
    try { Initialize-Tts $sync } catch { $sync.Tts = $null }
    $SettingsPanel.Visibility = 'Collapsed'
    Add-Bubble 'zap' 'Impostazioni salvate! BAM!'
    Show-Onomatopea 'BAM!'
    try { $ModelInfo.Text = Get-ModelStatusText $sync } catch { }
})

$BtnChiudiTeach.Add_Click({
    $TeachPanel.Visibility = 'Collapsed'
})

$BtnSalvaTeach.Add_Click({
    $n = $TeachNome.Text.Trim()
    $d = $TeachQuando.Text.Trim()
    $c = $TeachCodice.Text
    if (-not $n -or -not $c.Trim()) {
        [System.Windows.MessageBox]::Show($Window, 'Servono almeno il nome e lo script!', 'ZAP!', 'OK', 'Warning') | Out-Null
        return
    }
    if (-not $d) { $d = "Skill insegnata dall'utente il $(Get-Date -Format 'yyyy-MM-dd')" }
    $res = Save-Skill $sync $n $d $d $c
    $TeachPanel.Visibility = 'Collapsed'
    $TeachNome.Text = ''; $TeachQuando.Text = ''; $TeachCodice.Text = ''
    Add-Bubble 'zap' $res
    Show-Onomatopea 'IMPARATO!'
    Set-AvatarState 'ok'
    $StatusText.Text = 'HO IMPARATO QUALCOSA DI NUOVO!'
})

$BtnProgAggiorna.Add_Click({ Aggiorna-PannelloProgrammi })

$BtnProgAvvia.Add_Click({
    $nome = ''
    if ($ProgCombo.Text) { $nome = $ProgCombo.Text.Trim() }
    elseif ($ProgCombo.SelectedItem) { $nome = [string]$ProgCombo.SelectedItem }
    if (-not $nome) { Add-Bubble 'zap' 'Scegli un programma dalla lista.'; return }
    $r = Start-Programma $sync $nome ''
    Add-Bubble 'zap' ([string]$r)
})

$BtnProgCartella.Add_Click({
    $dir = Get-ProgrammiDir $sync
    try { if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null } } catch { }
    try { Start-Process 'explorer.exe' $dir } catch { Add-Bubble 'zap' ('Cartella programmi: ' + $dir) }
})

$BtnChiudiProg.Add_Click({ $ProgrammiPanel.Visibility = 'Collapsed' })
# --- AUTOMAZIONI: elenco di cose da far fare a ZAP da solo ---
function Aggiorna-PannelloAutomazioni {
    $AutoList.Children.Clear()
    $conv = New-Object System.Windows.Media.BrushConverter
    $catalogo = @(Get-CatalogoAutomazioni $sync.Base)
    foreach ($a in $catalogo) {
        $riga = New-Object System.Windows.Controls.StackPanel
        $riga.Margin = [System.Windows.Thickness]::new(0, 4, 0, 4)
        $cb = New-Object System.Windows.Controls.CheckBox
        $cb.Content = [string]$a.titolo
        $cb.Tag = [string]$a.id
        $cb.FontSize = 14
        $cb.FontWeight = [System.Windows.FontWeights]::SemiBold
        $cb.Foreground = $conv.ConvertFromString('#F0E9D8')
        [void]$riga.Children.Add($cb)
        $tb = New-Object System.Windows.Controls.TextBlock
        $tb.Text = ([string]$a.desc + '  [' + [string]$a.categoria + ' - ' + [string]$a.tipo + ' ' + [string]$a.orario + ']')
        $tb.FontSize = 11
        $tb.Foreground = $conv.ConvertFromString('#9AA4AE')
        $tb.TextWrapping = 'Wrap'
        $tb.Margin = [System.Windows.Thickness]::new(24, 0, 0, 0)
        [void]$riga.Children.Add($tb)
        [void]$AutoList.Children.Add($riga)
    }
}

if ($BtnAutomazioni) {
    $BtnAutomazioni.Add_Click({
        Aggiorna-PannelloAutomazioni
        $AutomazioniPanel.Visibility = 'Visible'
    })
}
if ($BtnAutoCrea) {
    $BtnAutoCrea.Add_Click({
        $fatte = 0
        foreach ($riga in $AutoList.Children) {
            $cb = $riga.Children[0]
            if (($cb -is [System.Windows.Controls.CheckBox]) -and $cb.IsChecked) {
                $item = Get-AutomazioneById $sync.Base ([string]$cb.Tag)
                if ($item) { Add-Bubble 'zap' (New-AutomazioneScelta $sync $item); $fatte++ }
            }
        }
        $testo = ''
        if ($AutoDescr) { $testo = [string]$AutoDescr.Text.Trim() }
        if ($testo) { Add-Bubble 'zap' (New-AutomazioneLibera $sync $testo); $fatte++ }
        if ($fatte -eq 0) { Add-Bubble 'zap' 'Non hai scelto nulla: spunta una o piu automazioni, oppure scrivi cosa vuoi automatizzare.' }
        else { Show-Onomatopea 'FATTO!'; Set-AvatarState 'ok'; $StatusText.Text = 'AUTOMAZIONI ATTIVATE!' }
        $AutoDescr.Text = ''
        Aggiorna-PannelloAutomazioni
    })
    $BtnAutoAggiorna.Add_Click({ Aggiorna-PannelloAutomazioni })
    $BtnAutoChiudi.Add_Click({ $AutomazioniPanel.Visibility = 'Collapsed' })
}

# --- KALI: console + strumenti (via WSL) - tutto in BACKGROUND, la UI non si blocca ---
function Start-KaliBackground {
    param([string]$Modo, [string]$Arg)
    $jobTxt = @'
param($base, $sync, $modo, $arg)
. (Join-Path $base 'brain\kali.ps1')
try {
    if ($modo -eq 'check') {
        $pronto = Test-KaliPronto
        $lista  = @(Get-KaliToolsStato)
        $sync.UiQueue.Enqueue(@{ Type = 'kali_tools'; Data = @{ pronto = [bool]$pronto; lista = $lista } })
    }
    elseif ($modo -eq 'cmd') {
        $r = Invoke-KaliCommand ([string]$arg) 300
        $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = [string]$r.out })
    }
    elseif ($modo -eq 'install') {
        foreach ($one in ([string]$arg -split ',')) {
            if ($one) { $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = (Installa-KaliTool $one) }) }
        }
        $sync.UiQueue.Enqueue(@{ Type = 'kali_tools'; Data = @{ pronto = (Test-KaliPronto); lista = @(Get-KaliToolsStato) } })
    }
    elseif ($modo -eq 'setup') {
        $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = (Installa-KaliDistro) })
    }
} catch {
    $sync.UiQueue.Enqueue(@{ Type = 'kali_out'; Data = ('errore: ' + $_.Exception.Message) })
}
'@
    try {
        $rs = [runspacefactory]::CreateRunspace()
        $rs.ApartmentState = 'MTA'
        $rs.Open()
        $ps = [powershell]::Create()
        $ps.Runspace = $rs
        [void]$ps.AddScript($jobTxt).AddArgument([string]$sync.Base).AddArgument($sync).AddArgument([string]$Modo).AddArgument([string]$Arg)
        [void]$ps.BeginInvoke()
    } catch {
        if ($KaliOut) { $KaliOut.AppendText('errore avvio: ' + $_.Exception.Message + "`r`n") }
    }
}

function Aggiorna-PannelloKali {
    if ($KaliTools) { $KaliTools.Children.Clear() }
    if ($KaliStatus) {
        $KaliStatus.Text = 'Controllo ambiente Kali... (la finestra resta reattiva)'
        $KaliStatus.Foreground = (New-Object System.Windows.Media.BrushConverter).ConvertFromString('#9BD39B')
    }
    Start-KaliBackground -Modo 'check' -Arg ''
}

function Invoke-KaliDaUI {
    $cmd = ''
    if ($KaliCmd) { $cmd = [string]$KaliCmd.Text.Trim() }
    if (-not $cmd) { return }
    $KaliOut.AppendText('$ ' + $cmd + "`r`n")
    $KaliOut.ScrollToEnd()
    $KaliCmd.Text = ''
    Start-KaliBackground -Modo 'cmd' -Arg $cmd
}

if ($BtnKali) {
    $BtnKali.Add_Click({ Aggiorna-PannelloKali; $KaliPanel.Visibility = 'Visible' })
}
if ($BtnKaliEsegui) {
    $BtnKaliEsegui.Add_Click({ Invoke-KaliDaUI })
    $KaliCmd.Add_KeyDown({ param($s, $e) if ($e.Key -eq [System.Windows.Input.Key]::Return) { Invoke-KaliDaUI } })
}
if ($BtnKaliInstalla) {
    $BtnKaliInstalla.Add_Click({
        $ids = @()
        foreach ($riga in $KaliTools.Children) {
            $cb = $riga.Children[0]
            if (($cb -is [System.Windows.Controls.CheckBox]) -and $cb.IsChecked) { $ids += [string]$cb.Tag }
        }
        if ($ids.Count -eq 0) { $KaliOut.AppendText('Nessuno strumento spuntato.' + "`r`n"); return }
        foreach ($id in $ids) { $KaliOut.AppendText('Installazione di ' + $id + ' in corso...' + "`r`n") }
        $KaliOut.ScrollToEnd()
        Start-KaliBackground -Modo 'install' -Arg ($ids -join ',')
    })
}
if ($BtnKaliSetup)    { $BtnKaliSetup.Add_Click({ $KaliOut.AppendText('Installazione di Kali: apparira la richiesta di AMMINISTRATORE di Windows (finestra UAC) - clicca SI. ' + 'Puo richiedere alcuni minuti. Se e il PRIMO avvio di WSL puo servire un riavvio del PC.' + "`r`n"); $KaliOut.ScrollToEnd(); Start-KaliBackground -Modo 'setup' -Arg '' }) }
if ($BtnKaliAggiorna) { $BtnKaliAggiorna.Add_Click({ Aggiorna-PannelloKali }) }
if ($BtnKaliChiudi)   { $BtnKaliChiudi.Add_Click({ $KaliPanel.Visibility = 'Collapsed' }) }

function Flush-TaskInCoda {
    $coda = Join-Path $sync.Base 'dati\task_in_coda.json'
    if (-not (Test-Path -LiteralPath $coda)) { return }
    try {
        $voci = @(Get-Content -LiteralPath $coda -Raw -Encoding UTF8 | ConvertFrom-Json)
        foreach ($v in $voci) { if ($v.testo) { $sync.InputQueue.Enqueue('[AUTOMAZIONE] ' + [string]$v.testo) } }
        Remove-Item -LiteralPath $coda -Force -ErrorAction SilentlyContinue
    } catch { }
}


# --- APPUNTI: sessione di scrittura salvata su file (non si perde) ---
$BtnAppunti.Add_Click({
    try { $AppuntiBox.Text = Get-AppuntiText $sync } catch { $AppuntiBox.Text = '' }
    $AppuntiPanel.Visibility = 'Visible'
    $AppuntiBox.Focus()
})
$BtnAppuntiSalva.Add_Click({
    try { [void](Set-Appunti $sync $AppuntiBox.Text) } catch { }
    Set-AvatarState 'ok'
    Show-Onomatopea 'SALVATO!'
    $StatusText.Text = 'APPUNTI SALVATI!'
})
$BtnAppuntiChiudi.Add_Click({
    try { [void](Set-Appunti $sync $AppuntiBox.Text) } catch { }
    $AppuntiPanel.Visibility = 'Collapsed'
})

# ===========================================================================
# v9 -- PANNELLI AGGIUNTIVI (POWERSHELL SCRIPT e MEMORIA)
# ---------------------------------------------------------------------------
# Sono costruiti da ui\panel_v9.xaml, un file SEPARATO da window.xaml.
# Motivo: se un solo elemento del XAML principale e' invalido, WPF non carica la
# finestra e ZAP non parte affatto. Cosi' invece, se il pannello non si carica,
# ZAP funziona lo stesso e il motivo finisce in logs\avvio.log.
# Nessuna riga di questo blocco puo' fermare l'avvio: tutto e' dentro try/catch.
# ===========================================================================

$script:PsVoci = @()
$PsPanel = $null; $EzPanel = $null
$PsElenco = $null; $PsCodice = $null; $PsInfo = $null; $PsCerca = $null
$EzStato = $null; $EzDiario = $null; $BtnEzTraccia = $null; $BtnEzPerimetro = $null
$script:PannelliV9 = $false

function Ps-Ricarica {
    param([string]$Query = '')
    try {
        if (-not $PsElenco) { return }
        $voci = @(Find-PsScriptArchivio $sync $Query '' 400)
        $script:PsVoci = $voci
        $PsElenco.Items.Clear()
        if ($voci.Count -eq 0) {
            [void]$PsElenco.Items.Add('(nessuno script in libreria)')
            $PsCodice.Text = ''
            $PsInfo.Text = 'Libreria vuota. Chiedi a ZAP di scrivere uno script: verra archiviato qui da solo.'
            return
        }
        foreach ($v in $voci) {
            $usi = 1
            try { $usi = [int]$v.usi } catch { }
            [void]$PsElenco.Items.Add('[' + [string]$v.categoria + '] ' + [string]$v.titolo + '   (' + [string]$v.file + ' - usi ' + $usi + ')')
        }
        $PsInfo.Text = ('Script in libreria: ' + $voci.Count + ' -- clicca una riga per leggere il codice.')
        $PsElenco.SelectedIndex = 0
    } catch {
        try { $PsInfo.Text = 'Errore nel caricamento: ' + $_.Exception.Message } catch { }
    }
}

function Ps-MostraSelezionato {
    try {
        if (-not $PsElenco -or -not $PsCodice) { return }
        $i = [int]$PsElenco.SelectedIndex
        $tutte = @($script:PsVoci)
        if ($i -lt 0 -or $i -ge $tutte.Count) { return }
        $v = $tutte[$i]
        $p = Join-Path (Get-PsLibreriaDir $sync) ([string]$v.file)
        if (Test-Path -LiteralPath $p) {
            $PsCodice.Text = [System.IO.File]::ReadAllText($p)
            $PsInfo.Text = ([string]$v.categoria + ' - fonte: ' + [string]$v.fonte + ' - salvato: ' + [string]$v.creato)
        } else {
            $PsCodice.Text = '(file mancante: ' + $p + ')'
        }
    } catch { }
}

function Ps-FileSelezionato {
    try {
        if (-not $PsElenco) { return '' }
        $i = [int]$PsElenco.SelectedIndex
        $tutte = @($script:PsVoci)
        if ($i -lt 0 -or $i -ge $tutte.Count) { return '' }
        return (Join-Path (Get-PsLibreriaDir $sync) ([string]$tutte[$i].file))
    } catch { return '' }
}

function Ez-Aggiorna {
    try {
        if (-not $EzStato) { return }
        $st = Get-EzapperoStato $sync
        $righe = @()
        $righe += 'Cartella Ezappero : ' + [string]$st.cartella
        $righe += 'Copia specchio    : ' + [string]$st.specchio
        $righe += 'Eventi registrati : ' + [string]$st.eventi
        $righe += 'Script archiviati : ' + [string]$st.script
        $righe += 'Sessioni salvate  : ' + [string]$st.sessioni
        $righe += 'Integrita         : ' + [string]$st.messaggio
        $righe += 'Guardia anti-bugia: ' + (Get-VeritaStato $sync)
        $tr = Get-TracciaStato $sync
        if ($tr.attiva) {
            $righe += 'Traccia           : ATTIVA (dal ' + [string]$tr.dal + ') - campioni: ' + [string]$tr.campioni
            if ($BtnEzTraccia) { $BtnEzTraccia.Content = 'TRACCIA: ON' }
        } else {
            $righe += 'Traccia           : spenta'
            if ($BtnEzTraccia) { $BtnEzTraccia.Content = 'TRACCIA: OFF' }
        }
        try {
            $gc = Get-GhostConfig $sync
            if ($BtnEzPerimetro) {
                if ($gc.blocca_fuori_ambito) { $BtnEzPerimetro.Content = 'PERIMETRO: ON' }
                else { $BtnEzPerimetro.Content = 'PERIMETRO: OFF' }
            }
        } catch { }
        $EzStato.Text = ($righe -join [Environment]::NewLine)
        if ($EzDiario) { $EzDiario.Text = (Get-ZapDiario $sync) }
    } catch {
        try { if ($EzStato) { $EzStato.Text = 'Errore: ' + $_.Exception.Message } } catch { }
    }
}

try {
    # ---- 1) due pulsanti nella barra in alto ----
    $top = $null
    try { $top = $Window.FindName('TopComandi') } catch { $top = $null }
    $btnPs = $null
    $btnEz = $null
    if ($top) {
        $stileTop = $null
        try { $stileTop = $Window.FindResource('TopBtn') } catch { $stileTop = $null }
        # v9.5: il pulsante PS e' stato TOLTO dalla barra in alto (il pannello resta,
        # si apre con il comando /ps oppure con /aiuto).
        $btnPs = $null

        $btnEz = New-Object System.Windows.Controls.Button
        $btnEz.Name = 'BtnEzappero'
        $btnEz.Content = 'MEMORIA'
        $btnEz.ToolTip = 'Ezappero: memoria indelebile e modalita traccia'
        $btnEz.Padding = New-Object System.Windows.Thickness(8,3,8,3)
        $btnEz.Margin = New-Object System.Windows.Thickness(0,0,4,0)
        $btnEz.FontSize = 9.5
        if ($stileTop) { $btnEz.Style = $stileTop }
        $btnEz.Background = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(212,175,55)))
        $btnEz.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(26,20,8)))
        [void]$top.Children.Add($btnEz)
    } else {
        Write-Fase 'v9: barra dei comandi non trovata, pulsante MEMORIA non aggiunto'
    }

    # ---- 2) i due pannelli, da ui\panel_v9.xaml ----
    $pxPath = Join-Path $base 'ui\panel_v9.xaml'
    if (Test-Path -LiteralPath $pxPath) {
        $px = Get-Content -LiteralPath $pxPath -Raw -Encoding UTF8
        $panelV9 = [Windows.Markup.XamlReader]::Parse($px)
        $radice = $Window.Content
        if ($radice -and $radice.Children) {
            try { [System.Windows.Controls.Grid]::SetColumnSpan($panelV9, 2) } catch { }
            try { [System.Windows.Controls.Grid]::SetRowSpan($panelV9, 2) } catch { }
            [void]$radice.Children.Add($panelV9)

            $PsPanel    = $panelV9.FindName('PsPanel')
            $PsCerca    = $panelV9.FindName('PsCerca')
            $PsElenco   = $panelV9.FindName('PsElenco')
            $PsCodice   = $panelV9.FindName('PsCodice')
            $PsInfo     = $panelV9.FindName('PsInfo')
            $EzPanel    = $panelV9.FindName('EzPanel')
            $EzStato    = $panelV9.FindName('EzStato')
            $EzDiario   = $panelV9.FindName('EzDiario')
            $BtnEzTraccia = $panelV9.FindName('BtnEzTraccia')
            $BtnEzPerimetro = $panelV9.FindName('BtnEzPerimetro')

            $script:PannelliV9 = $true
            Write-Fase 'v9: pannelli PS e MEMORIA caricati'
        } else {
            Write-Fase 'v9: radice della finestra non gestibile, pannelli non aggiunti'
        }
    } else {
        Write-Fase 'v9: ui\panel_v9.xaml non trovato, pannelli non disponibili'
    }

    # ---- 3) collegamento dei comandi (solo se i controlli esistono) ----
    if ($PsPanel -and $btnPs) {
        $bPsCerca    = $panelV9.FindName('BtnPsCerca')
        $bPsAggiorna = $panelV9.FindName('BtnPsAggiorna')
        $bPsCopia    = $panelV9.FindName('BtnPsCopia')
        $bPsEsegui   = $panelV9.FindName('BtnPsEsegui')
        $bPsCartella = $panelV9.FindName('BtnPsCartella')
        $bPsChiudi   = $panelV9.FindName('BtnPsChiudi')
        $bPsCrea     = $panelV9.FindName('BtnPsCrea')
        $PsRichiesta = $panelV9.FindName('PsRichiesta')

        # v9.2.1: la generazione dello script gira in un RUNSPACE dedicato
        # (brain\ps_crea_job.ps1) e risponde via $sync.UiQueue.
        # Prima la chiamata al modello era sul thread della UI: la finestra
        # restava bloccata finche' l'IA non rispondeva.
        if ($bPsCrea) {
            $bPsCrea.Add_Click({
                $q = ''
                try { if ($PsRichiesta) { $q = [string]$PsRichiesta.Text } } catch { }
                if (-not $q.Trim()) {
                    try { $PsInfo.Text = 'Scrivi cosa deve fare lo script (es: creami un comando powershell che elenca i file piu grandi della cartella Download).' } catch { }
                    return
                }
                if ($script:PsCreaOccupato) {
                    try { $PsInfo.Text = 'Sto gia scrivendo uno script: attendi che finisca.' } catch { }
                    return
                }
                $script:PsCreaOccupato = $true
                $script:PsCreaInizio   = Get-Date
                try {
                    if ($PsInfo) { $PsInfo.Text = 'ZAP sta scrivendo lo script... la finestra resta utilizzabile.' }
                    if ($bPsCrea) { $bPsCrea.IsEnabled = $false }
                    $sys = 'Sei un generatore di script PowerShell per Windows. Rispondi SOLO con il codice PowerShell richiesto: niente spiegazioni, niente markdown, nessun blocco di codice, nessun testo prima o dopo. Inizia con una riga di commento che descrive lo script. Usa solo comandi standard di Windows PowerShell 5.1, percorsi in variabili e nessun segnaposto da riempire: lo script deve essere pronto da eseguire.'

                    $rs = [runspacefactory]::CreateRunspace()
                    $rs.ApartmentState = 'STA'
                    $rs.ThreadOptions  = 'ReuseThread'
                    $rs.Open()
                    $rs.SessionStateProxy.SetVariable('sync', $sync)
                    $rs.SessionStateProxy.SetVariable('base', $base)
                    $rs.SessionStateProxy.SetVariable('domanda', $q)
                    $rs.SessionStateProxy.SetVariable('sysprompt', $sys)

                    $psCrea = [powershell]::Create()
                    $psCrea.Runspace = $rs
                    [void]$psCrea.AddScript((Get-Content (Join-Path $base 'brain\ps_crea_job.ps1') -Raw))
                    [void]$psCrea.BeginInvoke()

                    $script:PsCreaPs = $psCrea
                    $script:PsCreaRs = $rs
                } catch {
                    $script:PsCreaOccupato = $false
                    try { if ($bPsCrea) { $bPsCrea.IsEnabled = $true } } catch { }
                    try { if ($PsInfo) { $PsInfo.Text = 'Errore avvio generazione: ' + $_.Exception.Message } } catch { }
                }
            })
        }

        $btnPs.Add_Click({ try { $PsPanel.Visibility = 'Visible'; Ps-Ricarica '' } catch { } })
        if ($bPsAggiorna) { $bPsAggiorna.Add_Click({ try { if ($PsCerca) { $PsCerca.Text = '' }; Ps-Ricarica '' } catch { } }) }
        if ($bPsCerca)    { $bPsCerca.Add_Click({ try { Ps-Ricarica ([string]$PsCerca.Text) } catch { } }) }
        if ($PsCerca)     { $PsCerca.Add_KeyDown({ param($s1, $e1) if ($e1.Key -eq 'Return') { try { Ps-Ricarica ([string]$PsCerca.Text) } catch { } } }) }
        if ($PsElenco)    { $PsElenco.Add_SelectionChanged({ Ps-MostraSelezionato }) }
        if ($bPsCopia) {
            $bPsCopia.Add_Click({
                try {
                    if ($PsCodice.Text) {
                        Set-Clipboard -Value ([string]$PsCodice.Text) | Out-Null
                        $PsInfo.Text = 'Codice copiato negli appunti.'
                    }
                } catch { }
            })
        }
        if ($bPsEsegui) {
            $bPsEsegui.Add_Click({
                try {
                    $p = Ps-FileSelezionato
                    if (-not $p -or -not (Test-Path -LiteralPath $p)) { if ($PsInfo) { $PsInfo.Text = 'Nessuno script selezionato.' }; return }
                    $r = [System.Windows.MessageBox]::Show($Window,
                        ('Eseguire questo script su questo PC?' + [Environment]::NewLine + [Environment]::NewLine + $p),
                        'ZAP - esegui script', [System.Windows.MessageBoxButton]::YesNo, [System.Windows.MessageBoxImage]::Warning)
                    if ($r -ne [System.Windows.MessageBoxResult]::Yes) { return }
                    Start-Process -FilePath 'powershell.exe' -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "' + $p + '"') | Out-Null
                    if ($PsInfo) { $PsInfo.Text = 'Script avviato in una finestra separata.' }
                } catch {
                    try { if ($PsInfo) { $PsInfo.Text = 'Errore: ' + $_.Exception.Message } } catch { }
                }
            })
        }
        if ($bPsCartella) {
            $bPsCartella.Add_Click({ try { Start-Process explorer.exe -ArgumentList ('"' + (Get-PsLibreriaDir $sync) + '"') | Out-Null } catch { } })
        }
        if ($bPsChiudi) { $bPsChiudi.Add_Click({ try { $PsPanel.Visibility = 'Collapsed' } catch { } }) }
    }

    if ($EzPanel -and $btnEz) {
        $bEzVerifica = $panelV9.FindName('BtnEzVerifica')
        $bEzBackup   = $panelV9.FindName('BtnEzBackup')
        $bEzCartella = $panelV9.FindName('BtnEzCartella')
        $bEzChiudi   = $panelV9.FindName('BtnEzChiudi')

        $btnEz.Add_Click({ try { $EzPanel.Visibility = 'Visible'; Ez-Aggiorna } catch { } })
        if ($bEzVerifica) {
            $bEzVerifica.Add_Click({
                try {
                    $rep = Test-ZapIntegrita $sync
                    if ($rep.ok) {
                        [void][System.Windows.MessageBox]::Show($Window, ('Memoria integra: ' + $rep.totale + ' eventi, catena di hash valida.'), 'ZAP - memoria', 'OK', 'Information')
                    } else {
                        $fix = Repair-ZapDaSpecchio $sync
                        [void][System.Windows.MessageBox]::Show($Window, ($rep.messaggio + [Environment]::NewLine + [Environment]::NewLine + 'Ripristino: ' + $fix), 'ZAP - memoria', 'OK', 'Warning')
                    }
                    Ez-Aggiorna
                } catch { }
            })
        }
        if ($bEzBackup) {
            $bEzBackup.Add_Click({
                try {
                    $msg = Sync-EzapperoSpecchio $sync
                    $msg += [Environment]::NewLine + (Protect-Ezappero $sync)
                    [void][System.Windows.MessageBox]::Show($Window, $msg, 'ZAP - copia di sicurezza', 'OK', 'Information')
                    Ez-Aggiorna
                } catch { }
            })
        }
        if ($BtnEzTraccia) {
            $BtnEzTraccia.Add_Click({
                try {
                    if ((Get-TracciaStato $sync).attiva) { [void](Stop-Traccia $sync) } else { [void](Start-Traccia $sync) }
                    Ez-Aggiorna
                } catch { }
            })
        }
        if ($BtnEzPerimetro) {
            $BtnEzPerimetro.Add_Click({
                try {
                    $gc = Get-GhostConfig $sync
                    [void](Set-GhostPerimetro $sync (-not $gc.blocca_fuori_ambito))
                    Ez-Aggiorna
                } catch {
                    try { [void][System.Windows.MessageBox]::Show($Window, ('Perimetro non cambiato: ' + $_.Exception.Message), 'ZAP - perimetro', 'OK', 'Warning') } catch { }
                }
            })
        }
        if ($bEzCartella) {
            $bEzCartella.Add_Click({ try { Start-Process explorer.exe -ArgumentList ('"' + (Get-EzapperoDir $sync) + '"') | Out-Null } catch { } })
        }
        if ($bEzChiudi) { $bEzChiudi.Add_Click({ try { $EzPanel.Visibility = 'Collapsed' } catch { } }) }
    }
} catch {
    # QUALSIASI problema qui non deve impedire a ZAP di partire.
    try { Write-Fase ('v9: pannelli non caricati: ' + $_.Exception.Message) } catch { }
}

# ============================================================================
# v9.1  CABINA DI REGIA  (bottone AGENTI + monitoraggio live + perimetro GHOST)
# ----------------------------------------------------------------------------
# Questo blocco e' volutamente isolato: se qualcosa non va, ZAP parte lo stesso
# e al massimo manca la cabina. Non tocca nessuna funzione esistente.
# ============================================================================
$script:CabinaPronta = $false
$script:CabinaRighe = @{}
$script:CabinaFermati = @{}
$script:CabinaUltimoLog = ''

try {
    if (-not $sync.AgenteStop) { $sync.AgenteStop = [hashtable]::Synchronized(@{}) }
    if ($null -eq $sync.AgenteCorrente) { $sync.AgenteCorrente = '' }
    if ($null -eq $sync.SquadraPausa) { $sync.SquadraPausa = $false }
} catch { }

function Get-CabinaColoreStato {
    param([string]$Stato)
    switch (([string]$Stato).ToLowerInvariant()) {
        'pensa'      { return '#D4AF37' }
        'scrive'     { return '#E8C86A' }
        'strumento'  { return '#4EA1FF' }
        'in_coda'    { return '#9AA4AE' }
        'fatto'      { return '#39FF14' }
        'errore'     { return '#FF4B4B' }
        'fermato'    { return '#FF9F1C' }
        default      { return '#3A424D' }
    }
}

function New-CabinaPennello {
    param([string]$Colore)
    try {
        $conv = New-Object System.Windows.Media.BrushConverter
        return $conv.ConvertFromString([string]$Colore)
    } catch {
        $conv2 = New-Object System.Windows.Media.BrushConverter
        return $conv2.ConvertFromString('#9AA4AE')
    }
}

function Cabina-CostruisciRighe {
    param($Pannello)
    if (-not $Pannello) { return }
    $Pannello.Children.Clear()
    $script:CabinaRighe = @{}
    foreach ($id in @(Get-TelemetriaIds)) {
        $a = $null
        try { $a = Get-AgenteById $id } catch { $a = $null }
        $nome = ([string]$id).ToUpperInvariant()
        $titolo = ''
        if ($a) { $nome = [string]$a.nome; $titolo = [string]$a.titolo }

        $contenitore = New-Object System.Windows.Controls.StackPanel
        $contenitore.Margin = New-Object System.Windows.Thickness(0,0,0,6)

        $riga = New-Object System.Windows.Controls.Grid
        foreach ($larg in @(150, 120, 110, 1, 80, 92)) {
            $col = New-Object System.Windows.Controls.ColumnDefinition
            if ($larg -eq 1) {
                $col.Width = New-Object System.Windows.GridLength -ArgumentList 1, ([System.Windows.GridUnitType]::Star)
            } else {
                $col.Width = New-Object System.Windows.GridLength -ArgumentList ([double]$larg)
            }
            [void]$riga.ColumnDefinitions.Add($col)
        }

        $nomeTxt = New-Object System.Windows.Controls.TextBlock
        $nomeTxt.Text = $nome
        $nomeTxt.FontSize = 12
        $nomeTxt.FontWeight = [System.Windows.FontWeights]::Bold
        $nomeTxt.Foreground = (New-CabinaPennello '#F0E9D8')
        $nomeTxt.VerticalAlignment = 'Center'
        [void][System.Windows.Controls.Grid]::SetColumn($nomeTxt, 0)
        [void]$riga.Children.Add($nomeTxt)

        $pill = New-Object System.Windows.Controls.Border
        $pill.CornerRadius = New-Object System.Windows.CornerRadius(9)
        $pill.Padding = New-Object System.Windows.Thickness(8,2,8,2)
        $pill.HorizontalAlignment = 'Left'
        $pill.VerticalAlignment = 'Center'
        $pill.Background = (New-CabinaPennello '#3A424D')
        $badge = New-Object System.Windows.Controls.TextBlock
        $badge.Text = 'FERMO'
        $badge.FontSize = 10
        $badge.FontWeight = [System.Windows.FontWeights]::Bold
        $badge.Foreground = (New-CabinaPennello '#0A0A0A')
        $pill.Child = $badge
        [void][System.Windows.Controls.Grid]::SetColumn($pill, 1)
        [void]$riga.Children.Add($pill)

        $passoTxt = New-Object System.Windows.Controls.TextBlock
        $passoTxt.Text = ''
        $passoTxt.FontSize = 11
        $passoTxt.Foreground = (New-CabinaPennello '#9AA4AE')
        $passoTxt.VerticalAlignment = 'Center'
        [void][System.Windows.Controls.Grid]::SetColumn($passoTxt, 2)
        [void]$riga.Children.Add($passoTxt)

        $azioneTxt = New-Object System.Windows.Controls.TextBlock
        $azioneTxt.Text = $titolo
        $azioneTxt.FontSize = 11
        $azioneTxt.Foreground = (New-CabinaPennello '#D8DEE6')
        $azioneTxt.VerticalAlignment = 'Center'
        $azioneTxt.TextTrimming = [System.Windows.TextTrimming]::CharacterEllipsis
        [void][System.Windows.Controls.Grid]::SetColumn($azioneTxt, 3)
        [void]$riga.Children.Add($azioneTxt)

        $tempoTxt = New-Object System.Windows.Controls.TextBlock
        $tempoTxt.Text = '0s'
        $tempoTxt.FontSize = 11
        $tempoTxt.Foreground = (New-CabinaPennello '#6B7280')
        $tempoTxt.VerticalAlignment = 'Center'
        [void][System.Windows.Controls.Grid]::SetColumn($tempoTxt, 4)
        [void]$riga.Children.Add($tempoTxt)

        $btn = New-Object System.Windows.Controls.Button
        $btn.Content = 'FERMA'
        $btn.Width = 84
        $btn.Height = 24
        $btn.FontSize = 10
        $btn.FontWeight = [System.Windows.FontWeights]::Bold
        $btn.Tag = [string]$id
        $btn.Background = (New-CabinaPennello '#2A323D')
        $btn.Foreground = (New-CabinaPennello '#F0E9D8')
        [void][System.Windows.Controls.Grid]::SetColumn($btn, 5)
        [void]$riga.Children.Add($btn)
        $btn.Add_Click({
            param($s, $e)
            try { Cabina-FermaAgente ([string]$s.Tag) } catch { }
        })

        $dettaglio = New-Object System.Windows.Controls.TextBlock
        $dettaglio.Text = ''
        $dettaglio.FontSize = 10
        $dettaglio.Foreground = (New-CabinaPennello '#6B7280')
        $dettaglio.Margin = New-Object System.Windows.Thickness(4,2,0,0)
        $dettaglio.TextTrimming = [System.Windows.TextTrimming]::CharacterEllipsis

        [void]$contenitore.Children.Add($riga)
        [void]$contenitore.Children.Add($dettaglio)
        [void]$Pannello.Children.Add($contenitore)

        $script:CabinaRighe["$id"] = @{
            Pill = $pill; Badge = $badge; Passo = $passoTxt; Azione = $azioneTxt
            Tempo = $tempoTxt; Btn = $btn; Dettaglio = $dettaglio; Nome = $nome
        }
    }
}

function Cabina-FermaAgente {
    param([string]$Id)
    if (-not $Id) { return }
    try {
        $sync.AgenteStop[$Id] = $true
        [void](Write-TelemetriaEvento -Base $base -Id $Id -Stato 'fermato' -Azione 'fermato dalla cabina (pulsante)')
        Add-Activity ('- cabina: fermato ' + $Id + ' -')
    } catch { }
    try { Cabina-Aggiorna } catch { }
}

function Cabina-FermaTutto {
    try {
        $sync.SquadraStop = $true
        foreach ($id in @(Get-TelemetriaIds)) {
            try { $sync.AgenteStop[$id] = $true } catch { }
            try { [void](Write-TelemetriaEvento -Base $base -Id $id -Stato 'fermato' -Azione 'STOP GENERALE dalla cabina') } catch { }
        }
        Add-Activity '- cabina: STOP GENERALE -'
        if ($CabinaSintesi) { $CabinaSintesi.Text = 'STOP GENERALE: la squadra si ferma al prossimo passo.' }
    } catch { }
}

function Cabina-RiapriTutti {
    try {
        $sync.SquadraStop = $false
        foreach ($id in @(Get-TelemetriaIds)) { try { $sync.AgenteStop[$id] = $false } catch { } }
        Add-Activity '- cabina: agenti riabilitati -'
    } catch { }
}

function Cabina-GhostRicarica {
    try {
        if ($CabinaGhostModo) {
            if ($CabinaGhostModo.Items.Count -eq 0) {
                [void]$CabinaGhostModo.Items.Add('CHIUSO')
                [void]$CabinaGhostModo.Items.Add('AULA')
                [void]$CabinaGhostModo.Items.Add('APERTO')
            }
            $m = 'chiuso'
            try { $m = [string](Get-GhostModo $sync) } catch { }
            if ($m -eq 'aperto') { $CabinaGhostModo.SelectedIndex = 2 }
            elseif ($m -eq 'aula') { $CabinaGhostModo.SelectedIndex = 1 }
            else { $CabinaGhostModo.SelectedIndex = 0 }
        }
        if ($CabinaGhostAmbiti) {
            $a = @()
            try { $a = @(Get-GhostAmbiti $sync) } catch { }
            $CabinaGhostAmbiti.Text = ($a -join "`r`n")
        }
        if ($CabinaGhostInfo) {
            $h = $null
            try { $h = Get-GhostHud $sync } catch { $h = $null }
            if ($h) {
                $CabinaGhostInfo.Text = [string]$h.testo + '  -  ' + [string]$h.dettaglio
                $CabinaGhostInfo.Foreground = (New-CabinaPennello ([string]$h.colore))
            }
        }
    } catch { }
}

function Cabina-GhostApplica {
    try {
        $m = 'chiuso'
        if ($CabinaGhostModo -and $CabinaGhostModo.SelectedItem) { $m = [string]$CabinaGhostModo.SelectedItem }
        $r = Set-GhostPerimetro $sync $null $m.ToLower() 'scelto dalla cabina'
        Cabina-GhostRicarica
        try { Add-Bubble 'zap' $r } catch { }
        try { Ghost-AggiornaHud } catch { }
    } catch {
        try { Add-Bubble 'zap' ('Perimetro non cambiato: ' + $_.Exception.Message) } catch { }
    }
}

function Cabina-GhostSalvaElenco {
    try {
        $testo = ''
        if ($CabinaGhostAmbiti) { $testo = [string]$CabinaGhostAmbiti.Text }
        $r = Set-GhostAmbiti $sync $testo
        Cabina-GhostRicarica
        try { Add-Bubble 'zap' $r } catch { }
    } catch {
        try { Add-Bubble 'zap' ('Elenco non salvato: ' + $_.Exception.Message) } catch { }
    }
}

function Ghost-AggiornaHud {
    try {
        if (-not $script:BtnGhostHud) { return }
        $h = Get-GhostHud $sync
        $script:BtnGhostHud.Content = [string]$h.testo
        $script:BtnGhostHud.Foreground = (New-CabinaPennello '#0A0A0A')
        $script:BtnGhostHud.Background = (New-CabinaPennello ([string]$h.colore))
        $script:BtnGhostHud.ToolTip = [string]$h.dettaglio
    } catch { }
}

function Cabina-Apri {
    try {
        if (-not $CabinaPanel) { return }
        Cabina-GhostRicarica
        Cabina-Aggiorna
        $CabinaPanel.Visibility = 'Visible'
    } catch { }
}

function Cabina-Aggiorna {
    if (-not $CabinaPanel) { return }
    $s = $null
    try { $s = Read-TelemetriaStato $base } catch { $s = $null }
    if ($null -eq $s) { return }

    $lavorando = 0
    foreach ($id in @(Get-TelemetriaIds)) {
        $r = $null
        try { $r = $script:CabinaRighe["$id"] } catch { $r = $null }
        if (-not $r) { continue }
        $a = $null
        try { $a = Get-TelemetriaAgente $s $id } catch { $a = $null }
        if ($null -eq $a) { continue }

        $stato = 'fermo'
        try { $stato = [string]$a.stato } catch { }
        $colore = Get-CabinaColoreStato $stato

        try { $r.Pill.Background = (New-CabinaPennello $colore) } catch { }
        try { $r.Badge.Text = (Format-TelemetriaEtichetta $stato) } catch { }

        $passo = ''
        try { if ([int]$a.totale -gt 0) { $passo = ('passo ' + [string]$a.passo + '/' + [string]$a.totale) } } catch { $passo = '' }
        try { $r.Passo.Text = $passo } catch { }

        $az = ''
        try { $az = [string]$a.azione } catch { $az = '' }
        if (-not $az) { $az = '' }
        try { $r.Azione.Text = $az } catch { }

        $ms = 0
        try { $ms = [int]$a.ms } catch { $ms = 0 }
        try { $r.Tempo.Text = (Format-TelemetriaDurata $ms) } catch { }

        $det = ''
        try { $det = [string]$a.dettaglio } catch { $det = '' }
        if (-not $det) { try { $det = [string]$a.ultima_riga } catch { $det = '' } }
        if ($det.Length -gt 150) { $det = $det.Substring(0, 150) + '...' }
        try { $r.Dettaglio.Text = $det } catch { }

        if (@('pensa', 'scrive', 'strumento', 'in_coda') -contains $stato) { $lavorando++ }
    }

    # ---- watchdog: ferma chi si e' bloccato o sta facendo loop ----
    $lim = Get-TelemetriaLimiti $sync
    $al = $null
    try { $al = Test-TelemetriaAllarmeSquadra $s (Get-Date) $lim } catch { $al = $null }
    if ($al) {
        if ($al.livello -eq 'ok') {
            try { $CabinaAllarmeBox.Visibility = 'Collapsed' } catch { }
        } else {
            $pezzi = New-Object System.Collections.ArrayList
            foreach ($x in @($al.stop)) {
                $id = [string]$x.id
                [void]$pezzi.Add($id.ToUpperInvariant() + ': ' + (@($x.motivi) -join '; '))
                if (-not $script:CabinaFermati.ContainsKey($id)) {
                    $script:CabinaFermati[$id] = $true
                    try { $sync.AgenteStop[$id] = $true } catch { }
                    try { [void](Write-TelemetriaEvento -Base $base -Id $id -Stato 'fermato' -Azione ('stop automatico: ' + (@($x.motivi) -join '; '))) } catch { }
                    try { Add-Activity ('- watchdog: fermato ' + $id + ' (' + (@($x.motivi) -join '; ') + ') -') } catch { }
                }
            }
            foreach ($x in @($al.attenzione)) { [void]$pezzi.Add([string]$x.id + ': ' + (@($x.motivi) -join '; ')) }
            try {
                $CabinaAllarmeBox.Visibility = 'Visible'
                $CabinaAllarme.Text = 'CONTROLLO AGENTI: ' + ($pezzi -join '  |  ')
            } catch { }
        }
    }

    # ---- sintesi in alto ----
    try {
        $sq = 'fermo'
        try { $sq = [string]$s.squadra.stato } catch { }
        $richiesta = ''
        try { $richiesta = [string]$s.squadra.richiesta } catch { }
        if ($richiesta.Length -gt 70) { $richiesta = $richiesta.Substring(0, 70) + '...' }
        $CabinaSintesi.Text = 'squadra: ' + $sq + '   |   agenti al lavoro: ' + $lavorando + '/' + @(Get-TelemetriaIds).Count + $(if ($richiesta) { '   |   ' + $richiesta } else { '' })
    } catch { }
    try { if ($CabinaOrologio) { $CabinaOrologio.Text = (Get-Date -Format 'HH:mm:ss') } } catch { }

    # ---- log eventi ----
    try {
        if ($CabinaLog) {
            $ev = @(Get-TelemetriaEventiRecenti $base 30)
            $righe = New-Object System.Collections.ArrayList
            foreach ($e in $ev) {
                $ora = ''
                try { $ora = ([datetime]::Parse([string]$e.ora)).ToString('HH:mm:ss') } catch { $ora = '' }
                $nome = ([string]$e.agente).ToUpperInvariant()
                $st = ''
                try { $st = Format-TelemetriaEtichetta ([string]$e.stato) } catch { $st = '' }
                $az = ''
                try { $az = [string]$e.azione } catch { $az = '' }
                [void]$righe.Add(($ora.PadRight(9) + $nome.PadRight(10) + $st.PadRight(11) + $az))
            }
            $t = ($righe -join "`r`n")
            if ($t -ne $script:CabinaUltimoLog) {
                $script:CabinaUltimoLog = $t
                $CabinaLog.Text = $t
                try { $CabinaLog.ScrollToEnd() } catch { }
            }
        }
    } catch { }

    # ---- contatore sul pulsante AGENTI ----
    try {
        if ($script:BtnCabina) {
            # v9.2: stesso numero del pannello a sinistra (agenti ACCESI).
            # "chi sta lavorando" resta dentro la cabina, dove l'etichetta lo dice.
            $cg = $null
            try { $cg = Get-AgentiConteggioAttivi $sync } catch { $cg = $null }
            if ($cg) { $script:BtnCabina.Content = 'AGENTI ' + [string]$cg.attivi + '/' + [string]$cg.totale }
            else { $script:BtnCabina.Content = 'AGENTI ' + $lavorando + '/' + @(Get-TelemetriaIds).Count }
            if ($al -and $al.livello -eq 'stop') { $script:BtnCabina.Background = (New-CabinaPennello '#8B1E1E') }
            elseif ($al -and $al.livello -eq 'attenzione') { $script:BtnCabina.Background = (New-CabinaPennello '#7A5B10') }
            else { $script:BtnCabina.Background = (New-CabinaPennello '#1F3A2C') }
        }
    } catch { }
}

try {
    # ---- 1) pulsanti nella barra in alto ----
    $topC = $null
    try { $topC = $Window.FindName('TopComandi') } catch { $topC = $null }
    $stileTopC = $null
    try { $stileTopC = $Window.FindResource('TopBtn') } catch { $stileTopC = $null }

    if ($topC) {
        $script:BtnCabina = New-Object System.Windows.Controls.Button
        $script:BtnCabina.Name = 'BtnCabina'
        $script:BtnCabina.Content = 'AGENTI 0/7'
        try {
            $cg0 = Get-AgentiConteggioAttivi $sync
            if ($cg0) { $script:BtnCabina.Content = 'AGENTI ' + [string]$cg0.attivi + '/' + [string]$cg0.totale }
        } catch { }
        $script:BtnCabina.ToolTip = 'VERIFICA LAVORO AGENTI: chi sta lavorando, a che punto, da quanti secondi. Da qui fermi un agente o tutta la squadra.'
        $script:BtnCabina.Padding = New-Object System.Windows.Thickness(10,5,10,5)
        $script:BtnCabina.Margin = New-Object System.Windows.Thickness(0,0,6,0)
        $script:BtnCabina.FontWeight = [System.Windows.FontWeights]::Bold
        $script:BtnCabina.Foreground = (New-CabinaPennello '#EAF7EF')
        $script:BtnCabina.Background = (New-CabinaPennello '#1F3A2C')
        if ($stileTopC) { $script:BtnCabina.Style = $stileTopC }
        [void]$topC.Children.Add($script:BtnCabina)
        $script:BtnCabina.Add_Click({ try { Cabina-Apri } catch { } })

        $script:BtnGhostHud = New-Object System.Windows.Controls.Button
        $script:BtnGhostHud.Name = 'BtnGhostHud'
        $script:BtnGhostHud.Content = 'GHOST'
        $script:BtnGhostHud.ToolTip = 'Perimetro GHOST: CHIUSO / AULA / APERTO'
        $script:BtnGhostHud.Padding = New-Object System.Windows.Thickness(10,5,10,5)
        $script:BtnGhostHud.Margin = New-Object System.Windows.Thickness(0,0,6,0)
        $script:BtnGhostHud.FontWeight = [System.Windows.FontWeights]::Bold
        if ($stileTopC) { $script:BtnGhostHud.Style = $stileTopC }
        [void]$topC.Children.Add($script:BtnGhostHud)
        $script:BtnGhostHud.Add_Click({ try { Cabina-Apri } catch { } })
        Ghost-AggiornaHud
    }

    # ---- 2) il pannello, da ui\cabina.xaml ----
    $cabPath = Join-Path $base 'ui\cabina.xaml'
    if (Test-Path -LiteralPath $cabPath) {
        $cabXaml = Get-Content -LiteralPath $cabPath -Raw -Encoding UTF8
        $cabina = [Windows.Markup.XamlReader]::Parse($cabXaml)
        $radiceC = $Window.Content
        if ($radiceC -and $radiceC.Children) {
            try { [System.Windows.Controls.Grid]::SetColumnSpan($cabina, 2) } catch { }
            try { [System.Windows.Controls.Grid]::SetRowSpan($cabina, 2) } catch { }
            [void]$radiceC.Children.Add($cabina)

            $CabinaPanel        = $cabina.FindName('CabinaPanel')
            $CabinaElenco       = $cabina.FindName('CabinaElenco')
            $CabinaLog          = $cabina.FindName('CabinaLog')
            $CabinaSintesi      = $cabina.FindName('CabinaSintesi')
            $CabinaOrologio     = $cabina.FindName('CabinaOrologio')
            $CabinaAllarmeBox   = $cabina.FindName('CabinaAllarmeBox')
            $CabinaAllarme      = $cabina.FindName('CabinaAllarme')
            $BtnCabinaChiudi    = $cabina.FindName('BtnCabinaChiudi')
            $BtnCabinaFermaTutto = $cabina.FindName('BtnCabinaFermaTutto')
            $BtnCabinaPausa     = $cabina.FindName('BtnCabinaPausa')
            $BtnCabinaAzzera    = $cabina.FindName('BtnCabinaAzzera')
            $BtnCabinaCartella  = $cabina.FindName('BtnCabinaCartella')
            $CabinaGhostModo    = $cabina.FindName('CabinaGhostModo')
            $CabinaGhostApplica = $cabina.FindName('CabinaGhostApplica')
            $CabinaGhostAmbiti  = $cabina.FindName('CabinaGhostAmbiti')
            $CabinaGhostSalva   = $cabina.FindName('CabinaGhostSalva')
            $CabinaGhostInfo    = $cabina.FindName('CabinaGhostInfo')

            if ($CabinaElenco) { Cabina-CostruisciRighe $CabinaElenco }
            if ($BtnCabinaChiudi) { $BtnCabinaChiudi.Add_Click({ try { $CabinaPanel.Visibility = 'Collapsed' } catch { } }) }
            if ($BtnCabinaFermaTutto) {
                $BtnCabinaFermaTutto.Add_Click({
                    param($s, $e)
                    try {
                        if ($s.Content -eq 'FERMA TUTTO') { Cabina-FermaTutto; $s.Content = 'RIPRISTINA' }
                        else { Cabina-RiapriTutti; $s.Content = 'FERMA TUTTO' }
                    } catch { }
                })
            }
            if ($BtnCabinaPausa) {
                $BtnCabinaPausa.Add_Click({
                    param($s, $e)
                    try {
                        $sync.SquadraPausa = -not [bool]$sync.SquadraPausa
                        if ([bool]$sync.SquadraPausa) { $s.Content = 'RIPRENDI' } else { $s.Content = 'PAUSA' }
                    } catch { }
                })
            }
            if ($BtnCabinaAzzera) { $BtnCabinaAzzera.Add_Click({ try { [void](Reset-TelemetriaAgenti $base); Cabina-Aggiorna } catch { } }) }
            if ($BtnCabinaCartella) {
                $BtnCabinaCartella.Add_Click({
                    try {
                        $st = Read-TelemetriaStato $base
                        $c = [string]$st.squadra.cartella
                        if ($c -and (Test-Path -LiteralPath $c)) { Start-Process explorer.exe -ArgumentList ('"' + $c + '"') | Out-Null }
                        else { Start-Process explorer.exe -ArgumentList ('"' + (Join-Path $base 'report\agenti') + '"') | Out-Null }
                    } catch { }
                })
            }
            if ($CabinaGhostApplica) { $CabinaGhostApplica.Add_Click({ Cabina-GhostApplica }) }
            if ($CabinaGhostSalva)   { $CabinaGhostSalva.Add_Click({ Cabina-GhostSalvaElenco }) }

            Cabina-GhostRicarica

            # v9.1: se c'e' perimetro.txt i bersagli entrano DA SOLI nel perimetro
            # (una riga per bersaglio). Nessun comando da digitare in classe.
            try {
                $pf = Join-Path $base 'perimetro.txt'
                if (Test-Path -LiteralPath $pf) {
                    $prima = @(Get-GhostAmbiti $sync).Count
                    [void](Import-GhostPerimetroFile $sync)
                    $dopo = @(Get-GhostAmbiti $sync).Count
                    if ($dopo -gt $prima) {
                        try { Add-Activity ('- ghost: ' + ($dopo - $prima) + ' bersagli importati da perimetro.txt -') } catch { }
                        Ghost-AggiornaHud
                        Cabina-GhostRicarica
                    }
                }
            } catch { }

            $script:CabinaPronta = $true
            Write-Fase 'v9.1: cabina di regia caricata'
        } else {
            Write-Fase 'v9.1: radice della finestra non gestibile, cabina non aggiunta'
        }
    } else {
        Write-Fase 'v9.1: ui\cabina.xaml non trovato, cabina non disponibile'
    }
} catch {
    try { Write-Fase ('v9.1: cabina non caricata: ' + $_.Exception.Message) } catch { }
}

# ---- 3) timer: aggiorna la cabina e sorveglia gli agenti ----
try {
    if ($script:CabinaPronta) {
        $script:CabinaTimer = New-Object System.Windows.Threading.DispatcherTimer
        $script:CabinaTimer.Interval = [TimeSpan]::FromMilliseconds(900)
        $script:CabinaTimer.Add_Tick({ try { Cabina-Aggiorna } catch { } })
        $script:CabinaTimer.Start()
        try { Cabina-Aggiorna } catch { }
    }
} catch {
    try { Write-Fase ('v9.1: timer cabina non avviato: ' + $_.Exception.Message) } catch { }
}

# --- CAMBIA TEMA E COLORI ---
function Asp-Ricarica {
    $p = $sync.PaletteCorr
    if (-not $p) { $p = Get-PaletteDefault }
    $AspSfondo.Text = [string]$p.sfondo
    $AspSuperficie.Text = [string]$p.superficie
    $AspCampo.Text = [string]$p.campo
    $AspPill.Text = [string]$p.pill
    $AspAccento.Text = [string]$p.accento
    $AspAccentoChiaro.Text = [string]$p.accentoChiaro
    $AspAccentoScuro.Text = [string]$p.accentoScuro
    $AspArgento.Text = [string]$p.argento
    $AspArgentoScuro.Text = [string]$p.argentoScuro
    $AspTesto.Text = [string]$p.testo
    $AspTestoSuAccento.Text = [string]$p.testoSuAccento
    $AspBordo.Text = [string]$p.bordo
    $AspFont.Text = [string]$p.font
    $AspSize.Text = [string]$p.fontSize
}

function Asp-LeggiPalette {
    $p = Get-PaletteDefault
    $p.preset = 'personalizzato'
    $p.sfondo = $AspSfondo.Text.Trim()
    $p.superficie = $AspSuperficie.Text.Trim()
    $p.campo = $AspCampo.Text.Trim()
    $p.pill = $AspPill.Text.Trim()
    $p.accento = $AspAccento.Text.Trim()
    $p.accentoChiaro = $AspAccentoChiaro.Text.Trim()
    $p.accentoScuro = $AspAccentoScuro.Text.Trim()
    $p.argento = $AspArgento.Text.Trim()
    $p.argentoScuro = $AspArgentoScuro.Text.Trim()
    $p.testo = $AspTesto.Text.Trim()
    $p.testoSuAccento = $AspTestoSuAccento.Text.Trim()
    $p.bordo = $AspBordo.Text.Trim()
    $p.font = $AspFont.Text.Trim()
    try { $p.fontSize = [int]$AspSize.Text.Trim() } catch { $p.fontSize = 13 }
    if ($p.fontSize -lt 9) { $p.fontSize = 9 }
    if ($p.fontSize -gt 20) { $p.fontSize = 20 }
    return $p
}

function Asp-Salva {
    param($p)
    try {
        $h = @{}
        foreach ($k in @($p.Keys)) { $h[$k] = $p[$k] }
        $sync.Config.aspetto = $h
        Save-Config $sync
    } catch { }
}

function Asp-TemaDaFoto {
    param([string]$Percorso = '')
    # Se non mi passano un file, uso la prima FOTO allegata alla chat.
    if (-not $Percorso) {
        foreach ($a in @($sync.Allegati)) {
            $pp = ''
            try { $pp = [string]$a.Percorso } catch { }
            if ($pp -and (Test-Path $pp) -and ((Get-TipoAllegato $pp) -eq 'immagine')) { $Percorso = $pp; break }
        }
    }
    # Altrimenti chiedo di scegliere un'immagine.
    if (-not $Percorso) {
        try {
            $dlg = New-Object Microsoft.Win32.OpenFileDialog
            $dlg.Title  = 'Scegli una foto per creare il tema'
            $dlg.Filter = 'Immagini|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp;*.tif;*.tiff|Tutti i file|*.*'
            if ($dlg.ShowDialog($Window) -ne $true) { return }
            $Percorso = $dlg.FileName
        } catch { return }
    }
    $StatusText.Text = 'GUARDO LA FOTO...'
    $p = $null
    try { $p = Get-PaletteDaImmagine $Percorso } catch { $p = $null }
    if (-not $p) {
        Add-Bubble 'zap' 'Non riesco a leggere quella foto. Prova con un PNG o JPG.'
        $StatusText.Text = 'ERRORE'
        return
    }
    $p.sfondoImmagine = $Percorso
    Applica-Palette $sync $Window $p
    Asp-ApplicaSfondo $sync $Percorso
    Asp-Salva $p
    Asp-Ricarica
    Set-AvatarState 'ok'
    Show-Onomatopea 'NUOVO LOOK!'
    Add-Bubble 'zap' ('Ho creato un tema con i colori della foto "' + [System.IO.Path]::GetFileName($Percorso) + '". Se non ti piace: /tema e scegli AURA.')
    $StatusText.Text = 'TEMA DALLA FOTO!'
}

function Asp-Applica {
    param([string]$Nome)
    $p = $null
    if ($Nome) { $p = Get-TemaPreset $Nome } else { $p = Asp-LeggiPalette }
    Applica-Palette $sync $Window $p
    try { Asp-ApplicaSfondo $sync ([string]$p.sfondoImmagine) } catch { }
    Asp-Salva $p
    Asp-Ricarica
    Set-AvatarState 'ok'
    Show-Onomatopea 'NUOVO LOOK!'
    $StatusText.Text = 'TEMA APPLICATO!'
}

$BtnAspetto.Add_Click({
    Asp-Ricarica
    $AspettoPanel.Visibility = 'Visible'
})
$BtnAspApplica.Add_Click({ Asp-Applica '' })
$BtnAspRipristina.Add_Click({ Asp-Applica 'aura' })
$BtnAspChiudi.Add_Click({ $AspettoPanel.Visibility = 'Collapsed' })
if ($BtnTemaAura)     { $BtnTemaAura.Add_Click({ Asp-Applica 'aura' }) }
if ($BtnTemaNotte)    { $BtnTemaNotte.Add_Click({ Asp-Applica 'notte' }) }
if ($BtnTemaSmeraldo) { $BtnTemaSmeraldo.Add_Click({ Asp-Applica 'smeraldo' }) }
if ($BtnTemaViola)    { $BtnTemaViola.Add_Click({ Asp-Applica 'viola' }) }
if ($BtnTemaChiaro)   { $BtnTemaChiaro.Add_Click({ Asp-Applica 'chiaro' }) }
if ($BtnTemaFoto)     { $BtnTemaFoto.Add_Click({ Asp-TemaDaFoto }) }

$Window.Add_Closed({
    $sync.Quit = $true
    Stop-Listen $sync
    Stop-Speak $sync
    if ($sync.CurrentExec) { try { $sync.CurrentExec.Stop() } catch { } }
})

# --------------------------------------------------------------------------
# ALLEGATI / UPLOAD: allega un file di qualunque tipo, guardalo e fallo elaborare
# --------------------------------------------------------------------------

function Get-TipoAllegato {
    param([string]$Percorso)
    $ext = ''
    try { $ext = [System.IO.Path]::GetExtension($Percorso).ToLower() } catch { }
    if (@('.png','.jpg','.jpeg','.gif','.bmp','.webp','.tif','.tiff','.ico') -contains $ext) { return 'immagine' }
    if (@('.mp4','.mov','.avi','.mkv','.webm','.wmv','.m4v','.mpg','.mpeg','.3gp') -contains $ext) { return 'video' }
    if (@('.txt','.md','.log','.csv','.tsv','.json','.xml','.yml','.yaml','.ini','.cfg','.conf','.env',
          '.ps1','.psm1','.psd1','.bat','.cmd','.sh','.py','.js','.ts','.html','.htm','.css','.sql',
          '.cs','.java','.c','.cpp','.h','.r','.vb') -contains $ext) { return 'testo' }
    if (@('.docx','.xlsx','.pptx') -contains $ext) { return 'office' }
    if ($ext -eq '.pdf') { return 'pdf' }
    return 'altro'
}

function Get-TestoDaOffice {
    # docx/xlsx/pptx sono archivi ZIP con XML dentro: si estrae il testo senza altri programmi.
    param([string]$Percorso)
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $zip = [System.IO.Compression.ZipFile]::OpenRead($Percorso)
        $testo = ''
        foreach ($v in $zip.Entries) {
            if ($v.FullName -match '(document|sharedStrings|slide[0-9]+|sheet[0-9]+)\.xml$') {
                $sr = New-Object System.IO.StreamReader($v.Open())
                $x = $sr.ReadToEnd()
                $sr.Close()
                $x = $x -replace '<[^>]+>', ' '
                $testo = $testo + ' ' + ($x -replace '\s+', ' ')
            }
        }
        $zip.Dispose()
        return $testo.Trim()
    } catch { return '' }
}

function Get-TestoDaPdf {
    # Estrazione "best effort" del testo dei PDF non compressi (senza programmi esterni).
    param([string]$Percorso)
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Percorso)
        $s = [System.Text.Encoding]::GetEncoding(1252).GetString($bytes)
        $pezzi = @()
        foreach ($m in [regex]::Matches($s, '\(([^)]{2,})\)\s*Tj')) { $pezzi += $m.Groups[1].Value }
        foreach ($m in [regex]::Matches($s, '\[(.*?)\]\s*TJ')) { $pezzi += ($m.Groups[1].Value -replace '[\[\]]', ' ') }
        return (($pezzi -join ' ') -replace '\s+', ' ').Trim()
    } catch { return '' }
}

function Aggiorna-BarraAllegati {
    param($sync)
    if (-not $AllegatiBar) { return }
    $AllegatiBar.Children.Clear()
    if ($sync.Allegati.Count -eq 0) {
        $AllegatiBar.Visibility = 'Collapsed'
        if ($AllegatiInfo) { $AllegatiInfo.Text = '' }
        return
    }
    $AllegatiBar.Visibility = 'Visible'
    $tot = 0
    foreach ($a in @($sync.Allegati)) { $tot += [int]$a.Byte }
    if ($AllegatiInfo) { $AllegatiInfo.Text = ('(' + $sync.Allegati.Count + ' allegati, ' + [Math]::Round($tot / 1024.0, 1) + ' KB)') }
    $i = 0
    foreach ($a in @($sync.Allegati)) {
        $btn = New-Object System.Windows.Controls.Button
        $btn.Content = ([string]$a.Tipo + ': ' + [string]$a.Nome + '   x')
        $btn.FontSize = 11
        $btn.Foreground = '#EFDC8F'
        $btn.Background = '#1C222C'
        $btn.BorderBrush = '#D4AF37'
        $btn.BorderThickness = '1'
        $btn.Padding = '8,3'
        $btn.Margin = '0,0,6,0'
        $btn.Tag = $i
        $h = { Rimuovi-Allegato $sync ([int]$btn.Tag) }
        $btn.Add_Click($h.GetNewClosure())
        [void]$AllegatiBar.Children.Add($btn)
        $i = $i + 1
    }
}

function Aggiungi-Allegato {
    param($sync, [string]$Percorso)
    if (-not (Test-Path $Percorso)) { return }
    $voce = @{
        Percorso = $Percorso
        Nome     = [System.IO.Path]::GetFileName($Percorso)
        Tipo     = (Get-TipoAllegato $Percorso)
        Byte     = 0
        Testo    = ''
        B64      = ''
        Mime     = 'image/png'
    }
    try { $voce.Byte = (Get-Item $Percorso).Length } catch { }
    if ($voce.Tipo -eq 'testo') {
        try { $voce.Testo = [string](Get-Content -Path $Percorso -Raw -Encoding UTF8) } catch {
            try { $voce.Testo = [string](Get-Content -Path $Percorso -Raw) } catch { $voce.Testo = '' }
        }
        if ($voce.Testo.Length -gt 20000) { $voce.Testo = $voce.Testo.Substring(0, 20000) + "`n[... testo tagliato per lunghezza ...]" }
    } elseif ($voce.Tipo -eq 'office') {
        $voce.Testo = Get-TestoDaOffice $Percorso
    } elseif ($voce.Tipo -eq 'pdf') {
        $voce.Testo = Get-TestoDaPdf $Percorso
        # PDF scansionato o con poco testo: lo fa leggere direttamente al modello (vista documento)
        if (([string]$voce.Testo).Trim().Length -lt 200 -and [int]$voce.Byte -le 14000000) {
            try {
                $voce.B64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($Percorso))
                $voce.Mime = 'application/pdf'
            } catch { }
        }
    } elseif ($voce.Tipo -eq 'immagine') {
        $ext = [System.IO.Path]::GetExtension($Percorso).ToLower()
        $voce.Mime = 'image/png'
        if ($ext -eq '.jpg' -or $ext -eq '.jpeg') { $voce.Mime = 'image/jpeg' }
        elseif ($ext -eq '.gif') { $voce.Mime = 'image/gif' }
        elseif ($ext -eq '.bmp') { $voce.Mime = 'image/bmp' }
        elseif ($ext -eq '.webp') { $voce.Mime = 'image/webp' }
        try {
            if ([int]$voce.Byte -le 8000000) {
                $voce.B64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($Percorso))
            } else { $voce.Testo = '[immagine troppo grande per essere inviata: oltre 8 MB]' }
        } catch { }
    } elseif ($voce.Tipo -eq 'video') {
        $ext = [System.IO.Path]::GetExtension($Percorso).ToLower()
        $voce.Mime = 'video/mp4'
        if ($ext -eq '.mov') { $voce.Mime = 'video/quicktime' }
        elseif ($ext -eq '.webm') { $voce.Mime = 'video/webm' }
        elseif ($ext -eq '.avi') { $voce.Mime = 'video/x-msvideo' }
        elseif ($ext -eq '.wmv') { $voce.Mime = 'video/x-ms-wmv' }
        elseif ($ext -eq '.mkv') { $voce.Mime = 'video/x-matroska' }
        elseif ($ext -eq '.m4v') { $voce.Mime = 'video/x-m4v' }
        elseif ($ext -eq '.mpg' -or $ext -eq '.mpeg') { $voce.Mime = 'video/mpeg' }
        try {
            if ([int]$voce.Byte -le 14000000) {
                $voce.B64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($Percorso))
            } else { $voce.Testo = '[video troppo grande per l invio diretto: oltre 14 MB. Carica un fotogramma o riducilo.]' }
        } catch { }
    }
    [void]$sync.Allegati.Add($voce)
    Aggiorna-BarraAllegati $sync
}

function Rimuovi-Allegato {
    param($sync, [int]$Indice)
    if ($Indice -ge 0 -and $Indice -lt $sync.Allegati.Count) { $sync.Allegati.RemoveAt($Indice) }
    Aggiorna-BarraAllegati $sync
}

function Svuota-Allegati {
    param($sync)
    $sync.Allegati.Clear()
    Aggiorna-BarraAllegati $sync
}

function Apri-SceltaFile {
    param($sync, [string]$Tipo = 'tutto')
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Multiselect = $true
    if ($Tipo -eq 'foto') {
        $dlg.Title = 'Scegli una o piu immagini'
        $dlg.Filter = 'Immagini (*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.webp)|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.webp|Tutti i file (*.*)|*.*'
    } elseif ($Tipo -eq 'video') {
        $dlg.Title = 'Scegli uno o piu video'
        $dlg.Filter = 'Video (*.mp4;*.mov;*.avi;*.mkv;*.webm;*.wmv;*.m4v)|*.mp4;*.mov;*.avi;*.mkv;*.webm;*.wmv;*.m4v|Tutti i file (*.*)|*.*'
    } else {
        $dlg.Title = 'Scegli i file da dare a ZAP (qualunque tipo: foto, video, PDF, documenti)'
        $dlg.Filter = 'Tutti i file (*.*)|*.*'
    }
    $esito = $dlg.ShowDialog($Window)
    if ($esito -eq $true) {
        foreach ($f in @($dlg.FileNames)) { Aggiungi-Allegato $sync $f }
        $StatusText.Text = ('ALLEGATI: ' + $sync.Allegati.Count + ' pronti')
        Set-AvatarState 'pensa'
    }
}

function Get-AllegatiPerIA {
    # Trasforma gli allegati in testo per lo ZAP. Le immagini le fa "guardare" con la vista.
    param($sync)
    if ($sync.Allegati.Count -eq 0) { return '' }
    $righe = @()
    $righe += ''
    $righe += '--- ALLEGATI CHE TI HO DATO ---'
    foreach ($a in @($sync.Allegati)) {
        $righe += ('* ' + [string]$a.Tipo + ': ' + [string]$a.Nome + ' (' + [int]$a.Byte + ' byte)')
        if ([string]$a.Testo) {
            $righe += [string]$a.Testo
        } elseif ([string]$a.B64) {
            $descr = ''
            $domanda = 'Descrivi questa immagine in italiano, in modo breve e utile: cosa si vede, il testo leggibile e i dati importanti.'
            $etichetta = 'cosa vedo nell immagine'
            if ([string]$a.Tipo -eq 'video') {
                $domanda = 'Guarda questo video e raccontami in italiano, breve e utile: cosa succede, cosa si vede, eventuali testi o parlato importanti.'
                $etichetta = 'cosa vedo nel video'
            } elseif ([string]$a.Tipo -eq 'pdf') {
                $domanda = 'Leggi questo documento PDF e riassumi in italiano i punti importanti, i dati e i numeri che contiene.'
                $etichetta = 'cosa dice il documento'
            }
            try {
                $StatusText.Text = ('GUARDO: ' + [string]$a.Nome)
                $descr = [string](Invoke-GeminiVision $sync $domanda ([string]$a.B64) ([string]$a.Mime))
            } catch { $descr = '' }
            if ($descr) { $righe += ('[' + $etichetta + '] ' + $descr) }
            else { $righe += '[allegato: non sono riuscito a leggerlo (serve una chiave con la vista attiva)]' }
        } else {
            $righe += '[file allegato: non riesco a leggerne il contenuto automaticamente]'
        }
    }
    $righe += '--- FINE ALLEGATI ---'
    return ($righe -join "`n")
}

# --------------------------------------------------------------------------
# INTELLIGENZE AI (pannello + selettore). Le chiavi stanno solo in config.json.
# --------------------------------------------------------------------------

function Get-AiTextBoxes {
    param($radice)
    $out = New-Object System.Collections.ArrayList
    if ($null -eq $radice) { return @() }
    if ($radice -is [System.Windows.Controls.TextBox]) { [void]$out.Add($radice) }
    elseif ($radice -is [System.Windows.Controls.Panel]) { foreach ($c in $radice.Children) { foreach ($x in (Get-AiTextBoxes $c)) { [void]$out.Add($x) } } }
    elseif ($radice -is [System.Windows.Controls.Border]) { foreach ($x in (Get-AiTextBoxes $radice.Child)) { [void]$out.Add($x) } }
    elseif ($radice -is [System.Windows.Controls.ContentControl]) { if ($radice.Content) { foreach ($x in (Get-AiTextBoxes $radice.Content)) { [void]$out.Add($x) } } }
    return @($out.ToArray())
}

function New-AiField {
    param($pannello, [string]$etichetta, [string]$id, [string]$campo, [string]$valore)
    $l = New-Object System.Windows.Controls.TextBlock
    $l.Text = $etichetta; $l.FontSize = 11; $l.FontWeight = 'Bold'; $l.Margin = '0,4,0,0'; $l.Foreground = '#E8C86A'
    [void]$pannello.Children.Add($l)
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = [string]$valore
    $tb.FontSize = 13; $tb.FontFamily = 'Segoe UI'; $tb.Padding = '4,3'
    $tb.Background = '#141922'; $tb.Foreground = '#F0E9D8'; $tb.CaretBrush = '#D4AF37'
    $tb.BorderBrush = '#2A323D'; $tb.BorderThickness = '1'; $tb.Margin = '0,0,0,2'
    $tb.Tag = ($campo + ':' + $id)
    Set-InputTextMenu $tb
    [void]$pannello.Children.Add($tb)
}

function Aggiorna-AiList {
    if (-not $AiList) { return }
    $AiList.Children.Clear()
    if ($AiIntro) {
        $AiIntro.Text = ('Incolla la TUA chiave e scrivi il nome del modello per i servizi che vuoi usare. ' +
            'Finche'' un servizio non ha chiave E modello resta [ ] e non viene mai scelto. ' +
            'Io non posso procurarti le chiavi: premi "COME AVERE LE CHIAVI". ' +
            'Le chiavi restano solo nel tuo config.json e non finiscono mai nei log. ' +
            'Con IN SQUADRA: ON il servizio partecipa alla risposta unica (interruttore TUTTE INSIEME, a sinistra).')
    }
    foreach ($r in Get-ProviderRegistry) {
        $id = [string]$r.id
        $cfg = Get-ProviderConfig $sync $id
        $pronto = $false
        try { $pronto = Test-ProviderReady $sync $id } catch { }
        $box = New-Object System.Windows.Controls.Border
        $box.BorderBrush = '#2A323D'; $box.BorderThickness = '1.5'; $box.CornerRadius = '12'
        $box.Padding = '10'; $box.Margin = '0,0,0,8'; $box.Background = '#161B22'
        $sp = New-Object System.Windows.Controls.StackPanel
        $tit = New-Object System.Windows.Controls.TextBlock
        $tit.FontSize = 15; $tit.FontWeight = 'Bold'; $tit.Foreground = '#E8C86A'
        $tit.Text = ([string]$r.nome + '  ' + $(if ($pronto) { '[PRONTO]' } else { '[ ]' }))
        [void]$sp.Children.Add($tit)
        $nota = New-Object System.Windows.Controls.TextBlock
        $nota.FontSize = 11; $nota.FontStyle = 'Italic'; $nota.Foreground = '#9AA4AE'; $nota.TextWrapping = 'Wrap'
        $nota.Text = ('Lavori adatti: ' + (@($cfg.compiti) -join ', ') + '   -   pagina della chiave: ' + [string]$r.keyurl)
        [void]$sp.Children.Add($nota)
        New-AiField $sp 'Chiave (lascia vuoto se non usi questo servizio)' $id 'chiave' $cfg.chiave
        New-AiField $sp 'Endpoint (gia compilato: cambialo solo se sai cosa fai)' $id 'endpoint' $cfg.endpoint
        New-AiField $sp 'Modello (scrivi il nome esatto del modello scelto)' $id 'modello' $cfg.modello
        $b = New-Object System.Windows.Controls.Button
        $b.Content = 'SALVA QUESTO SERVIZIO'; $b.FontSize = 12; $b.Margin = '0,6,0,0'
        $b.Background = '#D4AF37'; $b.Foreground = '#1A1408'; $b.BorderBrush = '#D4AF37'; $b.BorderThickness = '1'; $b.Padding = '8,4'
        $b.Add_Click({ Save-AiPanel; Aggiorna-AiList; Add-Bubble 'zap' 'Salvato.' })
        [void]$sp.Children.Add($b)

        # v9.5: interruttore "in squadra" per questo servizio
        $bs = New-Object System.Windows.Controls.Button
        $bs.Content = 'IN SQUADRA: ' + $(if ($cfg.abilitato -eq $false) { 'OFF' } else { 'ON' })
        $bs.FontSize = 12
        $bs.Margin = '0,4,0,0'
        $bs.Padding = '8,4'
        $bs.BorderThickness = '1'
        $bs.Tag = $id
        if ($cfg.abilitato -eq $false) {
            $bs.Background = '#1A2028'; $bs.Foreground = '#C9CFD6'; $bs.BorderBrush = '#2A323D'
        } else {
            $bs.Background = '#2F6B4F'; $bs.Foreground = '#EAF6F0'; $bs.BorderBrush = '#3DDC84'
        }
        $bs.ToolTip = 'Accende o spegne questo servizio nella squadra (risposta unica da piu intelligenze).'
        $bs.Add_Click({
            param($mittente, $evento)
            try {
                if (Get-Command Toggle-IntelligenzaSquadra -ErrorAction SilentlyContinue) {
                    Toggle-IntelligenzaSquadra ([string]$mittente.Tag)
                    Aggiorna-AiList
                }
            } catch { }
        })
        [void]$sp.Children.Add($bs)
        $box.Child = $sp
        [void]$AiList.Children.Add($box)
    }
}

function Save-AiPanel {
    if (-not $sync.Config.provider_ai) { $sync.Config.provider_ai = Get-DefaultProviderAi }
    foreach ($tb in (Get-AiTextBoxes $AiList)) {
        $tag = [string]$tb.Tag
        if (-not $tag -or ($tag -notlike '*:*')) { continue }
        $i = $tag.IndexOf(':')
        $campo = $tag.Substring(0, $i)
        $id = $tag.Substring($i + 1)
        if (-not $sync.Config.provider_ai.ContainsKey($id)) { continue }
        $sync.Config.provider_ai[$id][$campo] = $tb.Text.Trim()
    }
    Save-Config $sync
}

function Aggiorna-AiCombo {
    if (-not $AiSel) { return }
    $mod = 'auto'
    try { if ($sync.Config.modalita_ai) { $mod = [string]$sync.Config.modalita_ai } } catch { }
    $AiSel.Items.Clear()
    [void]$AiSel.Items.Add('AUTOMATICO')
    foreach ($r in Get-ProviderRegistry) {
        $segno = ''
        try { if (Test-ProviderReady $sync ([string]$r.id)) { $segno = ' *' } } catch { }
        [void]$AiSel.Items.Add(([string]$r.id + $segno))
    }
    $daScegliere = 'AUTOMATICO'
    if ($mod -and $mod -ne 'auto') { $daScegliere = $mod }
    foreach ($it in @($AiSel.Items)) {
        $s = [string]$it
        if ($s -eq $daScegliere -or $s -like ($daScegliere + ' *')) { $AiSel.SelectedItem = $it; break }
    }
}

function Set-AiDaCombo {
    if (-not $AiSel -or -not $AiSel.SelectedItem) { return }
    $v = [string]$AiSel.SelectedItem
    if ($v -like 'AUTOMATICO*') { $sync.Config.modalita_ai = 'auto' }
    else { $sync.Config.modalita_ai = ($v -replace '\s*\*$', '') }
    Save-Config $sync
}

# --------------------------------------------------------------------------
function Test-ChatSilenziosa {
    # v9.4: default SI = la chat mostra SOLO la risposta finale.
    # I passaggi restano fuori dalla chat (nessuna riga "sto aprendo...").
    return (Get-CfgBool $sync.Config 'chat_silenziosa' $true)
}

# Timer di servizio: coda UI, conferme, microfono, fine parlato
# --------------------------------------------------------------------------

$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(120)

$timer.Add_Tick({

    # 1) Richieste di conferma dall'agente
    if ($sync.ConfirmRequest) {
        $req = $sync.ConfirmRequest
        $res = [System.Windows.MessageBox]::Show($Window,
            [string]$req.Text, 'ZAP! chiede conferma',
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Warning)
        $sync.ConfirmResult = ($res -eq [System.Windows.MessageBoxResult]::Yes)
        $sync.ConfirmRequest = $null
        try { if ($sync.ConfirmDone) { $sync.ConfirmDone.Set() } } catch { }
    }

    # 2) Coda dei messaggi dall'agente
    $item = $null
    while ($sync.UiQueue.TryDequeue([ref]$item)) {
        $type = [string]$item.Type
        $data = $item.Data
        switch ($type) {
            'chat' {
                Clear-LiveBubble
                Add-Bubble ([string]$data.who) ([string]$data.text)
            }
            'chatpartial' {
                # v9.4: in modalita' silenziosa non mostro il testo che scorre
                if (-not (Test-ChatSilenziosa)) {
                    if (([string]$data).Trim()) { Add-LiveBubble ([string]$data) }
                }
            }
            'userbubble' {
                # (gia mostrato dall'invio locale, se arriva doppio lo ignoriamo)
            }
            'agente' {
                Handle-AgenteEvento $data
            }
            'agenti' {
                # ZAP ha acceso/spento un agente: ridisegno il pannello a sinistra
                try { Update-AgentiPadrone } catch { }
            }
            'orchestra' {
                # v9.5: la squadra IA ha finito: riquadro compatto con le risposte dei modelli
                try { Add-OrchestraBolla $data } catch { }
            }
            'cine' {
                Handle-CineEvento $data
            }
            'status' {
                $StatusText.Text = [string]$data
            }
            'avatar' {
                Set-AvatarState ([string]$data)
            }
            'speak' {
                if ($sync.Config.voce.risposte_ad_alta_voce) {
                    $say = ConvertTo-SpeechText ([string]$data)
                    Set-AvatarState 'parla'
                    $sync.SpeakingTicks = 0
                    Start-Speak $sync $say
                }
            }
            'tool' {
                Clear-LiveBubble
                $StatusText.Text = ("ESEGUO: " + [string]$data)
                Set-AvatarState 'pensa'
                if (-not (Test-ChatSilenziosa)) { Add-Activity (" " + [string]$data + '...') }
                Show-Onomatopea ''
            }
            'toolresult' {
                $t = [string]$data.text
                if ($t.Length -gt 260) { $t = $t.Substring(0, 260) + '...' }
                $t = $t -replace "`r?`n", ' '
                if (-not (Test-ChatSilenziosa)) { Add-Activity ("-> " + [string]$data.name + ': ' + $t) }
            }
            'skin' {
                # v9.4: l'agente cambia interfaccia (arriva dallo strumento 'skin')
                try { [void](Set-Skin -Window $Window -Base $base -Nome ([string]$data)) } catch { }
            }
            'nastro' {
                # v9.4: l'agente accende/spegne il nastro (strumento 'nastro_notizie')
                try { [void](Set-ZapTickerVisibile -Window $Window -Base $base -Visibile ([bool]$data)) } catch { }
            }
            'kali_out' {
                if ($KaliOut) { $KaliOut.AppendText([string]$data + "`r`n"); $KaliOut.ScrollToEnd() }
            }
            'kali_tools' {
                if ($KaliTools) {
                    $KaliTools.Children.Clear()
                    $convk = New-Object System.Windows.Media.BrushConverter
                    if ([bool]$data.pronto) {
                        $KaliStatus.Text = 'Kali pronto (WSL). I comandi vengono eseguiti DENTRO Kali Linux.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#39FF14')
                    } else {
                        $KaliStatus.Text = 'Kali non ancora installato. Premi INSTALLA KALI. Nel frattempo i comandi girano in PowerShell.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#FFD24A')
                    }
                    foreach ($t in @($data.lista)) {
                        $riga = New-Object System.Windows.Controls.StackPanel
                        $riga.Orientation = 'Horizontal'
                        $riga.Margin = [System.Windows.Thickness]::new(0, 3, 0, 3)
                        $cb = New-Object System.Windows.Controls.CheckBox
                        $cb.Tag = [string]$t.id
                        $cb.Foreground = $convk.ConvertFromString('#7CFF7C')
                        [void]$riga.Children.Add($cb)
                        $tb = New-Object System.Windows.Controls.TextBlock
                        $stato = 'NON INSTALLATO'
                        if ($t.installato) { $stato = 'INSTALLATO' }
                        $tb.Text = ('  ' + [string]$t.nome + '  [' + $stato + ']  ' + [string]$t.desc)
                        $tb.FontFamily = 'Consolas'
                        $tb.FontSize = 12
                        if ($t.installato) { $tb.Foreground = $convk.ConvertFromString('#39FF14') } else { $tb.Foreground = $convk.ConvertFromString('#C88B8B') }
                        [void]$riga.Children.Add($tb)
                        [void]$KaliTools.Children.Add($riga)
                    }
                }
            }
            'kali_out' {
                if ($KaliOut) { $KaliOut.AppendText([string]$data + "`r`n"); $KaliOut.ScrollToEnd() }
            }
            'kali_tools' {
                if ($KaliTools) {
                    $KaliTools.Children.Clear()
                    $convk = New-Object System.Windows.Media.BrushConverter
                    if ([bool]$data.pronto) {
                        $KaliStatus.Text = 'Kali pronto (WSL). I comandi vengono eseguiti DENTRO Kali Linux.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#39FF14')
                    } else {
                        $KaliStatus.Text = 'Kali non ancora installato. Premi INSTALLA KALI. Nel frattempo i comandi girano in PowerShell.'
                        $KaliStatus.Foreground = $convk.ConvertFromString('#FFD24A')
                    }
                    foreach ($t in @($data.lista)) {
                        $riga = New-Object System.Windows.Controls.StackPanel
                        $riga.Orientation = 'Horizontal'
                        $riga.Margin = [System.Windows.Thickness]::new(0, 3, 0, 3)
                        $cb = New-Object System.Windows.Controls.CheckBox
                        $cb.Tag = [string]$t.id
                        $cb.Foreground = $convk.ConvertFromString('#7CFF7C')
                        [void]$riga.Children.Add($cb)
                        $tb = New-Object System.Windows.Controls.TextBlock
                        $stato = 'NON INSTALLATO'
                        if ($t.installato) { $stato = 'INSTALLATO' }
                        $tb.Text = ('  ' + [string]$t.nome + '  [' + $stato + ']  ' + [string]$t.desc)
                        $tb.FontFamily = 'Consolas'
                        $tb.FontSize = 12
                        if ($t.installato) { $tb.Foreground = $convk.ConvertFromString('#39FF14') } else { $tb.Foreground = $convk.ConvertFromString('#C88B8B') }
                        [void]$riga.Children.Add($tb)
                        [void]$KaliTools.Children.Add($riga)
                    }
                }
            }
            'error' {
                Clear-LiveBubble
                Add-Bubble 'zap' ("! " + [string]$data)
            }
            'pscrea' {
                # v9.2.1: esito della generazione fatta nel runspace dedicato.
                # Qui siamo sul thread della UI: salvo e aggiorno il pannello.
                $script:PsCreaOccupato = $false
                try { if ($bPsCrea) { $bPsCrea.IsEnabled = $true } } catch { }
                try { if ($script:PsCreaPs) { $script:PsCreaPs.Dispose() } } catch { }
                try { if ($script:PsCreaRs) { $script:PsCreaRs.Dispose() } } catch { }
                $script:PsCreaPs = $null
                $script:PsCreaRs = $null
                try {
                    if ([bool]$data.ok) {
                        $codice = [string]$data.codice
                        $dom = [string]$data.domanda
                        $tit = $dom.Trim()
                        if ($tit.Length -gt 60) { $tit = $tit.Substring(0, 60) }
                        $sav = Save-PsScriptArchivio $sync $codice $tit 'ps-pannello' 'creato-dal-pannello' $dom $false
                        Ps-Ricarica ''
                        if ($PsCodice) { $PsCodice.Text = $codice }
                        if ($PsInfo) { $PsInfo.Text = [string]$sav.messaggio + '  --  puoi copiarlo o eseguirlo con i pulsanti qui sotto.' }
                        if ($PsRichiesta) { $PsRichiesta.Text = '' }
                        try { Add-Activity '- script creato dalla casella PS -' } catch { }
                    } else {
                        if ($PsInfo) { $PsInfo.Text = 'Non sono riuscito a creare lo script: ' + [string]$data.errore }
                    }
                } catch {
                    try { if ($PsInfo) { $PsInfo.Text = 'Errore: ' + $_.Exception.Message } } catch { }
                }
            }
        }
    }

    # 2b) v9.2.1: se la generazione dello script non risponde entro 4 minuti
    #     sblocco il pulsante (la finestra non si e' mai bloccata comunque)
    if ($script:PsCreaOccupato -and $script:PsCreaInizio) {
        try {
            if (((Get-Date) - $script:PsCreaInizio).TotalSeconds -gt 240) {
                $script:PsCreaOccupato = $false
                if ($bPsCrea) { $bPsCrea.IsEnabled = $true }
                if ($PsInfo) { $PsInfo.Text = 'Nessuna risposta dal servizio IA entro 4 minuti: riprova.' }
            }
        } catch { }
    }

    # 3) Ascolto vocale in corso
    try { Update-MicLabel } catch { }
    if ($sync.Listening) {
        $r = Update-Listen $sync
        if ($null -ne $r) {
            $sync.Listening = $false
            $BtnParla.Content = 'PARLA'
            $t = [string]$r.Testo
            $e = [string]$r.Errore
            Set-AvatarState 'neutro'
            # v6: i marcatori stanno nel campo Errore. Prima erano controllati in Testo:
            # per questo i messaggi di aiuto giusti non comparivano mai.
            if ($e -like '!NESSUN_MIC*') {
                Add-Bubble 'zap' ("Non trovo un motore vocale utilizzabile su questo Windows.`n`n" + (Get-SpeechDiagnostica))
                $StatusText.Text = 'MICROFONO NON DISPONIBILE'
            }
            elseif ($e -like '!AUDIO*' -or $e -like '!WINRT*') {
                Add-Bubble 'zap' ("Non riesco a usare il microfono.`nDettaglio: " + $e + "`n`n" + (Get-SpeechDiagnostica))
                $StatusText.Text = 'MICROFONO: CONTROLLA I PERMESSI'
            }
            elseif ($e -like '!ERRORE*') {
                Add-Bubble 'zap' ("Problema col microfono: " + $e + "`n`n" + (Get-SpeechDiagnostica))
                $StatusText.Text = 'MICROFONO: ERRORE'
            }
            elseif ($e -like '!NESSUN_PARLATO*') {
                Add-Bubble 'zap' 'Non ho sentito niente... riprova e parla forte, dopo che compare "TI ASCOLTO"!'
                $StatusText.Text = 'PRONTO!'
            }
            elseif ($t.Trim()) {
                Send-UserText $t
            }
            else {
                Add-Bubble 'zap' 'Non ho sentito niente... riprova e parla forte!'
                $StatusText.Text = 'PRONTO!'
            }
        }
    }

    # 4) Fine del parlato: avatar torna neutro
    if ($sync.AvatarState -eq 'parla' -and $sync.Tts) {
        # confronto per testo: se la libreria vocale non e' caricata, il tipo non esiste
        $statoVoce = ''
        try { $statoVoce = [string]$sync.Tts.State } catch { $statoVoce = '' }
        if ($statoVoce -eq 'Speaking') {
            $sync.SpeakingTicks = 0
        }
        else {
            $sync.SpeakingTicks = [int]$sync.SpeakingTicks + 1
            if ($sync.SpeakingTicks -gt 3) {
                Set-AvatarState 'neutro'
                $sync.SpeakingTicks = 0
            }
        }
    }
})

# --------------------------------------------------------------------------
# Avvio
# --------------------------------------------------------------------------

Write-Fase '5/6 voce pronta'
try { Initialize-Tts $sync } catch {
    $sync.Tts = $null
    try { $sync.VoceDisponibile = $false } catch { }
    Write-Fase ('voce non disponibile, continuo senza: ' + $_.Exception.Message)
}
if (-not $sync.Tts) { Write-Fase 'voce disattivata (nessuna voce installata su questo PC): ZAP funziona normalmente' }
Update-ModeButton
if ($sync.Avatars['neutro']) { $Avatar.Source = $sync.Avatars['neutro'] }
try { Aggiorna-AiCombo } catch { }

# v5: log leggibile, senza segreti (ripulisce anche i log delle sessioni precedenti)
try { Protect-TuttiILog -Base $base | Out-Null } catch { }
try { Start-Transcript -Path (Join-Path $base 'logs\avvio.log') -Append | Out-Null } catch { }
try { Aggiorna-PannelloProgrammi } catch { }
Add-Activity ('- modalita: ' + (Get-ModalitaEtichetta ([string]$sync.Config.sicurezza)) + ' -')

# Riempie i campi impostazioni di default (servono se l'utente apre e salva subito)
$CfgNome.Text     = [string]$sync.Config.nome
$CfgApiBase.Text  = [string]$sync.Config.api_base
$CfgApiKey.Text   = [string]$sync.Config.api_key
$CfgModello.Text  = [string]$sync.Config.modello
foreach ($k in @('thorium','yandex','chrome','edge','brave','firefox')) { [void]$CfgBrowser.Items.Add($k) }
foreach ($k in @('duckduckgo','google','bing','yandex','startpage')) { [void]$CfgMotore.Items.Add($k) }
foreach ($k in @('Segoe UI','Calibri','Consolas','Verdana','Tahoma','Georgia','Trebuchet MS','Arial','Comic Sans MS')) { [void]$AspFont.Items.Add($k) }
foreach ($k in @('11','12','13','14','15','16')) { [void]$AspSize.Items.Add($k) }
try { Add-Activity ('- ' + (Get-AdminStatus) + ' -') } catch { }
$CfgBrowser.Text = [string]$sync.Config.browser
if (-not $CfgBrowser.Text) { $CfgBrowser.Text = 'thorium' }
if ($CfgMotore.Items.Contains([string]$sync.Config.motore_ricerca)) { $CfgMotore.SelectedItem = [string]$sync.Config.motore_ricerca } else { $CfgMotore.SelectedItem = 'duckduckgo' }
try { $ModelInfo.Text = Get-ModelStatusText $sync } catch { }
$BtnScaricaModello.Add_Click({
    Start-ModelPull $sync $CfgModello.Text.Trim()
    $ModelInfo.Text = 'Download avviato: guarda la chat per l esito.'
})

# --- v8: pannello SQUADRA (sotto la foto) e pannello CINEMA ---
$BtnCinema = $Window.FindName('BtnCinema')
try { . (Join-Path $base 'brain\agenti_ui.ps1') } catch { Write-ModuloNonCaricato 'brain\agenti_ui.ps1' $_.Exception.Message }
try { . (Join-Path $base 'brain\cinema_ui.ps1') } catch { Write-ModuloNonCaricato 'brain\cinema_ui.ps1' $_.Exception.Message }
try { Initialize-AgentiPadrone $Window $sync } catch { Add-Activity ('- pannello squadra: ' + $_.Exception.Message + ' -') }
try { Initialize-IntelligenzePadrone $Window $sync } catch { Add-Activity ('- pannello intelligenze: ' + $_.Exception.Message + ' -') }

# --- v9.2: pulsanti tondi accanto alla foto (lancia browser / diagnosi) ---
try {
    . (Join-Path $base 'brain\quick_actions.ps1')
    $BtnLanciaBrowser = $Window.FindName('BtnLanciaBrowser')
    $BtnDiagnosi      = $Window.FindName('BtnDiagnosi')
    if ($BtnLanciaBrowser) {
        $BtnLanciaBrowser.Add_Click({
            try {
                $msg = Start-ThoriumBrowser $sync
                Add-Bubble 'zap' $msg
            } catch {
                Add-Bubble 'zap' ('!Browser: ' + $_.Exception.Message)
            }
        })
    }
    if ($BtnDiagnosi) {
        $BtnDiagnosi.Add_Click({
            try { Show-DiagnosiPannello $Window }
            catch { Add-Bubble 'zap' ('!Diagnosi: ' + $_.Exception.Message) }
        })
    }
    Write-Fase 'v9.2: pulsanti lancia browser + diagnosi collegati'
} catch {
    try { Write-Fase ('v9.2: pulsanti rapidi non caricati: ' + $_.Exception.Message) } catch { }
}
try { Initialize-CinemaUI $Window $sync $base } catch { Add-Activity ('- pannello cinema: ' + $_.Exception.Message + ' -') }
if ($BtnCinema) { $BtnCinema.Add_Click({ Show-CinemaPanel $Window }) }

# Avvia l'agente in un runspace dedicato
$agentRs = [runspacefactory]::CreateRunspace()
$agentRs.ApartmentState = 'STA'
$agentRs.ThreadOptions  = 'ReuseThread'
$agentRs.Open()
$agentRs.SessionStateProxy.SetVariable('sync', $sync)
$agentRs.SessionStateProxy.SetVariable('base', $base)

$agentPs = [powershell]::Create()
$agentPs.Runspace = $agentRs
[void]$agentPs.AddScript((Get-Content (Join-Path $base 'brain\agent.ps1') -Raw))
$agentHandle = $agentPs.BeginInvoke()

# --- v8: runspace dedicato alla SQUADRA di agenti ---
$squadraRs = [runspacefactory]::CreateRunspace()
$squadraRs.ApartmentState = 'STA'
$squadraRs.ThreadOptions  = 'ReuseThread'
$squadraRs.Open()
$squadraRs.SessionStateProxy.SetVariable('sync', $sync)
$squadraRs.SessionStateProxy.SetVariable('base', $base)
$squadraPs = [powershell]::Create()
$squadraPs.Runspace = $squadraRs
[void]$squadraPs.AddScript((Get-Content (Join-Path $base 'brain\agenti_worker.ps1') -Raw))
$squadraHandle = $squadraPs.BeginInvoke()

# --- v8: runspace dedicato al motore CINEMA (disegno della GIF) ---
$cineRs = [runspacefactory]::CreateRunspace()
$cineRs.ApartmentState = 'STA'
$cineRs.ThreadOptions  = 'ReuseThread'
$cineRs.Open()
$cineRs.SessionStateProxy.SetVariable('sync', $sync)
$cineRs.SessionStateProxy.SetVariable('base', $base)
$cinePs = [powershell]::Create()
$cinePs.Runspace = $cineRs
[void]$cinePs.AddScript((Get-Content (Join-Path $base 'brain\cinema_job.ps1') -Raw))
$cineHandle = $cinePs.BeginInvoke()

try { Flush-TaskInCoda } catch { }

# ---- v7.9: TELECOMANDO VOCALE INTEGRATO ----
# All'avvio di ZAP si apre da solo anche "VOCE per ZAP" (dettatura + INVIA) e si chiude
# insieme a ZAP. Si disattiva con -NoVoice oppure con telecomando=$false in config.json.
# A ZAP_VOCE passo la MIA finestra (handle + pid): cosi' la trova sempre, anche se i
# titoli non sono leggibili per via dei privilegi diversi.
$script:VoceProc = $null
function Start-VoceRemoto {
    if ($NoVoice) { return }
    try { if (-not [bool]$sync.Config.voce.telecomando) { return } } catch { }
    $vps = Join-Path $base 'ZAP_VOCE.ps1'
    if (-not (Test-Path $vps)) { return }
    try {
        $hwnd = (New-Object System.Windows.Interop.WindowInteropHelper($Window)).Handle.ToInt64()
        $psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        if (-not (Test-Path $psExe)) { $psExe = 'powershell.exe' }
        $script:VoceProc = Start-Process -FilePath $psExe -PassThru -ArgumentList @(
            '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File', $vps,
            '-ZapHwnd', "$hwnd", '-ZapPid', "$PID")
    } catch { }
}
$timer.Start()

# --- v9: timer della MODALITA TRACCIA (gira sulla thread della UI: nessun thread extra) ---
$script:TimerTraccia = New-Object System.Windows.Threading.DispatcherTimer
$script:TimerTraccia.Interval = [TimeSpan]::FromSeconds(15)
$script:TimerTraccia.Add_Tick({
    try {
        if (-not (Get-TracciaStato $sync).attiva) { return }
        $cfgT = Get-TracciaConfig $sync
        $att = [double]([int]$cfgT.intervallo)
        if ($att -lt 5) { $att = 15 }
        if ([Math]::Abs($script:TimerTraccia.Interval.TotalSeconds - $att) -gt 0.5) {
            $script:TimerTraccia.Interval = [TimeSpan]::FromSeconds($att)
        }
        Write-TracciaCampione $sync
    } catch { }
})

# --- v9: MEMORIA INDELEBILE: preparo la cartella, controllo l'integrita, registro l'avvio ---
try {
    [void](Initialize-Ezappero $sync)
    $repAvvio = Test-ZapIntegrita $sync
    if (-not $repAvvio.ok) {
        $esito = Repair-ZapDaSpecchio $sync
        $StatusText.Text = 'MEMORIA RIPRISTINATA: ' + $esito
    }
    [void](Add-ZapLedgerEvento $sync 'sistema' ('ZAP v9 avviato. Modello: ' + [string]$config.modalita_ai) 'avvio' $false)
    if ((Test-Path -LiteralPath (Join-Path $base 'ZAP-CLI.ps1'))) { } # CLI pronta per le automazioni
} catch { }
# --- v9: PRIMO AVVIO AUTOMATICO ---------------------------------------------
# Se e' la prima volta (manca il marcatore), ZAP esegue da solo PRIMO_AVVIO.ps1:
# completa la configurazione, crea le cartelle, verifica/ripara la memoria, fa la
# copia di sicurezza, applica la protezione e registra le automazioni pianificate.
# Cosi' l'utente non deve leggere nessun passaggio: apre e basta.
try {
    $scriptPa  = Join-Path $base 'PRIMO_AVVIO.ps1'
    $markerPa  = Join-Path (Get-EzapperoDir $sync) 'primo-avvio.ok'
    if ((Test-Path -LiteralPath $scriptPa) -and -not (Test-Path -LiteralPath $markerPa)) {
        $StatusText.Text = 'PRIMO AVVIO: preparo la memoria...'
        # Chiamata in un processo SEPARATO: cosi' PRIMO_AVVIO non puo' toccare le variabili
        # di ZAP (succedeva con il caricamento diretto: sovrascriveva $base e $Admin).
        $psPa = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        if (-not (Test-Path -LiteralPath $psPa)) { $psPa = 'powershell.exe' }
        $argPa = '-NoProfile -ExecutionPolicy Bypass -File "' + $scriptPa + '" -Cartella "' + $base + '" -NonInterattivo -Silenzioso'
        try { Start-Process -FilePath $psPa -ArgumentList $argPa -Wait -WindowStyle Hidden | Out-Null } catch { }
        if (Test-Path -LiteralPath $markerPa) {
            $StatusText.Text = 'PRIMO AVVIO COMPLETATO - memoria pronta'
        } else {
            $StatusText.Text = 'Primo avvio incompleto: esegui PRIMO_AVVIO.bat come amministratore'
        }
    }
} catch { }
try { $script:TimerTraccia.Start() } catch { }

[void]$InputBox.Focus()
Write-Fase '6/6 finestra pronta: apro ZAP'
$Window.Add_ContentRendered({ try { Start-VoceRemoto } catch { } })
# v9.3: accendo il nastro notizie (scarica in background, non blocca la grafica)
try { Start-ZapTicker -Window $Window -Base $base } catch { Write-Fase ('nastro notizie: ' + $_.Exception.Message) }

# ---------------------------------------------------------------------------
# v9.4 -- TASTI ACCANTO ALLA FOTO
#   BtnNastro : mostra/nasconde il nastro delle notizie   (o tasto F8)
#   BtnSkin   : cambia interfaccia                         (o tasto F9 / Shift+F9)
# ---------------------------------------------------------------------------
try {
    if ($BtnNastroText) {
        if ([bool]$script:ZapTick.Visibile) { $BtnNastroText.Text = "nastro`nON" }
        else { $BtnNastroText.Text = "nastro`nOFF" }
    }
} catch { }
try {
    if ($BtnNastro) {
        $BtnNastro.Add_Click({ try { [void](Toggle-ZapTicker -Window $Window -Base $base) } catch { } })
    }
} catch { }
try {
    if ($BtnSkin) {
        # v9.4.3: l'esito finisce in chat. Se qualcosa non va, si legge il perche'
        # invece di premere il tasto e non vedere nulla.
        $BtnSkin.Add_Click({
            try {
                $esito = Set-SkinSuccessiva -Window $Window -Base $base -Verso 1
                Add-Bubble 'zap' ([string]$esito)
            } catch {
                Add-Bubble 'zap' ('Interfacce: errore -> ' + $_.Exception.Message)
            }
        })
    }
} catch { }
try {
    $Window.Add_KeyDown({
        param($s, $e)
        try {
            if ($e.Key -eq [System.Windows.Input.Key]::F9) {
                $verso = 1
                if (($e.KeyboardDevice.Modifiers -band [System.Windows.Input.ModifierKeys]::Shift) -ne 0) { $verso = -1 }
                try { Add-Bubble 'zap' ([string](Set-SkinSuccessiva -Window $Window -Base $base -Verso $verso)) }
                catch { Add-Bubble 'zap' ('Interfacce: errore -> ' + $_.Exception.Message) }
                $e.Handled = $true
            }
            elseif ($e.Key -eq [System.Windows.Input.Key]::F8) {
                [void](Toggle-ZapTicker -Window $Window -Base $base)
                $e.Handled = $true
            }
        } catch { }
    })
} catch { }
try { [void](Initialize-Skin -Window $Window -Base $base) } catch { try { Write-Fase ('skin: ' + $_.Exception.Message) } catch { } }


try {
    [void]$Window.ShowDialog()
}
finally {
    $sync.Quit = $true
    $timer.Stop()
    try { Stop-ZapTicker } catch { }
    try { $script:TimerTraccia.Stop() } catch { }
    Stop-Listen $sync
    Stop-Speak $sync
    try { if ($script:VoceProc -and -not $script:VoceProc.HasExited) { $script:VoceProc.Kill() } } catch { }
    try { $squadraPs.Stop() } catch { }
    try { $cinePs.Stop() } catch { }
    try { $squadraPs.Dispose() } catch { }
    try { $cinePs.Dispose() } catch { }
    try { $squadraRs.Close() } catch { }
    try { $cineRs.Close() } catch { }
    try { $agentPs.Stop() } catch { }
    try { $agentPs.Dispose() } catch { }
    try { $agentRs.Close() } catch { }
    try { Stop-Transcript | Out-Null } catch { }
    try { Protect-TuttiILog -Base $base | Out-Null } catch { }
}
