﻿# verifica_progetto.ps1 -- controllo completo del pacchetto ZAP (v9.6.1)
# Uso:  powershell -NoProfile -ExecutionPolicy Bypass -File tests\verifica_progetto.ps1
# Esce con 0 se il progetto e' sano, 1 se trova problemi veri.
$ErrorActionPreference = 'Continue'
$base = $PSScriptRoot
if (-not (Test-Path (Join-Path $base 'AVVIA.ps1'))) { $base = Split-Path -Parent $base }
if (-not (Test-Path (Join-Path $base 'AVVIA.ps1'))) {
    Write-Host 'ERRORE: non trovo AVVIA.ps1: lancia questo file da dentro la cartella di ZAP.' -ForegroundColor Red
    exit 1
}

$script:problemi = 0
$script:avvisi = 0
function Ok($t) { Write-Host ('  [OK]  ' + $t) -ForegroundColor Green }
function Ko($t) { $script:problemi++; Write-Host ('  [!!]  ' + $t) -ForegroundColor Red }
function Av($t) { $script:avvisi++; Write-Host ('  [--]  ' + $t) -ForegroundColor Yellow }

Write-Host ''
Write-Host ('ZAP -- verifica del progetto in: ' + $base) -ForegroundColor Cyan
Write-Host ('PowerShell: ' + $PSVersionTable.PSVersion + ' (' + $PSVersionTable.PSEdition + ')') -ForegroundColor DarkGray
Write-Host ''

# --- 1. file indispensabili -------------------------------------------------
Write-Host '1. File indispensabili'
$critici = @('AVVIA.ps1', 'AVVIA.bat', 'config.json', 'ui\window.xaml',
             'brain\tools.ps1', 'brain\llm.ps1', 'brain\provider_ai.ps1',
             'brain\orchestra.ps1', 'voice\tts.ps1', 'voice\stt.ps1')
foreach ($f in $critici) {
    if (Test-Path (Join-Path $base $f)) { Ok $f } else { Ko ('MANCA ' + $f) }
}

# --- 2. sintassi di ogni .ps1 ----------------------------------------------
Write-Host ''
Write-Host '2. Sintassi degli script'
$scripts = @(Get-ChildItem -Path $base -Recurse -File -Filter '*.ps1')
$guasti = 0
foreach ($s in $scripts) {
    $tok = $null; $err = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($s.FullName, [ref]$tok, [ref]$err)
    if ($err -and $err.Count -gt 0) {
        $guasti++
        Ko ($s.FullName.Replace($base, '') + ' riga ' + $err[0].Extent.StartLineNumber + ': ' + $err[0].Message)
    }
}
if ($guasti -eq 0) { Ok ('' + $scripts.Count + ' script compilano senza errori') }

# --- 3. interfaccia XAML ----------------------------------------------------
Write-Host ''
Write-Host '3. Interfaccia (XAML)'
$xamlFile = @(Get-ChildItem -Path (Join-Path $base 'ui') -Filter '*.xaml' -File)
$nomi = @{}
foreach ($x in $xamlFile) {
    try {
        [void][xml](Get-Content $x.FullName -Raw -Encoding UTF8)
        Ok ($x.Name + ': XML valido')
    } catch {
        Ko ($x.Name + ': XML NON valido -> ' + $_.Exception.Message)
    }
    foreach ($m in [regex]::Matches((Get-Content $x.FullName -Raw -Encoding UTF8), 'x:Name="([^"]+)"')) {
        $nomi[$m.Groups[1].Value] = $true
    }
}
$orfani = @{}
foreach ($s in $scripts) {
    foreach ($m in [regex]::Matches((Get-Content $s.FullName -Raw -Encoding UTF8), "FindName\(\s*'([^']+)'\s*\)")) {
        $n = $m.Groups[1].Value
        if (-not $nomi.ContainsKey($n)) { $orfani[$n] = $true }
    }
}
if ($orfani.Count -eq 0) {
    Ok 'ogni FindName() trova il suo elemento nel XAML'
} else {
    foreach ($k in $orfani.Keys) { Av ('FindName senza elemento nel XAML: ' + $k + ' (controllato nel codice: nessun crash)') }
}

# --- 4. config.json ---------------------------------------------------------
Write-Host ''
Write-Host '4. config.json'
$cfgPath = Join-Path $base 'config.json'
if (Test-Path $cfgPath) {
    try {
        $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
        Ok ('JSON valido, ' + $cfg.PSObject.Properties.Name.Count + ' chiavi')
        foreach ($blocco in @('motore', 'memoria', 'gemini_sicurezza', 'provider_ai', 'orchestrazione')) {
            if ($null -ne $cfg.$blocco) { Ok ('blocco ' + $blocco + ' presente') }
            else { Av ('blocco ' + $blocco + ' assente: si usano i valori di fabbrica') }
        }
        if ($cfg.provider_ai.gemini -and -not ([string]$cfg.provider_ai.gemini.chiave).Trim()) {
            Av 'chiave Gemini vuota: inseriscila in INTELLIGENZE AI (o in config.local.json)'
        }
    } catch {
        Ko ('config.json illeggibile: ' + $_.Exception.Message)
    }
} else { Ko 'config.json assente' }

# --- 5. file citati dal codice ---------------------------------------------
Write-Host ''
Write-Host '5. File citati dal codice'
$mancanti = @{}
foreach ($s in $scripts) {
    $testo = Get-Content $s.FullName -Raw -Encoding UTF8
    foreach ($m in [regex]::Matches($testo, "'(brain|ui|voice)[\\/]([A-Za-z0-9_\.\-]+\.(ps1|xaml))'")) {
        $rel = $m.Groups[1].Value + '\' + $m.Groups[2].Value
        if (-not (Test-Path (Join-Path $base $rel))) { $mancanti[$rel] = $true }
    }
}
if ($mancanti.Count -eq 0) { Ok 'tutti i moduli citati esistono' }
else { foreach ($k in $mancanti.Keys) { Ko ('citato ma assente: ' + $k) } }

# --- 6. codifica dei .ps1 ---------------------------------------------------
Write-Host ''
Write-Host '6. Codifica dei file .ps1 (serve UTF-8 con BOM per PowerShell 5.1)'
$senzaBom = 0
foreach ($s in $scripts) {
    $b = [System.IO.File]::ReadAllBytes($s.FullName)
    if (-not ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF)) { $senzaBom++ }
}
if ($senzaBom -eq 0) { Ok 'tutti gli script hanno il BOM' } else { Av ('' + $senzaBom + ' script senza BOM: le lettere accentate possono corrompersi') }

# --- esito ------------------------------------------------------------------
Write-Host ''
Write-Host ('--- problemi: ' + $script:problemi + '   avvisi: ' + $script:avvisi + ' ---')
if ($script:problemi -eq 0) {
    Write-Host 'Il progetto e'' sano: ZAP puo'' partire con AVVIA.bat.' -ForegroundColor Green
    exit 0
} else {
    Write-Host 'Ci sono problemi da correggere (vedi le righe [!!]).' -ForegroundColor Red
    exit 1
}
