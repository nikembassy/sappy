﻿# AVVIO_SICURO.ps1 -- avvia ZAP e, se non parte, ti dice perche' (la finestra non si chiude MAI).
#
# Perche' esiste: se qualcosa va storto, la finestra di avvio puo' sparire prima che tu
# riesca a leggere. Questo qui invece:
#   1. controlla l'ambiente e i file indispensabili
#   2. ripara da solo quello che si puo' riparare (window.xaml rovinato, config illeggibile,
#      moduli v9 non validi)
#   3. avvia ZAP come processo separato e aspetta 12 secondi: se e' ancora vivo, e' partito
#   4. se si e' chiuso, mostra le ultime righe di logs\avvio.log e l'errore vero
#   5. scrive tutto in logs\avvio-sicuro.log
#
# Solo caratteri ASCII: Windows PowerShell 5.1 lo legge senza ambiguita'.

$ErrorActionPreference = 'Continue'
$base = $PSScriptRoot
if (-not $base) { $base = (Get-Location).Path }

$logDir = Join-Path $base 'logs'
if (-not (Test-Path -LiteralPath $logDir)) { [void][System.IO.Directory]::CreateDirectory($logDir) }
$logFile = Join-Path $logDir 'avvio-sicuro.log'
$enc = New-Object System.Text.UTF8Encoding($false)

function Di {
    param([string]$Testo, [string]$Colore = 'Gray')
    Write-Host $Testo -ForegroundColor $Colore
    try { [System.IO.File]::AppendAllText($logFile, ($Testo + "`r`n"), $enc) } catch { }
}

function Titolo {
    param([string]$Testo)
    Write-Host ''
    Write-Host ('==> ' + $Testo) -ForegroundColor Cyan
    try { [System.IO.File]::AppendAllText($logFile, ("`r`n==> " + $Testo + "`r`n"), $enc) } catch { }
}

try { [System.IO.File]::WriteAllText($logFile, ('=== ZAP avvio sicuro ' + (Get-Date -Format 'dd/MM/yyyy HH:mm:ss') + ' ===' + "`r`n"), $enc) } catch { }

Write-Host ''
Write-Host '============================================================' -ForegroundColor Yellow
Write-Host '  ZAP - AVVIO SICURO (controllo, riparazione, avvio)' -ForegroundColor Yellow
Write-Host '============================================================' -ForegroundColor Yellow
Write-Host ('  cartella: ' + $base)

# ---------------------------------------------------------------------------
Titolo 'Ambiente'
$psExe = 'powershell.exe'
$abbiamoPs51 = $false
try {
    if ($env:WINDIR) {
        $cand = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        if (Test-Path -LiteralPath $cand) { $psExe = $cand; $abbiamoPs51 = $true }
    }
} catch { }
Di ('  PowerShell in uso : ' + $PSVersionTable.PSVersion.ToString() + ' (' + $PSVersionTable.PSEdition + ')')
Di ('  PowerShell 5.1    : ' + $(if ($abbiamoPs51) { 'trovato' } else { 'NON trovato' }))
$pol = 'sconosciuta'
try { $pol = (Get-ExecutionPolicy).ToString() } catch { }
Di ('  ExecutionPolicy   : ' + $pol)

# ---------------------------------------------------------------------------
Titolo 'Voce (sintesi vocale)'
# Su alcuni PC manca una voce installata: ZAP v8.7 si chiudeva proprio qui,
# prima di mostrare la finestra. Ora la voce e' opzionale.
$voceOk = $false
try {
    Add-Type -AssemblyName System.Speech -ErrorAction Stop
    $provaVoce = New-Object System.Speech.Synthesis.SpeechSynthesizer
    try { $provaVoce.Dispose() } catch { }
    $voceOk = $true
    Di '  [OK] sintesi vocale disponibile'
} catch {
    Di ('  [AVVISO] sintesi vocale non disponibile: ' + $_.Exception.Message) 'Yellow'
    Di '  Non e un problema: ZAP parte lo stesso, senza leggere ad alta voce.' 'Yellow'
}

# ---------------------------------------------------------------------------
Titolo 'File indispensabili'
$indispensabili = @(
    @{ p = 'AVVIA.ps1';        d = 'il programma' },
    @{ p = 'ui\window.xaml';   d = 'la finestra' },
    @{ p = 'config.json';      d = 'la configurazione' },
    @{ p = 'brain\agent.ps1';  d = 'il motore' },
    @{ p = 'brain\tools.ps1';  d = 'gli strumenti' },
    @{ p = 'brain\llm.ps1';    d = 'il collegamento all IA' }
)
$mancanti = @()
foreach ($f in $indispensabili) {
    $p = Join-Path $base $f.p
    if (Test-Path -LiteralPath $p) {
        Di ('  [OK]    ' + $f.p + '  (' + $f.d + ')')
    } else {
        Di ('  [MANCA] ' + $f.p + '  (' + $f.d + ')') 'Red'
        $mancanti += $f.p
    }
}
if (Test-Path -LiteralPath (Join-Path $base 'AVVIO_SICURO.ps1')) {
    $quanti = @(Get-ChildItem -LiteralPath $base -Recurse -File -ErrorAction SilentlyContinue).Count
    Di ('  File totali nella cartella: ' + $quanti + ' (devono essere circa 150)')
}

# ---------------------------------------------------------------------------
Titolo 'Controllo della finestra (window.xaml)'
$winXaml = Join-Path $base 'ui\window.xaml'
$winCopia = Join-Path $base 'ui\window.xaml.originale'
$winOk = $false
if (Test-Path -LiteralPath $winXaml) {
    try { [void][xml](Get-Content -LiteralPath $winXaml -Raw -Encoding UTF8); $winOk = $true } catch { $winOk = $false }
}
if ($winOk) {
    Di '  [OK] window.xaml e valido'
} elseif (Test-Path -LiteralPath $winCopia) {
    Di '  [GUASTO] window.xaml non valido: ripristino la copia originale' 'Yellow'
    try {
        Copy-Item -LiteralPath $winCopia -Destination $winXaml -Force
        Di '  [OK] window.xaml ripristinato' 'Green'
        $winOk = $true
    } catch { Di ('  [ERRORE] ripristino non riuscito: ' + $_.Exception.Message) 'Red' }
} else {
    Di '  [ERRORE] window.xaml mancante e nessuna copia disponibile' 'Red'
}

# ---------------------------------------------------------------------------
Titolo 'Controllo degli script'
$cartellaDisabilitati = Join-Path $base 'brain\_disabilitati'
$rotti = @()
$tot = 0
foreach ($f in @(Get-ChildItem -LiteralPath $base -Recurse -Filter *.ps1 -ErrorAction SilentlyContinue)) {
    if ($f.FullName -like ('*' + [System.IO.Path]::DirectorySeparatorChar + '_disabilitati' + '*')) { continue }
    $tot++
    $tok = $null
    $err = $null
    try {
        [void][System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tok, [ref]$err)
        if ($err -and $err.Count -gt 0) {
            $rotti += ,@{ file = $f; riga = $err[0].Extent.StartLineNumber; msg = $err[0].Message }
        }
    } catch {
        $rotti += ,@{ file = $f; riga = 0; msg = $_.Exception.Message }
    }
}
Di ('  Analizzati ' + $tot + ' script: ' + $rotti.Count + ' con errori')
foreach ($r in $rotti) {
    Di ('   [ERRORE] ' + $r.file.Name + ' riga ' + $r.riga + ': ' + $r.msg) 'Red'
}

# I moduli AGGIUNTIVI con errori vengono messi da parte: ZAP perde quella funzione ma parte.
$v9 = @('memoria_v9.ps1', 'ps_libreria.ps1', 'verita.ps1', 'traccia.ps1', 'office.ps1', 'email_gmail.ps1')
foreach ($r in $rotti) {
    if ($v9 -notcontains $r.file.Name) { continue }
    try {
        if (-not (Test-Path -LiteralPath $cartellaDisabilitati)) { [void][System.IO.Directory]::CreateDirectory($cartellaDisabilitati) }
        $dest = Join-Path $cartellaDisabilitati ($r.file.Name + '.rotto')
        Move-Item -LiteralPath $r.file.FullName -Destination $dest -Force
        Di ('   -> spostato ' + $r.file.Name + ' in brain\_disabilitati\ (ZAP parte senza quella funzione)') 'Yellow'
    } catch {
        Di ('   -> non riesco a spostare ' + $r.file.Name + ': ' + $_.Exception.Message) 'Red'
    }
}

# ---------------------------------------------------------------------------
Titolo 'Configurazione'
$cfgOk = $false
try {
    $null = (Get-Content -LiteralPath (Join-Path $base 'config.json') -Raw -Encoding UTF8) | ConvertFrom-Json
    $cfgOk = $true
    Di '  [OK] config.json si legge'
} catch {
    Di ('  [ERRORE] config.json non si legge: ' + $_.Exception.Message) 'Red'
    $cartBkp = Join-Path (Join-Path $base 'Ezappero') 'backup-config'
    $bkp = $null
    if (Test-Path -LiteralPath $cartBkp) {
        $bkp = Get-ChildItem -LiteralPath $cartBkp -Filter '*.json' -ErrorAction SilentlyContinue |
               Sort-Object LastWriteTime -Descending | Select-Object -First 1
    }
    if ($bkp) {
        try {
            Copy-Item -LiteralPath $bkp.FullName -Destination (Join-Path $base 'config.json') -Force
            Di ('  [OK] ripristinato da ' + $bkp.Name) 'Green'
            $cfgOk = $true
        } catch { Di '  [ERRORE] ripristino della configurazione non riuscito' 'Red' }
    } else {
        Di '  Nessuna copia di sicurezza disponibile: lancia PRIMO_AVVIO.bat' 'Yellow'
    }
}

# ---------------------------------------------------------------------------
Titolo 'Avvio di ZAP'
$avvia = Join-Path $base 'AVVIA.ps1'
$outFile = Join-Path $logDir 'avvio-stdout.txt'
$errFile = Join-Path $logDir 'avvio-stderr.txt'
$partito = $false

if ($mancanti.Count -gt 0 -or -not $winOk -or -not $cfgOk) {
    Di '  Non avvio: prima vanno sistemati i problemi segnalati sopra.' 'Red'
} else {
    Di '  Avvio in corso... (attendo 12 secondi per verificare che resti aperto)'
    try {
        $argumentiAvvio = @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', $avvia)
        if (-not $voceOk) { $argumentiAvvio += '-NoVoice' }
        $proc = Start-Process -FilePath $psExe `
            -ArgumentList $argumentiAvvio `
            -WorkingDirectory $base -PassThru `
            -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        Start-Sleep -Seconds 12
        if ($proc.HasExited) {
            Di ('  ZAP si e chiuso subito (codice ' + $proc.ExitCode + ')') 'Red'
            if (Test-Path -LiteralPath $errFile) {
                $righe = @(Get-Content -LiteralPath $errFile -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { $_.Trim() })
                if ($righe.Count -gt 0) {
                    Di '  --- ERRORI ---' 'Yellow'
                    foreach ($r in @($righe | Select-Object -Last 12)) { Di ('    ' + $r) 'Yellow' }
                }
            }
            if (Test-Path -LiteralPath $outFile) {
                $righe = @(Get-Content -LiteralPath $outFile -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { $_.Trim() })
                if ($righe.Count -gt 0) {
                    Di '  --- MESSAGGI ---' 'Yellow'
                    foreach ($r in @($righe | Select-Object -Last 12)) { Di ('    ' + $r) 'Yellow' }
                }
            }
        } else {
            $partito = $true
            Di ('  ZAP e in esecuzione (processo ' + $proc.Id + ').') 'Green'
        }
    } catch {
        Di ('  Non sono riuscito ad avviare: ' + $_.Exception.Message) 'Red'
    }
}

# ---------------------------------------------------------------------------
$logZap = Join-Path $logDir 'avvio.log'
if (Test-Path -LiteralPath $logZap) {
    Titolo 'Ultime righe del registro di ZAP (logs\avvio.log)'
    $righe = @(Get-Content -LiteralPath $logZap -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { $_.Trim() })
    foreach ($r in @($righe | Select-Object -Last 18)) { Di ('  ' + $r) }
}

Write-Host ''
Write-Host '============================================================' -ForegroundColor Yellow
if ($partito) {
    Write-Host '  ZAP E PARTITO.' -ForegroundColor Green
    Write-Host '  Se non vedi la finestra, controlla la barra delle applicazioni.' -ForegroundColor Green
} else {
    Write-Host '  ZAP NON E PARTITO: il motivo e scritto qui sopra.' -ForegroundColor Red
    Write-Host '  Rapporto completo: logs\avvio-sicuro.log' -ForegroundColor Yellow
}
Write-Host '============================================================' -ForegroundColor Yellow
Write-Host ''
