﻿# INSTALLA_v9.1.ps1 -- installazione AUTOMATICA della v9.1 (zero domande).
# ---------------------------------------------------------------------------
#  Lo lanci con un doppio clic (INSTALLA_v9.1.bat) e fa tutto da solo:
#    1. trova l'installazione di ZAP (o usa la cartella in cui sei);
#    2. fa un backup di ogni file che tocchera' (config.json e config.local.json compresi);
#    3. copia i file nuovi/aggiornati, lasciando intatti memory\, Ezappero\, report\,
#       programmi\, appunti\, skills\, aula\, perimetro.txt e LE CHIAVI API;
#    4. se config.local.json manca, lo rimette dal pacchetto;
#    5. imposta il perimetro GHOST su APERTO (i bersagli gia' dichiarati restano);
#    6. importa perimetro.txt se c'e';
#    7. esegue i test automatici: se qualcosa fallisce, RIPRISTINA il backup da solo;
#    8. avvia ZAP.
#  Nessuna scelta da fare. Se vuoi solo guardare cosa farebbe: INSTALLA_v9.1.bat -Prova
# ---------------------------------------------------------------------------

param(
    [string]$Da = '',        # installazione esistente (se vuota: la cerca)
    [switch]$Prova,          # simulazione: non tocca niente
    [switch]$NonAvviare,     # non lancia ZAP alla fine
    [switch]$SenzaTest       # salta i test (sconsigliato)
)

$ErrorActionPreference = 'Continue'
$io = $PSScriptRoot
$logFile = Join-Path $io 'INSTALLAZIONE_v9.1.log'
$esiti = New-Object System.Collections.ArrayList
$okN = 0
$koN = 0

function Scr {
    param([string]$T, [string]$Colore = '')
    try { Add-Content -LiteralPath $logFile -Value $T -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
    if ($Colore) { Write-Host $T -ForegroundColor $Colore } else { Write-Host $T }
}
function Passo { param([string]$T) Scr ''; Scr ('== ' + $T) 'Cyan' }
function Bene  { param([string]$T) $script:okN++; Scr ('   OK   ' + $T) 'Green' }
function Male  { param([string]$T) $script:koN++; Scr ('   STOP ' + $T) 'Red' }
function Nota  { param([string]$T) Scr ('   ...  ' + $T) 'DarkGray' }

try { if (Test-Path -LiteralPath $logFile) { Remove-Item -LiteralPath $logFile -Force -ErrorAction SilentlyContinue } } catch { }

Scr '=========================================================='
Scr ' ZAP-GEMINI v9.1  -  installazione automatica'
Scr (' ' + (Get-Date -Format 'dd/MM/yyyy HH:mm'))
Scr '=========================================================='
if ($Prova) { Nota 'MODALITA PROVA: nessun file verra toccato.' }

# ---------------------------------------------------------------------------
# 0) questo pacchetto e' davvero la v9.1?
# ---------------------------------------------------------------------------
Passo '0) Pacchetto'
$firmaPacchetto = @('AVVIA.ps1', 'brain\telemetria.ps1', 'brain\aula.ps1', 'brain\ghost.ps1', 'ui\cabina.xaml')
$manca = @()
foreach ($f in $firmaPacchetto) { if (-not (Test-Path -LiteralPath (Join-Path $io $f))) { $manca += $f } }
if ($manca.Count -gt 0) {
    Male ('pacchetto incompleto, manca: ' + ($manca -join ', '))
    Scr ''
    Scr 'Estrai di nuovo lo ZIP per intero (non solo alcuni file) e rilancia.' 'Yellow'
    exit 2
}
Bene ('pacchetto v9.1 completo: ' + $io)

# ---------------------------------------------------------------------------
# 1) dove installare
# ---------------------------------------------------------------------------
function Test-PathZap {
    param([string]$p)
    if (-not $p) { return $false }
    try {
        if (-not (Test-Path -LiteralPath $p)) { return $false }
        return ((Test-Path -LiteralPath (Join-Path $p 'AVVIA.ps1')) -and (Test-Path -LiteralPath (Join-Path $p 'brain\agenti.ps1')))
    } catch { return $false }
}

function Get-PunteggioZap {
    # Un'installazione "vera" ha le chiavi e i dati dell'utente: vale di piu'.
    param([string]$p)
    $punti = 0
    try {
        $cl = Join-Path $p 'config.local.json' -ErrorAction SilentlyContinue
        $cl = Join-Path $p 'config.local.json'
        if (Test-Path -LiteralPath $cl) {
            $raw = [System.IO.File]::ReadAllText($cl, [System.Text.Encoding]::UTF8)
            if ($raw -match '"chiave"\s*:\s*"[^"]+"') { $punti += 10 }
        }
        if (Test-Path -LiteralPath (Join-Path $p 'memory')) { $punti += 4 }
        if (Test-Path -LiteralPath (Join-Path $p 'Ezappero')) { $punti += 3 }
        if (Test-Path -LiteralPath (Join-Path $p 'report')) { $punti += 2 }
        if (Test-Path -LiteralPath (Join-Path $p 'config.json')) { $punti += 1 }
    } catch { }
    return $punti
}

function Find-InstallazioneZap {
    $me = ''
    try { $me = (Resolve-Path -LiteralPath $io).Path.TrimEnd('\') } catch { $me = $io.TrimEnd('\') }
    $trovate = New-Object System.Collections.ArrayList

    $radici = New-Object System.Collections.ArrayList
    try { [void]$radici.Add((Split-Path -Parent $me)) } catch { }

    $comuni = @(
        'C:\ZAP', 'C:\ZAP-Gemini', 'C:\Programmi', 'C:\Users\Public',
        (Join-Path $env:USERPROFILE 'Desktop'),
        (Join-Path $env:USERPROFILE 'OneDrive\Desktop'),
        (Join-Path $env:USERPROFILE 'Downloads'),
        (Join-Path $env:USERPROFILE 'Documents'),
        (Join-Path $env:USERPROFILE 'OneDrive\Documents'),
        (Join-Path $env:USERPROFILE 'OneDrive\Documenti')
    )
    foreach ($r in $comuni) { if ($r -and (Test-Path -LiteralPath $r)) { [void]$radici.Add($r) } }
    try { if ($env:USERPROFILE) { [void]$radici.Add($env:USERPROFILE) } } catch { }

    foreach ($rad in @($radici)) {
        # figli diretti che si chiamano ZAP*
        try {
            foreach ($d in @(Get-ChildItem -LiteralPath $rad -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'ZAP*' })) {
                if (Test-PathZap $d.FullName) {
                    $f = $d.FullName.TrimEnd('\')
                    if ($f -ne $me -and -not $trovate.Contains($f)) { [void]$trovate.Add($f) }
                }
            }
        } catch { }
        # discendenti fino a due livelli (senza scendere troppo: deve restare veloce)
        try {
            foreach ($d in @(Get-ChildItem -LiteralPath $rad -Directory -Recurse -Depth 2 -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'ZAP*' })) {
                if (Test-PathZap $d.FullName) {
                    $f = $d.FullName.TrimEnd('\')
                    if ($f -ne $me -and -not $trovate.Contains($f)) { [void]$trovate.Add($f) }
                }
            }
        } catch { }
    }

    if ($trovate.Count -eq 0) { return '' }
    $migliore = ''
    $puntiMax = -1
    foreach ($t in @($trovate)) {
        $p = Get-PunteggioZap $t
        if ($p -gt $puntiMax) { $puntiMax = $p; $migliore = $t }
    }
    return $migliore
}

Passo '1) Dove installare'
$dest = ''
if ($Da) {
    if (-not (Test-PathZap $Da)) {
        Male ('la cartella indicata non contiene ZAP: ' + $Da)
        exit 2
    }
    $dest = (Resolve-Path -LiteralPath $Da).Path.TrimEnd('\')
    Bene ('indicata da te: ' + $dest)
} else {
    $trovata = Find-InstallazioneZap
    if ($trovata) {
        $dest = $trovata
        Bene ('trovata da sola: ' + $dest + '  (punteggio installazione reale: ' + (Get-PunteggioZap $trovata) + ')')
    } else {
        $dest = (Resolve-Path -LiteralPath $io).Path.TrimEnd('\')
        Nota 'nessun altra installazione trovata: questa cartella DIVENTA ZAP'
        Bene ('installazione in loco: ' + $dest)
    }
}
$inLoco = ($dest -eq ((Resolve-Path -LiteralPath $io).Path.TrimEnd('\')))

# ---------------------------------------------------------------------------
# 2) cosa si tocca e cosa no
# ---------------------------------------------------------------------------
$file = @(
    'AVVIA.ps1',
    'brain\agent.ps1',
    'brain\agenti_worker.ps1',
    'brain\ghost.ps1',
    'brain\tools.ps1',
    'brain\pentest.ps1',
    'brain\aula.ps1',
    'brain\telemetria.ps1',
    'brain\pentest_ext.ps1',
    'ui\cabina.xaml',
    'tests\test_v91.ps1',
    'LEGGIMI_MODIFICHE_v9.1.txt',
    'MANUALE_LEZIONE_v9.1.md'
)
$daCopiare = @()
foreach ($f in $file) { if (Test-Path -LiteralPath (Join-Path $io $f)) { $daCopiare += $f } }

$protetti = @('config.json', 'config.local.json', 'perimetro.txt')
$cartelleProtette = @('memory', 'Ezappero', 'report', 'programmi', 'appunti', 'skills', 'aula', 'voice', 'logs')

Passo '2) Piano'
if ($inLoco) {
    Scr '   modalita: installazione in loco (i file sono gia a posto)'
} else {
    Scr ('   copio ' + $daCopiare.Count + ' file in: ' + $dest)
}
Scr ('   NON tocco  : ' + ($protetti -join ', '))
Scr ('   NON tocco  : ' + ($cartelleProtette -join '\ , ') + '\')

# ---------------------------------------------------------------------------
# 3) backup
# ---------------------------------------------------------------------------
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$backup = Join-Path $dest ('backup_v91_' + $stamp)
$primaEsisteva = @{}

Passo '3) Backup'
if ($Prova) {
    Nota ('[PROVA] avrei creato ' + $backup)
} else {
    $erroreBkp = ''
    try {
        New-Item -ItemType Directory -Path $backup -Force | Out-Null
        if (-not $inLoco) {
            foreach ($f in $daCopiare) {
                $vecchio = Join-Path $dest $f
                $primaEsisteva[$f] = (Test-Path -LiteralPath $vecchio)
                if ($primaEsisteva[$f]) {
                    $d = Join-Path $backup $f
                    $dd = Split-Path -Parent $d
                    if ($dd -and -not (Test-Path -LiteralPath $dd)) { New-Item -ItemType Directory -Path $dd -Force | Out-Null }
                    Copy-Item -LiteralPath $vecchio -Destination $d -Force
                }
            }
        }
        foreach ($p in @('config.json', 'config.local.json')) {
            $sorg = Join-Path $dest $p
            if (Test-Path -LiteralPath $sorg) { Copy-Item -LiteralPath $sorg -Destination (Join-Path $backup $p) -Force }
        }
        Bene ('copia di sicurezza in ' + $backup)
    } catch {
        $erroreBkp = $_.Exception.Message
        Male ('backup non riuscito: ' + $erroreBkp)
        Scr '   Mi fermo qui: senza backup non tocco niente.' 'Yellow'
        exit 3
    }
}

# ---------------------------------------------------------------------------
# 4) copia dei file
# ---------------------------------------------------------------------------
Passo '4) File v9.1'
if ($inLoco) {
    Bene 'file gia in posizione (nessuna copia necessaria)'
} else {
    foreach ($f in $daCopiare) {
        $src = Join-Path $io $f
        $dst = Join-Path $dest $f
        $dd = Split-Path -Parent $dst
        if ($dd -and -not (Test-Path -LiteralPath $dd)) { New-Item -ItemType Directory -Path $dd -Force | Out-Null }
        if ($Prova) { Nota ('[PROVA] copierei ' + $f); continue }
        try {
            Copy-Item -LiteralPath $src -Destination $dst -Force
            Bene $f
        } catch {
            Male ($f + ' -> ' + $_.Exception.Message)
        }
    }
}

# ---------------------------------------------------------------------------
# 5) chiavi API
# ---------------------------------------------------------------------------
Passo '5) Chiavi API (config.local.json)'
$chiaviDest = Join-Path $dest 'config.local.json'
$chiaviSrc = Join-Path $io 'config.local.json'

function Get-ContaChiavi {
    param([string]$p)
    try {
        $raw = [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8)
        $n = 0
        foreach ($m in [regex]::Matches($raw, '"chiave"\s*:\s*"([^"]*)"')) { if ($m.Groups[1].Value.Trim()) { $n++ } }
        return $n
    } catch { return -1 }
}

if (Test-Path -LiteralPath $chiaviDest) {
    $n = Get-ContaChiavi $chiaviDest
    Bene ('presente nella tua installazione: ' + $n + ' chiavi - NON la tocco')
} elseif (Test-Path -LiteralPath $chiaviSrc) {
    if ($Prova) {
        Nota '[PROVA] ripristinerei config.local.json dal pacchetto'
    } else {
        try {
            Copy-Item -LiteralPath $chiaviSrc -Destination $chiaviDest -Force
            Bene ('mancava: ripristinata dal pacchetto (' + (Get-ContaChiavi $chiaviDest) + ' chiavi)')
        } catch { Male ('non ho potuto ripristinare le chiavi: ' + $_.Exception.Message) }
    }
} else {
    Male 'config.local.json assente e non presente nel pacchetto: reinserisci le chiavi da IMPOSTAZIONI'
}

# ---------------------------------------------------------------------------
# 6) perimetro GHOST = APERTO
# ---------------------------------------------------------------------------
Passo '6) Perimetro GHOST'
function Set-GhostAperto {
    param([string]$cartella)
    $p = Join-Path $cartella 'config.json'
    if (-not (Test-Path -LiteralPath $p)) { return 'config.json non presente: verra creato al primo avvio' }
    $chiudi = {
        param($blocco)
        $h = [ordered]@{}
        if ($blocco) { foreach ($pr in @($blocco.PSObject.Properties)) { $h[$pr.Name] = $pr.Value } }
        return $h
    }
    try {
        $raw = [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8)
        $cfg = $raw | ConvertFrom-Json
        $mappa = [ordered]@{}
        foreach ($pr in @($cfg.PSObject.Properties)) { $mappa[$pr.Name] = $pr.Value }

        $gh = $null
        try { $gh = $mappa['ghost'] } catch { $gh = $null }
        $nuovo = [ordered]@{}
        if ($gh) { foreach ($pr in @($gh.PSObject.Properties)) { $nuovo[$pr.Name] = $pr.Value } }
        if (-not $nuovo.Contains('ambiti')) { $nuovo['ambiti'] = @() }
        if (-not $nuovo.Contains('attivo')) { $nuovo['attivo'] = $false }
        if (-not $nuovo.Contains('consenso')) { $nuovo['consenso'] = $false }
        if (-not $nuovo.Contains('consenti_privati')) { $nuovo['consenti_privati'] = $true }
        if (-not $nuovo.Contains('registra_tutto')) { $nuovo['registra_tutto'] = $true }
        if (-not $nuovo.Contains('aula_passivi')) { $nuovo['aula_passivi'] = $true }
        $nuovo['modo'] = 'aperto'
        $nuovo['blocca_fuori_ambito'] = $false
        $mappa['ghost'] = $nuovo

        if (-not $mappa.Contains('sicurezza_agenti')) {
            $mappa['sicurezza_agenti'] = [ordered]@{
                max_secondi_step = 240
                max_silenzio     = 120
                max_ripetizioni  = 3
                max_chiamate     = 40
                max_errori       = 3
            }
        }
        $out = ($mappa | ConvertTo-Json -Depth 12)
        [System.IO.File]::WriteAllText($p, $out, (New-Object System.Text.UTF8Encoding($false)))
        $amb = @()
        try { $amb = @($nuovo['ambiti']) } catch { }
        return ('modo APERTO impostato; bersagli gia dichiarati: ' + $amb.Count)
    } catch {
        return ('non ho potuto aggiornare config.json: ' + $_.Exception.Message)
    }
}

if ($Prova) {
    Nota '[PROVA] imposterei ghost.modo = aperto'
} else {
    $r = Set-GhostAperto $dest
    if ($r -like 'modo APERTO*') { Bene $r } else { Nota $r }
}

# ---------------------------------------------------------------------------
# 7) perimetro.txt (se c'e', i bersagli entrano da soli)
# ---------------------------------------------------------------------------
Passo '7) perimetro.txt'
$pfDest = Join-Path $dest 'perimetro.txt'
$pfSrc = Join-Path $io 'perimetro.txt'
if (Test-Path -LiteralPath $pfSrc) {
    if (-not (Test-Path -LiteralPath $pfDest)) {
        if (-not $Prova) { try { Copy-Item -LiteralPath $pfSrc -Destination $pfDest -Force } catch { } }
        Bene 'perimetro.txt copiato: i bersagli entrano da soli al primo avvio'
    } else { Nota 'perimetro.txt gia presente: lo lascio com e' }
} else {
    Nota 'nessun perimetro.txt (puoi crearlo quando vuoi: un bersaglio per riga)'
}

# ---------------------------------------------------------------------------
# 8) test automatici + rollback
# ---------------------------------------------------------------------------
Passo '8) Verifica'
$testOk = $true
if ($SenzaTest) {
    Nota 'test saltati (-SenzaTest)'
} elseif ($Prova) {
    Nota '[PROVA] eseguirei i test'
} else {
    $testPath = Join-Path $dest 'tests\test_v91.ps1'
    if (-not (Test-Path -LiteralPath $testPath)) {
        Nota 'tests\test_v91.ps1 non trovato: salto la verifica'
    } else {
        $uscita = ''
        try {
            # uso lo STESSO interprete che sta eseguendo l'installer: funziona sia con
            # powershell.exe (5.1) sia con pwsh (7), anche se non e' nel PATH.
            $psExe = ''
            try { $psExe = (Get-Process -Id $PID).Path } catch { $psExe = '' }
            if (-not $psExe) { $psExe = 'powershell' }
            $uscita = & $psExe -NoProfile -ExecutionPolicy Bypass -File $testPath 2>&1 | Out-String
        } catch { $uscita = [string]$_ }
        try { Add-Content -LiteralPath (Join-Path $dest 'tests\ESITO_test_v91.log') -Value $uscita -Encoding UTF8 } catch { }
        $m = [regex]::Match($uscita, 'RIEPILOGO:\s*(\d+)\s*passati,\s*(\d+)\s*falliti')
        if ($m.Success) {
            $np = [int]$m.Groups[1].Value
            $nf = [int]$m.Groups[2].Value
            if ($nf -eq 0) { Bene ('test: ' + $np + ' passati, 0 falliti') }
            else { $testOk = $false; Male ('test: ' + $nf + ' falliti su ' + ($np + $nf)) }
        } else {
            Nota 'non ho letto il riepilogo dei test (vedi tests\ESITO_test_v91.log)'
        }
    }
}

if (-not $testOk) {
    Passo '9) RIPRISTINO automatico'
    $ripristinati = 0
    foreach ($f in $daCopiare) {
        $bkp = Join-Path $backup $f
        $dst = Join-Path $dest $f
        $esisteva = $true
        try { $esisteva = [bool]$primaEsisteva[$f] } catch { $esisteva = $true }
        try {
            if (Test-Path -LiteralPath $bkp) { Copy-Item -LiteralPath $bkp -Destination $dst -Force; $ripristinati++ }
            elseif (-not $esisteva -and (Test-Path -LiteralPath $dst)) { Remove-Item -LiteralPath $dst -Force; $ripristinati++ }
        } catch { }
    }
    Bene ('file ripristinati: ' + $ripristinati + ' - sei tornato alla versione di prima')
    Scr ''
    Scr 'I test hanno trovato un problema: NON ho lasciato una versione a meta.' 'Yellow'
    Scr ('Dettagli completi: ' + (Join-Path $dest 'tests\ESITO_test_v91.log')) 'Yellow'
    exit 4
}

# ---------------------------------------------------------------------------
# 10) avvio
# ---------------------------------------------------------------------------
Passo '10) Avvio'
if ($Prova) {
    Nota '[PROVA] avrei avviato ZAP'
    Scr ''
    Scr 'PROVA FINITA: nessun file toccato.' 'Yellow'
    exit 0
}
if ($NonAvviare) {
    Nota 'avvio saltato (-NonAvviare)'
} else {
    $bat = Join-Path $dest 'AVVIA.bat'
    $ps1 = Join-Path $dest 'AVVIA.ps1'
    try {
        if (Test-Path -LiteralPath $bat) {
            Start-Process -FilePath $bat -WorkingDirectory $dest | Out-Null
            Bene 'ZAP avviato (AVVIA.bat)'
        } elseif (Test-Path -LiteralPath $ps1) {
            Start-Process -FilePath 'powershell' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $ps1 + '"')) -WorkingDirectory $dest | Out-Null
            Bene 'ZAP avviato (AVVIA.ps1)'
        } else {
            Nota 'non ho trovato AVVIA.bat: aprilo tu'
        }
    } catch { Nota ('non sono riuscito ad avviarlo: ' + $_.Exception.Message) }
}

Scr ''
Scr '=========================================================='
Scr (' INSTALLAZIONE v9.1 COMPLETATA  (' + $okN + ' operazioni ok)')
Scr '=========================================================='
Scr ''
Scr ' In ZAP ora trovi, in alto a destra:'
Scr '   - AGENTI 0/7   -> la cabina di regia (in tempo reale)'
Scr '   - GHOST: APERTO -> il perimetro (rosso = nessun blocco)'
Scr ''
Scr ' Comandi utili:'
Scr '   /ghost aggiungi miosito.it, www.miosito.it   (i tuoi siti)'
Scr '   /aula kit                                    (materiale lezione)'
Scr '   /agenti                                      (cabina)'
Scr ''
Scr (' Log completo: ' + $logFile) 'DarkGray'
Scr (' Backup di oggi: ' + $backup) 'DarkGray'
exit 0
