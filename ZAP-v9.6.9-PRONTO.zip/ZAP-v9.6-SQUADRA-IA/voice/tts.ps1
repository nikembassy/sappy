﻿# tts.ps1 - Sintesi vocale (le risposte ad alta voce)
# Usato dalla UI sul thread grafico. Il contenuto arriva dalla coda $sync.UiQueue.

try { Add-Type -AssemblyName System.Speech -ErrorAction Stop } catch { }

function Test-VoceDisponibile {
    # Prova a creare il sintetizzatore senza far cadere niente.
    try {
        $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
        try { $s.Dispose() } catch { }
        return $true
    } catch {
        return $false
    }
}

function Initialize-Tts {
    param($sync)

    if ($sync.Tts) {
        try { $sync.Tts.SpeakAsyncCancelAll() } catch { }
        try { $sync.Tts.Dispose() } catch { }
        $sync.Tts = $null
    }

    # v9 -- IMPORTANTE: su alcuni PC Windows manca una voce installata (o il motore
    # vocale non c'e'). In quel caso New-Object lancia un errore FATALE
    # ("Impossibile trovare un riconoscimento con l'ID richiesto... culture") e ZAP
    # si chiudeva subito, prima di mostrare la finestra.
    # Da qui in poi la voce e' OPZIONALE: se non funziona si perde la lettura ad alta
    # voce, non il programma.
    try {
        if (-not ('System.Speech.Synthesis.SpeechSynthesizer' -as [type])) {
            Add-Type -AssemblyName System.Speech -ErrorAction Stop
        }
    } catch {
        $sync.Tts = $null
        try { $sync.VoceDisponibile = $false } catch { }
        return
    }

    $s = $null
    try {
        $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
    } catch {
        $sync.Tts = $null
        try { $sync.VoceDisponibile = $false } catch { }
        try { $sync.Config.voce.risposte_ad_alta_voce = $false } catch { }
        return
    }

    try {
        $voceIt = $s.GetInstalledVoices() |
            Where-Object { $_.Enabled } |
            Where-Object { $_.VoiceInfo.Culture.Name -like 'it*' } |
            Select-Object -First 1
        if ($voceIt) { $s.SelectVoice($voceIt.VoiceInfo.Name) }
    } catch { }

    $rate = 1; $vol = 100
    try { $rate = [int]$sync.Config.voce.velocita } catch { }
    try { $vol  = [int]$sync.Config.voce.volume  } catch { }
    try { $s.Rate   = $rate } catch { }
    try { $s.Volume = $vol } catch { }

    $sync.Tts = $s
    try { $sync.VoceDisponibile = $true } catch { }
}

function ConvertTo-SpeechText {
    # Toglie markdown, codice e URL: la voce deve suonare naturale
    param([string]$Text)

    $t = $Text
    $t = [regex]::Replace($t, '(?s)```.*?```', '. ')
    $t = [regex]::Replace($t, '`[^`]*`', ' ')
    $t = [regex]::Replace($t, 'https?://\S+', ' link ')
    $t = [regex]::Replace($t, '[#*_>|{}\[\]]', ' ')
    $t = [regex]::Replace($t, '(?m)^\s*[-*-]\s*', '')
    $t = [regex]::Replace($t, '\s+', ' ').Trim()
    if ($t.Length -gt 900) { $t = $t.Substring(0, 880) + '. E ho finito!' }
    if (-not $t) { $t = 'Fatto!' }
    return $t
}

function Start-Speak {
    param($sync, [string]$Text)
    if (-not $sync.Tts) { return }
    if (-not $Text) { return }
    try {
        $sync.Tts.SpeakAsyncCancelAll()
        $sync.Tts.SpeakAsync($Text) | Out-Null
        $sync.Speaking = $true
    } catch {
        $sync.Speaking = $false
    }
}

function Stop-Speak {
    param($sync)
    if ($sync.Tts) {
        try { $sync.Tts.SpeakAsyncCancelAll() } catch { }
    }
    $sync.Speaking = $false
}
