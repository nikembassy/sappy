﻿# ZAP-SERVER.ps1 -- server HTTP minimale (Windows PowerShell 5.1)
# Ascolta SOLO su http://127.0.0.1:8765/
# Endpoint:
#   GET /health             -> {"ok":true}  (pubblico)
#   GET /stato              -> richiede X-ZAP-Token; esegue & ZAP-CLI.ps1 "stato"
#   GET /riepilogo-giornata -> richiede X-ZAP-Token; esegue & ZAP-CLI.ps1 "riepilogo-giornata"
#   altro                   -> 404

$ErrorActionPreference = 'Stop'
$url = 'http://127.0.0.1:8765/'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ZapCli = Join-Path $dir 'ZAP-CLI.ps1'
$TokenFile = Join-Path $dir 'ZAP-SERVER.token'

# --- token: genera se non esiste ---
if (-not (Test-Path -LiteralPath $TokenFile)) {
    $bytes = New-Object byte[] 32
    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    $hex = -join ($bytes | ForEach-Object { $_.ToString('x2') })
    Set-Content -LiteralPath $TokenFile -Value $hex -Encoding ASCII -NoNewline
}
$ServerToken = (Get-Content -LiteralPath $TokenFile -Raw).Trim()

$listener = New-Object System.Net.HttpListener
try {
    $listener.Prefixes.Add($url)
    $listener.Start()
} catch {
    Write-Host ("AVVIO FALLITO: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}

Write-Host ("In ascolto su " + $url)

function Invoke-Cli {
    param([string]$Command)
    $output = ''
    $exitCode = 0
    $errText = ''
    try {
        $output = & $ZapCli $Command *>&1 | Out-String
        $exitCode = $LASTEXITCODE
    } catch {
        $errText = $_.Exception.Message
        $exitCode = 1
    }
    if ($exitCode -ne 0) {
        $msg = if ($errText) { $errText } else { $output }
        return @{ ok = $false; output = $msg; exitCode = $exitCode }
    }
    return @{ ok = $true; output = $output; exitCode = $exitCode }
}

function Send-Json {
    param([int]$StatusCode, [string]$Json)
    $body = [System.Text.Encoding]::UTF8.GetBytes($Json)
    $res.StatusCode = $StatusCode
    $res.ContentType = 'application/json; charset=utf-8'
    $res.ContentLength64 = $body.Length
    $res.OutputStream.Write($body, 0, $body.Length)
}

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $req = $context.Request
        $res = $context.Response

        $path = $req.Url.AbsolutePath
        $method = $req.HttpMethod

        if ($method -eq 'GET' -and $path -eq '/health') {
            Send-Json 200 '{"ok":true}'
        }
        elseif ($method -eq 'GET' -and ($path -eq '/stato' -or $path -eq '/riepilogo-giornata')) {
            $provided = $req.Headers['X-ZAP-Token']
            if ($provided -eq $ServerToken) {
                $cmd = if ($path -eq '/stato') { 'stato' } else { 'riepilogo-giornata' }
                $r = Invoke-Cli -Command $cmd
                $obj = @{ ok = $r.ok; output = $r.output; exitCode = $r.exitCode }
                Send-Json 200 ($obj | ConvertTo-Json -Compress)
            } else {
                Send-Json 401 '{"ok":false,"error":"non autorizzato"}'
            }
        }
        else {
            Send-Json 404 '{"ok":false,"error":"not found"}'
        }

        $res.Close()
    }
} finally {
    $listener.Stop()
    $listener.Close()
}
