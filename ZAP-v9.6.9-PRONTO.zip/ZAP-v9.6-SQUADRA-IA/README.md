﻿[v9.6] ATTENZIONE: questo documento descrive la versione 9.5. Il motore
locale (Ollama) e' stato RIMOSSO: ZAP usa solo servizi in cloud (Gemini
primario, DeepSeek secondario). Vedi LEGGIMI_v9.6.txt.
--------------------------------------------------------------------------
# ZAP! v9.0 - Assistente Desktop con MEMORIA INDELEBILE

**Novita' della v9.0 (leggile qui, i dettagli in `LEGGIMI_MODIFICHE_v9.0.txt`)**

- **Memoria che non si perde** (`Ezappero`): registro append-only con catena di hash, copia
  specchio fuori dal progetto, rilevamento delle manomissioni e ripristino automatico.
  Appunti versionati: ogni salvataggio e' una copia datata, per sempre.
- **DeepSeek collegato** (`deepseek-v4-pro` e `deepseek-flash`), con function calling verificato.
- **Nuova sezione POWERSHELL SCRIPT** (pulsante `PS`): ogni script generato si archivia da solo,
  ordinato per categoria, con indice e ricerca (anche dentro il codice).
- **Guardia anti-bugia accesa di default**: regole di verita' nel prompt + controllo automatico
  di numeri, link e certezze assolute contro le prove del turno. Se non torna, ZAP lo dice.
- **Modalita' traccia**: registra cosa fai sul PC (finestra + programma) in `Ezappero\tracce`.
- **Fatture e buste paga** in HTML/PDF con numerazione progressiva (la busta paga e' dichiarata
  simulazione: non sostituisce un consulente del lavoro).
- **Posta Gmail** con bozze salvate (invio solo se lo autorizzi) - vedi `ISTRUZIONI_GMAIL.md`.
- **Automazioni ripulite**: rimosse quelle che cancellavano file; aggiunte verifica memoria,
  backup, riepilogo giornata, promemoria documenti.
- **Cassetta degli attrezzi**: `RACCOGLI_STRUMENTI.bat` censice i tuoi tool di pentest
  (Windows e Kali/WSL) in `documentazione\strumenti.json`; ZAP usa solo quelli che hai davvero,
  con 39 strumenti catalogati in 6 fasi e ricette pronte.
- **Modalita' GHOST** (settima): nessun filtro dentro il perimetro che dichiari, blocco fisico
  fuori. Per pentest sui tuoi programmi e sui tuoi siti, senza prediche e con la scatola nera.
- **Primo avvio automatico**: doppio clic su `PRIMO_AVVIO.bat` e non devi configurare niente
  (config, cartelle, protezione, copia di sicurezza, automazioni pianificate, controllo chiave).
  E' ripetibile e si puo' rilanciare con `-SoloVerifica` per rifare solo i controlli.

Test automatici: `powershell -ExecutionPolicy Bypass -File .\tests\test_v9.ps1` (71 test).
Se non si apre niente: doppio clic su `AVVIO_SICURO.bat` (non si chiude mai, diagnostica e avvia).
Altrimenti `logs\avvio.log` dice fin dove e' arrivato (ogni modulo si carica
per conto suo, quindi un problema non blocca piu' l'avvio).
Da terminale, senza aprire la grafica: `ZAP-CLI.ps1 stato`.

---

# ZAP! v9.0 - Assistente Desktop (Gemini in cloud + Llama locale, grafica personalizzabile)

ZAP! e' un assistente AI per Windows: finestra nativa (PowerShell + WPF), **zero installazioni**.
Il "cervello" e' **in cloud (Google Gemini)** oppure, per le domande semplici, **in locale (Llama)**.

## Novita' della v6.6

- **Basta caccia ai modelli**: la chat usa **UN solo modello** (parte da `gemini-3.1-flash-lite`
  verificato e veloce), con **UN solo ripiego**. Solo se entrambi falliscono cerca un modello
  disponibile **una volta** e lo **ricorda** (`memory\modello_scelto.txt`).
- **Nuova chiave Gemini** inserita e **verificata** (chat + visione funzionanti).

Dalla v6.5: pannello **INTELLIGENZE AI** leggibile in oro, pannello
**CAMBIA TEMA E COLORI**, menu senza sovrapposizioni. Dalla v6.4: modalita' **ENTERPRISE**,
`AVVIA_ADMIN.bat`, **appunti**, apprendimento dallo schermo. Dalla v6.3: grafica **AURA**,
upload **foto/video/PDF**, pannello **INSEGNA**.

## Requisiti
- **Windows 10/11**, connessione a internet e una **chiave API Google Gemini** (gia' presente).
- **Nessun modello locale**: ZAP lavora solo con servizi cloud. Ollama e' disattivato e non viene contattato.

## Avvio
1. Tasto destro su `INSTALLA.ps1` -> "Esegui con PowerShell".
2. Doppio clic su `AVVIA.bat` (oppure `AVVIA_ADMIN.bat` per i pieni permessi).

## Le 5 modalita'
| Modalita' | Comportamento |
|---|---|
| PRUDENTE | chiede sempre prima di agire |
| SMART | fa da solo le cose sicure, chiede per quelle rischiose |
| LIBERA | fa tutto senza chiedere |
| SVILUPPATORE | autonomia piena + riformula/riprova + ricerca web |
| **ENTERPRISE** | autonomia totale, nessun rifiuto, pensiero laterale, impara dallo schermo, si auto-migliora. **Non cancella mai senza conferma** |

## Tema e colori
Pulsante **TEMA** (o `/tema`): temi pronti **AURA / NOTTE / SMERALDO / VIOLA / CHIARO**; oppure
singoli colori e carattere/dimensione. APPLICA = dal vivo + salvato.

## Modelli e velocita'
- Un solo modello per volta: `gemini-3.1-flash-lite` -> un ripiego -> (solo se serve) ricerca
  automatica di un modello disponibile, che viene ricordato.
- In barra: "SCRIVO CON &lt;modello&gt;...".

## Comandi
`/aiuto` `/mode` `/tema` `/appunti` `/impara-schermo` `/migliorati` `/admin` `/skills` `/insegna`
`/allegati` `/foto` `/video` `/allegati-vuota` `/programmi` `/mic` `/ai` `/ferma` `/vuota`

## Note oneste
- **"Senza filtri"**: ZAP non rifiuta mai e usa il pensiero laterale (regola nel prompt). I filtri
  dei **server di Google** non si possono disattivare dal programma.
- **Amministratore**: con `AVVIA_ADMIN.bat` ZAP puo' eseguire qualunque comando; la cancellazione
  resta sempre soggetta alla tua conferma.
- **Grafica WPF**: verificata come struttura/sintassi (non eseguibile fuori da Windows).


## Aggiornamento v6.6.1 (correzioni)
- **Streaming**: la risposta compare mentre arriva (`:streamGenerateContent?alt=sse`), con ripiego
  automatico sulla chiamata classica se lo streaming non riesce.
- **Segreti separati**: le chiavi stanno in `config.local.json` (ignorato da git); `config.json`
  non contiene segreti e non ha piu' il BOM.
- **Niente dirottamento**: `api_base` e' vuoto; se non c'e' nessun servizio pronto il messaggio
  d'errore e' chiaro invece di puntare a un endpoint sbagliato.
- **Meno servizi nel giro**: restano attivi solo Gemini (ricerca/visione/veloce) e OpenAI
  (codice/testo); gli altri si accendono quando c'e' la chiave.
- **Piu' veloce**: timeout ridotti e nessuna sonda al motore locale (Ollama disattivato).
- **Avatar distinti**: `robot.png`, `robot_parla.png`, `robot_pensa.png` ora sono tre immagini
  diverse (prima erano lo stesso file).
