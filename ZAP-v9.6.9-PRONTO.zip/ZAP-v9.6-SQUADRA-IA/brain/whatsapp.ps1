﻿# whatsapp.ps1 -- ZAP v8.5 : invio WhatsApp VERIFICATO sull'APP DEL COMPUTER
# ---------------------------------------------------------------------------
#  Regola di questa versione (richiesta esplicita): WhatsApp Web NON si usa.
#  Solo l'app di Windows: quella classica (WhatsApp.exe) o quella dello Store.
#
#  Perche' la v8.3 a volte non inviava:
#   "scrivi_testo" incollava con Ctrl+V nella finestra che aveva il fuoco e
#   rispondeva "Scritto" SEMPRE, senza controllare niente. Se il fuoco era
#   sulla barra di ricerca il testo finiva nel vuoto, ma la risposta era
#   comunque "Scritto" e ZAP riferiva "fatto".
#
#  Qui invece ogni passo e' verificato, e il risultato comincia con
#  VERIFICATO: SI / PARZIALE / NO.
# ---------------------------------------------------------------------------

if (-not (Get-Command Find-Finestra -ErrorAction SilentlyContinue)) {
    $__pc = Join-Path (Split-Path -Parent $PSCommandPath) 'pc_controllo.ps1'
    if (Test-Path $__pc) { . $__pc }
}

# ---------------------------------------------------------------------------
# Rubrica: nome -> numero. E' il pezzo che rende l'invio affidabile.
# ---------------------------------------------------------------------------

function Get-ContattiPercorso {
    param([string]$Base)
    if (-not $Base) { $Base = (Get-Location).Path }
    return (Join-Path $Base 'memory\contatti.json')
}

function Get-Contatti {
    param([string]$Base)
    $p = Get-ContattiPercorso $Base
    $out = @{}
    if (Test-Path $p) {
        try {
            $raw = Get-Content -Path $p -Raw -Encoding UTF8
            $obj = $raw | ConvertFrom-Json
            foreach ($prop in $obj.contatti.PSObject.Properties) {
                $out[$prop.Name] = $prop.Value
            }
        } catch { }
    }
    return $out
}

function Save-Contatti {
    param([string]$Base, $Contatti)
    try {
        $p = Get-ContattiPercorso $Base
        $dir = Split-Path -Parent $p
        if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $obj = [pscustomobject]@{ versione = 1; contatti = $Contatti }
        $json = $obj | ConvertTo-Json -Depth 6
        [System.IO.File]::WriteAllText($p, $json, (New-Object System.Text.UTF8Encoding($false)))
        return $true
    } catch { return $false }
}

function ConvertTo-ChiaveContatto {
    param([string]$Nome)
    $n = ([string]$Nome).ToLowerInvariant().Trim()
    $n = $n -replace '[\u00E0\u00E1]', 'a'
    $n = $n -replace '[\u00E8\u00E9]', 'e'
    $n = $n -replace '[\u00EC\u00ED]', 'i'
    $n = $n -replace '[\u00F2\u00F3]', 'o'
    $n = $n -replace '[\u00F9\u00FA]', 'u'
    $n = $n -replace '[^a-z0-9 ]', ' '
    $n = ($n -replace '\s+', ' ').Trim()
    return $n
}

function Normalizza-Telefono {
    # Toglie spazi, trattini e parentesi; aggiunge il prefisso se manca.
    param([string]$Numero, [string]$Prefisso = '39')

    $n = ([string]$Numero) -replace '[^0-9+]', ''
    if (-not $n) { return '' }
    if ($n.StartsWith('+')) { return $n }
    if ($n.StartsWith('00')) { return ('+' + $n.Substring(2)) }
    if ($Prefisso -and $n.StartsWith($Prefisso) -and $n.Length -gt ($Prefisso.Length + 5)) { return ('+' + $n) }
    # in Italia il mobile non ha lo zero iniziale, il fisso si: 06... resta 06...
    if ($n.StartsWith('0')) { return ('+' + $Prefisso + $n) }
    if ($n.Length -ge 8 -and $n.Length -le 11) { return ('+' + $Prefisso + $n) }
    return ('+' + $n)
}

function Find-Contatto {
    param([string]$Base, [string]$Nome)

    $contatti = Get-Contatti $Base
    $k = ConvertTo-ChiaveContatto $Nome
    if (-not $k) { return $null }
    if ($contatti.ContainsKey($k)) { return $contatti[$k] }

    foreach ($chiave in @($contatti.Keys)) {
        if ($chiave.StartsWith($k)) { return $contatti[$chiave] }
    }
    foreach ($chiave in @($contatti.Keys)) {
        if ($chiave.Contains($k)) { return $contatti[$chiave] }
    }
    foreach ($chiave in @($contatti.Keys)) {
        $c = $contatti[$chiave]
        $bel = ConvertTo-ChiaveContatto ([string]$c.nome)
        if ($bel -and $bel.Contains($k)) { return $c }
    }
    return $null
}

function Set-Contatto {
    param([string]$Base, [string]$Nome, [string]$Telefono)
    $k = ConvertTo-ChiaveContatto $Nome
    if (-not $k) { return @{ ok = $false; messaggio = 'nome non valido' } }
    $tel = Normalizza-Telefono $Telefono
    if (-not $tel -or $tel.Length -lt 8) { return @{ ok = $false; messaggio = 'numero non valido' } }
    $contatti = Get-Contatti $Base
    $contatti[$k] = [pscustomobject]@{ nome = ([string]$Nome).Trim(); telefono = $tel }
    if (-not (Save-Contatti $Base $contatti)) { return @{ ok = $false; messaggio = 'non riesco a salvare la rubrica' } }
    return @{ ok = $true; messaggio = ('salvato: ' + ([string]$Nome).Trim() + ' = ' + $tel); telefono = $tel }
}

function Format-Contatti {
    param([string]$Base)
    $c = Get-Contatti $Base
    if ($c.Count -eq 0) {
        return 'Rubrica vuota. Per salvare un contatto: "salva il contatto Marco 3491234567".'
    }
    $righe = @('Rubrica WhatsApp (' + $c.Count + '):')
    foreach ($k in (@($c.Keys) | Sort-Object)) {
        $v = $c[$k]
        $righe += ('- ' + [string]$v.nome + '  ->  ' + [string]$v.telefono)
    }
    return ($righe -join "`n")
}

# ---------------------------------------------------------------------------
# L'APP DEL COMPUTER (niente WhatsApp Web)
# ---------------------------------------------------------------------------

function Get-WhatsAppDesktopComando {
    # Ritorna @{ tipo = 'exe' | 'aumid'; valore = ... } oppure $null.
    try {
        $p = Join-Path $env:LOCALAPPDATA 'WhatsApp\WhatsApp.exe'
        if (Test-Path $p) { return @{ tipo = 'exe'; valore = $p } }
    } catch { }

    try {
        $c = Get-Command 'WhatsApp.exe' -ErrorAction SilentlyContinue
        if ($c) { return @{ tipo = 'exe'; valore = [string]$c.Source } }
    } catch { }

    # app dello Store / MSIX: si avvia con shell:AppsFolder\<AppID>
    try {
        if (Get-Command Resolve-StartAppId -ErrorAction SilentlyContinue) {
            $aumid = Resolve-StartAppId 'WhatsApp'
            if ($aumid) { return @{ tipo = 'aumid'; valore = $aumid } }
        }
    } catch { }

    try {
        $appx = Get-AppxPackage -Name '*WhatsApp*' -ErrorAction SilentlyContinue
        if ($appx) {
            $fam = [string]$appx.PackageFamilyName
            if ($fam) { return @{ tipo = 'aumid'; valore = ($fam + '!App') } }
        }
    } catch { }

    return $null
}

function Test-WhatsAppDesktop {
    return ($null -ne (Get-WhatsAppDesktopComando))
}

function Start-WhatsAppDesktop {
    param($sync)
    $c = Get-WhatsAppDesktopComando
    if (-not $c) { return $false }
    try {
        if ($c.tipo -eq 'exe') { Start-Process -FilePath $c.valore }
        else { Start-Process ('shell:AppsFolder\' + $c.valore) }
        return $true
    } catch { return $false }
}

function New-LinkWhatsApp {
    # Serve anche per l'app desktop: whatsapp:// e' il protocollo ufficiale.
    param([string]$Telefono, [string]$Testo = '')

    $n = (Normalizza-Telefono $Telefono) -replace '[^0-9]', ''
    if (-not $n) { return '' }
    $u = 'whatsapp://send?phone=' + $n
    if ($Testo) { $u = $u + '&text=' + [System.Uri]::EscapeDataString($Testo) }
    return $u
}

function Get-FinestraWhatsApp {
    if (-not (Get-Command Find-Finestra -ErrorAction SilentlyContinue)) { return $null }
    foreach ($filtro in @('whatsapp')) {
        $f = Find-Finestra $filtro
        if ($f) { return $f }
    }
    return $null
}

function Wait-FinestraWhatsApp {
    param([int]$Secondi = 14)
    $fine = (Get-Date).AddSeconds($Secondi)
    while ((Get-Date) -lt $fine) {
        $f = Get-FinestraWhatsApp
        if ($f) { return $f }
        Start-Sleep -Milliseconds 400
    }
    return $null
}

function ConvertTo-SendKeysSicuro {
    # SendKeys tratta + ^ % ~ ( ) [ ] { } come comandi: vanno protetti.
    param([string]$Testo)
    $out = New-Object System.Text.StringBuilder
    foreach ($ch in ([string]$Testo).ToCharArray()) {
        switch ([string]$ch) {
            '+' { [void]$out.Append('{+}') }
            '^' { [void]$out.Append('{^}') }
            '%' { [void]$out.Append('{%}') }
            '~' { [void]$out.Append('{~}') }
            '(' { [void]$out.Append('{(}') }
            ')' { [void]$out.Append('{)}') }
            '[' { [void]$out.Append('{[}') }
            ']' { [void]$out.Append('{]}') }
            '{' { [void]$out.Append('{{}') }
            '}' { [void]$out.Append('{}}') }
            default { [void]$out.Append($ch) }
        }
    }
    return $out.ToString()
}

# ---------------------------------------------------------------------------
# Lettura del campo messaggio (UI Automation): e' la verifica vera
# ---------------------------------------------------------------------------

function Get-CampoMessaggioElemento {
    # L'elemento "campo di scrittura" della chat (l'Edit piu' in basso), o $null.
    param([int64]$Hwnd)

    try { Add-Type -AssemblyName UIAutomationClient -ErrorAction Stop } catch { return $null }
    try { Add-Type -AssemblyName UIAutomationTypes -ErrorAction Stop } catch { return $null }

    try {
        $root = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$Hwnd)
        if (-not $root) { return $null }

        $cond = New-Object System.Windows.Automation.PropertyCondition(
            [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
            [System.Windows.Automation.ControlType]::Edit)
        $edits = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
        if (-not $edits -or $edits.Count -eq 0) { return $null }

        $migliore = $null
        $migliorY = -1.0
        foreach ($e in $edits) {
            try {
                $r = $e.Current.BoundingRectangle
                if ($r.Height -le 0 -or $r.Width -le 0) { continue }
                if ($r.Y -gt $migliorY) { $migliorY = $r.Y; $migliore = $e }
            } catch { }
        }
        return $migliore
    } catch {
        return $null
    }
}

function Get-TestoCampoMessaggio {
    param([int64]$Hwnd)

    $el = Get-CampoMessaggioElemento $Hwnd
    if (-not $el) { return $null }

    try {
        $vp = $el.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
        if ($vp) { return [string]$vp.Current.Value }
    } catch { }
    try {
        $tp = $el.GetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern)
        if ($tp) { return [string]$tp.GetText(-1) }
    } catch { }
    try { return [string]$el.Current.Name } catch { }

    return $null
}

# ---------------------------------------------------------------------------
# Il cuore: invio con passi verificati, solo app desktop
# ---------------------------------------------------------------------------

function Invoke-WhatsAppInvia {
    param(
        $sync,
        [Parameter(Mandatory = $true)][string]$Contatto,
        [string]$Testo = '',
        [string]$Telefono = '',
        [switch]$NonInviare,
        [switch]$Simula,
        [int]$AttesaSecondi = 14
    )

    $passi = New-Object System.Collections.ArrayList
    function Passo([string]$t) { [void]$passi.Add($t) }

    $base = ''
    try { if ($sync -and $sync.Base) { $base = [string]$sync.Base } } catch { }
    if (-not $base) { $base = (Get-Location).Path }

    # --- 1) chi e' il destinatario --------------------------------------
    $tel = ''
    $nomeBello = [string]$Contatto
    if ($Telefono) {
        $tel = Normalizza-Telefono $Telefono
        Passo ('1. numero indicato a mano: ' + $tel)
    } elseif ($Contatto -match '^\+?[0-9][0-9\s\-\.]{6,20}$') {
        $tel = Normalizza-Telefono $Contatto
        Passo ('1. il destinatario e gia un numero: ' + $tel)
    } else {
        $c = Find-Contatto $base $Contatto
        if ($c) {
            $tel = [string]$c.telefono
            $nomeBello = [string]$c.nome
            Passo ('1. contatto "' + $nomeBello + '" in rubrica: ' + $tel)
        } else {
            Passo ('1. contatto "' + $Contatto + '" NON in rubrica')
            $m = "VERIFICATO: NO`nPassi:`n" + ($passi -join "`n")
            $m = $m + "`n!Non ho inviato niente: senza il numero non posso aprire la chat giusta. " +
                       "Salva il contatto una volta e poi funziona sempre: `"salva il contatto " + $Contatto + " 39XXXXXXXXXX`"."
            return [pscustomobject]@{ Verificato = 'NO'; Ok = $false; Testo = $m; Telefono = '' }
        }
    }

    if (-not $tel -or $tel.Length -lt 8) {
        $m = "VERIFICATO: NO`nPassi:`n" + ($passi -join "`n") + "`n!Numero non valido: non ho inviato niente."
        return [pscustomobject]@{ Verificato = 'NO'; Ok = $false; Testo = $m; Telefono = '' }
    }
    if (-not $Testo) {
        $m = "VERIFICATO: NO`nPassi:`n" + ($passi -join "`n") + "`n!Manca il testo del messaggio: non ho inviato niente."
        return [pscustomobject]@{ Verificato = 'NO'; Ok = $false; Testo = $m; Telefono = $tel }
    }

    # --- 2) il link ufficiale per l'app del computer ---------------------
    $link = New-LinkWhatsApp -Telefono $tel -Testo $Testo
    Passo ('2. link pronto: whatsapp://send?phone=' + ($tel -replace '[^0-9]', '') + '&text=...')

    if ($Simula) {
        $nota = 'app del computer: trovata'
        if (-not (Test-WhatsAppDesktop)) { $nota = 'app del computer: NON trovata (un invio vero fallirebbe qui)' }
        $m = "VERIFICATO: NO (simulazione)`nPassi:`n" + ($passi -join "`n") +
             "`n" + $nota + "`nNon ho aperto niente: e' una prova."
        return [pscustomobject]@{ Verificato = 'NO'; Ok = $true; Testo = $m; Telefono = $tel }
    }

    # --- 3) SOLO l'app del computer (niente WhatsApp Web) ----------------
    $comando = Get-WhatsAppDesktopComando
    if (-not $comando) {
        Passo '3. app WhatsApp per Windows: NON trovata'
        $m = "VERIFICATO: NO`nPassi:`n" + ($passi -join "`n") +
             "`n!L app di WhatsApp per Windows non risulta installata, e come mi hai chiesto non uso la versione web del browser." +
             "`nInstallala dallo Store (cerca WhatsApp) oppure dimmi dove sta WhatsApp.exe e la configuro."
        return [pscustomobject]@{ Verificato = 'NO'; Ok = $false; Testo = $m; Telefono = $tel }
    }
    Passo ('3. app del computer trovata (' + $comando.tipo + ')')

    # --- 3) apri l'app ---------------------------------------------------
    [void](Start-WhatsAppDesktop $sync)
    $fin = Wait-FinestraWhatsApp $AttesaSecondi
    if (-not $fin) {
        $m = "VERIFICATO: NO`nPassi:`n" + ($passi -join "`n") +
             "`n!Non sono riuscito ad aprire WhatsApp entro " + $AttesaSecondi + " secondi."
        return [pscustomobject]@{ Verificato = 'NO'; Ok = $false; Testo = $m; Telefono = $tel }
    }
    Passo ('4. finestra trovata: ' + [string]$fin.titolo)
    [void](Focus-Finestra 'whatsapp')
    Start-Sleep -Milliseconds 1200
    Passo '5. finestra in primo piano'

    # --- 4) il link ha gia' riempito il campo? --------------------------
    $prima = $null
    $prefillOk = $false
    try {
        Start-Process $link
        Start-Sleep -Milliseconds 2800
        $fin = Get-FinestraWhatsApp
        if ($fin) {
            [void](Focus-Finestra 'whatsapp')
            Start-Sleep -Milliseconds 900
            $prima = Get-TestoCampoMessaggio ([int64]$fin.hwnd)
            if ($prima) {
                $letto = ([string]$prima).Trim()
                if ($letto -and $letto.Contains(([string]$Testo).Trim())) { $prefillOk = $true }
            }
        }
    } catch { }
    Passo ('6. collegamento diretto: ' + $(if ($prefillOk) { 'campo gia riempito' } else { 'campo non riempito, provo la ricerca' }))

    # --- 5) altrimenti: ricerca interna + incolla -----------------------
    if (-not $prefillOk) {
        try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch { }
        try {
            [void](Focus-Finestra 'whatsapp')
            Start-Sleep -Milliseconds 500
            [System.Windows.Forms.SendKeys]::SendWait('^f')
            Start-Sleep -Milliseconds 800
            $cerca = ConvertTo-SendKeysSicuro $nomeBello
            [System.Windows.Forms.SendKeys]::SendWait($cerca)
            Start-Sleep -Milliseconds 1800
            [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
            Start-Sleep -Milliseconds 1800
            Passo ('7. cercato "' + $nomeBello + '" nella chat')
        } catch {
            Passo ('7. ricerca non riuscita: ' + $_.Exception.Message)
        }

        try {
            $fin2 = Get-FinestraWhatsApp
            if ($fin2) {
                $campo = Get-CampoMessaggioElemento ([int64]$fin2.hwnd)
                if ($campo) {
                    try { $campo.SetFocus() } catch { }
                    Start-Sleep -Milliseconds 350
                }
            }
            Set-Clipboard -Value $Testo
            Start-Sleep -Milliseconds 250
            [System.Windows.Forms.SendKeys]::SendWait('^v')
            Start-Sleep -Milliseconds 700
            Passo '8. testo incollato nel campo'
        } catch {
            Passo ('8. incolla non riuscito: ' + $_.Exception.Message)
        }
    }

    if ($NonInviare) {
        $m = "VERIFICATO: NO (solo preparato)`nPassi:`n" + ($passi -join "`n") +
             "`nWhatsApp e aperto con il messaggio dentro. Premi tu Invio per inviare."
        return [pscustomobject]@{ Verificato = 'NO'; Ok = $true; Testo = $m; Telefono = $tel }
    }

    # --- 6) Invio --------------------------------------------------------
    $letturaDisponibile = $false
    try {
        $fin3 = Get-FinestraWhatsApp
        if ($fin3) {
            $adesso = Get-TestoCampoMessaggio ([int64]$fin3.hwnd)
            if ($null -ne $adesso) { $letturaDisponibile = $true }
        }
        [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
        Passo '9. Invio premuto'
    } catch {
        $m = "VERIFICATO: NO`nPassi:`n" + ($passi -join "`n") + "`n!Non sono riuscito a premere Invio: " + $_.Exception.Message
        return [pscustomobject]@{ Verificato = 'NO'; Ok = $false; Testo = $m; Telefono = $tel }
    }

    Start-Sleep -Milliseconds 1000

    # --- 7) verifica: il campo si e' svuotato? ---------------------------
    $verificato = 'PARZIALE'
    try {
        $fin4 = Get-FinestraWhatsApp
        if ($fin4) {
            $dopo = Get-TestoCampoMessaggio ([int64]$fin4.hwnd)
            if ($letturaDisponibile -and $null -ne $dopo) {
                if (([string]$dopo).Trim().Length -eq 0) {
                    $verificato = 'SI'
                    Passo '10. campo vuoto dopo Invio: messaggio partito'
                } else {
                    $verificato = 'NO'
                    Passo '10. il campo contiene ancora del testo: Invio non e arrivato'
                }
            } else {
                Passo '10. non riesco a rileggere il campo: verifica solo parziale'
            }
        }
    } catch { }

    # --- 8) risposta -----------------------------------------------------
    $corpo = "`nPassi:`n" + ($passi -join "`n")
    if ($verificato -eq 'SI') {
        $corpo = $corpo + "`n`nMessaggio inviato a " + $nomeBello + ' (' + $tel + '): "' + $Testo + '"'
    } elseif ($verificato -eq 'PARZIALE') {
        $corpo = $corpo + "`n`nHo premuto Invio sulla chat di " + $nomeBello + ' (' + $tel + '), ma non ho potuto leggere la chat per confermarlo.'
    } else {
        $corpo = $corpo + "`n`n!Il messaggio NON risulta partito. Controlla WhatsApp e premi Invio tu."
    }

    return [pscustomobject]@{
        Verificato = $verificato
        Ok         = ($verificato -eq 'SI')
        Testo      = ('VERIFICATO: ' + $verificato + $corpo)
        Telefono   = $tel
    }
}

function Get-StatoWhatsApp {
    param($sync)
    $base = ''
    try { if ($sync -and $sync.Base) { $base = [string]$sync.Base } } catch { }
    if (-not $base) { $base = (Get-Location).Path }

    $righe = @('WhatsApp:')
    $c = Get-WhatsAppDesktopComando
    if ($c) { $righe += ('- app del computer: OK (' + $c.tipo + ' -> ' + $c.valore + ')') }
    else { $righe += '- app del computer: NON trovata (la versione web non viene usata)' }
    $f = Get-FinestraWhatsApp
    if ($f) { $righe += ('- finestra aperta: ' + [string]$f.titolo) } else { $righe += '- finestra aperta: no' }
    $ct = Get-Contatti $base
    $righe += ('- contatti in rubrica: ' + $ct.Count)
    $righe += ('- lettura del campo (verifica forte): ' + $(if ($f) { if ($null -ne (Get-TestoCampoMessaggio ([int64]$f.hwnd))) { 'disponibile' } else { 'non disponibile' } } else { 'n/d' }))
    return ($righe -join "`n")
}
