﻿# quick_actions.ps1 -- ZAP v9.2
# ---------------------------------------------------------------------------
#  Pulsanti tondi accanto alla foto di ZAP:
#    * LANCIA BROWSER -> apre Thorium (PATH, registro di ZAP, cartelle tipiche,
#                        ricerca di thorium.exe sul PC)
#    * DIAGNOSI       -> RAM, spazio disco e processi piu pesanti (SOLA LETTURA)
#
#  Regola di sicurezza: qui NON si scrive e NON si cancella nulla sul sistema.
#  La diagnosi usa solo comandi Get-* (lettura).
# ---------------------------------------------------------------------------

function Find-ThoriumExecutable {
    # Restituisce il percorso di thorium.exe, oppure '' se non lo trova.
    param($sync)

    # 1) percorso indicato a mano in config.json -> browser_paths.thorium
    try {
        $custom = ''
        $bp = $sync.Config.browser_paths
        if ($bp) { try { $custom = [string]$bp['thorium'] } catch { $custom = '' } }
        if ($custom -and (Test-Path -LiteralPath $custom)) { return $custom }
    } catch { }

    # 2) percorsi noti del browser Thorium (registro di ZAP, senza fallback su altri browser)
    try {
        if (Get-Command Get-BrowserRegistry -ErrorAction SilentlyContinue) {
            $reg = Get-BrowserRegistry
            foreach ($p in @($reg['thorium'].paths)) {
                if ($p -and (Test-Path -LiteralPath $p)) { return [string]$p }
            }
        }
    } catch { }

    # 3) nel PATH
    try {
        $c = Get-Command 'thorium.exe' -ErrorAction SilentlyContinue
        if ($c -and $c.Source -and (Test-Path -LiteralPath $c.Source)) { return [string]$c.Source }
    } catch { }

    # 4) where.exe
    try {
        $w = & where.exe thorium.exe 2>$null
        foreach ($r in @($w)) {
            if ($r -and (Test-Path -LiteralPath $r)) { return [string]$r }
        }
    } catch { }

    # 5) cartelle di installazione tipiche
    $pf   = [string]$env:ProgramFiles
    $pf86 = [string]${env:ProgramFiles(x86)}
    $la   = [string]$env:LOCALAPPDATA
    $up   = [string]$env:USERPROFILE
    $dirette = New-Object System.Collections.ArrayList
    foreach ($b in @($la, $pf, $pf86, $up)) {
        if ($b) { [void]$dirette.Add((Join-Path $b 'Thorium\Application\thorium.exe')) }
    }
    if ($up) { [void]$dirette.Add((Join-Path $up 'Desktop\Thorium\Application\thorium.exe')) }
    foreach ($d in @($dirette)) {
        if ($d -and (Test-Path -LiteralPath $d)) { return [string]$d }
    }

    # 6) ricerca limitata in profondita' nelle cartelle utente/installazione
    $radici = @($la, $pf, $pf86, $up)
    foreach ($r in $radici) {
        if (-not $r -or -not (Test-Path -LiteralPath $r)) { continue }
        try {
            $f = Get-ChildItem -LiteralPath $r -Filter 'thorium.exe' -Recurse -Depth 4 -File -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($f) { return [string]$f.FullName }
        } catch { }
    }
    return ''
}

function Get-HomeMotoreRicerca {
    param($sync)
    $m = ''
    try { $m = ([string]$sync.Config.motore_ricerca).Trim().ToLower() } catch { $m = '' }
    if ($m -eq 'yandex')     { return 'https://yandex.com/' }
    if ($m -eq 'duckduckgo') { return 'https://duckduckgo.com/' }
    if ($m -eq 'bing')       { return 'https://www.bing.com/' }
    if ($m -eq 'google')     { return 'https://www.google.com/' }
    return 'https://www.google.com/'
}

function Start-ThoriumBrowser {
    # Apre Thorium. Restituisce il messaggio da mostrare in chat.
    param($sync)
    $exe = Find-ThoriumExecutable $sync
    if (-not $exe) {
        return 'NON ESEGUITO: thorium.exe non trovato (PATH, cartelle di installazione, Desktop). Indica il percorso in config.json alla voce browser_paths.thorium.'
    }
    $url = Get-HomeMotoreRicerca $sync
    try {
        Start-Process -FilePath $exe -ArgumentList @($url) | Out-Null
        return ('ESEGUITO: Thorium avviato -> ' + $exe + '   (pagina: ' + $url + ')')
    } catch {
        $e1 = $_.Exception.Message
        try {
            Start-Process -FilePath $url | Out-Null
            return ('ESEGUITO con riserva: Thorium non e partito (' + $e1 + '); ho aperto il browser predefinito su ' + $url)
        } catch {
            return ('NON ESEGUITO: impossibile avviare il browser (' + $e1 + ')')
        }
    }
}

# ---------------------------------------------------------------------------
#  DIAGNOSI - sola lettura
# ---------------------------------------------------------------------------

function Format-Gb {
    param([double]$Byte)
    if ($Byte -le 0) { return '0 GB' }
    return ([string]([Math]::Round($Byte / 1GB, 1)) + ' GB')
}

function New-DiagnosiTesto {
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('DIAGNOSI PC - SOLA LETTURA - ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    [void]$righe.Add('(nessun file e nessuna impostazione vengono modificati)')
    [void]$righe.Add('')

    # --- a) RAM ---
    [void]$righe.Add('== A) MEMORIA RAM ==')
    $totB = 0.0
    $libB = 0.0
    try {
        $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
        $totB = [double]$os.TotalVisibleMemorySize * 1024
        $libB = [double]$os.FreePhysicalMemory * 1024
    } catch {
        try {
            $os = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction Stop
            $totB = [double]$os.TotalVisibleMemorySize * 1024
            $libB = [double]$os.FreePhysicalMemory * 1024
        } catch {
            [void]$righe.Add('  non disponibile: ' + $_.Exception.Message)
        }
    }
    if ($totB -gt 0) {
        $usaB = $totB - $libB
        $perc = [Math]::Round(($usaB / $totB) * 100, 1)
        [void]$righe.Add('  totale : ' + (Format-Gb $totB))
        [void]$righe.Add('  libera : ' + (Format-Gb $libB))
        [void]$righe.Add('  in uso : ' + (Format-Gb $usaB) + '  (' + [string]$perc + '%)')
    }
    [void]$righe.Add('')

    # --- b) DISCO ---
    [void]$righe.Add('== B) SPAZIO DISCO (unita locali) ==')
    try {
        $dischi = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop)
        if ($dischi.Count -eq 0) { [void]$righe.Add('  nessuna unita locale trovata') }
        foreach ($d in $dischi) {
            $sz = [double]$d.Size
            $fr = [double]$d.FreeSpace
            $pc = 0.0
            if ($sz -gt 0) { $pc = [Math]::Round(($fr / $sz) * 100, 1) }
            $eti = ''
            try { $eti = [string]$d.VolumeName } catch { $eti = '' }
            [void]$righe.Add('  ' + [string]$d.DeviceID + '  libero ' + (Format-Gb $fr) + ' su ' + (Format-Gb $sz) + '  (' + [string]$pc + '% libero)  ' + $eti)
        }
    } catch {
        [void]$righe.Add('  non disponibile: ' + $_.Exception.Message)
    }
    [void]$righe.Add('')

    # --- c) PROCESSI E SERVIZI ---
    $tutti = @()
    try { $tutti = @(Get-Process -ErrorAction SilentlyContinue) } catch { $tutti = @() }
    [void]$righe.Add('== C) PROCESSI PIU PESANTI (potenziali rallentamenti) ==')
    [void]$righe.Add('  processi attivi in totale: ' + [string]$tutti.Count)
    try {
        $servizi = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' })
        [void]$righe.Add('  servizi in esecuzione    : ' + [string]$servizi.Count)
    } catch { }
    [void]$righe.Add('')
    [void]$righe.Add('  --- top 10 per CPU (secondi di CPU accumulati) ---')
    try {
        $p1 = @($tutti | Where-Object { $_.CPU -ne $null } | Sort-Object -Property CPU -Descending | Select-Object -First 10)
        $i = 0
        foreach ($p in $p1) {
            $i++
            $nomeP = [string]$p.ProcessName
            if ($nomeP.Length -gt 26) { $nomeP = $nomeP.Substring(0, 26) }
            $cpu = [Math]::Round([double]$p.CPU, 1)
            $mb = [Math]::Round([double]$p.WorkingSet64 / 1MB, 0)
            [void]$righe.Add('  ' + ([string]$i).PadLeft(2) + '. ' + $nomeP.PadRight(26) + ' CPU ' + ([string]$cpu).PadLeft(9) + ' s   RAM ' + ([string]$mb).PadLeft(6) + ' MB')
        }
        if ($i -eq 0) { [void]$righe.Add('  (nessun dato CPU disponibile)') }
    } catch {
        [void]$righe.Add('  non disponibile: ' + $_.Exception.Message)
    }
    [void]$righe.Add('')
    [void]$righe.Add('  --- top 10 per RAM occupata ---')
    try {
        $p2 = @($tutti | Sort-Object -Property WorkingSet64 -Descending | Select-Object -First 10)
        $i = 0
        foreach ($p in $p2) {
            $i++
            $nomeP = [string]$p.ProcessName
            if ($nomeP.Length -gt 26) { $nomeP = $nomeP.Substring(0, 26) }
            $mb = [Math]::Round([double]$p.WorkingSet64 / 1MB, 0)
            $cpu = 0.0
            try { if ($p.CPU -ne $null) { $cpu = [Math]::Round([double]$p.CPU, 1) } } catch { }
            [void]$righe.Add('  ' + ([string]$i).PadLeft(2) + '. ' + $nomeP.PadRight(26) + ' RAM ' + ([string]$mb).PadLeft(6) + ' MB   CPU ' + ([string]$cpu).PadLeft(9) + ' s')
        }
    } catch {
        [void]$righe.Add('  non disponibile: ' + $_.Exception.Message)
    }
    [void]$righe.Add('')
    [void]$righe.Add('Suggerimento: se RAM libera e bassa o il disco sotto il 10%, chiudi i')
    [void]$righe.Add('programmi in cima alla lista. Questa finestra non cambia nulla da sola.')
    return ($righe -join [Environment]::NewLine)
}

function Show-DiagnosiPannello {
    # Finestra di sola lettura con il testo della diagnosi (Ctrl+C per copiare).
    param($Window)
    $testo = New-DiagnosiTesto
    $w = New-Object System.Windows.Window
    $w.Title = 'ZAP - Diagnosi PC (sola lettura)'
    $w.Width = 860
    $w.Height = 640
    $w.WindowStartupLocation = 'CenterScreen'
    try { if ($Window) { $w.Owner = $Window } } catch { }
    $w.Background = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(14, 17, 22)))
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.IsReadOnly = $true
    $tb.FontFamily = 'Consolas'
    $tb.FontSize = 11
    $tb.Text = $testo
    $tb.TextWrapping = 'NoWrap'
    $tb.AcceptsReturn = $true
    $tb.VerticalScrollBarVisibility = 'Auto'
    $tb.HorizontalScrollBarVisibility = 'Auto'
    $tb.BorderThickness = '0'
    $tb.Padding = '10'
    $tb.Background = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(10, 12, 16)))
    $tb.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(224, 232, 240)))
    $w.Content = $tb
    $w.ShowDialog() | Out-Null
}
