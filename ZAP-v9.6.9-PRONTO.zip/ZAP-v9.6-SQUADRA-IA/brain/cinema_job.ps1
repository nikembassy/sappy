﻿# cinema_job.ps1 -- esecutore del motore CINEMA (gira in un runspace dedicato)
# ---------------------------------------------------------------------------
#  Variabili attese dal runspace: $sync, $base
#  Due tipi di lavoro:
#    'offline' -> disegna la GIF fotogramma per fotogramma (cinema.ps1)
#    'ai'      -> chiama il modello video, poi converte in GIF con ffmpeg
# ---------------------------------------------------------------------------

$ErrorActionPreference = 'Continue'

try { Add-Type -AssemblyName PresentationCore -ErrorAction SilentlyContinue } catch { }
try { Add-Type -AssemblyName WindowsBase -ErrorAction SilentlyContinue } catch { }

. (Join-Path $base 'brain\cinema.ps1')
. (Join-Path $base 'brain\cinema_ai.ps1')
. (Join-Path $base 'brain\cinema_ffmpeg.ps1')

function Send-CineUI {
    param([string]$Tipo, $Dati)
    try { $sync.UiQueue.Enqueue(@{ Type = $Tipo; Data = $Dati }) } catch { }
}

function Get-CineNomeBase {
    param([string]$Percorso)
    $b = [System.IO.Path]::GetFileNameWithoutExtension($Percorso)
    $b = ($b -replace '[^\w\-]+', '_')
    if ($b.Length -gt 36) { $b = $b.Substring(0, 36) }
    return $b
}

function Invoke-LavoroOffline {
    param($job)

    $r = Invoke-CinemaAnima `
        -Sorgente ([string]$job.sorgente) `
        -CartellaUscita ([string]$job.cartella) `
        -Preset ([string]$job.preset) `
        -LatoMax ([int]$job.latormax) `
        -Secondi ([double]$job.secondi) `
        -Notifica { param($i, $n) Send-CineUI 'cine' @{ fase = 'frame'; i = $i; n = $n } } `
        -Annulla { [bool]$sync.CineStop }

    Send-CineUI 'cine' @{
        fase      = 'fine'
        motore    = 'offline'
        file      = $r.file
        preset    = $r.preset
        frames    = $r.frames
        larghezza = $r.larghezza
        altezza   = $r.altezza
        ms        = $r.ms
        byte      = $r.byte
    }
}

function Invoke-LavoroAI {
    param($job)

    $sorgente = [string]$job.sorgente
    $cartella = [string]$job.cartella
    $baseNome = Get-CineNomeBase $sorgente
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'

    if (-not (Test-Path $cartella)) { New-Item -ItemType Directory -Path $cartella -Force | Out-Null }
    $mp4 = Join-Path $cartella ($baseNome + '_' + [string]$job.movimento + '_' + $stamp + '.mp4')
    $gif = Join-Path $cartella ($baseNome + '_' + [string]$job.movimento + '_' + $stamp + '.gif')

    $notifica = {
        param($fase, $messaggio)
        Send-CineUI 'cine' @{ fase = 'ai'; passo = $fase; messaggio = $messaggio }
    }

    $video = Invoke-CinemaAiVideo `
        -sync $sync `
        -Sorgente $sorgente `
        -UscitaMp4 $mp4 `
        -Movimento ([string]$job.movimento) `
        -Extra ([string]$job.extra) `
        -Rapporto ([string]$job.rapporto) `
        -Risoluzione ([string]$job.risoluzione) `
        -Notifica $notifica `
        -Annulla { [bool]$sync.CineStop }

    Send-CineUI 'cine' @{ fase = 'ai'; passo = 'fatto'; messaggio = ('video pronto: ' + [System.IO.Path]::GetFileName($mp4)) }

    # --- da video a GIF -----------------------------------------------------
    $ff = Find-ZapFfmpeg $base
    if (-not $ff) {
        Send-CineUI 'cine' @{
            fase     = 'fine'
            motore   = 'ai'
            file     = $mp4
            video    = $mp4
            senzaGif = $true
            larghezza = 0
            altezza   = 0
            frames    = 0
            ms        = $video.ms
            byte      = $video.byte
            messaggio = 'Video pronto, ma manca ffmpeg per fare la GIF. Premi FFMPEG nella finestra per installarlo.'
        }
        return
    }

    Send-CineUI 'cine' @{ fase = 'ai'; passo = 'ffmpeg'; messaggio = 'converto in GIF (palette a 256 colori)...' }

    $lar = [int]$job.latormax
    if ($lar -le 0) { $lar = 640 }
    $sec = [double]$job.secondi
    if ($sec -le 0) { $sec = 0 }

    $conv = Convert-VideoToGif -Ffmpeg $ff -Video $mp4 -Gif $gif -Fps 20 -Larghezza $lar -Secondi $sec
    if (-not $conv.ok) {
        Send-CineUI 'cine' @{
            fase     = 'fine'
            motore   = 'ai'
            file     = $mp4
            video    = $mp4
            senzaGif = $true
            larghezza = 0
            altezza   = 0
            frames    = 0
            ms        = $video.ms
            byte      = $video.byte
            messaggio = ('Video pronto, ma la conversione non e riuscita: ' + [string]$conv.messaggio)
        }
        return
    }

    # WebP animato: piu bello e piu leggero della GIF, se il file non e enorme
    $webp = ''
    try {
        $wb = Convert-VideoToWebp -Ffmpeg $ff -Video $mp4 -Webp ([System.IO.Path]::ChangeExtension($gif, '.webp')) -Fps 24 -Larghezza $lar -Secondi $sec
        if ($wb.ok) { $webp = [System.IO.Path]::ChangeExtension($gif, '.webp') }
    } catch { }

    Send-CineUI 'cine' @{
        fase      = 'fine'
        motore    = 'ai'
        file      = $gif
        video     = $mp4
        webp      = $webp
        senzaGif  = $false
        larghezza = $lar
        altezza   = 0
        frames    = 0
        ms        = $video.ms
        byte      = $conv.byte
    }
}

while (-not $sync.Quit) {
    $job = $null
    $preso = $false
    try { $preso = $sync.CineQueue.TryDequeue([ref]$job) } catch { $preso = $false }

    if (-not ($preso -and $job)) {
        Start-Sleep -Milliseconds 120
        continue
    }

    $sync.CineStop = $false
    $tipo = 'offline'
    try { if ($job.tipo) { $tipo = [string]$job.tipo } } catch { }

    try {
        if ($tipo -eq 'ai') { Invoke-LavoroAI $job } else { Invoke-LavoroOffline $job }
    } catch {
        $msg = $_.Exception.Message
        if ($msg -eq 'ANNULLATO') {
            Send-CineUI 'cine' @{ fase = 'annullato' }
        } else {
            Send-CineUI 'cine' @{ fase = 'errore'; messaggio = $msg }
        }
    }
    $sync.CineStop = $false
}
