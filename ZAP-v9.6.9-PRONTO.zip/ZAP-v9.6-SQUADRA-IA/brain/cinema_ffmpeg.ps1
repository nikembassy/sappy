﻿# cinema_ffmpeg.ps1 -- ZAP CINEMA v8.2
# ---------------------------------------------------------------------------
#  Serve solo per la modalita' AI: il modello restituisce un VIDEO (mp4) e per
#  trasformarlo in GIF (o WebP animato) serve ffmpeg. Qui:
#    - lo cerchiamo (PATH, tools\ffmpeg, winget, percorso in config)
#    - lo installiamo con winget se manca
#    - convertiamo il video in GIF di alta qualita' (palette a 256 colori)
# ---------------------------------------------------------------------------

function Find-ZapFfmpeg {
    param([string]$Base = '')

    # 1) percorso scritto in config
    try {
        if ($sync -and $sync.Config -and $sync.Config.cinema -and $sync.Config.cinema.ffmpeg) {
            $p = [string]$sync.Config.cinema.ffmpeg
            if ($p -and (Test-Path $p)) { return $p }
        }
    } catch { }

    # 2) accanto a ZAP
    if ($Base) {
        foreach ($rel in @('tools\ffmpeg\ffmpeg.exe', 'tools\ffmpeg\bin\ffmpeg.exe', 'ffmpeg.exe')) {
            $p = Join-Path $Base $rel
            if (Test-Path $p) { return $p }
        }
    }

    # 3) nel PATH
    try {
        $c = Get-Command 'ffmpeg.exe' -ErrorAction SilentlyContinue
        if (-not $c) { $c = Get-Command 'ffmpeg' -ErrorAction SilentlyContinue }
        if ($c) { return [string]$c.Source }
    } catch { }

    # 4) installazione fatta da winget
    try {
        $radici = @()
        if ($env:LOCALAPPDATA) { $radici += (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages') }
        if ($env:ProgramFiles) { $radici += (Join-Path $env:ProgramFiles 'ffmpeg') }
        foreach ($r in $radici) {
            if (-not (Test-Path $r)) { continue }
            $trovati = @(Get-ChildItem -Path $r -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 3)
            if ($trovati.Count -gt 0) { return $trovati[0].FullName }
        }
    } catch { }

    return ''
}

function Test-ZapFfmpeg {
    param([string]$Exe)
    if (-not $Exe -or -not (Test-Path $Exe)) { return $false }
    try {
        $out = & $Exe -version 2>&1 | Select-Object -First 1
        if ([string]$out -match 'ffmpeg version') { return $true }
    } catch { }
    return $false
}

function Install-ZapFfmpeg {
    # Prova con winget (Windows 10 1809+ / Windows 11). Torna @{ok; messaggio}
    try {
        $winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue
        if (-not $winget) {
            return @{ ok = $false; messaggio = 'winget non c e su questo PC: scarica ffmpeg a mano da gyan.dev e mettilo in tools\ffmpeg\ffmpeg.exe' }
        }
        $args = @('install', '--id', 'Gyan.FFmpeg', '-e',
                  '--accept-source-agreements', '--accept-package-agreements',
                  '--disable-interactivity')
        $p = Start-Process -FilePath $winget.Source -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -eq 0) {
            return @{ ok = $true; messaggio = 'ffmpeg installato con winget.' }
        }
        return @{ ok = $false; messaggio = ('winget ha risposto con codice ' + $p.ExitCode + ': prova a installare ffmpeg a mano') }
    } catch {
        return @{ ok = $false; messaggio = ('installazione non riuscita: ' + $_.Exception.Message) }
    }
}

function Convert-VideoToGif {
    # GIF di alta qualita': palette generata dal video stesso (256 colori, dither).
    # Ritorna @{ ok; messaggio; byte }
    param(
        [string]$Ffmpeg,
        [string]$Video,
        [string]$Gif,
        [int]$Fps = 20,
        [int]$Larghezza = 640,
        [double]$Secondi = 0,
        [int]$Inizio = 0
    )

    if (-not (Test-ZapFfmpeg $Ffmpeg)) {
        return @{ ok = $false; messaggio = 'ffmpeg non disponibile' }
    }
    if (-not (Test-Path $Video)) {
        return @{ ok = $false; messaggio = ('video non trovato: ' + $Video) }
    }
    if ($Fps -lt 5) { $Fps = 5 }
    if ($Fps -gt 30) { $Fps = 30 }
    if ($Larghezza -lt 160) { $Larghezza = 160 }
    if ($Larghezza -gt 1280) { $Larghezza = 1280 }
    if ($Larghezza % 2 -ne 0) { $Larghezza = $Larghezza - 1 }

    $filtro = 'fps=' + $Fps + ',scale=' + $Larghezza + ':-1:flags=lanczos,' +
              'split[a][b];[a]palettegen=stats_mode=diff:max_colors=256[p];' +
              '[b][p]paletteuse=dither=sierra2_4a:diff_mode=rectangle'

    $argomenti = New-Object System.Collections.ArrayList
    [void]$argomenti.Add('-y')
    [void]$argomenti.Add('-hide_banner')
    [void]$argomenti.Add('-loglevel')
    [void]$argomenti.Add('error')
    if ($Inizio -gt 0) { [void]$argomenti.Add('-ss'); [void]$argomenti.Add([string]$Inizio) }
    [void]$argomenti.Add('-i'); [void]$argomenti.Add($Video)
    if ($Secondi -gt 0) { [void]$argomenti.Add('-t'); [void]$argomenti.Add([string]$Secondi) }
    [void]$argomenti.Add('-vf'); [void]$argomenti.Add($filtro)
    [void]$argomenti.Add('-loop'); [void]$argomenti.Add('0')
    [void]$argomenti.Add($Gif)

    try {
        $out = & $Ffmpeg @argomenti 2>&1
        if ((Test-Path $Gif) -and ((Get-Item $Gif).Length -gt 1024)) {
            return @{ ok = $true; messaggio = 'ok'; byte = (Get-Item $Gif).Length }
        }
        return @{ ok = $false; messaggio = ('ffmpeg non ha prodotto la GIF: ' + (($out | Out-String).Trim())) }
    } catch {
        return @{ ok = $false; messaggio = ('errore ffmpeg: ' + $_.Exception.Message) }
    }
}

function Convert-VideoToWebp {
    param([string]$Ffmpeg, [string]$Video, [string]$Webp, [int]$Fps = 24, [int]$Larghezza = 720, [double]$Secondi = 0)

    if (-not (Test-ZapFfmpeg $Ffmpeg)) { return @{ ok = $false; messaggio = 'ffmpeg non disponibile' } }
    if ($Larghezza % 2 -ne 0) { $Larghezza = $Larghezza - 1 }

    $filtro = 'fps=' + $Fps + ',scale=' + $Larghezza + ':-1:flags=lanczos'
    $argomenti = New-Object System.Collections.ArrayList
    [void]$argomenti.Add('-y')
    [void]$argomenti.Add('-hide_banner')
    [void]$argomenti.Add('-loglevel'); [void]$argomenti.Add('error')
    [void]$argomenti.Add('-i'); [void]$argomenti.Add($Video)
    if ($Secondi -gt 0) { [void]$argomenti.Add('-t'); [void]$argomenti.Add([string]$Secondi) }
    [void]$argomenti.Add('-vf'); [void]$argomenti.Add($filtro)
    [void]$argomenti.Add('-c:v'); [void]$argomenti.Add('libwebp_anim')
    [void]$argomenti.Add('-lossless'); [void]$argomenti.Add('0')
    [void]$argomenti.Add('-q:v'); [void]$argomenti.Add('80')
    [void]$argomenti.Add('-loop'); [void]$argomenti.Add('0')
    [void]$argomenti.Add($Webp)

    try {
        $out = & $Ffmpeg @argomenti 2>&1
        if ((Test-Path $Webp) -and ((Get-Item $Webp).Length -gt 1024)) {
            return @{ ok = $true; byte = (Get-Item $Webp).Length }
        }
        return @{ ok = $false; messaggio = (($out | Out-String).Trim()) }
    } catch {
        return @{ ok = $false; messaggio = $_.Exception.Message }
    }
}
