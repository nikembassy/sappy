﻿# orchestra.ps1 -- SQUADRA IA: tutte le intelligenze insieme (v9.5)
# ---------------------------------------------------------------------------
# Quando "TUTTE INSIEME" e' acceso, ogni domanda viene inviata IN PARALLELO a
# tutte le intelligenze accese e pronte (Gemini, Claude, DeepSeek, Qwen,
# Perplexity, OpenAI, DeepSeek...). Le loro risposte (bozze) tornano poi al
# COORDINATORE, che ne fonde il meglio in UNA sola risposta finale.
# Se un servizio non risponde, gli altri continuano: la squadra non si ferma.
#
# Questo file e' SOLO ASCII di proposito: Windows PowerShell 5.1 legge i .ps1
# senza BOM come ANSI e le lettere accentate diventerebbero caratteri rotti.
# ---------------------------------------------------------------------------

if (-not (Get-Command Get-ProviderRegistry -ErrorAction SilentlyContinue)) {
    try {
        $__prov = Join-Path (Split-Path -Parent $PSCommandPath) 'provider_ai.ps1'
        if (Test-Path $__prov) { . $__prov }
    } catch { }
}

# TLS 1.2 per tutti i servizi (senza questo Windows vecchio resta a TLS 1.0)
try {
    $__sp = [System.Net.ServicePointManager]
    $__sp.SecurityProtocol = ($__sp.SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12)
} catch { }

function ConvertTo-OrchestraBool {
    param($v)
    if ($null -eq $v) { return $false }
    if ($v -is [bool]) { return $v }
    $t = ([string]$v).Trim().ToLower()
    if ($t -eq 'true' -or $t -eq '1' -or $t -eq 'si' -or $t -eq 'on' -or $t -eq 'attivo') { return $true }
    return $false
}

function Get-OrchestraDefault {
    # Valori di partenza della squadra. Restano in config.json -> orchestrazione.
    return @{
        attivo          = $false
        giudice         = 'auto'
        min_modelli     = 2
        timeout_sec     = 75
        temperatura     = 0.5
        max_tok         = 900
        mostra_risposte = $true
    }
}

function Get-OrchestraConfig {
    param($sync)
    $def = Get-OrchestraDefault
    $out = @{}
    foreach ($k in @($def.Keys)) { $out[$k] = $def[$k] }
    $blk = $null
    try { $blk = $sync.Config.orchestrazione } catch { $blk = $null }
    if ($blk) {
        foreach ($k in @('attivo','giudice','min_modelli','timeout_sec','temperatura','max_tok','mostra_risposte')) {
            $v = $null
            try { $v = $blk[$k] } catch { $v = $null }
            if ($null -eq $v) {
                try { $v = $blk.$k } catch { $v = $null }
            }
            if ($null -ne $v) { $out[$k] = $v }
        }
    }
    return $out
}

function Test-OrchestraAttiva {
    param($sync)
    $c = Get-OrchestraConfig $sync
    if (-not (ConvertTo-OrchestraBool $c.attivo)) { return $false }
    # v9.6 -- Se in Impostazioni hai scelto un servizio preciso, risponde SOLO quello:
    # la squadra non si accende contro la tua scelta. Per usarla, metti AUTOMATICO
    # (o orchestrazione.rispetta_scelta = false).
    $rispetta = $true
    try { if ($sync.Config.orchestrazione.rispetta_scelta -eq $false) { $rispetta = $false } } catch { }
    if ($rispetta) {
        $mod = 'auto'
        try { if ($sync.Config.modalita_ai) { $mod = ([string]$sync.Config.modalita_ai).Trim().ToLower() } } catch { }
        if ($mod -and $mod -ne 'auto') { return $false }
    }
    return $true
}

function Set-OrchestraAttiva {
    param($sync, [bool]$On)
    try {
        if (-not $sync.Config.ContainsKey('orchestrazione') -or $null -eq $sync.Config['orchestrazione']) {
            $sync.Config['orchestrazione'] = Get-OrchestraDefault
        }
        $sync.Config['orchestrazione']['attivo'] = $On
        if (Get-Command Save-Config -ErrorAction SilentlyContinue) { Save-Config $sync }
    } catch { }
    return $On
}

function Get-Intelligenze {
    # Elenco completo dei servizi IA con il loro stato (acceso/spento, pronto/non pronto).
    param($sync, [switch]$SoloPronte, [switch]$SoloAttive)
    $out = @()
    foreach ($r in Get-ProviderRegistry) {
        $id = [string]$r.id
        $c = $null
        try { $c = Get-ProviderConfig $sync $id } catch { $c = $null }
        if (-not $c) { continue }
        $pronto = $false
        try { $pronto = Test-ProviderReady $sync $id } catch { $pronto = $false }
        $ab = $true
        try { if ($c.abilitato -eq $false) { $ab = $false } } catch { }
        if ($SoloAttive -and (-not $ab)) { continue }
        if ($SoloPronte -and (-not $pronto)) { continue }
        $out += @{
            id        = $id
            nome      = [string]$c.nome
            tipo      = [string]$c.tipo
            chiave    = [string]$c.chiave
            endpoint  = [string]$c.endpoint
            modello   = [string]$c.modello
            compiti   = @($c.compiti)
            pronto    = $pronto
            abilitato = $ab
        }
    }
    return @($out)
}

function Get-IntelligenzeAttive {
    # Chi lavora davvero adesso: acceso E pronto (chiave + modello presenti).
    param($sync)
    return @(Get-Intelligenze -sync $sync -SoloAttive -SoloPronte)
}

function Get-IntelligenzaAbilitata {
    param($sync, [string]$Id)
    foreach ($m in @(Get-Intelligenze -sync $sync)) {
        if ([string]$m.id -eq [string]$Id) { return [bool]$m.abilitato }
    }
    return $false
}

function Set-IntelligenzaAbilitata {
    param($sync, [string]$Id, [bool]$On)
    try {
        if (-not $sync.Config.provider_ai) { $sync.Config.provider_ai = Get-DefaultProviderAi }
        if ($sync.Config.provider_ai.ContainsKey([string]$Id)) {
            $sync.Config.provider_ai[[string]$Id]['abilitato'] = [bool]$On
            if (Get-Command Save-Config -ErrorAction SilentlyContinue) { Save-Config $sync }
        }
    } catch { }
    return $On
}

function Get-OrchestraConteggi {
    param($sync)
    $tot = 0; $att = 0; $pronte = 0
    foreach ($m in @(Get-Intelligenze -sync $sync)) {
        $tot++
        if ($m.abilitato) {
            $att++
            if ($m.pronto) { $pronte++ }
        }
    }
    return @{ totale = $tot; attive = $att; pronte = $pronte }
}

function Get-OrchestraErroreBreve {
    param([string]$Testo)
    $t = ([string]$Testo) -replace '\s+', ' '
    $t = $t.Trim()
    if ($t.Length -gt 160) { $t = $t.Substring(0, 160) + '...' }
    return $t
}

function New-IntelligenzaRichiesta {
    # Prepara la richiesta HTTP di UNA intelligenza. Nessuno strumento qui:
    # le bozze sono risposte di testo, gli strumenti restano al coordinatore.
    param($M, [string]$Sistema, [string]$Domanda, [double]$Temp, [int]$MaxTok)

    $tipo = ([string]$M.tipo).Trim().ToLower()
    $id = ([string]$M.id).Trim().ToLower()
    $modello = [string]$M.modello
    $uri = [string]$M.endpoint
    $headers = @{}
    $body = $null

    if ($tipo -eq 'gemini') {
        if ($uri -match '\{model\}') {
            $uri = $uri.Replace('{model}', $modello)
        } elseif (-not $uri) {
            $uri = 'https://generativelanguage.googleapis.com/v1beta/models/' + $modello + ':generateContent'
        }
        $headers['x-goog-api-key'] = [string]$M.chiave
        $body = @{
            systemInstruction = @{ parts = @(@{ text = [string]$Sistema }) }
            contents          = @(@{ role = 'user'; parts = @(@{ text = [string]$Domanda }) })
            generationConfig  = @{ temperature = $Temp; maxOutputTokens = $MaxTok }
        }
    }
    elseif ($tipo -eq 'anthropic') {
        if (-not $uri) { $uri = 'https://api.anthropic.com/v1/messages' }
        $headers['x-api-key'] = [string]$M.chiave
        $headers['anthropic-version'] = '2023-06-01'
        $body = @{
            model       = $modello
            max_tokens  = $MaxTok
            temperature = $Temp
            system      = [string]$Sistema
            messages    = @(@{ role = 'user'; content = [string]$Domanda })
        }
    }
    elseif ($id -eq 'perplexity') {
        $uri = ([string]$M.endpoint).TrimEnd('/')
        if ($uri -match '/chat/completions$') { $uri = $uri.Substring(0, $uri.Length - 17) }
        if ($uri -notmatch '/v1/(agent|responses)$') {
            if ($uri -match '/v1$') { $uri = $uri + '/agent' } else { $uri = $uri + '/v1/agent' }
        }
        $headers['Authorization'] = 'Bearer ' + [string]$M.chiave
        $body = @{
            model             = $modello
            input             = @(@{ role = 'user'; content = @(@{ type = 'input_text'; text = [string]$Domanda }) })
            instructions      = [string]$Sistema
            max_output_tokens = $MaxTok
        }
    }
    else {
        if (-not $uri) {
            if ([string]$M.base) { $uri = ([string]$M.base).TrimEnd('/') + '/chat/completions' }
        }
        if ($uri -notmatch '/chat/completions') { $uri = $uri.TrimEnd('/') + '/chat/completions' }
        if ([string]$M.chiave) { $headers['Authorization'] = 'Bearer ' + [string]$M.chiave }
        $body = @{
            model       = $modello
            temperature = $Temp
            max_tokens  = $MaxTok
            messages    = @(
                @{ role = 'system'; content = [string]$Sistema },
                @{ role = 'user';   content = [string]$Domanda }
            )
        }
    }

    # JSON costruito a mano: ConvertTo-Json di Windows PowerShell 5.1 schiaccia gli
    # array con un solo elemento (parts:[{...}] -> parts:{...}) e Gemini risponde 400.
    # ConvertTo-JsonText (in brain\llm.ps1) emette sempre gli array, su 5.1 e su 7.
    $json = ''
    if (Get-Command ConvertTo-JsonText -ErrorAction SilentlyContinue) {
        try { $json = ConvertTo-JsonText $body } catch { $json = '' }
    }
    if (-not $json) {
        try { $json = ($body | ConvertTo-Json -Depth 8 -Compress) } catch { $json = '' }
    }
    if (-not $json) { return $null }

    return @{
        id      = [string]$M.id
        nome    = [string]$M.nome
        modello = $modello
        tipo    = $tipo
        uri     = $uri
        headers = $headers
        body    = $json
    }
}

function ConvertFrom-IntelligenzaRisposta {
    # Estrae il testo dalla risposta, qualunque sia il formato del servizio.
    param([string]$Tipo, $Dati)
    if ($null -eq $Dati) { return '' }
    $t = ([string]$Tipo).Trim().ToLower()

    if ($t -eq 'gemini') {
        $testo = ''
        foreach ($cand in @($Dati.candidates)) {
            if (-not $cand) { continue }
            foreach ($p in @($cand.content.parts)) {
                if ($p -and $p.text) { $testo = $testo + [string]$p.text }
            }
            if ($testo) { break }
        }
        return $testo
    }
    if ($t -eq 'anthropic') {
        $testo = ''
        foreach ($blocco in @($Dati.content)) {
            if (-not $blocco) { continue }
            if ([string]$blocco.type -eq 'text') { $testo = $testo + [string]$blocco.text }
        }
        return $testo
    }

    # formato "Responses" (Perplexity /v1/agent)
    $output = $null
    try { $output = $Dati.output } catch { $output = $null }
    if ($output) {
        $testo = ''
        foreach ($o in @($output)) {
            if (-not $o) { continue }
            if ([string]$o.type -eq 'message') {
                foreach ($c in @($o.content)) { if ($c -and $c.text) { $testo = $testo + [string]$c.text } }
            }
        }
        if ($testo) { return $testo }
    }
    try { if ($Dati.output_text) { return [string]$Dati.output_text } } catch { }

    # formato OpenAI-compatibile
    try {
        $v = $null
        $v = $Dati.choices[0].message.content
        if ($null -ne $v) { return [string]$v }
    } catch { }
    try { return [string]$Dati.choices[0].text } catch { }
    return ''
}

function Invoke-OrchestraBozze {
    # Chiede la stessa cosa a tutti, IN PARALLELO (HttpClient: le richieste partono
    # insieme). Se il parallelo non e' disponibile, ripiega su una chiamata alla
    # volta: la squadra risponde comunque, solo piu' lentamente.
    param($sync, [string]$Domanda, [string]$Sistema, [array]$Squadra, $cfg)

    $timeout = 75
    try { $timeout = [int]$cfg.timeout_sec } catch { }
    if ($timeout -lt 20) { $timeout = 20 }
    if ($timeout -gt 300) { $timeout = 300 }

    $temp = 0.5
    try { $temp = [double]$cfg.temperatura } catch { }
    $maxTok = 900
    try { $maxTok = [int]$cfg.max_tok } catch { }
    if ($maxTok -lt 200) { $maxTok = 200 }

    $richieste = @()
    foreach ($m in @($Squadra)) {
        $r = $null
        try { $r = New-IntelligenzaRichiesta -M $m -Sistema $Sistema -Domanda $Domanda -Temp $temp -MaxTok $maxTok } catch { $r = $null }
        if ($r) { $richieste += $r }
    }
    if ($richieste.Count -eq 0) { return @() }

    $risultati = @()
    $paralleloOk = $false

    try {
        $client = New-Object System.Net.Http.HttpClient
        $client.Timeout = [TimeSpan]::FromSeconds($timeout + 5)
        $voci = @()
        foreach ($r in $richieste) {
            $req = New-Object -TypeName System.Net.Http.HttpRequestMessage -ArgumentList @([System.Net.Http.HttpMethod]::Post, [string]$r.uri)
            $req.Content = New-Object -TypeName System.Net.Http.StringContent -ArgumentList @([string]$r.body, [System.Text.Encoding]::UTF8, 'application/json')
            foreach ($hk in @($r.headers.Keys)) {
                [void]$req.Headers.TryAddWithoutValidation([string]$hk, [string]$r.headers[$hk])
            }
            [void]$req.Headers.TryAddWithoutValidation('User-Agent', 'ZAP/9.5 (squadra-ia)')
            $voci += @{ Richiesta = $r; Req = $req; Task = $client.SendAsync($req); Inizio = [DateTime]::UtcNow; Ms = 0 }
        }

        $tasks = @()
        foreach ($v in $voci) { $tasks += $v.Task }
        try { [void][System.Threading.Tasks.Task]::WaitAll([System.Threading.Tasks.Task[]]$tasks, ([int]($timeout * 1000))) } catch { }

        foreach ($v in $voci) {
            $ms = [int]([DateTime]::UtcNow - $v.Inizio).TotalMilliseconds
            $voce = @{
                id = [string]$v.Richiesta.id; nome = [string]$v.Richiesta.nome
                modello = [string]$v.Richiesta.modello; tipo = [string]$v.Richiesta.tipo
                testo = ''; errore = ''; ms = $ms
            }
            $completata = $false
            try { $completata = [bool]$v.Task.IsCompleted } catch { $completata = $false }
            if (-not $completata) {
                $voce.errore = 'nessuna risposta entro ' + $timeout + 's'
            } else {
                try {
                    $resp = $v.Task.Result
                    $codice = [int]$resp.StatusCode
                    $corpo = [string]$resp.Content.ReadAsStringAsync().Result
                    if ($codice -ge 200 -and $codice -lt 300) {
                        $dati = $null
                        try { $dati = $corpo | ConvertFrom-Json } catch { $dati = $null }
                        if ($dati) {
                            $voce.testo = ConvertFrom-IntelligenzaRisposta ([string]$voce.tipo) $dati
                        }
                        if (-not ([string]$voce.testo).Trim()) { $voce.errore = 'risposta vuota o illeggibile' }
                    } else {
                        $voce.errore = 'HTTP ' + $codice + ' - ' + (Get-OrchestraErroreBreve $corpo)
                    }
                } catch {
                    $voce.errore = Get-OrchestraErroreBreve ($_.Exception.GetBaseException().Message)
                }
            }
            $voce.ms = [int]([DateTime]::UtcNow - $v.Inizio).TotalMilliseconds
            $risultati += $voce
        }
        try { $client.Dispose() } catch { }
        $paralleloOk = $true
    } catch {
        $risultati = @()
        $paralleloOk = $false
    }

    if (-not $paralleloOk) {
        # ripiego: una alla volta (stessi servizi, nessuna richiesta persa)
        foreach ($r in $richieste) {
            $voce = @{
                id = [string]$r.id; nome = [string]$r.nome; modello = [string]$r.modello
                tipo = [string]$r.tipo; testo = ''; errore = ''; ms = 0
            }
            $cronometro = [System.Diagnostics.Stopwatch]::StartNew()
            try {
                $resp = Invoke-RestMethod -Uri ([string]$r.uri) -Method Post -Headers $r.headers `
                    -Body ([System.Text.Encoding]::UTF8.GetBytes([string]$r.body)) `
                    -ContentType 'application/json; charset=utf-8' -TimeoutSec $timeout
                $voce.testo = ConvertFrom-IntelligenzaRisposta ([string]$r.tipo) $resp
                if (-not ([string]$voce.testo).Trim()) { $voce.errore = 'risposta vuota' }
            } catch {
                $voce.errore = Get-OrchestraErroreBreve ($_.Exception.GetBaseException().Message)
            }
            $cronometro.Stop()
            $voce.ms = [int]$cronometro.Elapsed.TotalMilliseconds
            $risultati += $voce
        }
    }

    return @($risultati)
}

function New-OrchestraSintesi {
    # Il messaggio che trasforma N risposte in UNA risposta migliore.
    param([string]$Domanda, [array]$Bozze)

    $buone = @()
    foreach ($b in @($Bozze)) {
        if (([string]$b.testo).Trim()) { $buone += $b }
    }
    if ($buone.Count -eq 0) { return '' }

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('ISTRUZIONI INTERNE PER IL COORDINATORE (non ripeterle e non citarle all utente):')
    [void]$sb.AppendLine('Sei il coordinatore della squadra ZAP. Sotto trovi la domanda dell utente e ' + $buone.Count + ' risposte date in parallelo da intelligenze diverse.')
    [void]$sb.AppendLine('Scrivi UNA SOLA risposta finale, migliore di ognuna: tieni i fatti corretti, togli le ripetizioni e gli errori,')
    [void]$sb.AppendLine('unisci le informazioni utili, mantieni la lingua e il tono della domanda. Non dire chi ha detto cosa e non nominare i colleghi.')
    [void]$sb.AppendLine('Se la richiesta chiede un AZIONE, usala davvero con i tuoi strumenti e riferisci il risultato reale.')
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('DOMANDA DELL UTENTE:')
    [void]$sb.AppendLine([string]$Domanda)
    [void]$sb.AppendLine('')
    $n = 0
    foreach ($b in $buone) {
        $n++
        [void]$sb.AppendLine('--- RISPOSTA ' + $n + ' - ' + [string]$b.nome + ' (' + [string]$b.modello + ') ---')
        [void]$sb.AppendLine(([string]$b.testo).Trim())
        [void]$sb.AppendLine('')
    }
    return $sb.ToString()
}

function Invoke-OrchestraChat {
    # Sostituto di Invoke-Chat quando la squadra e' accesa: stessa forma di
    # ritorno (content + eventuali tool_calls), quindi il ciclo dell agente
    # continua a funzionare senza altre modifiche.
    param($sync, [array]$Messages, [array]$Tools)

    $cfg = Get-OrchestraConfig $sync
    $min = 2
    try { $min = [int]$cfg.min_modelli } catch { }
    if ($min -lt 2) { $min = 2 }

    $squadra = @(Get-IntelligenzeAttive $sync)
    if ($squadra.Count -lt $min) {
        # non c'e' abbastanza squadra: si comporta come prima (un solo modello)
        return (Invoke-Chat $sync $Messages $Tools)
    }

    $domanda = ''
    try { $domanda = Get-UltimoTestoUtente $Messages } catch { $domanda = '' }
    if (-not ([string]$domanda).Trim()) { return (Invoke-Chat $sync $Messages $Tools) }

    $sistema = 'Sei una delle intelligenze della squadra ZAP. Rispondi in modo diretto, preciso e completo ' +
               'alla domanda dell utente, nella sua lingua. Niente premesse, niente elenchi inutili: ' +
               'da la soluzione migliore possibile, pronta da usare.'

    try {
        $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = ('SQUADRA IA AL LAVORO (' + $squadra.Count + ' intelligenze)...') })
    } catch { }

    $inizio = [DateTime]::UtcNow
    $bozze = @()
    try {
        $bozze = @(Invoke-OrchestraBozze -sync $sync -Domanda $domanda -Sistema $sistema -Squadra $squadra -cfg $cfg)
    } catch {
        $bozze = @()
    }
    $secondi = [math]::Round(([DateTime]::UtcNow - $inizio).TotalSeconds, 1)

    $buone = @()
    foreach ($b in @($bozze)) {
        if (([string]$b.testo).Trim()) { $buone += $b }
    }

    if ((ConvertTo-OrchestraBool $cfg.mostra_risposte) -and $bozze.Count -gt 0) {
        try {
            $sync.UiQueue.Enqueue(@{ Type = 'orchestra'; Data = @{ secondi = $secondi; bozze = @($bozze) } })
        } catch { }
    }

    if ($buone.Count -eq 0) {
        # nessuno ha risposto: provo con il modello singolo, come prima
        try { $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = 'SQUADRA MUTA: provo da solo...' }) } catch { }
        return (Invoke-Chat $sync $Messages $Tools)
    }

    if ($buone.Count -eq 1) {
        $solo = $buone[0]
        return @{ role = 'assistant'; content = [string]$solo.testo }
    }

    # v9.6 -- MODALITA' ELENCO (config -> orchestrazione.giudice = "elenco").
    # Ogni intelligenza risponde per se', con il suo nome sopra: nessuna fusione,
    # nessuno scambio di identita'. Con "fonde" torna il vecchio comportamento.
    $modo = 'elenco'
    try { if ($sync.Config.orchestrazione.giudice) { $modo = ([string]$sync.Config.orchestrazione.giudice).Trim().ToLower() } } catch { }
    if ($modo -eq 'elenco' -or $modo -eq 'tutti') {
        $parti = @()
        foreach ($b in $buone) {
            $chi = ''
            try { $chi = [string]$b.nome } catch { $chi = '' }
            if (-not $chi) { try { $chi = [string]$b.id } catch { $chi = 'modello' } }
            $testo = ''
            try { $testo = [string]$b.testo } catch { $testo = '' }
            if ($testo.Length -gt 1200) { $testo = $testo.Substring(0, 1200) + '...' }
            $parti += ('--- ' + $chi + ' ---' + [Environment]::NewLine + $testo)
        }
        return @{ role = 'assistant'; content = ($parti -join ([Environment]::NewLine + [Environment]::NewLine)) }
    }

    $sintesi = New-OrchestraSintesi -Domanda $domanda -Bozze $buone
    try {
        # La sintesi prende il posto dell ULTIMO messaggio dell utente: cosi' la
        # conversazione resta alternata (utente / assistente) e Gemini e Claude non
        # si lamentano di due messaggi utente di fila.
        $messaggi = @()
        $ultimoUtente = -1
        for ($i = 0; $i -lt @($Messages).Count; $i++) {
            if ([string]$Messages[$i].role -eq 'user') { $ultimoUtente = $i }
        }
        for ($i = 0; $i -lt @($Messages).Count; $i++) {
            if ($i -eq $ultimoUtente) { $messaggi += @{ role = 'user'; content = $sintesi } }
            else { $messaggi += $Messages[$i] }
        }
        if ($ultimoUtente -lt 0) { $messaggi += @{ role = 'user'; content = $sintesi } }
        $msg = Invoke-Chat $sync $messaggi $Tools
        if ($msg -and ([string]$msg.content).Trim()) { return $msg }
        if ($msg -and $msg.tool_calls) { return $msg }
    } catch { }

    # la fusione non e' riuscita: consegno la bozza piu' completa, dichiarando la fonte
    $migliore = $buone[0]
    foreach ($b in $buone) {
        if (([string]$b.testo).Length -gt ([string]$migliore.testo).Length) { $migliore = $b }
    }
    return @{ role = 'assistant'; content = ([string]$migliore.testo) }
}

function Format-OrchestraStato {
    param($sync)
    $c = Get-OrchestraConfig $sync
    $n = Get-OrchestraConteggi $sync
    $on = ConvertTo-OrchestraBool $c.attivo
    $righe = @()
    $righe += 'SQUADRA IA - tutte le intelligenze insieme: ' + $(if ($on) { 'ACCESO' } else { 'spento' })
    $righe += ('Intelligenze accese: ' + $n.attive + ' su ' + $n.totale + '   -   pronte adesso: ' + $n.pronte)
    if ($on) {
        if ($n.pronte -ge 2) {
            $righe += 'Ogni domanda va a tutte quelle pronte, in parallelo; poi il coordinatore fonde le risposte in una sola.'
        } else {
            $righe += 'Con meno di 2 intelligenze pronte si usa il modello singolo (aggiungi una chiave o accendine un altra).'
        }
    }
    foreach ($m in @(Get-Intelligenze -sync $sync)) {
        $segno = '[ ]'
        if ($m.abilitato) { $segno = '[X]' }
        $stato = 'non pronta'
        if ($m.pronto) { $stato = 'pronta' }
        $righe += ('  ' + $segno + ' ' + [string]$m.nome + ' - ' + ([string]$m.modello) + ' - ' + $stato)
    }
    $righe += ''
    $righe += 'Comandi: /squadra on | /squadra off | /squadra stato'
    return ($righe -join [Environment]::NewLine)
}
