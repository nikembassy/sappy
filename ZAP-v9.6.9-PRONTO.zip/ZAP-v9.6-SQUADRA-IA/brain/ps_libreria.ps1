﻿# ps_libreria.ps1 -- LIBRERIA POWERSHELL di ZAP (sezione "POWERSHELL SCRIPT").
#
# Ogni script che ZAP scrive, trova sul web o riceve in chat finisce QUI, ordinato da solo:
#
#   Ezappero\powershell-script\<categoria>\<data>-<titolo>.ps1
#   Ezappero\powershell-script\indice.jsonl   (indice leggibile dalla macchina)
#   Ezappero\powershell-script\INDICE.md      (indice leggibile dall'utente)
#
# La categoria viene scelta automaticamente leggendo il codice (parole chiave), il titolo e
# la fonte. Se lo stesso script e' gia' presente (stesso hash) non viene duplicato: si annota
# solo un nuovo "uso".

$script:ZapCategorieScript = [ordered]@{
    'sistema'      = @('get-ciminstance','get-service','start-service','stop-service','eventlog','wmi','processo','process','registro','registry','set-itemproperty','windows update','defender','task scheduler','scheduledtask')
    'file'         = @('get-childitem','copy-item','move-item','new-item','test-path','get-content','set-content','rename-item','robocopy','path','cartella','file','csv','excel','zip','compress-archive','expand-archive')
    'rete'         = @('invoke-webrequest','invoke-restmethod','curl','netstat','ping','test-netconnection','dns','ipconfig','firewall','proxy','url','http')
    'email'        = @('smtp','smtpclient','send-mailmessage','mailmessage','gmail','outlook','imap','pop3','posta','email','pec')
    'documenti'    = @('fattura','busta paga','bustapaga','contratto','pdf','html','word','docx','report','relazione','stampa','print','documento','cedolino','f24')
    'web-api'      = @('json','api','token','oauth','bearer','graph','telegram','whatsapp','webhook','rest','endpoint')
    'sicurezza'    = @('securestring','credential','encrypt','decrypt','certificate','hash','acl','icacls','permessi','password','autorizzazione','audit')
    'backup'       = @('backup','copia','restore','ripristino','archivio','snapshot','versioning','sync')
    'media'        = @('ffmpeg','video','audio','immagine','image','bitmap','gif','mp4','resize','convert')
    'automazione'  = @('foreach','start-sleep','while','loop','timer','job','runspace','batch','pianifica','schedule','trigger')
    'dev'          = @('function','param','class','module','psm1','git','nuget','dotnet','python','npm','build','test')
    'database'     = @('sql','select ','insert ','update ','delete ','connection','sqlite','postgres','mysql','dataset','datatable')
}

function Get-PsLibreriaDir {
    param($sync)
    return (Join-Path (Get-EzapperoDir $sync) 'powershell-script')
}

function ConvertTo-PsSlug {
    param([string]$Testo, [int]$Max = 48)
    $t = ([string]$Testo).ToLowerInvariant()
    # Tabella costruita a runtime con i codici Unicode: nel sorgente non c'e' nemmeno
    # un carattere accentato (Windows PowerShell 5.1 legge i file senza BOM come ANSI).
    $mappa = @{}
    $coppie = @(
        @(0x00E0, 'a'), @(0x00E1, 'a'), @(0x00E2, 'a'), @(0x00E4, 'a'),
        @(0x00E8, 'e'), @(0x00E9, 'e'), @(0x00EA, 'e'), @(0x00EB, 'e'),
        @(0x00EC, 'i'), @(0x00ED, 'i'), @(0x00EE, 'i'), @(0x00EF, 'i'),
        @(0x00F2, 'o'), @(0x00F3, 'o'), @(0x00F4, 'o'), @(0x00F6, 'o'),
        @(0x00F9, 'u'), @(0x00FA, 'u'), @(0x00FB, 'u'), @(0x00FC, 'u'),
        @(0x00E7, 'c'), @(0x00F1, 'n')
    )
    foreach ($c in $coppie) { $mappa[[string][char]$c[0]] = [string]$c[1] }
    foreach ($k in $mappa.Keys) { $t = $t.Replace($k, $mappa[$k]) }
    $t = $t -replace '[^a-z0-9]+', '-'
    $t = $t.Trim('-')
    if (-not $t) { $t = 'script' }
    if ($t.Length -gt $Max) { $t = $t.Substring(0, $Max).Trim('-') }
    return $t
}

function Get-PsCategoriaScript {
    # Classifica il codice in una categoria leggendo le parole chiave. PURA (testabile).
    param([string]$Codice, [string]$Titolo = '', [string]$Fonte = '')
    $testo = (([string]$Codice) + "`n" + [string]$Titolo).ToLowerInvariant()
    $migliore = 'altro'
    $punteggioMax = 0
    foreach ($cat in $script:ZapCategorieScript.Keys) {
        $p = 0
        foreach ($kw in $script:ZapCategorieScript[$cat]) {
            if ($testo.Contains($kw)) { $p++ }
        }
        if ($p -gt $punteggioMax) { $punteggioMax = $p; $migliore = $cat }
    }
    return $migliore
}

function Get-PsTitoloAutomatico {
    # Se l'utente/il modello non da' un titolo, lo ricava dal primo commento utile.
    param([string]$Codice, [string]$Suggerito = '')
    if ($Suggerito -and $Suggerito.Trim()) { return (($Suggerito.Trim()) -replace "`r?`n", ' ') }
    foreach ($riga in ([string]$Codice) -split "`r?`n") {
        $r = $riga.Trim()
        if (-not $r) { continue }
        if ($r.StartsWith('#')) {
            $t = $r.TrimStart('#').Trim()
            if ($t.Length -ge 8) { return $t }
            continue
        }
        if ($r.Length -ge 8) {
            if ($r.Length -gt 70) { $r = $r.Substring(0, 70) }
            return $r
        }
    }
    return 'script senza titolo'
}

function Get-PsIndicePath { param($sync) return (Join-Path (Get-PsLibreriaDir $sync) 'indice.jsonl') }

function Read-PsIndice {
    param($sync)
    $p = Get-PsIndicePath $sync
    $out = New-Object System.Collections.ArrayList
    if (-not (Test-Path -LiteralPath $p)) { return @() }
    try {
        foreach ($r in [System.IO.File]::ReadAllLines($p)) {
            if (-not $r -or -not $r.Trim()) { continue }
            try { [void]$out.Add(($r | ConvertFrom-Json)) } catch { }
        }
    } catch { }
    return @($out.ToArray())
}

function Write-PsIndiceMd {
    # Riscrive INDICE.md raggruppato per categoria (e' questo che l'utente legge).
    param($sync)
    $voci = @(Read-PsIndice $sync)
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('# INDICE DELLA LIBRERIA POWERSHELL DI ZAP')
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine("Aggiornato: " + (Get-Date -Format 'dd/MM/yyyy HH:mm') + " -- script totali: " + $voci.Count)
    [void]$sb.AppendLine('')
    if ($voci.Count -eq 0) {
        [void]$sb.AppendLine('_Ancora nessuno script. Chiedi a ZAP di scriverne uno: finira'' qui da solo._')
    } else {
        $cats = @($voci | ForEach-Object { [string]$_.categoria } | Sort-Object -Unique)
        foreach ($cat in $cats) {
            [void]$sb.AppendLine('## ' + $cat.ToUpperInvariant())
            [void]$sb.AppendLine('')
            foreach ($v in @($voci | Where-Object { [string]$_.categoria -eq $cat })) {
                $usi = 1
                try { $usi = [int]$v.usi } catch { $usi = 1 }
                $tit = [string]$v.titolo
                $rel = [string]$v.file
                [void]$sb.AppendLine("- **$tit** -- ``$rel`` (fonte: $($v.fonte), usato $usi volte)")
                if ($v.descrizione) { [void]$sb.AppendLine("  - $($v.descrizione)") }
            }
            [void]$sb.AppendLine('')
        }
    }
    $p = Join-Path (Get-PsLibreriaDir $sync) 'INDICE.md'
    try {
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($p, $sb.ToString(), $enc)
    } catch { }
    return $p
}

function Save-PsScriptArchivio {
    # Salva uno script nella libreria. Restituisce il messaggio da mostrare (e un flag ok).
    param(
        $sync,
        [string]$Codice,
        [string]$Titolo = '',
        [string]$Fonte = 'chat',
        [string]$Tag = '',
        [string]$Descrizione = '',
        [bool]$Eseguito = $false
    )
    if (-not $Codice -or $Codice.Trim().Length -lt 3) {
        return @{ ok = $false; messaggio = 'Script vuoto: niente da salvare.'; file = '' }
    }
    try { [void](Initialize-Ezappero $sync) } catch { }

    $dir = Get-PsLibreriaDir $sync
    $cat = Get-PsCategoriaScript $Codice $Titolo $Fonte
    $tit = Get-PsTitoloAutomatico $Codice $Titolo
    $hash = Get-Sha256Hex $Codice

    # Gia' presente? (stesso codice) -> non duplico, annoto l'uso.
    $voci = @(Read-PsIndice $sync)
    $esistente = @($voci | Where-Object { [string]$_.hash -eq $hash }) | Select-Object -First 1
    if ($esistente) {
        $usi = 1
        try { $usi = [int]$esistente.usi + 1 } catch { $usi = 2 }
        $tutte = @($voci | ForEach-Object {
            if ([string]$_.hash -eq $hash) {
                $c = $_
                $c.usi = $usi
                $c.ultimo_uso = (Get-Date -Format 'o')
                $c
            } else { $_ }
        })
        $enc = New-Object System.Text.UTF8Encoding($false)
        $testo = ($tutte | ForEach-Object { (ConvertTo-Json -InputObject $_ -Compress -Depth 6) }) -join "`r`n"
        Set-ZapFileProtetto (Get-PsIndicePath $sync) $false
        [System.IO.File]::WriteAllText((Get-PsIndicePath $sync), $testo + "`r`n", $enc)
        Set-ZapFileProtetto (Get-PsIndicePath $sync) $true
        return @{ ok = $true; messaggio = "Script gia' in libreria (uso #$usi): $tit"; file = [string]$esistente.file }
    }

    $slug = ConvertTo-PsSlug $tit
    $catDir = Join-Path $dir $cat
    if (-not (Test-Path -LiteralPath $catDir)) { New-Item -ItemType Directory -Path $catDir -Force | Out-Null }
    $nomeFile = (Get-Date -Format 'yyyy-MM-dd-HHmm') + '-' + $slug + '.ps1'
    $full = Join-Path $catDir $nomeFile
    $i = 1
    while (Test-Path -LiteralPath $full) {
        $nomeFile = (Get-Date -Format 'yyyy-MM-dd-HHmm') + '-' + $slug + "-$i.ps1"
        $full = Join-Path $catDir $nomeFile
        $i++
    }

    $intestazione = @"
# ============================================================
# ZAP - Libreria PowerShell
# Titolo:     $tit
# Categoria:  $cat
# Fonte:      $Fonte
# Salvato:    $(Get-Date -Format 'dd/MM/yyyy HH:mm')
# Hash:       $hash
# ============================================================

"@
    try {
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($full, $intestazione + [string]$Codice, $enc)
    } catch {
        return @{ ok = $false; messaggio = ('Salvataggio non riuscito: ' + $_.Exception.Message); file = '' }
    }

    $rel = $cat + '\' + $nomeFile
    $voce = [ordered]@{
        titolo      = $tit
        categoria   = $cat
        file        = $rel
        fonte       = $Fonte
        tag         = $Tag
        descrizione = $Descrizione
        hash        = $hash
        creato      = (Get-Date -Format 'o')
        ultimo_uso  = (Get-Date -Format 'o')
        usi         = 1
        eseguito    = $Eseguito
    }
    $linea = (ConvertTo-Json -InputObject $voce -Compress -Depth 6)
    $okAppend = Write-ZapUtf8Append (Get-PsIndicePath $sync) $linea
    if ($okAppend) { Set-ZapFileProtetto (Get-PsIndicePath $sync) $true }
    [void](Write-PsIndiceMd $sync)

    # copia nello specchio (sopravvive alla cancellazione del progetto)
    $mir = Get-EzapperoMirrorDir $sync
    if ($mir) {
        try {
            $md = Join-Path $mir ('powershell-script\' + $cat)
            if (-not (Test-Path -LiteralPath $md)) { New-Item -ItemType Directory -Path $md -Force | Out-Null }
            [System.IO.File]::Copy($full, (Join-Path $md $nomeFile), $true)
        } catch { }
    }

    [void](Add-ZapLedgerEvento $sync 'script' ("Archiviato script PowerShell [$cat] $tit -> $rel (fonte: $Fonte)") 'powershell' $false)
    return @{ ok = $true; messaggio = "Archiviato in libreria: $rel (categoria: $cat)"; file = $rel }
}

function Find-PsScriptArchivio {
    # Ricerca libera: titolo, categoria, tag, descrizione e anche DENTRO il codice.
    param($sync, [string]$Query = '', [string]$Categoria = '', [int]$Max = 10)
    $voci = @(Read-PsIndice $sync)
    if ($Categoria) {
        $voci = @($voci | Where-Object { [string]$_.categoria -eq $Categoria })
    }
    if ($Query -and $Query.Trim()) {
        $parole = @($Query.ToLowerInvariant() -split '[^a-z0-9aeeiou]+' | Where-Object { $_.Length -ge 3 })
        $punti = @()
        foreach ($v in $voci) {
            $campo = (([string]$v.titolo) + ' ' + ([string]$v.categoria) + ' ' + ([string]$v.tag) + ' ' + ([string]$v.descrizione)).ToLowerInvariant()
            $corpo = ''
            try {
                $p = Join-Path (Get-PsLibreriaDir $sync) ([string]$v.file)
                if (Test-Path -LiteralPath $p) { $corpo = ([System.IO.File]::ReadAllText($p)).ToLowerInvariant() }
            } catch { }
            $s = 0
            foreach ($w in $parole) {
                if ($campo.Contains($w)) { $s += 3 }
                elseif ($corpo.Contains($w)) { $s += 1 }
            }
            if ($s -gt 0) { $punti += [pscustomobject]@{ Score = $s; Voce = $v } }
        }
        $voci = @($punti | Sort-Object -Property Score -Descending | ForEach-Object { $_.Voce })
    }
    return @($voci | Select-Object -First $Max)
}

function Format-PsScriptElenco {
    param($sync, $Voci)
    $v = @($Voci)
    if ($v.Count -eq 0) { return 'Nessuno script trovato in libreria.' }
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("Libreria PowerShell: $($v.Count) risultati")
    foreach ($x in $v) {
        $usi = 1
        try { $usi = [int]$x.usi } catch { $usi = 1 }
        $riga = "- [$($x.categoria)] $($x.titolo)  ->  $($x.file)  (usi: $usi)"
        [void]$out.Add($riga)
    }
    return ($out -join "`r`n")
}

function Get-PsLibreriaStats {
    param($sync)
    $voci = @(Read-PsIndice $sync)
    $perCat = @{}
    foreach ($v in $voci) {
        $c = [string]$v.categoria
        if (-not $perCat.ContainsKey($c)) { $perCat[$c] = 0 }
        $perCat[$c] = $perCat[$c] + 1
    }
    return @{ totale = $voci.Count; categorie = $perCat }
}
