﻿# aula.ps1 -- v9.1 KIT DIDATTICO: la lezione di pentest, pronta da proiettare.
# ---------------------------------------------------------------------------
#  Questo modulo non aggiunge potenza: aggiunge ORDINE. Serve a fare in classe
#  quello che chiedi: mostrare una vulnerabilita' sui TUOI siti, spiegare perche'
#  esiste e mostrare come si chiude. Ogni scenario ha:
#     obiettivo   -> cosa devono capire gli studenti
#     comandi     -> cosa lanciare (copia-incolla)
#     guardare    -> cosa guardare nell'output per capire che e' vera
#     difesa      -> la contromisura precisa, con il codice/header da mettere
#     tempo       -> minuti previsti
#
#  Genera anche il materiale: New-AulaKit crea la cartella aula\ con perimetro,
#  scenari, checklist, difese e una scheda da compilare per gli studenti.
# ---------------------------------------------------------------------------

function Get-AulaScenari {
    # Catalogo degli scenari. Ogni voce e' autonoma e verificabile.
    return @(
        @{
            id = 'header'
            titolo = 'Header di sicurezza mancanti'
            livello = 'base'
            tempo = 8
            obiettivo = 'Capire che il browser si difende solo se il server glielo dice.'
            comandi = @('curl -s -I https://IL-TUO-SITO', 'whatweb https://IL-TUO-SITO')
            guardare = 'Cerca Content-Security-Policy, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Strict-Transport-Security. Se mancano, sono assenti.'
            difesa = 'Aggiungi gli header lato server. Apache: Header always set X-Content-Type-Options "nosniff" (e gli altri). Nginx: add_header X-Frame-Options "DENY" always; La CSP e'' quella che conta davvero contro XSS.'
        },
        @{
            id = 'tls'
            titolo = 'TLS vecchio o cifrari deboli'
            livello = 'base'
            tempo = 10
            obiettivo = 'Vedere che un sito "con il lucchetto" puo'' comunque accettare TLS 1.0 o cifrari rotti.'
            comandi = @('testssl https://IL-TUO-SITO', 'sslscan IL-TUO-SITO:443', 'openssl s_client -connect IL-TUO-SITO:443 -tls1_1')
            guardare = 'Nell''output di testssl: righe con TLS 1.0/1.1 offerti, RC4, 3DES, SWEET32, certificato scaduto o nome non corrispondente.'
            difesa = 'Disabilita TLS 1.0 e 1.1, tieni solo 1.2 e 1.3 con cifrari AEAD. Rinnova il certificato con ACME (Let''s Encrypt) e attiva HSTS dopo aver verificato che tutto il sito sia su HTTPS.'
        },
        @{
            id = 'file-esposti'
            titolo = 'File e cartelle che non dovrebbero essere online'
            livello = 'base'
            tempo = 12
            obiettivo = 'Far capire che il 90% delle fughe di dati non e'' un exploit: e'' un file lasciato li''.'
            comandi = @('curl -s -o /dev/null -w "%{http_code}" https://IL-TUO-SITO/.git/config', 'curl -s -o /dev/null -w "%{http_code}" https://IL-TUO-SITO/.env', 'ffuf -u https://IL-TUO-SITO/FUZZ -w /usr/share/wordlists/dirb/common.txt -mc 200,301,403')
            guardare = 'Un 200 su .git/config o .env e'' una bomba: espone storia del codice o chiavi. Un 403 dice che il file c''e'' ma e'' protetto: meglio di 200, peggio di 404.'
            difesa = 'Sposta i file fuori dalla webroot. Regola nginx: location ~ /\.(git|env|htaccess) { deny all; } Rimuovi i backup (.zip, .sql, .bak) e impedisci il listing delle directory (autoindex off).'
        },
        @{
            id = 'dir-listing'
            titolo = 'Elenco delle directory attivo'
            livello = 'base'
            tempo = 5
            obiettivo = 'Vedere quanto costa poco mappare un sito mal configurato.'
            comandi = @('curl -s https://IL-TUO-SITO/uploads/ | head -40', 'gobuster dir -u https://IL-TUO-SITO -w /usr/share/wordlists/dirb/common.txt -q')
            guardare = 'Se compare "Index of /" il server elenca i file: nomi, date, dimensioni.'
            difesa = 'Apache: Options -Indexes. Nginx: autoindex off; (e'' il default, ma un include sbagliato lo riaccende).'
        },
        @{
            id = 'banner'
            titolo = 'Il server racconta la sua versione'
            livello = 'base'
            tempo = 4
            obiettivo = 'Capire che ogni informazione regalata e'' un passo avanti per chi attacca.'
            comandi = @('curl -s -I https://IL-TUO-SITO', 'nmap -sV -p 80,443 IL-TUO-SITO')
            guardare = 'Server: Apache/2.4.49, X-Powered-By: PHP/7.4, X-AspNet-Version.'
            difesa = 'Apache: ServerTokens Prod, ServerSignature Off. Nginx: server_tokens off; PHP: expose_php = Off. Aggiorna: la versione vecchia e'' il vero problema.'
        },
        @{
            id = 'cookie'
            titolo = 'Cookie di sessione senza protezioni'
            livello = 'base'
            tempo = 6
            obiettivo = 'Vedere come si ruba una sessione quando il cookie e'' scritto male.'
            comandi = @('curl -s -I https://IL-TUO-SITO/login', 'curl -s -D - -o /dev/null https://IL-TUO-SITO/ | findstr /i "set-cookie"')
            guardare = 'Set-Cookie senza HttpOnly, senza Secure, senza SameSite.'
            difesa = 'Imposta Set-Cookie: sessione=...; HttpOnly; Secure; SameSite=Lax. HttpOnly toglie il cookie a JavaScript (XSS), Secure lo toglie al traffico in chiaro, SameSite ferma il CSRF.'
        },
        @{
            id = 'xss'
            titolo = 'XSS riflesso in un parametro'
            livello = 'medio'
            tempo = 15
            obiettivo = 'Vedere il proprio codice eseguito nel browser di un altro utente.'
            comandi = @('curl -s "https://IL-TUO-SITO/cerca?q=<script>alert(1)</script>"', 'dalfox url "https://IL-TUO-SITO/cerca?q=test"')
            guardare = 'Il payload torna indietro NON codificato dentro l''HTML (o dentro un attributo). Se diventa &lt;script&gt; il sito e'' protetto.'
            difesa = 'Codifica in uscita (context-aware: HTML, attributo, JS, URL). CSP con default-src ''self'' e niente ''unsafe-inline''. Cookie HttpOnly come seconda barriera.'
        },
        @{
            id = 'sqli'
            titolo = 'SQL injection su un form di ricerca'
            livello = 'medio'
            tempo = 18
            obiettivo = 'Far vedere che un apice puo'' cambiare il significato di una query.'
            comandi = @('curl -s "https://IL-TUO-SITO/prodotto?id=1%27"', 'sqlmap -u "https://IL-TUO-SITO/prodotto?id=1" --batch --level 1 --risk 1')
            guardare = 'Errore SQL nell''HTML (MySQL, PostgreSQL...), oppure tempi di risposta diversi con SLEEP. Con sqlmap: "parameter id is vulnerable".'
            difesa = 'Query parametrizzate (prepared statement) SEMPRE, mai concatenazione. Utente DB con permessi minimi (SELECT, niente DROP). WAF solo come rete di sicurezza, non come soluzione.'
        },
        @{
            id = 'auth'
            titolo = 'Login senza limite di tentativi'
            livello = 'medio'
            tempo = 12
            obiettivo = 'Capire la differenza tra password debole e assenza di rate limit.'
            comandi = @('hydra -l admin -P /usr/share/wordlists/rockyou.txt -t 4 IL-TUO-SITO http-post-form "/login:utente=^USER^&password=^PASS^:F=Accesso negato"')
            guardare = 'Quanti tentativi al secondo passano prima di un blocco. Se ne passano migliaia, non c''e'' rate limit.'
            difesa = 'Rate limit per IP e per utente, blocco progressivo, MFA per gli account amministrativi, password hashate con Argon2id o bcrypt (mai MD5/SHA1).'
        },
        @{
            id = 'idor'
            titolo = 'IDOR: cambio l''id e vedo i dati di un altro'
            livello = 'medio'
            tempo = 10
            obiettivo = 'Capire che "autenticato" non vuol dire "autorizzato".'
            comandi = @('curl -s -b cookie.txt https://IL-TUO-SITO/api/fattura/1001', 'curl -s -b cookie.txt https://IL-TUO-SITO/api/fattura/1002')
            guardare = 'Con lo stesso cookie di Mario, la fattura 1002 (di Luca) si apre. Quello e'' un IDOR.'
            difesa = 'Autorizzazione a ogni richiesta: l''oggetto deve essere filtrato per proprietario nella query (WHERE id=? AND utente_id=?). Non fidarti mai dell''id che arriva dal client.'
        },
        @{
            id = 'cors'
            titolo = 'CORS permissivo'
            livello = 'medio'
            tempo = 8
            obiettivo = 'Vedere un''altra origine leggere le risposte delle API.'
            comandi = @('curl -s -H "Origin: https://sito-attaccante.example" -D - -o /dev/null https://IL-TUO-SITO/api/profilo')
            guardare = 'Access-Control-Allow-Origin: * oppure l''origine riflessa, insieme a Access-Control-Allow-Credentials: true.'
            difesa = 'Lista bianca esplicita delle origini. Mai * con le credenziali. Preflight coerente e metodi minimi.'
        },
        @{
            id = 'api-auth'
            titolo = 'API che risponde senza autenticazione'
            livello = 'medio'
            tempo = 8
            obiettivo = 'Far vedere che le API "interne" spesso sono pubbliche.'
            comandi = @('curl -s https://IL-TUO-SITO/api/utenti', 'curl -s https://IL-TUO-SITO/api/config')
            guardare = 'JSON completo senza token, oppure 200 con dati anche togliendo il cookie.'
            difesa = 'Autenticazione obbligatoria a livello di endpoint (non solo nel frontend), token con scadenza breve, risposte minime (non restituire campi che non servono).'
        },
        @{
            id = 'upload'
            titolo = 'Upload di file senza controlli'
            livello = 'avanzato'
            tempo = 20
            obiettivo = 'Capire perche'' un upload e'' di fatto esecuzione di codice.'
            comandi = @('curl -s -F "file=@test.php" https://IL-TUO-SITO/upload', 'curl -s -F "file=@test.php;type=image/png" https://IL-TUO-SITO/upload')
            guardare = 'Il file viene accettato anche con estensione .php o con content-type falsificato, e poi raggiungibile via URL.'
            difesa = 'Controlla estensione E content-type E magic bytes, rinomina il file con un nome casuale, salvalo FUORI dalla webroot, servilo con header Content-Disposition: attachment.'
        },
        @{
            id = 'dopo'
            titolo = 'Dopo: cosa resta acceso'
            livello = 'base'
            tempo = 6
            obiettivo = 'Chiudere la lezione sul controllo: chi ha fatto cosa, e come lo dimostro.'
            comandi = @('/audit', '/ghost stato', '/agenti')
            guardare = 'La scatola nera (Ezappero) con data, ora, comando e bersaglio; la cabina con lo stato degli agenti.'
            difesa = 'Log delle azioni, inventario degli asset, piano di patch. La sicurezza e'' un processo misurabile, non un prodotto.'
        }
    )
}

function Get-AulaChecklist {
    # Copertura: le categorie che un pentest web completo deve toccare.
    # Serve a rispondere a "ogni tipo di pentesting": qui vedi cosa manca.
    return @(
        @{ categoria = 'Ricognizione passiva'; prova = 'DNS, whois, sottodomini, email, tecnologie'; strumenti = 'whois, dig, subfinder, theHarvester, whatweb'; fase = 'ricognizione'; difesa = 'Riduci l''esposizione: DNS minimi, niente record di test, sottodomini dismessi chiusi.' }
        @{ categoria = 'Scansione porte e servizi'; prova = 'Cosa e'' raggiungibile da fuori'; strumenti = 'nmap -sV, nmap --top-ports, rustscan'; fase = 'scansione'; difesa = 'Chiudi le porte che non servono, sposta i pannelli admin su VPN, aggiorna i servizi esposti.' }
        @{ categoria = 'Configurazione web'; prova = 'Header, banner, directory listing, metodi HTTP'; strumenti = 'curl -I, whatweb, nikto, gobuster'; fase = 'web'; difesa = 'Header di sicurezza, ServerTokens Off, -Indexes, metodi solo quelli necessari.' }
        @{ categoria = 'TLS e certificati'; prova = 'Versioni, cifrari, catena, scadenza'; strumenti = 'testssl, sslscan, openssl s_client'; fase = 'tls'; difesa = 'TLS 1.2/1.3, cifrari AEAD, HSTS, rinnovo automatico del certificato.' }
        @{ categoria = 'File e backup esposti'; prova = '.git, .env, .sql, .bak, .zip'; strumenti = 'ffuf, feroxbuster, curl'; fase = 'web'; difesa = 'Niente file di sviluppo online, deny esplicito, backup fuori dalla webroot.' }
        @{ categoria = 'Injection (SQL, comandi, template)'; prova = 'Parametri che finiscono in query o shell'; strumenti = 'sqlmap, commix, tplmap'; fase = 'verifica'; difesa = 'Query parametrizzate, niente shell costruita da input, sandboxing.' }
        @{ categoria = 'XSS e contenuti attivi'; prova = 'Payload riflessi, stored, DOM'; strumenti = 'dalfox, xsstrike, ZAP'; fase = 'verifica'; difesa = 'Encoding in uscita, CSP rigorosa, niente innerHTML con dati utente.' }
        @{ categoria = 'Autenticazione e sessioni'; prova = 'Rate limit, password deboli, cookie, logout'; strumenti = 'hydra, curl, ZAP'; fase = 'verifica'; difesa = 'MFA, lockout, Argon2id, cookie HttpOnly+Secure+SameSite, invalidazione vera al logout.' }
        @{ categoria = 'Autorizzazione (IDOR, ruoli)'; prova = 'Oggetti altrui raggiungibili cambiando id'; strumenti = 'curl, ZAP, Postman'; fase = 'verifica'; difesa = 'Controllo di proprieta'' su ogni query, test automatici sui ruoli.' }
        @{ categoria = 'API e token'; prova = 'Endpoint senza auth, JWT non verificato, CORS'; strumenti = 'curl, jwt_tool, arjun, ZAP'; fase = 'verifica'; difesa = 'Auth per endpoint, firma JWT verificata, scadenza breve, CORS a lista bianca.' }
        @{ categoria = 'Upload e path traversal'; prova = 'File eseguibili, ../ nei percorsi'; strumenti = 'curl, ffuf'; fase = 'verifica'; difesa = 'Validazione doppia, rename, storage fuori webroot, canonicalizzazione dei path.' }
        @{ categoria = 'Componenti e CVE note'; prova = 'Versioni vulnerabili di CMS, plugin, librerie'; strumenti = 'nuclei, wpscan, searchsploit, whatweb'; fase = 'web'; difesa = 'Inventario delle dipendenze, update periodici, rimozione dei plugin non usati.' }
        @{ categoria = 'Infrastruttura e rete interna'; prova = 'SMB, SNMP, credenziali di default (solo lab)'; strumenti = 'nxc, enum4linux-ng, snmpwalk'; fase = 'scansione'; difesa = 'Segmentazione, disabilitare SMBv1, SNMPv3, niente credenziali di default.' }
        @{ categoria = 'Difesa attiva'; prova = 'WAF, rate limit, monitoraggio'; strumenti = 'wafw00f, curl ripetuto, log del server'; fase = 'web'; difesa = 'WAF configurato, rate limit, alert su errori 4xx/5xx e picchi.' }
    )
}

function Format-AulaScenari {
    param($Scenari = $null)
    if ($null -eq $Scenari) { $Scenari = Get-AulaScenari }
    $righe = New-Object System.Collections.ArrayList
    $n = 0
    foreach ($s in $Scenari) {
        $n++
        [void]$righe.Add(('[' + $n.ToString('00') + '] ' + $s.titolo + '  (' + $s.livello + ', ~' + $s.tempo + ' min)'))
        [void]$righe.Add('     obiettivo: ' + $s.obiettivo)
        foreach ($c in @($s.comandi)) { [void]$righe.Add('     comando  : ' + $c) }
        [void]$righe.Add('     guarda   : ' + $s.guardare)
        [void]$righe.Add('     difesa   : ' + $s.difesa)
        [void]$righe.Add('')
    }
    return ($righe -join "`n")
}

function Format-AulaChecklist {
    param($Voci = $null)
    if ($null -eq $Voci) { $Voci = Get-AulaChecklist }
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('COPERTURA DEL TEST (cosa e'' stato provato e cosa no)')
    foreach ($v in $Voci) {
        [void]$righe.Add('  [ ] ' + ([string]$v.categoria).PadRight(38) + ' fase: ' + ([string]$v.fase).PadRight(13) + ' strumenti: ' + $v.strumenti)
    }
    return ($righe -join "`n")
}

function New-AulaKit {
    # Scrive il materiale della lezione in <base>\aula\*. Non tocca nulla di esistente
    # (se i file ci sono, aggiunge un numero progressivo alla cartella).
    param($sync, [string]$Cartella = '')
    try {
        $b = ''
        try { $b = [string]$sync.Base } catch { $b = '' }
        if (-not $b) { $b = (Get-Location).Path }
        if (-not $Cartella) {
            $radice = Join-Path $b 'aula'
            $stamp = Get-Date -Format 'yyyyMMdd-HHmm'
            $Cartella = Join-Path $radice $stamp
            $i = 1
            while (Test-Path -LiteralPath $Cartella) { $Cartella = Join-Path $radice ($stamp + '-' + $i); $i++ }
        }
        New-Item -ItemType Directory -Path $Cartella -Force | Out-Null
        $enc = New-Object System.Text.UTF8Encoding($false)

        # 0) perimetro
        $ambiti = @()
        try { $ambiti = @(Get-GhostAmbiti $sync) } catch { }
        $p = New-Object System.Collections.ArrayList
        [void]$p.Add('# PERIMETRO DELLA LEZIONE - un bersaglio per riga')
        [void]$p.Add('# Sono i TUOI siti. Aggiungili in ZAP con: /ghost perimetro-file')
        [void]$p.Add('# Esempi: miosito.it   *.miosito.it   192.168.1.0/24   lab.local')
        foreach ($a in $ambiti) { [void]$p.Add([string]$a) }
        [System.IO.File]::WriteAllText((Join-Path $Cartella '00-PERIMETRO.txt'), ($p -join "`r`n"), $enc)

        # 1) scenari
        $s = New-Object System.Collections.ArrayList
        [void]$s.Add('# SCENARI DELLA LEZIONE')
        [void]$s.Add('')
        [void]$s.Add('Sostituisci IL-TUO-SITO con il tuo dominio o il tuo IP di laboratorio.')
        [void]$s.Add('Ogni scenario: cosa mostri, cosa guardano gli studenti, come si chiude.')
        [void]$s.Add('')
        [void]$s.Add((Format-AulaScenari))
        [System.IO.File]::WriteAllText((Join-Path $Cartella '01-SCENARI.md'), ($s -join "`r`n"), $enc)

        # 2) checklist
        $c = New-Object System.Collections.ArrayList
        [void]$c.Add('# CHECKLIST DI COPERTURA')
        [void]$c.Add('')
        [void]$c.Add('Spunta mentre procedi: alla fine sai esattamente cosa hai provato e cosa resta.')
        [void]$c.Add('')
        [void]$c.Add((Format-AulaChecklist))
        [System.IO.File]::WriteAllText((Join-Path $Cartella '02-CHECKLIST.md'), ($c -join "`r`n"), $enc)

        # 3) difese
        $d = New-Object System.Collections.ArrayList
        [void]$d.Add('# DIFESE - una riga per vulnerabilita')
        [void]$d.Add('')
        [void]$d.Add('Questa e la parte che serve davvero: la stessa vulnerabilita con la sua contromisura.')
        [void]$d.Add('')
        foreach ($sc in (Get-AulaScenari)) {
            [void]$d.Add('## ' + $sc.titolo)
            [void]$d.Add('- **Rischio**: ' + $sc.guardare)
            [void]$d.Add('- **Difesa**: ' + $sc.difesa)
            [void]$d.Add('')
        }
        [System.IO.File]::WriteAllText((Join-Path $Cartella '03-DIFESE.md'), ($d -join "`r`n"), $enc)

        # 4) scheda studenti
        $q = New-Object System.Collections.ArrayList
        [void]$q.Add('# SCHEDA STUDENTE')
        [void]$q.Add('')
        [void]$q.Add('Compila mentre osservi la dimostrazione.')
        [void]$q.Add('')
        foreach ($sc in (Get-AulaScenari)) {
            [void]$q.Add('## ' + $sc.titolo)
            [void]$q.Add('1. Cosa ho visto (output o comportamento):')
            [void]$q.Add('   ____________________________________________________________')
            [void]$q.Add('2. Perche succede (in una frase):')
            [void]$q.Add('   ____________________________________________________________')
            [void]$q.Add('3. Come lo chiudo:')
            [void]$q.Add('   ____________________________________________________________')
            [void]$q.Add('')
        }
        [System.IO.File]::WriteAllText((Join-Path $Cartella '04-SCHEDA-STUDENTE.md'), ($q -join "`r`n"), $enc)

        # 5) copia del perimetro nella cartella del progetto (comoda per /ghost perimetro-file)
        try {
            $pf = Join-Path $b 'perimetro.txt'
            if (-not (Test-Path -LiteralPath $pf)) {
                [System.IO.File]::WriteAllText($pf, ($p -join "`r`n"), $enc)
            }
        } catch { }

        return ('Kit della lezione creato in:' + "`r`n  " + $Cartella + "`r`n" +
                'File: 00-PERIMETRO.txt, 01-SCENARI.md, 02-CHECKLIST.md, 03-DIFESE.md, 04-SCHEDA-STUDENTE.md')
    } catch {
        return ('Non ho potuto creare il kit: ' + $_.Exception.Message)
    }
}

function Format-AulaInfo {
    param($sync)
    $scene = @(Get-AulaScenari)
    $voci = @(Get-AulaChecklist)
    $min = 0
    foreach ($s in $scene) { $min += [int]$s.tempo }
    $righe = @()
    $righe += 'KIT DIDATTICO (aula)'
    $righe += ('  scenari pronti    : ' + $scene.Count + '  (~' + $min + ' minuti in totale)')
    $righe += ('  categorie coperte : ' + $voci.Count)
    $righe += '  comandi: /aula elenco | /aula kit | /aula checklist | /aula difese'
    return ($righe -join "`n")
}
