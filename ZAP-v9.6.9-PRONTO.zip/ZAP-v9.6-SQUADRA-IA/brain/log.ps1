﻿# log.ps1 -- Log leggibili e SENZA SEGRETI (richiesta esplicita: "log leggibili senza segreti").
# Ogni riga scritta passa da Protect-LogText; i file gia' scritti possono essere ripuliti
# con Protect-LogFile / Protect-TuttiILog.

function Protect-LogText {
    param([string]$Text)
    if (-not $Text) { return '' }
    $t = $Text
    # chiavi Google AI Studio: formato nuovo "AQ.xxxx" e classico "AIza..."
    $t = [regex]::Replace($t, 'AQ\.[A-Za-z0-9_\-]{10,}', 'AQ.***RIMOSSA***')
    $t = [regex]::Replace($t, 'AIza[0-9A-Za-z_\-]{20,}', 'AIza***RIMOSSA***')
    # v6: prefissi degli altri servizi IA (OpenAI, Groq, xAI, Perplexity, Cerebras, Fireworks, HuggingFace)
    $t = [regex]::Replace($t, 'sk-[A-Za-z0-9_\-]{16,}', 'sk-***RIMOSSA***')
    $t = [regex]::Replace($t, 'gsk_[A-Za-z0-9]{16,}', 'gsk_***RIMOSSA***')
    $t = [regex]::Replace($t, 'xai-[A-Za-z0-9]{16,}', 'xai-***RIMOSSA***')
    $t = [regex]::Replace($t, 'pplx-[A-Za-z0-9]{16,}', 'pplx-***RIMOSSA***')
    $t = [regex]::Replace($t, 'csk-[A-Za-z0-9]{16,}', 'csk-***RIMOSSA***')
    $t = [regex]::Replace($t, 'fw_[A-Za-z0-9]{16,}', 'fw_***RIMOSSA***')
    $t = [regex]::Replace($t, 'hf_[A-Za-z0-9]{16,}', 'hf_***RIMOSSA***')
    # e la parola "chiave = ..." / "chiave: ..." in chiaro
    $t = [regex]::Replace($t, '(?i)\bchiave\s*[:=]\s*([^\s"'',;}{]{6,})', 'chiave=***RIMOSSA***')
    # coppie chiave=valore / "chiave": "valore"
    # NB: la regola del Bearer va PRIMA di quella generica, altrimenti la generica
    # consuma la parola "Bearer" e lascia il token in chiaro.
    $t = [regex]::Replace($t, '(?i)bearer\s+[A-Za-z0-9\._\-]{12,}', 'Bearer ***RIMOSSA***')
    $t = [regex]::Replace($t, '(?i)("?(?:api[_-]?key|apikey|x-goog-api-key|authorization)"?\s*[:=]\s*)(["'']?)([^\s"'',;}{]{6,})', '$1***RIMOSSA***')
    $t = [regex]::Replace($t, '(?i)[?&]key=[A-Za-z0-9\._\-]{12,}', '?key=***RIMOSSA***')
    return $t
}

function Test-ContieneSegreti {
    # Usata dai test: dice se un testo contiene ancora qualcosa che sembra una chiave.
    param([string]$Text)
    if (-not $Text) { return $false }
    return [bool]([regex]::IsMatch($Text, 'AQ\.[A-Za-z0-9_\-]{10,}|AIza[0-9A-Za-z_\-]{20,}|sk-[A-Za-z0-9_\-]{16,}|gsk_[A-Za-z0-9]{16,}|xai-[A-Za-z0-9]{16,}|pplx-[A-Za-z0-9]{16,}|csk-[A-Za-z0-9]{16,}|fw_[A-Za-z0-9]{16,}|hf_[A-Za-z0-9]{16,}'))
}

function Protect-LogFile {
    param([string]$Path)
    if (-not $Path -or -not (Test-Path $Path)) { return $false }
    try {
        $raw = Get-Content -Path $Path -Raw -Encoding UTF8
        if ($null -eq $raw -or $raw -eq '') { return $false }
        $clean = Protect-LogText $raw
        if ($clean -ne $raw) { Set-Content -Path $Path -Value $clean -Encoding UTF8; return $true }
        return $false
    } catch { return $false }
}

function Add-LogLine {
    param([string]$Path, [string]$Text)
    $riga = (Get-Date -Format 'o') + '  ' + (Protect-LogText $Text)
    if (Add-FileLineSafe $Path $riga) { return }
    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path $dir)) { [void][System.IO.Directory]::CreateDirectory($dir) }
        Add-Content -Path $Path -Value $riga -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch { }
}

function Protect-TuttiILog {
    param([string]$Base)
    $n = 0
    $dir = Join-Path $Base 'logs'
    if (-not (Test-Path $dir)) { return 0 }
    foreach ($f in @(Get-ChildItem -Path $dir -File -ErrorAction SilentlyContinue)) {
        if (Protect-LogFile $f.FullName) { $n++ }
    }
    return $n
}

# ---------------------------------------------------------------------------
# v8: SCRITTURA SICURA dei file di log
# L'errore "Il processo non puo accedere al file ... perche e in uso da un
# altro processo" nasce quando antivirus, OneDrive o un'altra istanza di ZAP
# tengono aperto il file per un istante: Add-Content apre il file in modo
# esclusivo e fallisce. Qui si apre in CONDIVISIONE, si riprova e, se serve,
# si scrive su un file alternativo. L'avvio non deve mai mostrare errori.
# ---------------------------------------------------------------------------

function Add-FileLineSafe {
    param(
        [string]$Path,
        [string]$Text,
        [int]$Tentativi = 6,
        [int]$AttesaMs = 60,
        [long]$RuotaByte = 3000000
    )

    if (-not $Path) { return $false }

    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path $dir)) { [void][System.IO.Directory]::CreateDirectory($dir) }
    } catch { }

    # se il log e' enorme lo ruota (senza mai bloccare l'avvio)
    try {
        if ($RuotaByte -gt 0 -and (Test-Path $Path)) {
            $info = New-Object System.IO.FileInfo($Path)
            if ($info.Length -gt $RuotaByte) {
                $vecchio = $Path + '.1'
                try { if (Test-Path $vecchio) { [System.IO.File]::Delete($vecchio) } } catch { }
                try { [System.IO.File]::Move($Path, $vecchio) } catch { }
            }
        }
    } catch { }

    if ($Tentativi -lt 1) { $Tentativi = 1 }
    $cond = [System.IO.FileShare]([int][System.IO.FileShare]::ReadWrite -bor [int][System.IO.FileShare]::Delete)

    for ($i = 0; $i -lt $Tentativi; $i++) {
        $fs = $null
        $sw = $null
        try {
            $fs = [System.IO.FileStream]::new($Path, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, $cond, 4096, [System.IO.FileOptions]::None)
            $sw = [System.IO.StreamWriter]::new($fs, (New-Object System.Text.UTF8Encoding($false)))
            $sw.WriteLine([string]$Text)
            $sw.Flush()
            $sw.Dispose()
            $sw = $null
            $fs = $null
            return $true
        } catch {
            if ($sw) { try { $sw.Dispose() } catch { } }
            if ($fs) { try { $fs.Dispose() } catch { } }
            Start-Sleep -Milliseconds ([int]($AttesaMs * ($i + 1)))
        }
    }
    return $false
}
