﻿# intelligenze_ui.ps1 -- pannello INTELLIGENZE sulla sinistra (v9.5)
# ---------------------------------------------------------------------------
#  Sotto la foto dell'avatar ora ci sono DUE linguette:
#     INTELLIGENZE  -> le IA con il loro interruttore (accesa / spenta)
#     SQUADRA       -> gli agenti di sempre (invariati)
#  In cima c'e' l'interruttore generale "TUTTE INSIEME": quando e' acceso ogni
#  domanda va a tutte le intelligenze accese, in parallelo, e le risposte
#  vengono fuse in una sola.
#  File solo ASCII: Windows PowerShell 5.1 legge i .ps1 senza BOM come ANSI.
# ---------------------------------------------------------------------------

$script:ZapIiWindow   = $null
$script:ZapIiSync     = $null
$script:ZapIiLista    = $null
$script:ZapIiConteggio = $null
$script:ZapOrchestraPill = $null
$script:ZapOrchestraStato = $null
$script:ZapOrchestraInfo = $null
$script:ZapOrchestraBox = $null
$script:ZapTabIA      = $null
$script:ZapTabSquadra = $null
$script:ZapTabCorrente = 'ia'

function Format-SecondiOrchestra {
    param($Secondi)
    $s = 0.0
    try { $s = [double]$Secondi } catch { $s = 0.0 }
    if ($s -lt 0) { $s = 0 }
    if ($s -lt 10) { return ([math]::Round($s, 1)).ToString() + 's' }
    return ([math]::Round($s, 0)).ToString() + 's'
}

function Get-IntelligenzaSegno {
    param([string]$Id, [string]$Nome)
    switch (([string]$Id).ToLower()) {
        'gemini'     { return 'G' }
        'anthropic'  { return 'C' }
        'openai'     { return 'O' }
        'deepseek'   { return 'D' }
        'qwen'       { return 'Q' }
        'perplexity' { return 'P' }
        'openrouter' { return 'R' }
        'groq'       { return 'K' }
        'mistral'    { return 'M' }
        'xai'        { return 'X' }
        'together'   { return 'T' }
        'cerebras'   { return 'B' }
        'fireworks'  { return 'F' }
    }
    $n = [string]$Nome
    if ($n.Length -gt 0) { return $n.Substring(0, 1).ToUpper() }
    return '#'
}

function New-IntelligenzaRiga {
    # Una riga del pannello: segno, nome, modello, interruttore ON/OFF.
    param($M, [bool]$Attivo)

    $pronta = [bool]$M.pronto
    $bd = New-Object System.Windows.Controls.Border
    $bd.CornerRadius = '9'
    $bd.Padding = '7,4,7,4'
    $bd.Margin = '0,0,0,4'
    $bd.Cursor = 'Hand'
    $bd.Tag = [string]$M.id

    if ($Attivo) {
        $bd.Background = '#171C24'
        if ($pronta) { $bd.BorderBrush = '#7EEBAE' } else { $bd.BorderBrush = '#C9A227' }
        $bd.BorderThickness = '1'
        $bd.Opacity = 1.0
    } else {
        $bd.Background = '#101419'
        $bd.BorderBrush = '#252C36'
        $bd.BorderThickness = '1'
        $bd.Opacity = 0.5
    }

    $stato = 'pronta'
    if (-not $pronta) { $stato = 'manca chiave o modello' }
    $bd.ToolTip = ([string]$M.nome + ' - ' + [string]$M.modello + "`n" + 'Lavori: ' + (@($M.compiti) -join ', ') + "`n" + 'Stato: ' + $stato + "`n`nClic per accendere o spegnere questa intelligenza.")

    $g = New-Object System.Windows.Controls.Grid
    foreach ($w in @('Auto', '*', 'Auto')) {
        $c = New-Object System.Windows.Controls.ColumnDefinition
        $c.Width = $w
        [void]$g.ColumnDefinitions.Add($c)
    }

    $badge = New-Object System.Windows.Controls.Border
    $badge.Width = '20'; $badge.Height = '20'
    $badge.CornerRadius = '6'
    $badge.Background = '#1B2430'
    $badge.BorderBrush = '#D4AF37'
    $badge.BorderThickness = '1'
    $badge.VerticalAlignment = 'Center'
    $bl = New-Object System.Windows.Controls.TextBlock
    $bl.Text = Get-IntelligenzaSegno ([string]$M.id) ([string]$M.nome)
    $bl.FontSize = 10
    $bl.FontWeight = 'Bold'
    $bl.Foreground = '#E8C86A'
    $bl.HorizontalAlignment = 'Center'
    $bl.VerticalAlignment = 'Center'
    $badge.Child = $bl
    [System.Windows.Controls.Grid]::SetColumn($badge, 0)

    $sp = New-Object System.Windows.Controls.StackPanel
    $sp.Margin = '6,0,5,0'
    $sp.VerticalAlignment = 'Center'

    $nm = New-Object System.Windows.Controls.TextBlock
    $nm.Text = [string]$M.nome
    $nm.FontSize = 11
    $nm.FontWeight = 'Bold'
    $nm.Foreground = '#E8C86A'
    $nm.TextTrimming = 'CharacterEllipsis'

    $tt = New-Object System.Windows.Controls.TextBlock
    $tt.Text = [string]$M.modello
    if (-not ([string]$M.modello).Trim()) { $tt.Text = 'modello non impostato' }
    $tt.FontSize = 9
    $tt.Foreground = '#95A0AC'
    $tt.TextTrimming = 'CharacterEllipsis'

    [void]$sp.Children.Add($nm)
    [void]$sp.Children.Add($tt)
    [System.Windows.Controls.Grid]::SetColumn($sp, 1)

    $pill = New-Object System.Windows.Controls.Border
    $pill.CornerRadius = '8'
    $pill.Padding = '6,2,6,2'
    $pill.VerticalAlignment = 'Center'
    if ($Attivo) {
        if ($pronta) { $pill.Background = '#2F6B4F' } else { $pill.Background = '#5A4A1E' }
    } else {
        $pill.Background = '#1A2028'
    }
    $pt = New-Object System.Windows.Controls.TextBlock
    $pt.FontSize = 9
    $pt.FontWeight = 'Bold'
    if ($Attivo) { $pt.Text = 'ON'; $pt.Foreground = '#EAF6F0' } else { $pt.Text = 'OFF'; $pt.Foreground = '#7C8794' }
    $pill.Child = $pt
    [System.Windows.Controls.Grid]::SetColumn($pill, 2)

    [void]$g.Children.Add($badge)
    [void]$g.Children.Add($sp)
    [void]$g.Children.Add($pill)
    $bd.Child = $g
    return $bd
}

function Update-OrchestraPill {
    $sync = $script:ZapIiSync
    if (-not $sync) { return }
    $on = $false
    $n = @{ totale = 0; attive = 0; pronte = 0 }
    try { $on = Test-OrchestraAttiva $sync } catch { $on = $false }
    try { $n = Get-OrchestraConteggi $sync } catch { }

    if ($script:ZapOrchestraPill) {
        if ($on) { $script:ZapOrchestraPill.Background = '#3DDC84' } else { $script:ZapOrchestraPill.Background = '#3A4550' }
    }
    if ($script:ZapOrchestraStato) {
        if ($on) { $script:ZapOrchestraStato.Text = 'ON'; $script:ZapOrchestraStato.Foreground = '#04120B' }
        else { $script:ZapOrchestraStato.Text = 'OFF'; $script:ZapOrchestraStato.Foreground = '#D8DEE6' }
    }
    if ($script:ZapOrchestraBox) {
        if ($on) { $script:ZapOrchestraBox.BorderBrush = '#3DDC84'; $script:ZapOrchestraBox.Background = '#143028' }
        else { $script:ZapOrchestraBox.BorderBrush = '#2A323D'; $script:ZapOrchestraBox.Background = '#12161C' }
    }
    if ($script:ZapOrchestraInfo) {
        if ($on) {
            $script:ZapOrchestraInfo.Text = ('risposta unica da ' + $n.pronte + ' intelligenze pronte')
        } else {
            $script:ZapOrchestraInfo.Text = 'una intelligenza alla volta'
        }
    }
    if ($script:ZapIiConteggio) {
        if ($script:ZapTabCorrente -eq 'ia') {
            $script:ZapIiConteggio.Text = ('attive ' + $n.attive + '/' + $n.totale)
        }
    }
}

function Update-IntelligenzePadrone {
    # Ridisegna l'elenco delle intelligenze (dopo un clic o un salvataggio).
    $sync = $script:ZapIiSync
    if (-not $script:ZapIiLista -or -not $sync) { return }
    $script:ZapIiLista.Children.Clear()
    $lista = @()
    try { $lista = @(Get-Intelligenze -sync $sync) } catch { $lista = @() }

    foreach ($m in $lista) {
        $riga = $null
        try { $riga = New-IntelligenzaRiga $m ([bool]$m.abilitato) } catch { $riga = $null }
        if (-not $riga) { continue }
        $riga.Add_MouseLeftButtonUp({
            param($mittente, $evento)
            try { Toggle-IntelligenzaSquadra ([string]$mittente.Tag) } catch { }
        })
        [void]$script:ZapIiLista.Children.Add($riga)
    }
    Update-OrchestraPill
}

function Toggle-IntelligenzaSquadra {
    param([string]$Id)
    $sync = $script:ZapIiSync
    if (-not $sync -or -not $Id) { return }
    $prima = $false
    try { $prima = Get-IntelligenzaAbilitata $sync $Id } catch { $prima = $false }
    $dopo = -not $prima
    try { [void](Set-IntelligenzaAbilitata $sync $Id $dopo) } catch { }
    # v9.6.7 -- SE ACCENDI UNA IA, PARLI CON QUELLA.
    # Prima il clic cambiava solo l'interruttore: modalita_ai restava "auto" e ZAP
    # continuava a scegliere lui (Gemini per primo). Da qui in poi la scelta e' esplicita
    # e viene scritta su config.json, cosi' resta anche dopo il riavvio.
    try {
        $attuale = [string]$sync.Config.modalita_ai
        if ($dopo) {
            $sync.Config.modalita_ai = [string]$Id
        } elseif ($attuale -and $attuale.Trim().ToLower() -eq ([string]$Id).Trim().ToLower()) {
            $sync.Config.modalita_ai = 'auto'
        }
        if (Get-Command Save-Config -ErrorAction SilentlyContinue) { Save-Config $sync }
        if (Get-Command Aggiorna-AiCombo -ErrorAction SilentlyContinue) { Aggiorna-AiCombo }
        if ($dopo -and (Get-Command Add-Bubble -ErrorAction SilentlyContinue)) {
            Add-Bubble 'zap' ('Ora parli con ' + [string]$Id + ': risponde solo questo servizio. Per tornare alla scelta automatica scrivi /ai auto.')
        }
    } catch { }
    try { Update-IntelligenzePadrone } catch { }
    try { if (Get-Command Aggiorna-AiList -ErrorAction SilentlyContinue) { Aggiorna-AiList } } catch { }
    try {
        if (Get-Command Add-Activity -ErrorAction SilentlyContinue) {
            Add-Activity ('- intelligenza ' + $Id + ': ' + $(if ($dopo) { 'ACCESA' } else { 'spenta' }) + ' -')
        }
    } catch { }
    try {
        $n = Get-OrchestraConteggi $sync
        if ($StatusText) { $StatusText.Text = ('SQUADRA IA: ' + $n.attive + ' accese, ' + $n.pronte + ' pronte') }
    } catch { }
}

function Set-TabIntelligenze {
    param([string]$Quale)
    $q = ([string]$Quale).Trim().ToLower()
    if ($q -ne 'squadra') { $q = 'ia' }
    $script:ZapTabCorrente = $q
    $lista = $script:ZapIiLista
    if ($lista) { if ($q -eq 'ia') { $lista.Visibility = 'Visible' } else { $lista.Visibility = 'Collapsed' } }
    $ag = $null
    try { $ag = $script:ZapIiWindow.FindName('AgentiLista') } catch { $ag = $null }
    if ($ag) { if ($q -eq 'ia') { $ag.Visibility = 'Collapsed' } else { $ag.Visibility = 'Visible' } }
    $cAg = $null
    try { $cAg = $script:ZapIiWindow.FindName('AgentiConteggio') } catch { $cAg = $null }
    if ($cAg) { if ($q -eq 'ia') { $cAg.Visibility = 'Collapsed' } else { $cAg.Visibility = 'Visible' } }
    if ($script:ZapIiConteggio) { if ($q -eq 'ia') { $script:ZapIiConteggio.Visibility = 'Visible' } else { $script:ZapIiConteggio.Visibility = 'Collapsed' } }
    if ($script:ZapTabIA) {
        if ($q -eq 'ia') { $script:ZapTabIA.Background = '#D4AF37'; $script:ZapTabIA.Foreground = '#1A1408' }
        else { $script:ZapTabIA.Background = '#161B22'; $script:ZapTabIA.Foreground = '#E8C86A' }
    }
    if ($script:ZapTabSquadra) {
        if ($q -eq 'squadra') { $script:ZapTabSquadra.Background = '#D4AF37'; $script:ZapTabSquadra.Foreground = '#1A1408' }
        else { $script:ZapTabSquadra.Background = '#161B22'; $script:ZapTabSquadra.Foreground = '#E8C86A' }
    }
    try { Update-OrchestraPill } catch { }
}

function Toggle-OrchestraDaUI {
    $sync = $script:ZapIiSync
    if (-not $sync) { return }
    $ora = $false
    try { $ora = Test-OrchestraAttiva $sync } catch { $ora = $false }
    $nuovo = -not $ora
    try { [void](Set-OrchestraAttiva $sync $nuovo) } catch { }
    try { Update-IntelligenzePadrone } catch { }
    try {
        if ($nuovo) {
            Add-Bubble 'zap' ('SQUADRA IA ACCESA: da adesso ogni domanda va a TUTTE le intelligenze accese, in parallelo, e le risposte vengono fuse in una sola.' + "`n`n" + (Format-OrchestraStato $sync))
        } else {
            Add-Bubble 'zap' 'SQUADRA IA SPENTA: torna a rispondere una sola intelligenza (quella scelta da ZAP in automatico).'
        }
    } catch { }
}

function Add-OrchestraBolla {
    # Riquadro compatto nella chat: chi ha risposto, in quanto tempo, con le bozze apribili.
    param($Dati)
    if (-not $ChatPanel) { return }
    $secondi = 0.0
    try { $secondi = [double]$Dati.secondi } catch { }
    $bozze = @()
    try { $bozze = @($Dati.bozze) } catch { $bozze = @() }

    $ok = 0; $ko = 0
    foreach ($x in $bozze) { if (([string]$x.testo).Trim()) { $ok++ } else { $ko++ } }

    $b = New-Object System.Windows.Controls.Border
    $b.CornerRadius = '11'
    $b.Background = '#0F1A15'
    $b.BorderBrush = '#2F6B4F'
    $b.BorderThickness = '1'
    $b.Padding = '10,7,10,7'
    $b.Margin = '12,4,80,6'
    $b.HorizontalAlignment = 'Left'
    $b.MaxWidth = 640

    $sp = New-Object System.Windows.Controls.StackPanel

    $hd = New-Object System.Windows.Controls.TextBlock
    $testoHd = 'SQUADRA IA  -  ' + $ok + ' risposte in ' + (Format-SecondiOrchestra $secondi) + '  -  fuse in una sola'
    if ($ko -gt 0) { $testoHd = $testoHd + '  (' + $ko + ' non disponibili)' }
    $hd.Text = $testoHd
    $hd.FontSize = 10
    $hd.FontWeight = 'Bold'
    $hd.Foreground = '#7EEBAE'
    $hd.TextWrapping = 'Wrap'
    [void]$sp.Children.Add($hd)

    foreach ($x in $bozze) {
        $r = New-Object System.Windows.Controls.TextBlock
        $r.FontSize = 10
        $r.TextWrapping = 'Wrap'
        $r.Margin = '0,2,0,0'
        $nome = [string]$x.nome
        $tempo = Format-SecondiOrchestra ([double]$x.ms / 1000.0)
        if (([string]$x.testo).Trim()) {
            $r.Text = ('[ok]  ' + $nome + '  ' + $tempo + '  ' + ([string]$x.testo).Length + ' caratteri')
            $r.Foreground = '#7EEBAE'
        } else {
            $err = [string]$x.errore
            if ($err.Length -gt 80) { $err = $err.Substring(0, 80) + '...' }
            $r.Text = ('[--]  ' + $nome + '  ' + $err)
            $r.Foreground = '#C98A80'
        }
        [void]$sp.Children.Add($r)
    }

    $bozzeOk = @()
    foreach ($x in $bozze) { if (([string]$x.testo).Trim()) { $bozzeOk += $x } }
    if ($bozzeOk.Count -gt 0) {
        $ex = New-Object System.Windows.Controls.Expander
        $ex.Header = 'vedi le risposte separate'
        $ex.Foreground = '#9AA4AE'
        $ex.FontSize = 10
        $ex.Margin = '0,6,0,0'
        $tb = New-Object System.Windows.Controls.TextBox
        $tb.IsReadOnly = $true
        $tb.TextWrapping = 'Wrap'
        $tb.FontSize = 11
        $tb.Background = 'Transparent'
        $tb.Foreground = '#D8DEE6'
        $tb.BorderThickness = '0'
        $tb.MaxHeight = 300
        $tb.VerticalScrollBarVisibility = 'Auto'
        $testo = ''
        foreach ($x in $bozzeOk) {
            $testo = $testo + '### ' + [string]$x.nome + ' (' + [string]$x.modello + ')' + [Environment]::NewLine + ([string]$x.testo).Trim() + [Environment]::NewLine + [Environment]::NewLine
        }
        $tb.Text = $testo
        if (Get-Command Set-TextBoxCopyMenu -ErrorAction SilentlyContinue) { Set-TextBoxCopyMenu $tb }
        $ex.Content = $tb
        [void]$sp.Children.Add($ex)
    }

    $b.Child = $sp
    [void]$ChatPanel.Children.Add($b)
    try { $ChatScroll.ScrollToEnd() } catch { }
}

function Initialize-IntelligenzePadrone {
    param($Window, $sync)

    $script:ZapIiWindow = $Window
    $script:ZapIiSync   = $sync
    $script:ZapIiLista  = $null
    try { $script:ZapIiLista = $Window.FindName('AiLista') } catch { $script:ZapIiLista = $null }
    try { $script:ZapIiConteggio = $Window.FindName('IiConteggio') } catch { $script:ZapIiConteggio = $null }
    try { $script:ZapOrchestraPill = $Window.FindName('OrchestraPill') } catch { $script:ZapOrchestraPill = $null }
    try { $script:ZapOrchestraStato = $Window.FindName('OrchestraStato') } catch { $script:ZapOrchestraStato = $null }
    try { $script:ZapOrchestraInfo = $Window.FindName('OrchestraInfo') } catch { $script:ZapOrchestraInfo = $null }
    try { $script:ZapOrchestraBox = $Window.FindName('OrchestraMaster') } catch { $script:ZapOrchestraBox = $null }
    try { $script:ZapTabIA = $Window.FindName('BtnTabIA') } catch { $script:ZapTabIA = $null }
    try { $script:ZapTabSquadra = $Window.FindName('BtnTabSquadra') } catch { $script:ZapTabSquadra = $null }

    if ($script:ZapOrchestraBox) {
        $script:ZapOrchestraBox.Add_MouseLeftButtonUp({ param($m, $e) try { Toggle-OrchestraDaUI } catch { } })
    }
    if ($script:ZapTabIA) {
        $script:ZapTabIA.Add_Click({ param($m, $e) try { Set-TabIntelligenze 'ia' } catch { } })
    }
    if ($script:ZapTabSquadra) {
        $script:ZapTabSquadra.Add_Click({ param($m, $e) try { Set-TabIntelligenze 'squadra' } catch { } })
    }

    if (-not $script:ZapIiLista) { return }
    Update-IntelligenzePadrone
    Set-TabIntelligenze 'ia'
}
