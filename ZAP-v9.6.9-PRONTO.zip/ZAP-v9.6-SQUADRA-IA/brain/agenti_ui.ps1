﻿# agenti_ui.ps1 -- pannello della SQUADRA nell'interfaccia (v8.0)
# ---------------------------------------------------------------------------
#  Costruisce, sotto la foto dell'avatar, l'elenco dei sei agenti:
#  nome dorato, ruolo, interruttore. Clic = attiva / disattiva.
#  Lo stato viene salvato in memory\agenti.json e resta al riavvio.
# ---------------------------------------------------------------------------

$script:ZapAgentiSync = $null
$script:ZapAgentiWindow = $null
$script:ZapAgentiLista = $null
$script:ZapAgentiConteggio = $null

function Get-AgentePillON {
    return '#E8C86A'
}

function New-AgenteRiga {
    param($Agente, [bool]$Attivo)

    $bd = New-Object System.Windows.Controls.Border
    $bd.CornerRadius = '9'
    $bd.Padding = '8,5,8,5'
    $bd.Margin = '0,0,0,5'
    $bd.Cursor = 'Hand'
    $bd.Tag = [string]$Agente.id
    $bd.ToolTip = ([string]$Agente.nome + ' - ' + [string]$Agente.titolo + "`n" + [string]$Agente.ruolo + "`n`nClic per accendere o spegnere.")

    if ($Attivo) {
        $bd.Background = '#171C24'
        $bd.BorderBrush = [string]$Agente.oro
        $bd.BorderThickness = '1'
        $bd.Opacity = 1.0
    } else {
        $bd.Background = '#101419'
        $bd.BorderBrush = '#252C36'
        $bd.BorderThickness = '1'
        $bd.Opacity = 0.55
    }

    $g = New-Object System.Windows.Controls.Grid
    $c0 = New-Object System.Windows.Controls.ColumnDefinition
    $c0.Width = 'Auto'
    $c1 = New-Object System.Windows.Controls.ColumnDefinition
    $c1.Width = '*'
    $c2 = New-Object System.Windows.Controls.ColumnDefinition
    $c2.Width = 'Auto'
    [void]$g.ColumnDefinitions.Add($c0)
    [void]$g.ColumnDefinitions.Add($c1)
    [void]$g.ColumnDefinitions.Add($c2)

    # simbolo dell'agente
    $gl = New-Object System.Windows.Controls.TextBlock
    $gl.Text = [string]$Agente.glifo
    $gl.FontSize = 15
    $gl.Width = 20
    $gl.VerticalAlignment = 'Center'
    $gl.TextAlignment = 'Center'
    $gl.Foreground = [string]$Agente.oro
    [System.Windows.Controls.Grid]::SetColumn($gl, 0)

    # nome + ruolo
    $sp = New-Object System.Windows.Controls.StackPanel
    $sp.Margin = '6,0,6,0'
    $sp.VerticalAlignment = 'Center'

    $nm = New-Object System.Windows.Controls.TextBlock
    $nm.Text = [string]$Agente.nome
    $nm.FontSize = 12
    $nm.FontWeight = 'Bold'
    $nm.Foreground = [string]$Agente.oro
    $nm.TextTrimming = 'CharacterEllipsis'

    $tt = New-Object System.Windows.Controls.TextBlock
    $tt.Text = [string]$Agente.titolo
    $tt.FontSize = 10
    $tt.Foreground = '#95A0AC'
    $tt.TextTrimming = 'CharacterEllipsis'

    [void]$sp.Children.Add($nm)
    [void]$sp.Children.Add($tt)
    [System.Windows.Controls.Grid]::SetColumn($sp, 1)

    # interruttore
    $pill = New-Object System.Windows.Controls.Border
    $pill.CornerRadius = '8'
    $pill.Padding = '7,2,7,2'
    $pill.VerticalAlignment = 'Center'
    $pt = New-Object System.Windows.Controls.TextBlock
    $pt.FontSize = 10
    $pt.FontWeight = 'Bold'
    if ($Attivo) {
        $pill.Background = [string]$Agente.oro
        $pt.Text = 'ON'
        $pt.Foreground = '#151007'
    } else {
        $pill.Background = '#1B2129'
        $pill.BorderBrush = '#2A323D'
        $pill.BorderThickness = '1'
        $pt.Text = 'OFF'
        $pt.Foreground = '#7A8592'
    }
    $pill.Child = $pt
    [System.Windows.Controls.Grid]::SetColumn($pill, 2)

    [void]$g.Children.Add($gl)
    [void]$g.Children.Add($sp)
    [void]$g.Children.Add($pill)
    $bd.Child = $g
    if ($script:ZapAgenteClick) {
        try { $bd.Add_MouseLeftButtonUp($script:ZapAgenteClick) } catch { }
    }

    return $bd
}

function Update-AgentiPadrone {
    if (-not $script:ZapAgentiLista) { return }
    $sync = $script:ZapAgentiSync
    if (-not $sync) { return }

    $script:ZapAgentiLista.Children.Clear()
    $attivi = Get-AgentiAttiviLista $sync
    $n = 0
    foreach ($a in (Get-AgentiCatalogo)) {
        $on = $false
        if ($attivi -contains $a.id) { $on = $true; $n = $n + 1 }
        [void]$script:ZapAgentiLista.Children.Add((New-AgenteRiga $a $on))
    }
    if ($script:ZapAgentiConteggio) {
        # v9.2: stesso conteggio del pulsante AGENTI in alto (agenti ACCESI).
        $cg = Get-AgentiConteggioAttivi $sync
        $script:ZapAgentiConteggio.Text = [string]$cg.testo
    }
}

function Toggle-AgenteDaUI {
    param([string]$Id)
    $sync = $script:ZapAgentiSync
    if (-not $sync) { return }
    $a = Get-AgenteById $Id
    if (-not $a) { return }

    $attuali = Get-AgentiAttiviLista $sync
    $nuovo = New-Object System.Collections.ArrayList
    $era = $false
    foreach ($x in $attuali) {
        if ([string]$x -eq [string]$Id) { $era = $true } else { [void]$nuovo.Add([string]$x) }
    }
    if (-not $era) { [void]$nuovo.Add([string]$Id) }
    $sync.AgentiAttivi = @($nuovo)
    try { Save-AgentiAttivi ([string]$sync.Base) $nuovo | Out-Null } catch { }

    Update-AgentiPadrone

    if (Get-Command Add-Activity -ErrorAction SilentlyContinue) {
        if ($era) { Add-Activity ('- ' + $a.nome + ' spento') }
        else { Add-Activity ('+ ' + $a.nome + ' attivo (' + $a.titolo + ')') }
    }
}

$script:ZapAgenteClick = {
    param($mittente, $evento)
    $id = ''
    try { $id = [string]$mittente.Tag } catch { }
    if ($id) { Toggle-AgenteDaUI $id }
}

function Initialize-AgentiPadrone {
    param($Window, $sync)

    $script:ZapAgentiSync = $sync
    $script:ZapAgentiWindow = $Window
    $script:ZapAgentiLista = $Window.FindName('AgentiLista')
    $script:ZapAgentiConteggio = $Window.FindName('AgentiConteggio')

    if (-not $script:ZapAgentiLista) { return }

    # lo stato salvato ha la precedenza; se manca, si parte dal default
    try { $sync.AgentiAttivi = @(Import-AgentiAttivi ([string]$sync.Base)) } catch { }
    if ($null -eq $sync.AgentiAttivi) { $sync.AgentiAttivi = @(Import-AgentiAttivi ([string]$sync.Base)) }

    Update-AgentiPadrone
}

function Set-AgenteStatoUI {
    # Porta un agente nello stato voluto (senza rimbalzare come il toggle).
    param([string]$Id, [bool]$Attivo)
    $sync = $script:ZapAgentiSync
    if (-not $sync) { return }
    $a = Get-AgenteById $Id
    if (-not $a) { return }

    $nuovo = New-Object System.Collections.ArrayList
    foreach ($x in (Get-AgentiAttiviLista $sync)) {
        if ([string]$x -ne [string]$Id) { [void]$nuovo.Add([string]$x) }
    }
    if ($Attivo) { [void]$nuovo.Add([string]$Id) }
    $sync.AgentiAttivi = @($nuovo)
    try { Save-AgentiAttivi ([string]$sync.Base) $nuovo | Out-Null } catch { }
    Update-AgentiPadrone
}

function Add-AgenteBolla {
    # Bolla della chat con l'intestazione dorata dell'agente.
    param([string]$Nome, [string]$Titolo, [string]$Testo, [string]$Oro, [string]$Glifo, [int]$Numero, [int]$Totale)

    if (-not $Oro) { $Oro = '#E8C86A' }
    if (-not $ChatPanel) { return }

    $b = New-Object System.Windows.Controls.Border
    $b.CornerRadius = '14'
    $b.BorderThickness = '1.5'
    $b.BorderBrush = $Oro
    $b.Background = '#141922'
    $b.Padding = '12,8,12,8'
    $b.MaxWidth = 640
    $b.HorizontalAlignment = 'Left'
    $b.Margin = '0,6,60,6'

    $sp = New-Object System.Windows.Controls.StackPanel

    $hd = New-Object System.Windows.Controls.TextBlock
    $intest = [string]$Glifo + '   ' + $Nome + '   -   ' + $Titolo
    if ($Totale -gt 0) { $intest = $intest + '   (' + $Numero + '/' + $Totale + ')' }
    $hd.Text = $intest
    $hd.FontSize = 11
    $hd.FontWeight = 'Bold'
    $hd.Foreground = $Oro
    $hd.Margin = '0,0,0,4'
    [void]$sp.Children.Add($hd)

    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Text = [string]$Testo
    $tb.FontSize = 13
    $tb.Foreground = '#E9E2D2'
    $tb.TextWrapping = 'Wrap'
    $tb.IsReadOnly = $true
    $tb.BorderThickness = '0'
    $tb.Background = 'Transparent'
    $tb.Padding = '0'
    $tb.Margin = '0'
    $tb.IsTabStop = $false
    $tb.VerticalScrollBarVisibility = 'Disabled'
    $tb.HorizontalScrollBarVisibility = 'Disabled'
    if (Get-Command Set-TextBoxCopyMenu -ErrorAction SilentlyContinue) { Set-TextBoxCopyMenu $tb }
    [void]$sp.Children.Add($tb)

    $b.Child = $sp
    [void]$ChatPanel.Children.Add($b)
    try { $ChatScroll.ScrollToEnd() } catch { }
}

function Handle-AgenteEvento {
    # Riceve gli eventi della squadra dalla coda UI (tipo 'agente').
    param($Dati)

    $fase = ''
    try { $fase = [string]$Dati.fase } catch { }

    switch ($fase) {
        'inizio' {
            $n = 0
            try { $n = [int]$Dati.totale } catch { }
            if (Get-Command Add-Activity -ErrorAction SilentlyContinue) {
                Add-Activity ('- squadra al lavoro: ' + $n + ' agenti -')
            }
            try { $StatusText.Text = 'SQUADRA AL LAVORO...' } catch { }
            try { Set-AvatarState 'pensa' } catch { }
        }
        'start' {
            if (Get-Command Add-Activity -ErrorAction SilentlyContinue) {
                Add-Activity ('+ ' + [string]$Dati.nome + ' (' + [string]$Dati.titolo + ') sta lavorando...')
            }
        }
        'fine' {
            Add-AgenteBolla ([string]$Dati.nome) ([string]$Dati.titolo) ([string]$Dati.testo) ([string]$Dati.oro) ([string]$Dati.glifo) ([int]$Dati.numero) ([int]$Dati.totale)
        }
        'sintesi' {
            if (Get-Command Add-Activity -ErrorAction SilentlyContinue) {
                Add-Activity '- il coordinatore unisce i contributi -'
            }
        }
        'completo' {
            try { Add-Bubble 'zap' ([string]$Dati.sintesi) } catch { }
            $cart = ''
            try { $cart = [string]$Dati.cartella } catch { }
            if ($cart -and (Get-Command Add-Activity -ErrorAction SilentlyContinue)) {
                Add-Activity ('resoconto salvato in: ' + $cart)
            }
            try { $StatusText.Text = 'SQUADRA: FATTO!' } catch { }
            try { Set-AvatarState 'ok' } catch { }
        }
        'errore' {
            try { Add-Bubble 'zap' ('La squadra si e fermata: ' + [string]$Dati.messaggio) } catch { }
            try { $StatusText.Text = 'SQUADRA: ERRORE' } catch { }
            try { Set-AvatarState 'neutro' } catch { }
        }
        default { }
    }
}
