﻿# cinema_ui.ps1 -- pannello CINEMA nell'interfaccia (v8.2)
# ---------------------------------------------------------------------------
#  Due motori:
#    OFFLINE  -> disegna la GIF in locale (istantaneo, nessun costo)
#    AI       -> manda la foto al modello video (Gemini Omni Flash), riceve un
#                filmato vero e lo converte in GIF/WebP con ffmpeg
# ---------------------------------------------------------------------------

$script:ZapCineSync = $null
$script:ZapCineBase = ''
$script:ZapCineFoto = ''
$script:ZapCineGif = ''
$script:ZapCineVideo = ''
$script:ZapCineBusy = $false
$script:ZapCineIds = @()
$script:ZapCineMov = @()
$script:ZapCineUI = @{}

function Add-CineLog {
    param([string]$Testo)
    $tb = $script:ZapCineUI['log']
    if (-not $tb) { return }
    try {
        $tb.AppendText(((Get-Date -Format 'HH:mm:ss') + '  ' + $Testo + "`r`n"))
        $tb.ScrollToEnd()
    } catch { }
}

function Set-CineStato {
    param([string]$Testo)
    $st = $script:ZapCineUI['stato']
    if ($st) { $st.Text = $Testo }
}

function Get-CineMotore {
    $c = $script:ZapCineUI['motore']
    if ($c) { if ($c.SelectedIndex -eq 1) { return 'ai' } }
    return 'offline'
}

function Get-CineLatoScelto {
    $c = $script:ZapCineUI['lato']
    if (-not $c) { return 560 }
    switch ($c.SelectedIndex) {
        0 { return 420 }
        1 { return 560 }
        2 { return 720 }
        3 { return 900 }
        default { return 560 }
    }
}

function Get-CinePresetScelto {
    $c = $script:ZapCineUI['preset']
    if (-not $c) { return 'aura' }
    $i = $c.SelectedIndex
    if ($i -lt 0 -or $i -ge $script:ZapCineIds.Count) { return 'aura' }
    return [string]$script:ZapCineIds[$i]
}

function Get-CineMovimentoScelto {
    $c = $script:ZapCineUI['movimento']
    if (-not $c) { return 'vita' }
    $i = $c.SelectedIndex
    if ($i -lt 0 -or $i -ge $script:ZapCineMov.Count) { return 'vita' }
    return [string]$script:ZapCineMov[$i]
}

function Update-CineDescrizione {
    if ((Get-CineMotore) -eq 'ai') {
        $m = Get-CinemaMovimento (Get-CineMovimentoScelto)
        $tb = $script:ZapCineUI['descrizione']
        if ($tb) { $tb.Text = [string]$m.descrizione }
    } else {
        $p = Get-CinemaPreset (Get-CinePresetScelto)
        $tb = $script:ZapCineUI['descrizione']
        if ($tb) { $tb.Text = [string]$p.descrizione }
    }
}

function Update-CineMotoreUI {
    $ai = ((Get-CineMotore) -eq 'ai')
    $coppie = @(
        @('lblPreset', -not $ai), @('preset', -not $ai),
        @('lblMov', $ai), @('movimento', $ai), @('prompt', $ai)
    )
    foreach ($c in $coppie) {
        $ctrl = $script:ZapCineUI[$c[0]]
        if ($ctrl) { if ($c[1]) { $ctrl.Visibility = 'Visible' } else { $ctrl.Visibility = 'Collapsed' } }
    }
    $info = $script:ZapCineUI['motoreInfo']
    if ($info) {
        if ($ai) {
            $ff = Find-ZapFfmpeg $script:ZapCineBase
            if ($ff) {
                $info.Text = 'Il modello genera un video vero (il soggetto si muove). Poi ffmpeg lo trasforma in GIF. Tempo: 1-3 minuti per clip. Serve un progetto Google con fatturazione attiva.'
            } else {
                $info.Text = 'Manca ffmpeg: il video verra salvato in MP4 ma non convertito in GIF. Premi FFMPEG qui sotto.'
            }
        } else {
            $info.Text = 'Motore locale: vedi la foto muoversi (zoom, luce, pulviscolo). Istantaneo, gratis, nessuna API.'
        }
    }
    Update-CineDescrizione
}

function Update-CineAnteprima {
    $img = $script:ZapCineUI['anteprima']
    if (-not $img) { return }
    $foto = $script:ZapCineFoto
    if (-not $foto -or -not (Test-Path $foto)) { return }
    try {
        $src = Get-CinemaImmagine $foto 1200
        $preset = Get-CinePresetScelto
        $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ('zap_cine_ant_' + [guid]::NewGuid().ToString('N') + '.png')
        [void](New-CinemaAnteprima $src $preset $tmp 0.30 (Get-CineLatoScelto))
        $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
        $bmp.BeginInit()
        $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bmp.UriSource = (New-Object System.Uri($tmp, [System.UriKind]::Absolute))
        $bmp.EndInit()
        $bmp.Freeze()
        $img.Source = $bmp
        try { Remove-Item $tmp -Force -ErrorAction SilentlyContinue } catch { }
    } catch {
        Add-CineLog ('anteprima non riuscita: ' + $_.Exception.Message)
    }
}

function Set-CineFoto {
    param([string]$Percorso)
    if (-not $Percorso) { return }
    if (-not (Test-Path $Percorso)) { return }
    $script:ZapCineFoto = $Percorso
    $lbl = $script:ZapCineUI['file']
    if ($lbl) { $lbl.Text = [System.IO.Path]::GetFileName($Percorso) }
    $v = $script:ZapCineUI['vuoto']
    if ($v) { $v.Visibility = 'Collapsed' }
    Add-CineLog ('foto scelta: ' + [System.IO.Path]::GetFileName($Percorso))
    Update-CineAnteprima
}

function Set-CineBusy {
    param([bool]$Busy)
    $script:ZapCineBusy = $Busy
    foreach ($k in @('anima', 'scegli', 'motore', 'preset', 'movimento', 'lato', 'durata')) {
        $ctrl = $script:ZapCineUI[$k]
        if ($ctrl) { if ($Busy) { $ctrl.IsEnabled = $false } else { $ctrl.IsEnabled = $true } }
    }
    $bar = $script:ZapCineUI['bar']
    if ($bar) { if (-not $Busy) { $bar.Value = 0 } }
}

function Start-CineAnima {
    $sync = $script:ZapCineSync
    if (-not $sync) { return }
    if ($script:ZapCineBusy) { return }
    if (-not $script:ZapCineFoto) {
        Add-CineLog 'prima scegli una foto.'
        return
    }
    if (-not $sync.CineQueue) { Add-CineLog 'motore non disponibile.'; return }

    $cart = ''
    try { $cart = Join-Path ([string]$sync.Base) 'output\cinema' } catch { $cart = '' }
    if (-not $cart) { $cart = (Join-Path $script:ZapCineBase 'output\cinema') }
    try { if (-not (Test-Path $cart)) { New-Item -ItemType Directory -Path $cart -Force | Out-Null } } catch { }

    $secondi = 3.0
    $c = $script:ZapCineUI['durata']
    if ($c) {
        switch ($c.SelectedIndex) {
            0 { $secondi = 2.0 }
            1 { $secondi = 3.0 }
            2 { $secondi = 4.0 }
            3 { $secondi = 6.0 }
            default { $secondi = 3.0 }
        }
    }

    $motore = Get-CineMotore
    Set-CineBusy $true

    if ($motore -eq 'ai') {
        $extra = ''
        try { $extra = [string]$script:ZapCineUI['prompt'].Text } catch { }
        Add-CineLog ('MOTORE AI - movimento: ' + (Get-CinemaMovimento (Get-CineMovimentoScelto)).nome)
        Set-CineStato 'sto chiamando il modello video...'
        try {
            $sync.CineQueue.Enqueue(@{
                tipo        = 'ai'
                sorgente    = $script:ZapCineFoto
                movimento   = (Get-CineMovimentoScelto)
                extra       = $extra
                rapporto    = 'auto'
                risoluzione = '720p'
                latormax    = (Get-CineLatoScelto)
                secondi     = $secondi
                cartella    = $cart
            })
        } catch {
            Add-CineLog ('errore: ' + $_.Exception.Message)
            Set-CineBusy $false
        }
        return
    }

    Add-CineLog ('MOTORE OFFLINE - regia: ' + (Get-CinemaPreset (Get-CinePresetScelto)).nome)
    try {
        $sync.CineQueue.Enqueue(@{
            tipo     = 'offline'
            sorgente = $script:ZapCineFoto
            preset   = (Get-CinePresetScelto)
            latormax = (Get-CineLatoScelto)
            secondi  = $secondi
            cartella = $cart
        })
    } catch {
        Add-CineLog ('errore: ' + $_.Exception.Message)
        Set-CineBusy $false
    }
}

function Update-CineFfmpegStato {
    $ff = Find-ZapFfmpeg $script:ZapCineBase
    $b = $script:ZapCineUI['ffmpeg']
    if ($b) {
        if ($ff) { $b.Content = 'FFMPEG OK' } else { $b.Content = 'INSTALLA FFMPEG' }
    }
    return $ff
}

function Initialize-CinemaUI {
    param($Window, $sync, [string]$Base)

    $script:ZapCineSync = $sync
    $script:ZapCineBase = $Base

    foreach ($k in @('anteprima', 'preset', 'descrizione', 'durata', 'lato', 'bar', 'log', 'stato', 'file', 'vuoto',
                     'motore', 'motoreInfo', 'movimento', 'prompt', 'lblPreset', 'lblMov')) {
        $script:ZapCineUI[$k] = $Window.FindName(('Cine' + $k.Substring(0,1).ToUpper() + $k.Substring(1)))
    }
    # i due nomi non seguono lo schema Cine<X>: li sistemo a mano
    $script:ZapCineUI['motore'] = $Window.FindName('CineMotore')
    $script:ZapCineUI['motoreInfo'] = $Window.FindName('CineMotoreInfo')
    $script:ZapCineUI['movimento'] = $Window.FindName('CineMovimento')
    $script:ZapCineUI['prompt'] = $Window.FindName('CinePrompt')

    $btnScegli = $Window.FindName('BtnCineScegli')
    $btnAnima = $Window.FindName('BtnCineAnima')
    $btnApri = $Window.FindName('BtnCineApri')
    $btnCart = $Window.FindName('BtnCineCartella')
    $btnChat = $Window.FindName('BtnCineChat')
    $btnChiudi = $Window.FindName('BtnCineChiudi')
    $btnFf = $Window.FindName('BtnCineFfmpeg')

    $script:ZapCineUI['scegli'] = $btnScegli
    $script:ZapCineUI['anima'] = $btnAnima
    $script:ZapCineUI['ffmpeg'] = $btnFf
    $script:ZapCineUI['pannello'] = $Window.FindName('CinemaPanel')

    # --- motore ------------------------------------------------------------
    if ($script:ZapCineUI['motore']) {
        $script:ZapCineUI['motore'].Items.Clear()
        [void]$script:ZapCineUI['motore'].Items.Add('OFFLINE (istantaneo, gratis)')
        [void]$script:ZapCineUI['motore'].Items.Add('AI (video vero, Gemini Omni Flash)')
        $script:ZapCineUI['motore'].SelectedIndex = 0
    }

    # --- regie offline -----------------------------------------------------
    $script:ZapCineIds = @(Get-CinemaPresetNomi)
    if ($script:ZapCineUI['preset']) {
        $script:ZapCineUI['preset'].Items.Clear()
        foreach ($id in $script:ZapCineIds) { [void]$script:ZapCineUI['preset'].Items.Add((Get-CinemaPreset $id).nome) }
        $script:ZapCineUI['preset'].SelectedIndex = 0
    }

    # --- movimenti AI ------------------------------------------------------
    $script:ZapCineMov = @(Get-CinemaMovimentoNomi)
    if ($script:ZapCineUI['movimento']) {
        $script:ZapCineUI['movimento'].Items.Clear()
        foreach ($id in $script:ZapCineMov) { [void]$script:ZapCineUI['movimento'].Items.Add((Get-CinemaMovimento $id).nome) }
        $script:ZapCineUI['movimento'].SelectedIndex = 0
    }

    if ($script:ZapCineUI['durata']) {
        $script:ZapCineUI['durata'].Items.Clear()
        foreach ($v in @('2 secondi', '3 secondi', '4 secondi', '6 secondi')) { [void]$script:ZapCineUI['durata'].Items.Add($v) }
        $script:ZapCineUI['durata'].SelectedIndex = 1
    }
    if ($script:ZapCineUI['lato']) {
        $script:ZapCineUI['lato'].Items.Clear()
        foreach ($v in @('Piccola (420)', 'Media (560)', 'Grande (720)', 'Extra (900)')) { [void]$script:ZapCineUI['lato'].Items.Add($v) }
        $script:ZapCineUI['lato'].SelectedIndex = 1
    }

    if ($btnScegli) {
        $btnScegli.Add_Click({
            $dlg = New-Object Microsoft.Win32.OpenFileDialog
            $dlg.Title = 'Scegli la foto da animare'
            $dlg.Filter = 'Immagini|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff;*.webp|Tutti i file|*.*'
            if ($dlg.ShowDialog() -eq $true) { Set-CineFoto $dlg.FileName }
        })
    }
    if ($btnAnima) { $btnAnima.Add_Click({ Start-CineAnima }) }
    if ($script:ZapCineUI['motore']) { $script:ZapCineUI['motore'].Add_SelectionChanged({ Update-CineMotoreUI }) }
    if ($script:ZapCineUI['preset']) {
        $script:ZapCineUI['preset'].Add_SelectionChanged({
            Update-CineDescrizione
            if (-not $script:ZapCineBusy) { Update-CineAnteprima }
        })
    }
    if ($script:ZapCineUI['movimento']) { $script:ZapCineUI['movimento'].Add_SelectionChanged({ Update-CineDescrizione }) }
    if ($script:ZapCineUI['lato']) {
        $script:ZapCineUI['lato'].Add_SelectionChanged({ if (-not $script:ZapCineBusy) { Update-CineAnteprima } })
    }
    if ($btnApri) {
        $btnApri.Add_Click({
            $f = $script:ZapCineGif
            if (-not $f) { $f = $script:ZapCineVideo }
            if ($f -and (Test-Path $f)) { try { Start-Process -FilePath $f } catch { Add-CineLog 'non riesco ad aprire il file.' } }
            else { Add-CineLog 'niente da aprire: premi ANIMA.' }
        })
    }
    if ($btnCart) {
        $btnCart.Add_Click({
            try {
                $cart = Join-Path $script:ZapCineBase 'output\cinema'
                if (Test-Path $cart) { Start-Process -FilePath 'explorer.exe' -ArgumentList $cart }
            } catch { }
        })
    }
    if ($btnChat) {
        $btnChat.Add_Click({
            $f = $script:ZapCineGif
            if (-not $f) { $f = $script:ZapCineVideo }
            if (-not $f) { Add-CineLog 'niente da mandare: premi ANIMA.'; return }
            $nome = [System.IO.Path]::GetFileName($f)
            try { Add-Bubble 'zap' ('Fatto: ' + $nome + ' - la trovi in output\cinema.') } catch { }
            try {
                $InputBox.Text = 'Ho appena creato questo: ' + $f
                $InputBox.CaretIndex = $InputBox.Text.Length
                [void]$InputBox.Focus()
            } catch { }
        })
    }
    if ($btnFf) {
        $btnFf.Add_Click({
            Add-CineLog 'installo ffmpeg con winget...'
            $r = Install-ZapFfmpeg
            Add-CineLog [string]$r.messaggio
            $ff = Update-CineFfmpegStato
            if ($ff) { Add-CineLog ('ffmpeg trovato: ' + $ff) } else { Add-CineLog 'ffmpeg ancora non trovato.' }
            Update-CineMotoreUI
        })
    }
    if ($btnChiudi) {
        $btnChiudi.Add_Click({
            $p = $script:ZapCineUI['pannello']
            if ($p) { $p.Visibility = 'Collapsed' }
        })
    }

    $ff = Update-CineFfmpegStato
    if ($ff) { Add-CineLog 'ffmpeg pronto.' } else { Add-CineLog 'ffmpeg assente: il motore AI salvera solo MP4 finche non lo installi.' }
    Update-CineMotoreUI
    Add-CineLog 'motore pronto.'
}

function Show-CinemaPanel {
    param($Window)
    $p = $script:ZapCineUI['pannello']
    if (-not $p) { $p = $Window.FindName('CinemaPanel') }
    if ($p) {
        $p.Visibility = 'Visible'
        Update-CineMotoreUI
    }
}

function Handle-CineEvento {
    param($Dati)

    $fase = ''
    try { $fase = [string]$Dati.fase } catch { }

    switch ($fase) {
        'frame' {
            $bar = $script:ZapCineUI['bar']
            $n = [int]$Dati.n
            $i = [int]$Dati.i
            if ($bar -and $n -gt 0) { $bar.Value = [Math]::Round(100.0 * $i / $n, 0) }
            Set-CineStato ('disegno il fotogramma ' + $i + ' di ' + $n)
        }
        'ai' {
            $bar = $script:ZapCineUI['bar']
            if ($bar -and $bar.Value -lt 15) { $bar.Value = 15 }
            Add-CineLog ('[AI] ' + [string]$Dati.messaggio)
            Set-CineStato ([string]$Dati.messaggio)
        }
        'fine' {
            $script:ZapCineGif = ''
            try { $script:ZapCineGif = [string]$Dati.file } catch { }
            try { $script:ZapCineVideo = [string]$Dati.video } catch { $script:ZapCineVideo = '' }
            Set-CineBusy $false
            $bar = $script:ZapCineUI['bar']
            if ($bar) { $bar.Value = 100 }

            $kb = [Math]::Round(([double]$Dati.byte) / 1024.0, 0)
            $motore = ''
            try { $motore = [string]$Dati.motore } catch { }
            $senzaGif = $false
            try { $senzaGif = [bool]$Dati.senzaGif } catch { }

            if ($senzaGif) {
                $m = 'Video salvato: ' + [System.IO.Path]::GetFileName([string]$Dati.video) + ' (' + $kb + ' KB)'
                try { if ($Dati.messaggio) { $m = [string]$Dati.messaggio } } catch { }
                Set-CineStato $m
                Add-CineLog $m
            } else {
                $st = 'GIF pronta: ' + [System.IO.Path]::GetFileName([string]$Dati.file) + ' (' + $kb + ' KB'
                try {
                    if ([int]$Dati.larghezza -gt 0) { $st = $st + ', ' + $Dati.larghezza + 'px' }
                    if ([int]$Dati.frames -gt 0) { $st = $st + ', ' + $Dati.frames + ' fotogrammi' }
                } catch { }
                $st = $st + ', ' + [Math]::Round([double]$Dati.ms / 1000.0, 1) + ' s)'
                Set-CineStato $st
                Add-CineLog ('fatto (' + $motore + '): ' + [System.IO.Path]::GetFileName([string]$Dati.file))
                try {
                    if ($Dati.webp) { Add-CineLog ('anche WebP: ' + [System.IO.Path]::GetFileName([string]$Dati.webp)) }
                    if ($Dati.video) { Add-CineLog ('video originale: ' + [System.IO.Path]::GetFileName([string]$Dati.video)) }
                } catch { }
            }
            Add-CineLog ('cartella: ' + (Split-Path -Parent ([string]$Dati.file)))
        }
        'errore' {
            Set-CineBusy $false
            Set-CineStato ('errore: ' + [string]$Dati.messaggio)
            Add-CineLog ('errore: ' + [string]$Dati.messaggio)
        }
        'annullato' {
            Set-CineBusy $false
            Add-CineLog 'annullato.'
            Set-CineStato 'annullato.'
        }
        default { }
    }
}
