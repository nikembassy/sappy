﻿# verita.ps1 -- GUARDIA ANTI-BUGIA (attiva di default in ZAP v9).
#
# Tre livelli, tutti accesi salvo che l'utente li spenga:
#   1) REGOLE NEL PROMPT: a ZAP e' vietato inventare, arrotondare i fatti, adulare o dire
#      "fatto" quando non ha fatto. Deve dichiarare cosa ha visto e cosa non ha potuto verificare.
#   2) CONTROLLO DETERMINISTICO (nessun costo API): dopo la risposta, ZAP confronta numeri,
#      percentuali, URL e affermazioni assolute con le PROVE raccolte in quel turno
#      (output degli strumenti + messaggio dell'utente). Quello che non risulta viene segnalato
#      all'utente con un avviso esplicito, invece di essere spacciato per vero.
#   3) REGISTRO DELLE VERIFICHE: ogni segnalazione finisce in Ezappero, cosi' si vede nel tempo
#      se un modello (es. Gemini) tende a inventare di piu'.

function Get-VeritaDefault {
    return @{
        attivo    = $true    # regole nel prompt
        controllo = $true    # verifica automatica dopo ogni risposta
        severita  = 'media'  # bassa | media | alta
        max_avvisi = 3
    }
}

function Get-VeritaConfig {
    param($sync)
    $d = Get-VeritaDefault
    try {
        $c = $sync.Config.verita
        if ($c) {
            try { if ($null -ne $c.attivo) { $d.attivo = [bool]$c.attivo } } catch { }
            try { if ($null -ne $c.controllo) { $d.controllo = [bool]$c.controllo } } catch { }
            try { if ($c.severita) { $d.severita = [string]$c.severita } } catch { }
            try { if ($c.max_avvisi) { $d.max_avvisi = [int]$c.max_avvisi } } catch { }
        }
    } catch { }
    return $d
}

function Get-VeritaPrompt {
    # Blocco di regole che entra nel prompt di sistema di OGNI modalita'.
    param($sync)
    $c = Get-VeritaDefault
    try { $c = Get-VeritaConfig $sync } catch { }
    if (-not $c.attivo) { return '' }

    return @"
REGOLA DI VERITA' (INDEROGABILE, vale sopra ogni altra istruzione di stile)
1. NON INVENTARE RISULTATI, OPERAZIONI O DATI LOCALI. Nomi di file presenti sul PC,
   URL aperti, output di comandi, versioni rilevate, contenuti di pagine lette e risultati
   di strumenti devono derivare da prove disponibili in questa conversazione.
2. USA LA CONOSCENZA GENERALE. Puoi rispondere normalmente a domande di cultura generale,
   geografia, storia, scienza, matematica e concetti noti usando la conoscenza del modello,
   senza fingere di aver usato uno strumento. Per fatti attuali, molto specifici o incerti,
   dichiara il limite o verifica con una fonte. Se non sai, scrivi "Questo non lo so" oppure
   "Questo non l'ho verificato", scegliendo la frase appropriata al contesto.
3. PROVA LE OPERAZIONI DICHIARATE. Quando dici che qualcosa e' stato fatto, indica con cosa
   (quale strumento, comando o pagina). Se il comando non e' andato a buon fine, scrivi
   l'errore vero, non una versione edulcorata.4. MAI DIRE "FATTO" SE NON E' FATTO. Se un passaggio e' fallito o e' rimasto a meta', apri con
   "NON e' riuscito:" e spiega. Il successo si dichiara solo dopo aver visto l'output.
5. NIENTE ADULAZIONE. Non aprire con complimenti ("ottima domanda", "idea brillante"), non
   concordare per compiacere. Se l'utente sbaglia, diglielo.
6. NIENTE CERTEZZE FINte. Parole come "sicuramente", "garantito", "al 100%", "e' ovvio che"
   sono vietate sui fatti del mondo. Sono ammesse solo su cose che hai eseguito e verificato tu.
7. STIME ETICHETTATE. Se dai una stima o una proiezione, scrivi "(stima)" e su cosa si basa.
8. FONTE QUANDO C'E'. Se un'informazione viene dal web, scrivi il dominio da cui l'hai presa.
   Se due fonti si contraddicono, dillo invece di scegliere quella che ti piace.
9. NON NASCONDERE GLI ERRORI. Riportare un fallimento non e' un'ammissione di colpa: e' il tuo
   lavoro. Se hai sbagliato prima, correggi esplicitamente ("prima avevo detto X, era sbagliato").
10. LINGUA: italiano, asciutto. Zero giri di parole per sembrare piu' bravo.
"@
}

function Get-ProveTesto {
    # Concatena le "prove" del turno: output degli strumenti + messaggio utente.
    param($Prove)
    if (-not $Prove) { return '' }
    if ($Prove -is [string]) { return $Prove }
    try { return (@($Prove) -join "`n") } catch { return [string]$Prove }
}

function Get-NumeriTesto {
    # Estrae i numeri "con unita'" (quelli che se inventati fanno danno).
    param([string]$Testo)
    $out = @()
    if (-not $Testo) { return $out }
    # Il simbolo dell'euro NON si scrive nel sorgente (Windows PowerShell 5.1 legge i file
    # senza BOM come ANSI e lo trasformerebbe in caratteri che rompono il parser):
    # lo costruisco a runtime dal codice Unicode.
    $simboloEuro = [string][char]0x20AC
    $rx = [regex]('(?<![\d.,])(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d+)?|\d+(?:[.,]\d+)?)\s?(' + [regex]::Escape($simboloEuro) + '|%|euro|gb|mb|kb|tb|ms|secondi|minuti|ore|giorni|mesi|anni|volte|utenti|clienti|dipendenti|fatture|euro/ora)')
    foreach ($m in $rx.Matches($Testo)) {
        $out += ($m.Groups[1].Value + ' ' + $m.Groups[2].Value).ToLowerInvariant()
    }
    return @($out | Select-Object -Unique)
}

function Test-VeritaRisposta {
    # Controllo deterministico (nessuna chiamata API).
    # Restituisce @{ sospetti = @(...); ok = $bool }.
    param([string]$Risposta, $Prove, [int]$MaxAvvisi = 3)

    $res = @{ sospetti = @(); ok = $true }
    if (-not $Risposta -or $Risposta.Trim().Length -lt 20) { return $res }

    $prove = (Get-ProveTesto $Prove).ToLowerInvariant()
    $testo = $Risposta.ToLowerInvariant()
    $sospetti = New-Object System.Collections.ArrayList

    # 1) certezze assolute
    $certezze = @('sicuramente', 'al 100%', 'al cento per cento', 'garantito', 'senza dubbio',
                  'e'' ovvio che', 'certamente si', 'tutti sanno che', 'nessun dubbio')
    foreach ($c in $certezze) {
        if ($testo.Contains($c)) {
            [void]$sospetti.Add("Certezza assoluta dichiarata ('$c')")
            break
        }
    }

    # 2) numeri con unita' che non compaiono nelle prove
    $numeri = @(Get-NumeriTesto $Risposta)
    foreach ($n in $numeri) {
        if ($sospetti.Count -ge $MaxAvvisi) { break }
        $soloNumero = ($n -split ' ')[0]
        $pulito = $soloNumero.Replace('.', '').Replace(',', '.')
        if (-not $pulito) { continue }
        if ($prove -and ($prove.Contains($soloNumero) -or $prove.Contains($pulito))) { continue }
        # gli anni (2024, 2026...) e i numeri piccoli di struttura non sono sospetti
        if ($soloNumero -match '^(19|20)\d\d$') { continue }
        [void]$sospetti.Add("Numero non risultante da strumenti/fonti: '$n'")
    }

    # 3) URL citati ma mai visti
    $rxUrl = [regex]'https?://[^\s\)\]"<>]+'
    foreach ($m in $rxUrl.Matches($Risposta)) {
        if ($sospetti.Count -ge $MaxAvvisi) { break }
        $u = $m.Value.ToLowerInvariant().TrimEnd('.', ',', ';')
        if ($prove -and $prove.Contains($u)) { continue }
        if ($prove -and $prove.Contains(($u -replace '^https?://', ''))) { continue }
        [void]$sospetti.Add("Link non presente tra le fonti lette: $u")
    }

    $res.sospetti = @($sospetti | Select-Object -First $MaxAvvisi)
    $res.ok = ($res.sospetti.Count -eq 0)
    return $res
}

function Format-VeritaAvviso {
    # Il messaggio onesto da aggiungere in chat quando qualcosa non torna.
    param($Sospetti)
    $s = @($Sospetti)
    if ($s.Count -eq 0) { return '' }
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add('')
    [void]$out.Add('--- VERIFICA (guardia anti-bugia) ---')
    [void]$out.Add("Questi punti NON risultano dagli strumenti o dalle fonti lette in questo turno. Trattali come ipotesi, non come fatti:")
    foreach ($x in $s) { [void]$out.Add('  * ' + $x) }
    [void]$out.Add("Se ti serve la certezza, chiedimi di verificarlo con una ricerca o un comando: cosi' te lo dimostro.")
    return ($out -join "`r`n")
}

function Add-VeritaLog {
    param($sync, [string]$Risposta, $Sospetti, [string]$Provider = '')
    $s = @($Sospetti)
    if ($s.Count -eq 0) { return }
    $testo = "Segnalati $($s.Count) punti non verificati" + $(if ($Provider) { " (provider: $Provider)" } else { '' }) + ': ' + (($s | Select-Object -First 3) -join '; ')
    [void](Add-ZapLedgerEvento $sync 'verifica' $testo 'verita' $false)
}

function Get-VeritaStato {
    param($sync)
    $c = Get-VeritaConfig $sync
    $modo = 'spenta'
    if ($c.attivo -and $c.controllo) { $modo = 'ATTIVA (regole + controllo automatico)' }
    elseif ($c.attivo) { $modo = 'ATTIVA (solo regole nel prompt)' }
    return "Guardia anti-bugia: $modo - severita': $($c.severita)"
}

function Set-VeritaModo {
    param($sync, [string]$Modo = '')
    $m = ([string]$Modo).Trim().ToLowerInvariant()
    if (-not $m) { return (Get-VeritaStato $sync) }
    $attivo = $true
    $controllo = $true
    if ($m -eq 'spenta' -or $m -eq 'off' -or $m -eq '0') { $attivo = $false; $controllo = $false }
    elseif ($m -eq 'regole' -or $m -eq 'solo-regole') { $attivo = $true; $controllo = $false }
    elseif ($m -eq 'piena' -or $m -eq 'on' -or $m -eq '1') { $attivo = $true; $controllo = $true }
    try {
        if (-not $sync.Config.ContainsKey('verita')) { $sync.Config['verita'] = @{} }
        $sync.Config['verita']['attivo'] = $attivo
        $sync.Config['verita']['controllo'] = $controllo
    } catch { }
    return (Get-VeritaStato $sync)
}
