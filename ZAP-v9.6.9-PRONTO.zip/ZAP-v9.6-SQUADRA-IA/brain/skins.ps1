﻿# ==========================================================================
#  skins.ps1  -  ZAP! v9.4  "INTERFACCE" (skin)
# --------------------------------------------------------------------------
#  5 interfacce + quella classica. Ognuna cambia COLORI e DISEGNO, ma NON
#  tocca i comandi: tutti i pulsanti restano dove sono e continuano a funzionare.
#
#  Due strati, nessuno dei due cattura i clic (IsHitTestVisible=False):
#    SkinPanel  = DENTRO il pannello sinistro, dietro la foto: qui vive il disegno
#    SkinLayer  = sopra tutta la finestra: cornice e scanline, molto tenui
#
#  Come si cambia:
#     tasto tondo "skin" accanto alla foto   |   F9 (Shift+F9 indietro)
#     /skin            -> elenco
#     /skin astronave  -> la attiva
#     /skin-ai <testo> -> l'IA ne inventa una nuova
#     /skin-scarica <url> -> installa una skin da internet
#     strumento 'skin' (l'agente puo' cambiarla da solo)
#
#  Formato di una skin (JSON dichiarativo): nome, titolo, palette{...}, scena{...}
# ==========================================================================

$script:SkinJson = @'
[
  {
    "nome": "classica",
    "titolo": "ZAP Classica",
    "descrizione": "L'aspetto attuale: oro su antracite. Sobria, zero distrazioni.",
    "palette": null,
    "scena": {
      "sfondo": [
        "#0E1116",
        "#12161C"
      ]
    }
  },
  {
    "nome": "astronave",
    "titolo": "Cabina Astronave",
    "descrizione": "Console di una nave: lamelle di scafo, griglia di navigazione, spie ai bordi.",
    "palette": {
      "sfondo": "#05080D",
      "superficie": "#0B1520",
      "campo": "#08111A",
      "pill": "#0E1B27",
      "accento": "#38E1FF",
      "accentoChiaro": "#9AEFFF",
      "accentoScuro": "#1A8FA8",
      "argento": "#B8CBD6",
      "argentoScuro": "#7C96A4",
      "testo": "#E6F6FF",
      "testoSuAccento": "#02131A",
      "bordo": "#17303F"
    },
    "scena": {
      "sfondo": [
        "#05080D",
        "#0B1622"
      ],
      "griglia": {
        "tipo": "linee",
        "colore": "#38E1FF",
        "passo": 58,
        "opacita": 0.07
      },
      "stelle": {
        "numero": 90,
        "colore": "#9AEFFF",
        "opacita": 0.45
      },
      "anelli": [
        {
          "r": 1.2,
          "spessore": 2,
          "colore": "#38E1FF",
          "opacita": 0.55
        },
        {
          "r": 1.34,
          "spessore": 1,
          "colore": "#38E1FF",
          "opacita": 0.28,
          "tratteggio": "3 7"
        }
      ],
      "angoli": {
        "colore": "#38E1FF",
        "lunghezza": 54,
        "spessore": 2,
        "opacita": 0.5
      },
      "scanline": {
        "colore": "#9AEFFF",
        "passo": 4,
        "opacita": 0.035
      },
      "forma": {
        "tipo": "astronave",
        "colore": "#38E1FF",
        "opacita": 0.3
      }
    }
  },
  {
    "nome": "universo",
    "titolo": "Universo / Stella",
    "descrizione": "Campo stellare, nebulosa viola e una stella pulsante dietro la foto.",
    "palette": {
      "sfondo": "#070312",
      "superficie": "#130A26",
      "campo": "#0F0720",
      "pill": "#1B0F33",
      "accento": "#C9A7FF",
      "accentoChiaro": "#E3D2FF",
      "accentoScuro": "#8B5FD6",
      "argento": "#CFC7E6",
      "argentoScuro": "#9A90B8",
      "testo": "#F3EEFF",
      "testoSuAccento": "#150731",
      "bordo": "#2C1B4A"
    },
    "scena": {
      "sfondo": [
        "#070312",
        "#1B0A38"
      ],
      "stelle": {
        "numero": 260,
        "colore": "#FFFFFF",
        "opacita": 0.75
      },
      "anelli": [
        {
          "r": 1.24,
          "spessore": 2,
          "colore": "#C9A7FF",
          "opacita": 0.5
        },
        {
          "r": 1.46,
          "spessore": 1,
          "colore": "#8B5FD6",
          "opacita": 0.35,
          "tratteggio": "2 9"
        }
      ],
      "forma": {
        "tipo": "stella",
        "colore": "#C9A7FF",
        "opacita": 0.22
      }
    }
  },
  {
    "nome": "ologramma",
    "titolo": "Ologramma HUD",
    "descrizione": "Il look dell'immagine che hai caricato: anelli concentrici, tacche, verde-ciano.",
    "palette": {
      "sfondo": "#020C0C",
      "superficie": "#04201C",
      "campo": "#031714",
      "pill": "#062A24",
      "accento": "#2EF2C8",
      "accentoChiaro": "#A6FFEC",
      "accentoScuro": "#159E84",
      "argento": "#B6E5DB",
      "argentoScuro": "#74A79D",
      "testo": "#E4FFF9",
      "testoSuAccento": "#002018",
      "bordo": "#0F3A33"
    },
    "scena": {
      "sfondo": [
        "#020C0C",
        "#062A24"
      ],
      "griglia": {
        "tipo": "punti",
        "colore": "#2EF2C8",
        "passo": 34,
        "opacita": 0.1
      },
      "anelli": [
        {
          "r": 1.16,
          "spessore": 1,
          "colore": "#2EF2C8",
          "opacita": 0.7
        },
        {
          "r": 1.3,
          "spessore": 2,
          "colore": "#2EF2C8",
          "opacita": 0.45,
          "tratteggio": "10 6"
        },
        {
          "r": 1.52,
          "spessore": 1,
          "colore": "#A6FFEC",
          "opacita": 0.28,
          "tratteggio": "2 10"
        }
      ],
      "angoli": {
        "colore": "#2EF2C8",
        "lunghezza": 38,
        "spessore": 1.5,
        "opacita": 0.45
      },
      "scanline": {
        "colore": "#2EF2C8",
        "passo": 3,
        "opacita": 0.05
      },
      "forma": {
        "tipo": "ologramma",
        "colore": "#2EF2C8",
        "opacita": 0.34
      }
    }
  },
  {
    "nome": "fantasy",
    "titolo": "Fantasy / Rune",
    "descrizione": "Cerchio runico, oro antico e verde bosco: un grimorio da avventuriero.",
    "palette": {
      "sfondo": "#0A0F08",
      "superficie": "#131A10",
      "campo": "#101710",
      "pill": "#1A2416",
      "accento": "#E5C36B",
      "accentoChiaro": "#F6E3A8",
      "accentoScuro": "#A8873A",
      "argento": "#CFCBBA",
      "argentoScuro": "#98957F",
      "testo": "#F7F2DE",
      "testoSuAccento": "#1A1406",
      "bordo": "#2E3A26"
    },
    "scena": {
      "sfondo": [
        "#0A0F08",
        "#1A2312"
      ],
      "stelle": {
        "numero": 70,
        "colore": "#F6E3A8",
        "opacita": 0.35
      },
      "anelli": [
        {
          "r": 1.22,
          "spessore": 2,
          "colore": "#E5C36B",
          "opacita": 0.55
        },
        {
          "r": 1.4,
          "spessore": 1,
          "colore": "#A8873A",
          "opacita": 0.4,
          "tratteggio": "5 5"
        }
      ],
      "forma": {
        "tipo": "runa",
        "colore": "#E5C36B",
        "opacita": 0.3
      },
      "angoli": {
        "colore": "#E5C36B",
        "lunghezza": 40,
        "spessore": 2,
        "opacita": 0.35
      }
    }
  },
  {
    "nome": "cyberpunk",
    "titolo": "Cyberpunk Neon",
    "descrizione": "Magenta e ciano, circuiti stampati e bagliore al neon.",
    "palette": {
      "sfondo": "#0A0410",
      "superficie": "#170826",
      "campo": "#12061E",
      "pill": "#200B33",
      "accento": "#FF2D95",
      "accentoChiaro": "#FFA6CF",
      "accentoScuro": "#B0155F",
      "argento": "#D8C6E6",
      "argentoScuro": "#9C87B4",
      "testo": "#FFF0F8",
      "testoSuAccento": "#21001A",
      "bordo": "#3A1350"
    },
    "scena": {
      "sfondo": [
        "#0A0410",
        "#22083A"
      ],
      "griglia": {
        "tipo": "linee",
        "colore": "#FF2D95",
        "passo": 46,
        "opacita": 0.1
      },
      "stelle": {
        "numero": 80,
        "colore": "#00F0FF",
        "opacita": 0.55
      },
      "anelli": [
        {
          "r": 1.18,
          "spessore": 2,
          "colore": "#FF2D95",
          "opacita": 0.6
        },
        {
          "r": 1.38,
          "spessore": 1,
          "colore": "#00F0FF",
          "opacita": 0.4,
          "tratteggio": "8 4"
        }
      ],
      "forma": {
        "tipo": "circuito",
        "colore": "#00F0FF",
        "opacita": 0.3
      },
      "angoli": {
        "colore": "#FF2D95",
        "lunghezza": 44,
        "spessore": 2,
        "opacita": 0.5
      },
      "scanline": {
        "colore": "#00F0FF",
        "passo": 6,
        "opacita": 0.04
      }
    }
  }
]
'@

$script:SkinFallback = @(
    [pscustomobject]@{ nome='classica'; titolo='ZAP Classica'; descrizione='L''aspetto attuale: oro su antracite. Sobria, zero distrazioni.'; palette=$null; scena=[pscustomobject]@{ sfondo=@('#0E1116', '#12161C') } },
    [pscustomobject]@{ nome='astronave'; titolo='Cabina Astronave'; descrizione='Console di una nave: lamelle di scafo, griglia di navigazione, spie ai bordi.'; palette=[pscustomobject]@{ sfondo='#05080D'; superficie='#0B1520'; campo='#08111A'; pill='#0E1B27'; accento='#38E1FF'; accentoChiaro='#9AEFFF'; accentoScuro='#1A8FA8'; argento='#B8CBD6'; argentoScuro='#7C96A4'; testo='#E6F6FF'; testoSuAccento='#02131A'; bordo='#17303F' }; scena=[pscustomobject]@{ sfondo=@('#05080D', '#0B1622'); griglia=[pscustomobject]@{ tipo='linee'; colore='#38E1FF'; passo=58; opacita=0.07 }; stelle=[pscustomobject]@{ numero=90; colore='#9AEFFF'; opacita=0.45 }; anelli=@([pscustomobject]@{ r=1.2; spessore=2; colore='#38E1FF'; opacita=0.55 }, [pscustomobject]@{ r=1.34; spessore=1; colore='#38E1FF'; tratteggio='3 7'; opacita=0.28 }); angoli=[pscustomobject]@{ colore='#38E1FF'; lunghezza=54; spessore=2; opacita=0.5 }; scanline=[pscustomobject]@{ colore='#9AEFFF'; passo=4; opacita=0.035 }; forma=[pscustomobject]@{ tipo='astronave'; colore='#38E1FF'; opacita=0.3 } } },
    [pscustomobject]@{ nome='universo'; titolo='Universo / Stella'; descrizione='Campo stellare, nebulosa viola e una stella pulsante dietro la foto.'; palette=[pscustomobject]@{ sfondo='#070312'; superficie='#130A26'; campo='#0F0720'; pill='#1B0F33'; accento='#C9A7FF'; accentoChiaro='#E3D2FF'; accentoScuro='#8B5FD6'; argento='#CFC7E6'; argentoScuro='#9A90B8'; testo='#F3EEFF'; testoSuAccento='#150731'; bordo='#2C1B4A' }; scena=[pscustomobject]@{ sfondo=@('#070312', '#1B0A38'); stelle=[pscustomobject]@{ numero=260; colore='#FFFFFF'; opacita=0.75 }; anelli=@([pscustomobject]@{ r=1.24; spessore=2; colore='#C9A7FF'; opacita=0.5 }, [pscustomobject]@{ r=1.46; spessore=1; colore='#8B5FD6'; tratteggio='2 9'; opacita=0.35 }); forma=[pscustomobject]@{ tipo='stella'; colore='#C9A7FF'; opacita=0.22 } } },
    [pscustomobject]@{ nome='ologramma'; titolo='Ologramma HUD'; descrizione='Il look dell''immagine che hai caricato: anelli concentrici, tacche, verde-ciano.'; palette=[pscustomobject]@{ sfondo='#020C0C'; superficie='#04201C'; campo='#031714'; pill='#062A24'; accento='#2EF2C8'; accentoChiaro='#A6FFEC'; accentoScuro='#159E84'; argento='#B6E5DB'; argentoScuro='#74A79D'; testo='#E4FFF9'; testoSuAccento='#002018'; bordo='#0F3A33' }; scena=[pscustomobject]@{ sfondo=@('#020C0C', '#062A24'); griglia=[pscustomobject]@{ tipo='punti'; colore='#2EF2C8'; passo=34; opacita=0.1 }; anelli=@([pscustomobject]@{ r=1.16; spessore=1; colore='#2EF2C8'; opacita=0.7 }, [pscustomobject]@{ r=1.3; spessore=2; colore='#2EF2C8'; tratteggio='10 6'; opacita=0.45 }, [pscustomobject]@{ r=1.52; spessore=1; colore='#A6FFEC'; tratteggio='2 10'; opacita=0.28 }); angoli=[pscustomobject]@{ colore='#2EF2C8'; lunghezza=38; spessore=1.5; opacita=0.45 }; scanline=[pscustomobject]@{ colore='#2EF2C8'; passo=3; opacita=0.05 }; forma=[pscustomobject]@{ tipo='ologramma'; colore='#2EF2C8'; opacita=0.34 } } },
    [pscustomobject]@{ nome='fantasy'; titolo='Fantasy / Rune'; descrizione='Cerchio runico, oro antico e verde bosco: un grimorio da avventuriero.'; palette=[pscustomobject]@{ sfondo='#0A0F08'; superficie='#131A10'; campo='#101710'; pill='#1A2416'; accento='#E5C36B'; accentoChiaro='#F6E3A8'; accentoScuro='#A8873A'; argento='#CFCBBA'; argentoScuro='#98957F'; testo='#F7F2DE'; testoSuAccento='#1A1406'; bordo='#2E3A26' }; scena=[pscustomobject]@{ sfondo=@('#0A0F08', '#1A2312'); stelle=[pscustomobject]@{ numero=70; colore='#F6E3A8'; opacita=0.35 }; anelli=@([pscustomobject]@{ r=1.22; spessore=2; colore='#E5C36B'; opacita=0.55 }, [pscustomobject]@{ r=1.4; spessore=1; colore='#A8873A'; tratteggio='5 5'; opacita=0.4 }); angoli=[pscustomobject]@{ colore='#E5C36B'; lunghezza=40; spessore=2; opacita=0.35 }; forma=[pscustomobject]@{ tipo='runa'; colore='#E5C36B'; opacita=0.3 } } },
    [pscustomobject]@{ nome='cyberpunk'; titolo='Cyberpunk Neon'; descrizione='Magenta e ciano, circuiti stampati e bagliore al neon.'; palette=[pscustomobject]@{ sfondo='#0A0410'; superficie='#170826'; campo='#12061E'; pill='#200B33'; accento='#FF2D95'; accentoChiaro='#FFA6CF'; accentoScuro='#B0155F'; argento='#D8C6E6'; argentoScuro='#9C87B4'; testo='#FFF0F8'; testoSuAccento='#21001A'; bordo='#3A1350' }; scena=[pscustomobject]@{ sfondo=@('#0A0410', '#22083A'); griglia=[pscustomobject]@{ tipo='linee'; colore='#FF2D95'; passo=46; opacita=0.1 }; stelle=[pscustomobject]@{ numero=80; colore='#00F0FF'; opacita=0.55 }; anelli=@([pscustomobject]@{ r=1.18; spessore=2; colore='#FF2D95'; opacita=0.6 }, [pscustomobject]@{ r=1.38; spessore=1; colore='#00F0FF'; tratteggio='8 4'; opacita=0.4 }); angoli=[pscustomobject]@{ colore='#FF2D95'; lunghezza=44; spessore=2; opacita=0.5 }; scanline=[pscustomobject]@{ colore='#00F0FF'; passo=6; opacita=0.04 }; forma=[pscustomobject]@{ tipo='circuito'; colore='#00F0FF'; opacita=0.3 } } }
)


$script:SkinCache     = $null
$script:SkinUltimoErrore = ''

$script:SkinCorrente  = ''
$script:SkinTimer     = $null
$script:SkinWindow    = $null

function Get-SkinDefinizioni {
    if (-not $script:SkinCache) {
        # v9.4.4: le 6 interfacce di serie sono OGGETTI PowerShell, non JSON.
        # Niente ConvertFrom-Json all'avvio = niente piu' liste vuote su PS 5.1.
        $script:SkinCache = @($script:SkinFallback)
    }
    return $script:SkinCache
}

function Write-SkinLog {
    # v9.4.3: diario delle skin in ui\skin_log.txt (aiuta a capire senza indovinare).
    param([string]$Base, [string]$Testo)
    try {
        if (-not $Base) { return }
        $dir = Join-Path $Base 'ui'
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $f = Join-Path $dir 'skin_log.txt'
        $riga = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '  ' + $Testo + "`r`n"
        [System.IO.File]::AppendAllText($f, $riga, (New-Object System.Text.UTF8Encoding($false)))
    } catch { }
}

function Get-SkinFileScelta {
    param([string]$Base)
    if (-not $Base) { try { $Base = (Get-Location).Path } catch { } }
    return (Join-Path $Base 'ui\skin.json')
}

function Get-SkinAttuale {
    param([string]$Base)
    if ($script:SkinCorrente) { return [string]$script:SkinCorrente }
    try {
        $f = Get-SkinFileScelta $Base
        if (Test-Path -LiteralPath $f) {
            $j = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($j.nome) { $script:SkinCorrente = [string]$j.nome; return [string]$j.nome }
        }
    } catch { }
    return 'classica'
}

function Save-SkinScelta {
    param([string]$Base, [string]$Nome)
    try {
        $f = Get-SkinFileScelta $Base
        $dir = Split-Path -Parent $f
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $txt = '{"nome":"' + [string]$Nome + '"}'
        [System.IO.File]::WriteAllText($f, $txt, (New-Object System.Text.UTF8Encoding($false)))
    } catch { }
}

function Get-SkinNomi {
    param([string]$Base)
    $nomi = New-Object System.Collections.ArrayList
    foreach ($s in @(Get-SkinDefinizioni)) { [void]$nomi.Add([string]$s.nome) }
    try {
        if ($Base) {
            $dir = Join-Path $Base 'ui\skins'
            if (Test-Path -LiteralPath $dir) {
                foreach ($f in @(Get-ChildItem -LiteralPath $dir -Filter *.json -File -ErrorAction SilentlyContinue)) {
                    $n = [System.IO.Path]::GetFileNameWithoutExtension($f.Name).ToLowerInvariant()
                    if ($n -and -not $nomi.Contains($n)) { [void]$nomi.Add($n) }
                }
            }
        }
    } catch { }
    return @($nomi)
}

function Get-Skin {
    param([string]$Nome, [string]$Base)
    $n = ([string]$Nome).Trim().ToLowerInvariant()
    if ($n) {
        foreach ($s in @(Get-SkinDefinizioni)) { if ([string]$s.nome -eq $n) { return $s } }
        try {
            if ($Base) {
                $f = Join-Path $Base ('ui\skins\' + $n + '.json')
                if (Test-Path -LiteralPath $f) { return (Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json) }
            }
        } catch { }
    }
    return (@(Get-SkinDefinizioni) | Select-Object -First 1)
}

function Get-SkinElencoTesto {
    param([string]$Base)
    $corr = Get-SkinAttuale -Base $Base
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('INTERFACCE DISPONIBILI (tasto F9 per cambiarle):')
    foreach ($s in @(Get-SkinDefinizioni)) {
        $segno = '   '
        if ([string]$s.nome -eq $corr) { $segno = ' > ' }
        [void]$righe.Add($segno + [string]$s.nome + '  -  ' + [string]$s.titolo + ': ' + [string]$s.descrizione)
    }
    $extra = @()
    try {
        if ($Base) {
            $dir = Join-Path $Base 'ui\skins'
            if (Test-Path -LiteralPath $dir) { $extra = @(Get-ChildItem -LiteralPath $dir -Filter *.json -File -ErrorAction SilentlyContinue | ForEach-Object { [System.IO.Path]::GetFileNameWithoutExtension($_.Name) }) }
        }
    } catch { }
    if (@($extra).Count -gt 0) { [void]$righe.Add('installate da te: ' + ($extra -join ', ')) }
    [void]$righe.Add('')
    [void]$righe.Add('/skin <nome> per attivarla - /skin-ai <descrizione> per inventarne una')
    return ($righe -join "`n")
}

function Test-SkinValida {
    # Accetta solo skin dichiarative: nessun XAML, nessun colore arbitrario.
    param($Skin)
    $err = New-Object System.Collections.ArrayList
    if (-not $Skin) { return @{ ok = $false; errore = 'skin vuota' } }
    $n = ''
    try { $n = [string]$Skin.nome } catch { }
    if (-not $n) { [void]$err.Add('manca il nome') }
    elseif ($n -notmatch '^[a-z0-9_\-]{2,24}$') { [void]$err.Add('nome non valido (minuscole, 2-24 caratteri)') }
    try {
        if ($Skin.palette) {
            foreach ($k in @('sfondo','superficie','campo','pill','accento','accentoChiaro','accentoScuro','argento','argentoScuro','testo','testoSuAccento','bordo')) {
                $v = $null
                try { $v = [string]$Skin.palette.$k } catch { }
                if ($v -and ($v -notmatch '^#[0-9A-Fa-f]{6}$')) { [void]$err.Add('colore ' + $k + ' non valido: ' + $v) }
            }
        }
        if ($Skin.scena) {
            foreach ($c in @($Skin.scena.sfondo)) {
                $cs = [string]$c
                if ($cs -and ($cs -notmatch '^#[0-9A-Fa-f]{6}$')) { [void]$err.Add('sfondo non valido: ' + $cs) }
            }
            $tipo = ''
            try { $tipo = [string]$Skin.scena.forma.tipo } catch { }
            if ($tipo -and ($tipo -notin @('astronave','stella','ologramma','runa','circuito'))) {
                [void]$err.Add('forma non ammessa: ' + $tipo)
            }
        }
    } catch { }
    if ($err.Count -gt 0) { return @{ ok = $false; errore = ($err -join '; ') } }
    return @{ ok = $true; errore = '' }
}

# ------------------------------ disegno -----------------------------------

function New-SkinColor {
    param([string]$Hex)
    try { return [System.Windows.Media.ColorConverter]::ConvertFromString([string]$Hex) } catch { return [System.Windows.Media.Colors]::Transparent }
}

function New-SkinBrush {
    param([string]$Hex, [double]$Opacita = 1.0)
    try {
        $b = (New-Object System.Windows.Media.BrushConverter).ConvertFromString([string]$Hex)
        try { $b = $b.Clone() } catch { }
        $o = [double]$Opacita
        if ($o -lt 0) { $o = 0 }
        if ($o -gt 1) { $o = 1 }
        $b.Opacity = $o
        return $b
    } catch { return $null }
}

function Invoke-SkinForma {
    param($Canvas, $Forma, [double]$W, [double]$H, [double]$Cx, [double]$Cy, [double]$R)
    if (-not $Forma) { return }
    $tipo = [string]$Forma.tipo
    if (-not $tipo) { return }
    $brush = New-SkinBrush ([string]$Forma.colore) ([double]$Forma.opacita)
    if (-not $brush) { return }

    if ($tipo -eq 'astronave') {
        $p = New-Object System.Windows.Media.PointCollection
        $p.Add([System.Windows.Point]::new($W * 0.50, $H * 0.52))
        $p.Add([System.Windows.Point]::new($W * 0.98, $H * 0.99))
        $p.Add([System.Windows.Point]::new($W * 0.50, $H * 0.90))
        $p.Add([System.Windows.Point]::new($W * 0.02, $H * 0.99))
        $poly = New-Object System.Windows.Shapes.Polygon
        $poly.Points = $p
        $poly.Stroke = $brush
        $poly.StrokeThickness = 2
        $poly.Fill = [System.Windows.Media.Brushes]::Transparent
        [void]$Canvas.Children.Add($poly)
        foreach ($yy in @(($H * 0.66), ($H * 0.73))) {
            $ln = New-Object System.Windows.Shapes.Line
            $ln.X1 = $W * 0.12; $ln.X2 = $W * 0.88; $ln.Y1 = $yy; $ln.Y2 = $yy
            $ln.Stroke = $brush; $ln.StrokeThickness = 1
            [void]$Canvas.Children.Add($ln)
        }
    }
    elseif ($tipo -eq 'stella') {
        $p = New-Object System.Windows.Media.PointCollection
        $ro = [Math]::Max(90.0, $R * 2.6)
        $ri = $ro * 0.44
        for ($i = 0; $i -lt 10; $i++) {
            $ang = (-90.0 + ($i * 36.0)) * [Math]::PI / 180.0
            $rr = $ro
            if ($i % 2 -eq 1) { $rr = $ri }
            $p.Add([System.Windows.Point]::new($Cx + [Math]::Cos($ang) * $rr, $Cy + [Math]::Sin($ang) * $rr))
        }
        $poly = New-Object System.Windows.Shapes.Polygon
        $poly.Points = $p
        $poly.Fill = $brush
        $poly.Stroke = $brush
        $poly.StrokeThickness = 1
        [void]$Canvas.Children.Add($poly)
    }
    elseif ($tipo -eq 'ologramma') {
        foreach ($k in @(1.6, 1.95, 2.35)) {
            $d = $R * 2 * $k
            $e = New-Object System.Windows.Shapes.Ellipse
            $e.Width = $d; $e.Height = $d
            $e.Stroke = $brush; $e.StrokeThickness = 1
            [System.Windows.Controls.Canvas]::SetLeft($e, $Cx - $d / 2)
            [System.Windows.Controls.Canvas]::SetTop($e, $Cy - $d / 2)
            [void]$Canvas.Children.Add($e)
        }
        for ($i = 0; $i -lt 24; $i++) {
            $ang = ($i * 15.0) * [Math]::PI / 180.0
            $r1 = $R * 2.35
            $r2 = $r1 + 10
            $ln = New-Object System.Windows.Shapes.Line
            $ln.X1 = $Cx + [Math]::Cos($ang) * $r1
            $ln.Y1 = $Cy + [Math]::Sin($ang) * $r1
            $ln.X2 = $Cx + [Math]::Cos($ang) * $r2
            $ln.Y2 = $Cy + [Math]::Sin($ang) * $r2
            $ln.Stroke = $brush; $ln.StrokeThickness = 1
            [void]$Canvas.Children.Add($ln)
        }
    }
    elseif ($tipo -eq 'runa') {
        foreach ($k in @(1.9, 2.25)) {
            $d = $R * 2 * $k
            $e = New-Object System.Windows.Shapes.Ellipse
            $e.Width = $d; $e.Height = $d
            $e.Stroke = $brush; $e.StrokeThickness = 1.5
            [System.Windows.Controls.Canvas]::SetLeft($e, $Cx - $d / 2)
            [System.Windows.Controls.Canvas]::SetTop($e, $Cy - $d / 2)
            [void]$Canvas.Children.Add($e)
        }
        for ($i = 0; $i -lt 8; $i++) {
            $ang = ($i * 45.0) * [Math]::PI / 180.0
            $rr = $R * 2.25
            $px = $Cx + [Math]::Cos($ang) * $rr
            $py = $Cy + [Math]::Sin($ang) * $rr
            $p = New-Object System.Windows.Media.PointCollection
            $p.Add([System.Windows.Point]::new($px, $py - 9))
            $p.Add([System.Windows.Point]::new($px + 7, $py))
            $p.Add([System.Windows.Point]::new($px, $py + 9))
            $p.Add([System.Windows.Point]::new($px - 7, $py))
            $poly = New-Object System.Windows.Shapes.Polygon
            $poly.Points = $p
            $poly.Fill = $brush
            [void]$Canvas.Children.Add($poly)
        }
    }
    elseif ($tipo -eq 'circuito') {
        $passo = 70.0
        $base = @(@(0, 0, 1, 1), @($W, 0, -1, 1), @(0, $H, 1, -1), @($W, $H, -1, -1))
        foreach ($b in $base) {
            $x0 = [double]$b[0]; $y0 = [double]$b[1]; $sx = [double]$b[2]; $sy = [double]$b[3]
            $p = New-Object System.Windows.Media.PointCollection
            $p.Add([System.Windows.Point]::new($x0 + $sx * 6, $y0 + $sy * 6))
            $p.Add([System.Windows.Point]::new($x0 + $sx * ($passo * 2), $y0 + $sy * 6))
            $p.Add([System.Windows.Point]::new($x0 + $sx * ($passo * 2), $y0 + $sy * ($passo * 1.3)))
            $p.Add([System.Windows.Point]::new($x0 + $sx * ($passo * 3.2), $y0 + $sy * ($passo * 1.3)))
            $poly = New-Object System.Windows.Shapes.Polyline
            $poly.Points = $p
            $poly.Stroke = $brush
            $poly.StrokeThickness = 1.5
            [void]$Canvas.Children.Add($poly)
        }
    }
}

function Invoke-SkinDisegna {
    param($Window, [string]$Base)
    if (-not $Window) { return }
    try {
        $canvas = $Window.FindName('SkinPanel')
        if (-not $canvas) { return }
        $front = $Window.FindName('SkinLayer')
        $WW = 0.0; $HH = 0.0
        try { $WW = [double]$Window.ActualWidth; $HH = [double]$Window.ActualHeight } catch { }
        try { if ($front) { $front.Children.Clear() } } catch { }

        $skin = Get-Skin -Nome (Get-SkinAttuale -Base $Base) -Base $Base
        if (-not $skin) { return }
        $sc = $skin.scena
        if (-not $sc) { $sc = [pscustomobject]@{} }

        $W = [double]$canvas.ActualWidth
        $H = [double]$canvas.ActualHeight
        if ($W -lt 40 -or $H -lt 40) { return }

        $canvas.Children.Clear()

        # --- fondo a gradiente del pannello (sostituisce i puntini) ---
        try {
            if ($sc.sfondo -and @($sc.sfondo).Count -ge 2) {
                $br = New-Object System.Windows.Media.LinearGradientBrush
                $br.StartPoint = [System.Windows.Point]::new(0, 0)
                $br.EndPoint = [System.Windows.Point]::new(0.30, 1)
                $br.GradientStops.Add((New-Object System.Windows.Media.GradientStop (New-SkinColor ([string]$sc.sfondo[0])), 0.0))
                $br.GradientStops.Add((New-Object System.Windows.Media.GradientStop (New-SkinColor ([string]$sc.sfondo[1])), 1.0))
                $rect = New-Object System.Windows.Shapes.Rectangle
                $rect.Width = $W; $rect.Height = $H
                $rect.Fill = $br
                [System.Windows.Controls.Canvas]::SetLeft($rect, 0)
                [System.Windows.Controls.Canvas]::SetTop($rect, 0)
                [void]$canvas.Children.Add($rect)
                $root = $Window.FindName('RootSurface')
                if ($root) { $root.Background = (New-SkinBrush ([string]$sc.sfondo[0]) 1.0) }
            }
        } catch { }

        # --- griglia ---
        try {
            if ($sc.griglia) {
                $g = $sc.griglia
                $passo = [double]$g.passo
                if ($passo -lt 10) { $passo = 40 }
                $gb = New-SkinBrush ([string]$g.colore) ([double]$g.opacita)
                if ($gb) {
                    $tipoG = [string]$g.tipo
                    if ($tipoG -eq 'punti') {
                        $max = 600; $n = 0
                        for ($x = $passo; $x -lt $W; $x += $passo) {
                            for ($y = $passo; $y -lt $H; $y += $passo) {
                                if ($n -ge $max) { break }
                                $e = New-Object System.Windows.Shapes.Ellipse
                                $e.Width = 2; $e.Height = 2
                                $e.Fill = $gb
                                [System.Windows.Controls.Canvas]::SetLeft($e, $x)
                                [System.Windows.Controls.Canvas]::SetTop($e, $y)
                                [void]$canvas.Children.Add($e)
                                $n++
                            }
                        }
                    } else {
                        for ($x = $passo; $x -lt $W; $x += $passo) {
                            $ln = New-Object System.Windows.Shapes.Line
                            $ln.X1 = $x; $ln.X2 = $x; $ln.Y1 = 0; $ln.Y2 = $H
                            $ln.Stroke = $gb; $ln.StrokeThickness = 1
                            [void]$canvas.Children.Add($ln)
                        }
                        for ($y = $passo; $y -lt $H; $y += $passo) {
                            $ln = New-Object System.Windows.Shapes.Line
                            $ln.X1 = 0; $ln.X2 = $W; $ln.Y1 = $y; $ln.Y2 = $y
                            $ln.Stroke = $gb; $ln.StrokeThickness = 1
                            [void]$canvas.Children.Add($ln)
                        }
                    }
                }
            }
        } catch { }

        # --- stelle ---
        try {
            if ($sc.stelle -and [int]$sc.stelle.numero -gt 0) {
                $st = $sc.stelle
                $rnd = New-Object System.Random 20261108
                $sb = New-SkinBrush ([string]$st.colore) ([double]$st.opacita)
                $num = [int]$st.numero
                if ($num -gt 300) { $num = 300 }
                if ($sb) {
                    for ($i = 0; $i -lt $num; $i++) {
                        $d = 1.0 + ($rnd.NextDouble() * 2.0)
                        $e = New-Object System.Windows.Shapes.Ellipse
                        $e.Width = $d; $e.Height = $d
                        $e.Fill = $sb
                        [System.Windows.Controls.Canvas]::SetLeft($e, ($rnd.NextDouble() * $W))
                        [System.Windows.Controls.Canvas]::SetTop($e, ($rnd.NextDouble() * $H))
                        [void]$canvas.Children.Add($e)
                    }
                }
            }
        } catch { }

        # --- posizione della foto (per gli anelli) ---
        $cx = $W / 2
        $cy = $H * 0.36
        $raggio = 105.0
        try {
            $av = $Window.FindName('Avatar')
            if ($av -and $av.ActualWidth -gt 20) {
                $pt = $av.TransformToAncestor($canvas).Transform([System.Windows.Point]::new(0, 0))
                $cx = $pt.X + ($av.ActualWidth / 2)
                $cy = $pt.Y + ($av.ActualHeight / 2)
                $raggio = [Math]::Max($av.ActualWidth, $av.ActualHeight) / 2
            }
        } catch { }

        # --- forma decorativa ---
        try { Invoke-SkinForma -Canvas $canvas -Forma $sc.forma -W $W -H $H -Cx $cx -Cy $cy -R $raggio } catch { }

        # --- anelli attorno alla foto ---
        try {
            foreach ($an in @($sc.anelli)) {
                if (-not $an) { continue }
                $k = [double]$an.r
                if ($k -lt 1) { $k = 1.1 }
                $d = $raggio * 2 * $k
                $e = New-Object System.Windows.Shapes.Ellipse
                $e.Width = $d; $e.Height = $d
                $e.Stroke = New-SkinBrush ([string]$an.colore) ([double]$an.opacita)
                $sp = [double]$an.spessore
                if ($sp -lt 1) { $sp = 1 }
                $e.StrokeThickness = $sp
                $tr = [string]$an.tratteggio
                if ($tr) {
                    $parti = @($tr -split '\s+' | Where-Object { $_ })
                    $dash = New-Object System.Windows.DoubleCollection
                    foreach ($pp in $parti) { $dash.Add([double]$pp) }
                    if ($dash.Count -gt 0) { $e.StrokeDashArray = $dash }
                }
                [System.Windows.Controls.Canvas]::SetLeft($e, $cx - $d / 2)
                [System.Windows.Controls.Canvas]::SetTop($e, $cy - $d / 2)
                [void]$canvas.Children.Add($e)
            }
        } catch { }

        # --- cornice della finestra + scanline (strato SOPRA, molto tenue) ---
        try {
            if ($front -and $WW -gt 80 -and $HH -gt 80) {
                if ($sc.angoli) {
                    $a = $sc.angoli
                    $L = [double]$a.lunghezza
                    if ($L -lt 10) { $L = 40 }
                    $ab = New-SkinBrush ([string]$a.colore) ([double]$a.opacita)
                    $sp = [double]$a.spessore
                    if ($sp -lt 1) { $sp = 1 }
                    if ($ab) {
                        $combi = @(
                            @(0, 0, 1, 1), @($WW, 0, -1, 1), @(0, $HH, 1, -1), @($WW, $HH, -1, -1)
                        )
                        foreach ($c in $combi) {
                            $x0 = [double]$c[0]; $y0 = [double]$c[1]; $dx = [double]$c[2]; $dy = [double]$c[3]
                            $p = New-Object System.Windows.Media.PointCollection
                            $p.Add([System.Windows.Point]::new($x0 + $dx * $L, $y0 + $dy * 2))
                            $p.Add([System.Windows.Point]::new($x0 + $dx * 2, $y0 + $dy * 2))
                            $p.Add([System.Windows.Point]::new($x0 + $dx * 2, $y0 + $dy * $L))
                            $pl = New-Object System.Windows.Shapes.Polyline
                            $pl.Points = $p
                            $pl.Stroke = $ab
                            $pl.StrokeThickness = $sp
                            [void]$front.Children.Add($pl)
                        }
                    }
                }
                if ($sc.scanline) {
                    $sl = $sc.scanline
                    $passo = [double]$sl.passo
                    if ($passo -lt 2) { $passo = 4 }
                    $sb = New-SkinBrush ([string]$sl.colore) ([double]$sl.opacita)
                    if ($sb) {
                        for ($y = 0; $y -lt $HH; $y += $passo) {
                            $r = New-Object System.Windows.Shapes.Rectangle
                            $r.Width = $WW; $r.Height = 1
                            $r.Fill = $sb
                            [System.Windows.Controls.Canvas]::SetLeft($r, 0)
                            [System.Windows.Controls.Canvas]::SetTop($r, $y)
                            [void]$front.Children.Add($r)
                        }
                    }
                }
            }
        } catch { }
    } catch { }
}

function Request-SkinRedraw {
    param($Window)
    $script:SkinWindow = $Window
    try {
        if (-not $script:SkinTimer) {
            $script:SkinTimer = New-Object System.Windows.Threading.DispatcherTimer
            $script:SkinTimer.Interval = [TimeSpan]::FromMilliseconds(180)
            $script:SkinTimer.Add_Tick({
                try { $script:SkinTimer.Stop() } catch { }
                try { Invoke-SkinDisegna -Window $script:SkinWindow } catch { }
            })
        }
        $script:SkinTimer.Stop()
        $script:SkinTimer.Start()
    } catch { }
}

function Test-PaletteSicura {
    # True solo se ogni colore della palette e' una SINGOLA stringa #RRGGBB.
    # Serve a impedire che un elenco di colori arrivi a WPF (errore v9.4).
    param($Palette)
    try {
        if (-not $Palette) { return $false }
        foreach ($k in @('sfondo','superficie','campo','pill','accento','accentoChiaro','accentoScuro',
                         'argento','argentoScuro','testo','testoSuAccento','bordo')) {
            $v = $Palette[$k]
            if ($null -eq $v) { return $false }
            if ($v -is [array]) { return $false }
            if (([string]$v) -notmatch '^#[0-9A-Fa-f]{6}$') { return $false }
        }
        return $true
    } catch { return $false }
}

function Set-Skin {
    param($Window, [string]$Base, [string]$Nome, [switch]$Silenzioso)
    # v9.4.1: se per qualsiasi motivo arrivasse un ELENCO di skin, prendo quella
    # giusta per nome. (L'elenco produceva "bordo" = tutti i colori appiccicati.)
    $cercato = ([string]$Nome).Trim().ToLowerInvariant()
    $trovate = @(Get-Skin -Nome $Nome -Base $Base)
    $skin = @($trovate | Where-Object { $_ -and ([string]$_.nome -eq $cercato) }) | Select-Object -First 1
    if (-not $skin -and $trovate.Count -gt 0) { $skin = $trovate[0] }
    if (-not $skin) {
        $script:SkinUltimoErrore = 'skin non trovata: ' + [string]$Nome
        try { Write-SkinLog -Base $Base -Testo $script:SkinUltimoErrore } catch { }
        return ('Skin non trovata: ' + [string]$Nome + ' (definizioni: ' + @(Get-SkinDefinizioni).Count + ')')
    }
    $nome = [string]$skin.nome
    try { Write-SkinLog -Base $Base -Testo ('applico la skin: ' + $nome) } catch { }

    # 1) colori dei comandi (tutti i pulsanti restano dove sono)
    try {
        if ($skin.palette) {
            $tinte = @('sfondo','superficie','campo','pill','accento','accentoChiaro','accentoScuro',
                       'argento','argentoScuro','testo','testoSuAccento','bordo')
            $lette = @{}
            foreach ($k in $tinte) {
                $v = $null
                try { $v = $skin.palette.$k } catch { }
                if ($v -is [array]) { $v = $null }          # elenco = guasto: lo ignoro
                $vs = ([string]$v).Trim()
                if ($vs -match '^#[0-9A-Fa-f]{6}$') { $lette[$k] = $vs.ToUpper() }
            }
            if ($lette.Count -ge 4) {
                $pal = Get-PaletteDefault
                foreach ($k in $tinte) { if ($lette.ContainsKey($k)) { $pal[$k] = $lette[$k] } }
                $pal.preset = $nome
                if (Test-PaletteSicura $pal) {
                    $s = $null
                    try { $s = (Get-Variable -Name sync -ValueOnly -ErrorAction SilentlyContinue) } catch { }
                    if ($s -and (Get-Command Applica-Palette -ErrorAction SilentlyContinue)) { Applica-Palette $s $Window $pal }
                    try { Write-Fase ('interfaccia ' + $nome + ': colori ' + [string]$pal.accento + ' su ' + [string]$pal.sfondo) } catch { }
                } else {
                    try { Write-Fase ('interfaccia ' + $nome + ': colori non validi, resto con la palette di ZAP') } catch { }
                }
            }
        }
    } catch {
        try { Write-Fase ('interfaccia ' + $nome + ': colori non applicati -> ' + $_.Exception.Message) } catch { }
    }

    # 2) FONDO DEL PANNELLO: assegnazione diretta, si vede per forza.
    #    Non passa dalla palette ne' dal disegno: sono due righe su elementi noti.
    try {
        $sf = @()
        try { $sf = @($skin.scena.sfondo) } catch { }
        if ($sf.Count -ge 2) {
            $c1 = [string]$sf[0]; $c2 = [string]$sf[1]
            if (($c1 -match '^#[0-9A-Fa-f]{6}$') -and ($c2 -match '^#[0-9A-Fa-f]{6}$')) {
                $br = New-Object System.Windows.Media.LinearGradientBrush
                $br.StartPoint = [System.Windows.Point]::new(0, 0)
                $br.EndPoint = [System.Windows.Point]::new(0.35, 1)
                $br.GradientStops.Add((New-Object System.Windows.Media.GradientStop (New-SkinColor $c1), 0.0))
                $br.GradientStops.Add((New-Object System.Windows.Media.GradientStop (New-SkinColor $c2), 1.0))
                $pann = $Window.FindName('PannelloSinistro')
                if ($pann) { $pann.Background = $br }
                $rad = $Window.FindName('RootSurface')
                if ($rad) { $rad.Background = New-SkinBrush $c1 1.0 }
                try { Write-SkinLog -Base $Base -Testo ('fondo applicato: ' + $c1 + ' -> ' + $c2) } catch { }
            }
        }
    } catch {
        $script:SkinUltimoErrore = 'fondo non applicato: ' + $_.Exception.Message
        try { Write-SkinLog -Base $Base -Testo $script:SkinUltimoErrore } catch { }
    }

    # 3) disegno
    $script:SkinCorrente = $nome
    try { Save-SkinScelta -Base $Base -Nome $nome } catch { }
    try { Invoke-SkinDisegna -Window $Window -Base $Base }
    catch {
        $script:SkinUltimoErrore = 'disegno non riuscito: ' + $_.Exception.Message
        try { Write-SkinLog -Base $Base -Testo $script:SkinUltimoErrore } catch { }
    }

    # 3) RETE DI SICUREZZA (v9.4.1): se la palette in uso non e' sana la riporto
    #    ai valori di ZAP. Cosi' un errore di colore non puo' piu' bloccare
    #    l'apertura della finestra (era esattamente questo il blocco di v9.4).
    try {
        $s2 = $null
        try { $s2 = (Get-Variable -Name sync -ValueOnly -ErrorAction SilentlyContinue) } catch { }
        if ($s2 -and -not (Test-PaletteSicura $s2.Palette)) {
            $s2.Palette = Get-PaletteDefault
            $s2.PaletteCorr = Get-PaletteDefault
            try { Write-Fase 'palette non valida rilevata: ripristinata quella di ZAP' } catch { }
        }
    } catch { }

    if (-not $Silenzioso) { try { Write-Fase ('interfaccia: ' + $nome) } catch { } }
    return ('Interfaccia attiva: ' + [string]$skin.titolo + ' (' + $nome + ')')
}

function Set-SkinSuccessiva {
    param($Window, [string]$Base, [int]$Verso = 1)
    $nomi = @(Get-SkinNomi -Base $Base)
    if ($nomi.Count -eq 0) { return 'Nessuna interfaccia disponibile.' }
    $corr = Get-SkinAttuale -Base $Base
    $i = [Array]::IndexOf($nomi, $corr)
    if ($i -lt 0) { $i = 0 }
    $i = ($i + $Verso) % $nomi.Count
    if ($i -lt 0) { $i = $nomi.Count - 1 }
    return (Set-Skin -Window $Window -Base $Base -Nome ([string]$nomi[$i]))
}

function Initialize-Skin {
    param($Window, [string]$Base)
    $n = Get-SkinAttuale -Base $Base
    $r = ''
    try {
        $r = Set-Skin -Window $Window -Base $Base -Nome $n -Silenzioso
    } catch {
        # una skin che non si disegna non deve impedire a ZAP di partire
        try { Write-Fase ('skin non applicata, resto con la classica -> ' + $_.Exception.Message) } catch { }
        try { $script:SkinCorrente = 'classica' } catch { }
    }
    try { $Window.Add_ContentRendered({ try { Invoke-SkinDisegna -Window $Window -Base $Base } catch { } }) } catch { }
    try { $Window.Add_SizeChanged({ try { Request-SkinRedraw -Window $Window } catch { } }) } catch { }
    return $r
}

function Import-SkinDaUrl {
    param($sync, $Window, [string]$Base, [string]$Url)
    if (-not $Url) { return 'Indica l''indirizzo: /skin-scarica https://.../skin.json' }
    if ($Url -notmatch '^https?://') { return '!L''indirizzo deve iniziare con http:// o https://' }
    $txt = ''
    try {
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        $txt = (Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 30).Content
    } catch { return ('!Scarico non riuscito: ' + $_.Exception.Message) }
    $i = $txt.IndexOf('{'); $j = $txt.LastIndexOf('}')
    if ($i -lt 0 -or $j -le $i) { return '!Il file scaricato non contiene un JSON di skin.' }
    $obj = $null
    try { $obj = $txt.Substring($i, $j - $i + 1) | ConvertFrom-Json } catch { return ('!JSON non valido: ' + $_.Exception.Message) }
    $v = Test-SkinValida $obj
    if (-not $v.ok) { return ('!Skin rifiutata: ' + $v.errore) }
    try {
        $dir = Join-Path $Base 'ui\skins'
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $f = Join-Path $dir ([string]$obj.nome + '.json')
        [System.IO.File]::WriteAllText($f, ($obj | ConvertTo-Json -Depth 8), (New-Object System.Text.UTF8Encoding($false)))
    } catch { return ('!Non riesco a salvare la skin: ' + $_.Exception.Message) }
    $r = Set-Skin -Window $Window -Base $Base -Nome ([string]$obj.nome)
    return ('Skin scaricata e installata.' + "`n" + $r)
}

function New-SkinDaAI {
    param($sync, $Window, [string]$Base, [string]$Testo)
    if (-not $Testo) { return 'Dimmi come la vuoi: /skin-ai una stazione spaziale anni 70, arancione e ambra' }
    $esempio = '{"nome":"mia_skin","titolo":"Mia Skin","descrizione":"fatta su misura","palette":{"sfondo":"#0A0A12","superficie":"#12121F","campo":"#0F0F1A","pill":"#1A1A2A","accento":"#FF8800","accentoChiaro":"#FFC46B","accentoScuro":"#A85500","argento":"#C9CFD6","argentoScuro":"#9AA4AE","testo":"#F0F0F8","testoSuAccento":"#1A0E00","bordo":"#2A2A3D"},"scena":{"sfondo":["#0A0A12","#1A1A2A"],"stelle":{"numero":120,"colore":"#FFFFFF","opacita":0.6},"anelli":[{"r":1.2,"spessore":2,"colore":"#FF8800","opacita":0.5}],"angoli":{"colore":"#FF8800","lunghezza":40,"spessore":2,"opacita":0.4},"forma":{"tipo":"ologramma","colore":"#FF8800","opacita":0.3}}}'
    $prompt = @"
Inventa una interfaccia (skin) per ZAP. Rispondi SOLO con un oggetto JSON valido: niente testo, niente commenti, niente blocchi di codice.
Schema esatto da copiare cambiando i valori:
$esempio

Regole: "nome" solo lettere minuscole e underscore; TUTTI i colori in formato #RRGGBB; "scena.forma.tipo" puo essere SOLO uno tra: astronave, stella, ologramma, runa, circuito; "tratteggio" facoltativo (esempio "4 6"); "opacita" tra 0 e 1.
Descrizione dell'utente: $Testo
"@
    $msgs = @(
        @{ role = 'system'; content = 'Sei un designer di interfacce. Rispondi esclusivamente con JSON valido, senza spiegazioni.' },
        @{ role = 'user'; content = $prompt }
    )
    $txt = ''
    try {
        $msg = Invoke-Chat $sync $msgs @()
        $txt = ConvertTo-PlainString $msg.content
    } catch { return ('!IA non disponibile: ' + $_.Exception.Message) }
    $i = $txt.IndexOf('{'); $j = $txt.LastIndexOf('}')
    if ($i -lt 0 -or $j -le $i) { return '!La IA non ha restituito un JSON utilizzabile. Riprova con una descrizione piu semplice.' }
    $obj = $null
    try { $obj = $txt.Substring($i, $j - $i + 1) | ConvertFrom-Json } catch { return ('!JSON non valido: ' + $_.Exception.Message) }
    $v = Test-SkinValida $obj
    if (-not $v.ok) { return ('!Skin rifiutata: ' + $v.errore) }
    try {
        $dir = Join-Path $Base 'ui\skins'
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $f = Join-Path $dir ([string]$obj.nome + '.json')
        [System.IO.File]::WriteAllText($f, ($obj | ConvertTo-Json -Depth 8), (New-Object System.Text.UTF8Encoding($false)))
    } catch { return ('!Non riesco a salvare la skin: ' + $_.Exception.Message) }
    $r = Set-Skin -Window $Window -Base $Base -Nome ([string]$obj.nome)
    return ('Interfaccia inventata e salvata in ui\skins\' + [string]$obj.nome + '.json' + "`n" + $r)
}
