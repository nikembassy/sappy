﻿# telemetria.ps1 -- v9.1 CABINA DI REGIA: cosa stanno facendo gli agenti, in tempo reale.
# ---------------------------------------------------------------------------
#  Problema che risolve: la squadra lavora dentro un runspace separato. La finestra
#  non sa cosa sta succedendo finche' l'agente non ha finito. Qui invece ogni passo
#  viene scritto su disco (memory\telemetria) e la cabina lo legge 1 volta al secondo.
#  Cosi' si vede: chi sta lavorando, a che punto e', da quanti secondi, con quale
#  strumento, l'ultima riga prodotta e se qualcosa si e' bloccato.
#
#  File prodotti:
#    memory\telemetria\stato.json          -> fotografia istantanea dei 7 agenti
#    memory\telemetria\eventi-AAAAMMGG.jsonl -> registro append-only (una riga = un evento)
#
#  Regole di sicurezza (watchdog), valutate dalla cabina:
#    - un agente che resta su un passo oltre max_secondi_step  -> STOP
#    - nessun evento per oltre max_silenzio                   -> ATTENZIONE (silenzio)
#    - stesso comando ripetuto max_ripetizioni volte          -> STOP (loop)
#    - oltre max_chiamate strumenti                           -> STOP (budget)
#    - oltre max_errori errori                                -> ATTENZIONE
#  Le funzioni marcate [PURA] non toccano Windows e sono coperte dai test.
# ---------------------------------------------------------------------------

function Get-TelemetriaLimitiDefault {
    # Limiti del watchdog. Sovrascrivibili da config.json -> sicurezza_agenti.
    return @{
        max_secondi_step = 240
        max_silenzio     = 120
        max_ripetizioni  = 3
        max_chiamate     = 40
        max_errori       = 3
    }
}

function Get-TelemetriaLimiti {
    param($sync)
    $l = Get-TelemetriaLimitiDefault
    try {
        $c = $sync.Config.sicurezza_agenti
        if ($c) {
            foreach ($k in @('max_secondi_step', 'max_silenzio', 'max_ripetizioni', 'max_chiamate', 'max_errori')) {
                try { if ($null -ne $c.$k -and [int]$c.$k -gt 0) { $l[$k] = [int]$c.$k } } catch { }
            }
        }
    } catch { }
    return $l
}

function Get-TelemetriaDir {
    param([string]$Base)
    if (-not $Base) { $Base = (Get-Location).Path }
    return (Join-Path $Base 'memory\telemetria')
}

function Get-TelemetriaStatoPercorso {
    param([string]$Base)
    return (Join-Path (Get-TelemetriaDir $Base) 'stato.json')
}

function Get-TelemetriaLogPercorso {
    param([string]$Base, $Quando = $null)
    if (-not $Quando) { $Quando = Get-Date }
    return (Join-Path (Get-TelemetriaDir $Base) ('eventi-' + (Get-Date $Quando -Format 'yyyyMMdd') + '.jsonl'))
}

function Get-TelemetriaIds {
    # I sette agenti della squadra. Se agenti.ps1 e' caricato uso il suo catalogo,
    # cosi' se domani se ne aggiunge uno la cabina lo mostra da sola.
    $out = New-Object System.Collections.ArrayList
    try {
        if (Get-Command Get-AgentiCatalogo -ErrorAction SilentlyContinue) {
            foreach ($a in (Get-AgentiCatalogo)) { [void]$out.Add([string]$a.id) }
        }
    } catch { }
    if ($out.Count -eq 0) {
        foreach ($id in @('aurelio', 'serafina', 'leonardo', 'vittoria', 'dante', 'orione', 'zeus')) { [void]$out.Add($id) }
    }
    return @($out)
}

function New-TelemetriaAgente {
    param([string]$Id)
    $nome = ([string]$Id).ToUpperInvariant()
    $titolo = ''
    $oro = '#D4AF37'
    try {
        if (Get-Command Get-AgenteById -ErrorAction SilentlyContinue) {
            $a = Get-AgenteById $Id
            if ($a) { $nome = [string]$a.nome; $titolo = [string]$a.titolo; $oro = [string]$a.oro }
        }
    } catch { }
    return [ordered]@{
        id          = [string]$Id
        nome        = $nome
        titolo      = $titolo
        oro         = $oro
        stato       = 'fermo'      # fermo | in_coda | pensa | scrive | strumento | fatto | errore | fermato
        azione      = ''
        dettaglio   = ''
        passo       = 0
        totale      = 0
        inizio      = ''
        ultima      = ''
        ms          = 0
        strumento   = ''
        comando     = ''
        file        = ''
        ultima_riga = ''
        chiamate    = 0
        errori      = 0
        ripetizioni = 0
        fermato     = $false
    }
}

function New-TelemetriaStato {
    # [PURA] Stato iniziale completo.
    param($Ids = $null)
    if ($null -eq $Ids) { $Ids = Get-TelemetriaIds }
    $agenti = [ordered]@{}
    foreach ($id in @($Ids)) { $agenti[[string]$id] = (New-TelemetriaAgente ([string]$id)) }
    return [ordered]@{
        versione  = 1
        aggiornato = (Get-Date -Format 'o')
        squadra   = [ordered]@{ stato = 'fermo'; passo = 0; totale = 0; richiesta = ''; cartella = ''; avviata = '' }
        agenti    = $agenti
    }
}

function Get-TelemetriaAgente {
    # Legge una voce dallo stato, creandola se manca (stato.json puo' essere vecchio).
    param($Stato, [string]$Id)
    if ($null -eq $Stato) { return (New-TelemetriaAgente $Id) }
    $a = $null
    try { $a = $Stato.agenti.$Id } catch { $a = $null }
    if ($null -eq $a) {
        $nuovo = New-TelemetriaAgente $Id
        try { $Stato.agenti | Add-Member -NotePropertyName $Id -NotePropertyValue $nuovo -Force } catch { }
        return $nuovo
    }
    return $a
}

function Read-TelemetriaStato {
    # Legge stato.json. Se non c'e' o e' illeggibile (scrittura in corso) riprova.
    param([string]$Base)
    $p = Get-TelemetriaStatoPercorso $Base
    for ($t = 0; $t -lt 3; $t++) {
        try {
            if (Test-Path -LiteralPath $p) {
                $raw = [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8)
                if ($raw -and $raw.Trim()) {
                    $o = $raw | ConvertFrom-Json
                    if ($o) { return $o }
                }
            }
            return (New-TelemetriaStato)
        } catch {
            Start-Sleep -Milliseconds 40
        }
    }
    return (New-TelemetriaStato)
}

function Save-TelemetriaStato {
    param([string]$Base, $Stato)
    try {
        $dir = Get-TelemetriaDir $Base
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $p = Get-TelemetriaStatoPercorso $Base
        $tmp = $p + '.tmp'
        try { $Stato.aggiornato = (Get-Date -Format 'o') } catch { }
        $json = ($Stato | ConvertTo-Json -Depth 8)
        [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
        # PS 5.1: [IO.File]::Move non ha la sovrascrittura a 3 argomenti.
        try {
            if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue }
            [System.IO.File]::Move($tmp, $p)
        } catch {
            Copy-Item -LiteralPath $tmp -Destination $p -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
        }
        return $true
    } catch { return $false }
}

function Write-TelemetriaEvento {
    # Un evento = una riga nel registro + aggiornamento dello stato dell'agente.
    # Non deve MAI far fallire il lavoro dell'agente: ogni errore qui viene ingoiato.
    param(
        [string]$Base,
        [string]$Id,
        [string]$Stato = '',
        [string]$Azione = '',
        [string]$Dettaglio = '',
        [int]$Passo = -1,
        [int]$Totale = -1,
        [int]$Ms = -1,
        [string]$File = '',
        [string]$UltimaRiga = '',
        [string]$Strumento = '',
        [string]$Comando = '',
        [string]$Errore = ''
    )
    try {
        if (-not $Id) { return $false }
        $s = Read-TelemetriaStato $Base
        $a = Get-TelemetriaAgente $s $Id
        $ora = Get-Date -Format 'o'

        if ($Stato) { $a.stato = $Stato }
        if ($Azione) { $a.azione = $Azione }
        if ($Dettaglio) { $a.dettaglio = $Dettaglio }
        if ($Passo -ge 0) { $a.passo = $Passo }
        if ($Totale -ge 0) { $a.totale = $Totale }
        if ($Ms -ge 0) { $a.ms = $Ms }
        if ($File) { $a.file = $File }
        if ($Strumento) { $a.strumento = $Strumento }
        if ($Errore) { $a.errori = [int]$a.errori + 1 }
        if ($Comando) {
            # anti-loop: conto quante volte di fila lo stesso comando
            if ([string]$a.comando -eq $Comando) { $a.ripetizioni = [int]$a.ripetizioni + 1 }
            else { $a.ripetizioni = 0 }
            $a.comando = $Comando
        }
        if ($UltimaRiga) {
            $u = [string]$UltimaRiga
            $u = $u -replace "`r?`n", ' '
            if ($u.Length -gt 240) { $u = $u.Substring(0, 240) + '...' }
            $a.ultima_riga = $u
        }
        if ($Stato -eq 'pensa' -and -not $a.inizio) { $a.inizio = $ora }
        $a.ultima = $ora
        if ($Stato -eq 'strumento') { $a.chiamate = [int]$a.chiamate + 1 }
        if ($Stato -eq 'fatto' -or $Stato -eq 'errore' -or $Stato -eq 'fermato') {
            if ($a.inizio) {
                try { $a.ms = [int]((Get-Date) - [datetime]::Parse([string]$a.inizio)).TotalMilliseconds } catch { }
            }
        }
        [void](Save-TelemetriaStato $Base $s)

        $riga = [ordered]@{
            ora     = $ora
            agente  = $Id
            stato   = $Stato
            azione  = $Azione
            passo   = $Passo
            totale  = $Totale
            ms      = $Ms
            esito   = $Errore
            riga    = $UltimaRiga
        }
        $dir = Get-TelemetriaDir $Base
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $log = Get-TelemetriaLogPercorso $Base
        $line = ($riga | ConvertTo-Json -Compress -Depth 4)
        [System.IO.File]::AppendAllText($log, ($line + "`n"), (New-Object System.Text.UTF8Encoding($false)))
        return $true
    } catch { return $false }
}

function Set-TelemetriaSquadra {
    # Stato complessivo della squadra (richiesta in corso, cartella, passo).
    param([string]$Base, [string]$Stato = '', [string]$Richiesta = '', [string]$Cartella = '', [int]$Passo = -1, [int]$Totale = -1)
    try {
        $s = Read-TelemetriaStato $Base
        if ($Stato) { $s.squadra.stato = $Stato }
        if ($Richiesta) {
            $r = [string]$Richiesta
            if ($r.Length -gt 300) { $r = $r.Substring(0, 300) + '...' }
            $s.squadra.richiesta = $r
        }
        if ($Cartella) { $s.squadra.cartella = $Cartella }
        if ($Passo -ge 0) { $s.squadra.passo = $Passo }
        if ($Totale -ge 0) { $s.squadra.totale = $Totale }
        if ($Stato -eq 'al_lavoro' -and -not $s.squadra.avviata) { $s.squadra.avviata = (Get-Date -Format 'o') }
        [void](Save-TelemetriaStato $Base $s)
        return $true
    } catch { return $false }
}

function Reset-TelemetriaAgenti {
    # Riporta tutti gli agenti a 'fermo' (inizio di un nuovo giro di squadra).
    param([string]$Base, [switch]$MantieniLog)
    try {
        $s = Read-TelemetriaStato $Base
        foreach ($id in @(Get-TelemetriaIds)) {
            $a = Get-TelemetriaAgente $s $id
            $a.stato = 'fermo'
            $a.azione = ''
            $a.dettaglio = ''
            $a.passo = 0
            $a.totale = 0
            $a.inizio = ''
            $a.ms = 0
            $a.strumento = ''
            $a.comando = ''
            $a.file = ''
            $a.ultima_riga = ''
            $a.chiamate = 0
            $a.errori = 0
            $a.ripetizioni = 0
            $a.fermato = $false
        }
        $s.squadra.stato = 'fermo'
        $s.squadra.passo = 0
        $s.squadra.totale = 0
        [void](Save-TelemetriaStato $Base $s)
        return $true
    } catch { return $false }
}

function Test-TelemetriaAllarme {
    # [PURA] Decide se un agente va fermato o segnalato.
    # Esito: @{ livello = 'ok'|'attenzione'|'stop'; motivi = @() }
    param($Agente, $Ora = $null, $Limiti = $null)
    if ($null -eq $Agente) { return @{ livello = 'ok'; motivi = @() } }
    if ($null -eq $Limiti) { $Limiti = Get-TelemetriaLimitiDefault }
    if ($null -eq $Ora) { $Ora = Get-Date }

    $motivi = New-Object System.Collections.ArrayList
    $livello = 'ok'

    $stato = ''
    try { $stato = [string]$Agente.stato } catch { }
    if (@('fermo', 'fatto', 'errore', 'fermato') -contains $stato) { return @{ livello = 'ok'; motivi = @() } }

    $ultima = $null
    try { if ($Agente.ultima) { $ultima = [datetime]::Parse([string]$Agente.ultima) } } catch { $ultima = $null }
    $inizio = $null
    try { if ($Agente.inizio) { $inizio = [datetime]::Parse([string]$Agente.inizio) } } catch { $inizio = $null }

    $secondiStep = 0
    if ($ultima) { $secondiStep = ($Ora - $ultima).TotalSeconds }
    $secondiTotali = 0
    if ($inizio) { $secondiTotali = ($Ora - $inizio).TotalSeconds }

    if ($secondiTotali -gt [double]$Limiti.max_secondi_step) {
        [void]$motivi.Add('passo in corso da ' + [int]$secondiTotali + 's (limite ' + [int]$Limiti.max_secondi_step + 's)')
        $livello = 'stop'
    }
    if ($secondiStep -gt [double]$Limiti.max_silenzio) {
        [void]$motivi.Add('nessun segnale da ' + [int]$secondiStep + 's')
        if ($livello -ne 'stop') { $livello = 'stop' }
    }
    if ([int]$Agente.ripetizioni -ge [int]$Limiti.max_ripetizioni) {
        [void]$motivi.Add('stesso comando ripetuto ' + [int]$Agente.ripetizioni + ' volte (loop)')
        $livello = 'stop'
    }
    if ([int]$Agente.chiamate -gt [int]$Limiti.max_chiamate) {
        [void]$motivi.Add('troppi strumenti usati (' + [int]$Agente.chiamate + ')')
        $livello = 'stop'
    }
    if ([int]$Agente.errori -ge [int]$Limiti.max_errori) {
        [void]$motivi.Add('errori ripetuti (' + [int]$Agente.errori + ')')
        if ($livello -eq 'ok') { $livello = 'attenzione' }
    }
    if ($livello -eq 'ok' -and $secondiStep -gt ([double]$Limiti.max_silenzio / 2)) {
        [void]$motivi.Add('passo lento (' + [int]$secondiStep + 's)')
        $livello = 'attenzione'
    }
    return @{ livello = $livello; motivi = @($motivi) }
}

function Test-TelemetriaAllarmeSquadra {
    # [PURA] Allarme complessivo: aggrega i sette agenti.
    param($Stato, $Ora = $null, $Limiti = $null)
    if ($null -eq $Ora) { $Ora = Get-Date }
    if ($null -eq $Limiti) { $Limiti = Get-TelemetriaLimitiDefault }
    $stop = New-Object System.Collections.ArrayList
    $att = New-Object System.Collections.ArrayList
    if ($null -ne $Stato) {
        try {
            foreach ($p in @($Stato.agenti.PSObject.Properties)) {
                $r = Test-TelemetriaAllarme $p.Value $Ora $Limiti
                if ($r.livello -eq 'stop') { [void]$stop.Add(@{ id = $p.Name; motivi = $r.motivi }) }
                elseif ($r.livello -eq 'attenzione') { [void]$att.Add(@{ id = $p.Name; motivi = $r.motivi }) }
            }
        } catch { }
    }
    $liv = 'ok'
    if ($att.Count -gt 0) { $liv = 'attenzione' }
    if ($stop.Count -gt 0) { $liv = 'stop' }
    return @{ livello = $liv; stop = @($stop); attenzione = @($att) }
}

function Format-TelemetriaEtichetta {
    # [PURA] Come si legge lo stato di un agente.
    param([string]$Stato)
    switch (([string]$Stato).ToLowerInvariant()) {
        'fermo'      { return 'FERMO' }
        'in_coda'    { return 'IN CODA' }
        'pensa'      { return 'PENSA' }
        'scrive'     { return 'SCRIVE' }
        'strumento'  { return 'STRUMENTO' }
        'fatto'      { return 'FATTO' }
        'errore'     { return 'ERRORE' }
        'fermato'    { return 'FERMATO' }
        default      { return 'FERMO' }
    }
}

function Format-TelemetriaDurata {
    # [PURA] Millisecondi -> "12s" / "1m 04s".
    param([int]$Ms)
    if ($Ms -lt 1000) { return '0s' }
    $s = [int][math]::Floor($Ms / 1000)
    if ($s -lt 60) { return ($s.ToString() + 's') }
    return ([int][math]::Floor($s / 60)).ToString() + 'm ' + (($s % 60).ToString('00')) + 's'
}

function Get-TelemetriaEventiRecenti {
    # Ultime N righe del registro di oggi (per il riquadro log della cabina).
    param([string]$Base, [int]$Quanti = 40)
    $out = New-Object System.Collections.ArrayList
    try {
        $log = Get-TelemetriaLogPercorso $Base
        if (-not (Test-Path -LiteralPath $log)) { return @() }
        $righe = @([System.IO.File]::ReadAllLines($log, [System.Text.Encoding]::UTF8))
        $da = [math]::Max(0, $righe.Count - $Quanti)
        for ($i = $da; $i -lt $righe.Count; $i++) {
            $r = $righe[$i]
            if (-not $r -or -not $r.Trim()) { continue }
            try {
                $o = $r | ConvertFrom-Json
                [void]$out.Add($o)
            } catch { }
        }
    } catch { }
    return @($out)
}

function Format-TelemetriaCabina {
    # Versione testuale della cabina: usata da /agenti e dai test.
    param([string]$Base)
    $s = Read-TelemetriaStato $Base
    $lim = Get-TelemetriaLimitiDefault
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('CABINA DI REGIA - LAVORO AGENTI')
    $sq = 'fermo'
    try { $sq = [string]$s.squadra.stato } catch { }
    [void]$righe.Add('  squadra: ' + $sq + $(if ($s.squadra.richiesta) { '  |  ' + [string]$s.squadra.richiesta } else { '' }))
    $n = 0
    foreach ($id in @(Get-TelemetriaIds)) {
        $a = Get-TelemetriaAgente $s $id
        $n++
        $riga = '  ' + $n.ToString('00') + '. ' + ([string]$a.nome).PadRight(10) + ' ' + (Format-TelemetriaEtichetta ([string]$a.stato)).PadRight(11)
        if ([int]$a.totale -gt 0) { $riga += ' passo ' + [string]$a.passo + '/' + [string]$a.totale }
        else { $riga += '              ' }
        $riga += '  ' + (Format-TelemetriaDurata ([int]$a.ms)) + '  ' + [string]$a.azione
        [void]$righe.Add($riga.TrimEnd())
        if ($a.ultima_riga) { [void]$righe.Add('      > ' + [string]$a.ultima_riga) }
    }
    $al = Test-TelemetriaAllarmeSquadra $s (Get-Date) $lim
    if ($al.livello -ne 'ok') {
        $testo = New-Object System.Collections.ArrayList
        foreach ($x in @($al.stop)) { [void]$testo.Add(($x.id + ': ' + (@($x.motivi) -join '; '))) }
        foreach ($x in @($al.attenzione)) { [void]$testo.Add(($x.id + ': ' + (@($x.motivi) -join '; '))) }
        [void]$righe.Add('  ALLARME (' + $al.livello + '): ' + ($testo -join ' | '))
    }
    return ($righe -join "`n")
}

function Reset-TelemetriaTutto {
    # Comodita' per la cabina: cancella stato e registro (non la memoria Ezappero).
    param([string]$Base)
    try {
        $dir = Get-TelemetriaDir $Base
        if (Test-Path -LiteralPath $dir) {
            Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        }
        [void](Save-TelemetriaStato $Base (New-TelemetriaStato))
        return 'Telemetria azzerata.'
    } catch { return 'Non ho potuto azzerare la telemetria.' }
}
