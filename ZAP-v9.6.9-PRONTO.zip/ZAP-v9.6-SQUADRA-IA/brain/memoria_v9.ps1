﻿# memoria_v9.ps1 -- MEMORIA INDELEBILE di ZAP (cartella "Ezappero").
#
# Idee di fondo (v9):
#  1) REGISTRO APPEND-ONLY con CATENA DI HASH: ogni evento e' una riga JSON che contiene
#     l'hash della riga precedente. Non si puo' riscrivere il passato senza rompere la catena,
#     e ZAP se ne accorge subito (Test-ZapIntegrita).
#  2) DOPPIA COPIA (specchio): ogni riga viene scritta anche nella cartella specchio, fuori dal
#     progetto. Se qualcuno cancella o azzera la copia principale, si ripristina dallo specchio.
#  3) FILE PROTETTI: attributi ReadOnly+Hidden+System e, quando possibile, ACL che NEGA la
#     cancellazione (icacls /deny DE,DC). Serve AVVIA_ADMIN.bat per la protezione piena.
#  4) SNAPSHOT VERSIONATI: nulla viene mai sovrascritto. Gli appunti e le sessioni restano
#     in copie datate, per sempre.
#
# Onesta' tecnica: nessun file e' "assolutamente indistruttibile" su un PC di cui sei
# amministratore (un admin puo' sempre prendere possesso). Quello che qui e' garantito e':
#   - nessuna scrittura distrugge il passato (append-only + snapshot datati);
#   - ogni manomissione e' RILEVABILE (catena di hash);
#   - c'e' sempre una SECONDA copia fuori dal progetto;
#   - il ripristino e' automatico dallo specchio.

$script:ZapLedgerLock = $null

function Get-EzapperoConfig {
    param($sync)
    $d = @{
        cartella      = 'Ezappero'
        specchio      = ''
        proteggi      = $true
        snapshot_ore  = 6
        max_righe_prompt = 18
    }
    try {
        $c = $sync.Config.ezappero
        if ($c) {
            try { if ($c.cartella) { $d.cartella = [string]$c.cartella } } catch { }
            try { if ($c.specchio) { $d.specchio = [string]$c.specchio } } catch { }
            try { if ($null -ne $c.proteggi) { $d.proteggi = [bool]$c.proteggi } } catch { }
            try { if ($c.snapshot_ore) { $d.snapshot_ore = [int]$c.snapshot_ore } } catch { }
            try { if ($c.max_righe_prompt) { $d.max_righe_prompt = [int]$c.max_righe_prompt } } catch { }
        }
    } catch { }
    if (-not $d.specchio) {
        # Specchio FUORI dal progetto: se si cancella la cartella del programma, la memoria resta.
        $u = $env:USERPROFILE
        if (-not $u) { $u = $env:HOME }
        if (-not $u) { $u = (Get-Location).Path }
        $d.specchio = Join-Path $u 'ZAP-Ezappero-Specchio'
    }
    return $d
}

function Get-ZapProjectBase {
    param($sync)
    $b = ''
    try { $b = [string]$sync.Base } catch { }
    if (-not $b) { $b = $PSScriptRoot }
    if (-not $b) { $b = (Get-Location).Path }
    return $b
}

function Get-EzapperoDir {
    param($sync)
    $c = Get-EzapperoConfig $sync
    $rel = [string]$c.cartella
    if ([System.IO.Path]::IsPathRooted($rel)) { return $rel }
    return (Join-Path (Get-ZapProjectBase $sync) $rel)
}

function Get-EzapperoMirrorDir {
    param($sync)
    $c = Get-EzapperoConfig $sync
    return [string]$c.specchio
}

function Get-ZapLedgerPath { param($sync) return (Join-Path (Get-EzapperoDir $sync) 'ledger.jsonl') }
function Get-ZapLedgerHeadPath { param($sync) return (Join-Path (Get-EzapperoDir $sync) 'ledger.head.json') }

function Initialize-Ezappero {
    # Crea la struttura di cartelle (idempotente). Non tocca nulla di esistente.
    param($sync)
    $dir = Get-EzapperoDir $sync
    foreach ($s in @('', 'sessioni', 'appunti', 'appunti\versioni', 'lezioni', 'diario',
                     'powershell-script', 'tracce', 'tracce\scatti', 'documenti',
                     'documenti\fatture', 'documenti\buste-paga', 'snapshot', 'email')) {
        $p = if ($s) { Join-Path $dir $s } else { $dir }
        if (-not (Test-Path -LiteralPath $p)) {
            try { New-Item -ItemType Directory -Path $p -Force | Out-Null } catch { }
        }
    }
    $mir = Get-EzapperoMirrorDir $sync
    if ($mir) {
        foreach ($s in @('', 'sessioni', 'appunti', 'powershell-script', 'tracce', 'documenti')) {
            $p = if ($s) { Join-Path $mir $s } else { $mir }
            if (-not (Test-Path -LiteralPath $p)) {
                try { New-Item -ItemType Directory -Path $p -Force | Out-Null } catch { }
            }
        }
    }
    $led = Get-ZapLedgerPath $sync
    if (-not (Test-Path -LiteralPath $led)) {
        try { [System.IO.File]::WriteAllText($led, '', (New-Object System.Text.UTF8Encoding($false))) } catch { }
    }
    return $dir
}

function Get-Sha256Hex {
    param([string]$Text)
    try {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        $bytes = [System.Text.Encoding]::UTF8.GetBytes([string]$Text)
        $hash = $sha.ComputeHash($bytes)
        return ([System.BitConverter]::ToString($hash) -replace '-', '').ToLowerInvariant()
    } catch { return '' }
}

function Set-ZapFileProtetto {
    # Attributi: sola lettura + nascosto + sistema. Non impedisce a un admin di cancellare,
    # ma ferma gli errori, gli script distratti e le pulizie automatiche.
    param([string]$Path, [bool]$On = $true)
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return }
    try {
        $item = Get-Item -LiteralPath $Path -Force
        if ($On) { $item.Attributes = ($item.Attributes -bor [System.IO.FileAttributes]::ReadOnly -bor [System.IO.FileAttributes]::Hidden) }
        else { $item.Attributes = ($item.Attributes -band (-bnot [System.IO.FileAttributes]::ReadOnly)) }
    } catch { }
}

function Write-ZapUtf8Append {
    param([string]$Path, [string]$Line)
    if (-not $Path) { return $false }
    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        # se il file e' in sola lettura lo sblocco un attimo, scrivo, e lo riblocco.
        if (Test-Path -LiteralPath $Path) { Set-ZapFileProtetto $Path $false }
        [System.IO.File]::AppendAllText($Path, $Line + "`r`n", (New-Object System.Text.UTF8Encoding($false)))
        return $true
    } catch { return $false }
}

function Get-ZapLedgerHead {
    param($sync)
    $h = @{ n = 0; h = ('0' * 64); aggiornato = '' }
    $p = Get-ZapLedgerHeadPath $sync
    if (Test-Path -LiteralPath $p) {
        try {
            $j = Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($j) {
                if ($null -ne $j.n) { $h.n = [int]$j.n }
                if ($j.h) { $h.h = [string]$j.h }
                if ($j.aggiornato) { $h.aggiornato = [string]$j.aggiornato }
            }
        } catch { }
    }
    return $h
}

function Save-ZapLedgerHead {
    param($sync, [int]$N, [string]$H)
    $p = Get-ZapLedgerHeadPath $sync
    $obj = @{ n = $N; h = $H; aggiornato = (Get-Date -Format 'o') }
    try {
        Set-ZapFileProtetto $p $false
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($p, (ConvertTo-Json -InputObject $obj -Compress), $enc)
    } catch { }
}

function Add-ZapLedgerEvento {
    # Scrive un evento nel registro indelebile. Restituisce la riga scritta (o $null).
    # Tutto passa di qui: chat, comandi, script, note, lezioni, documenti, email, tracce.
    param(
        $sync,
        [string]$Tipo = 'evento',
        [string]$Testo = '',
        [string]$Tag = '',
        [bool]$Permanente = $false
    )
    if (-not $Testo) { return $null }
    try { [void](Initialize-Ezappero $sync) } catch { }

    $head = Get-ZapLedgerHead $sync
    $n = [int]$head.n + 1
    $ts = (Get-Date -Format 'o')
    $hPrev = [string]$head.h
    if (-not $hPrev) { $hPrev = ('0' * 64) }

    $testoPulito = ([string]$Testo)
    if ($testoPulito.Length -gt 4000) { $testoPulito = $testoPulito.Substring(0, 4000) + ' ...[troncato]' }

    # L'hash si calcola su un interruttore NUMERICO del tempo (millisecondi UTC), non sulla data
    # testuale: ConvertFrom-Json trasforma le date ISO in oggetti DateTime (formato locale),
    # e l'hash non tornerebbe piu'. Il campo 't' resta solo per la lettura umana.
    $msEpoch = [long]([System.DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
    $materiale = "$hPrev|$n|$msEpoch|$Tipo|$Tag|$testoPulito"
    $h = Get-Sha256Hex $materiale

    $rec = [ordered]@{
        n     = $n
        ts    = $msEpoch
        t     = $ts
        tipo  = $Tipo
        tag   = $Tag
        perm  = $Permanente
        testo = $testoPulito
        h     = $h
        prev  = $hPrev
    }
    $line = (ConvertTo-Json -InputObject $rec -Compress -Depth 4)

    $ok = Write-ZapUtf8Append (Get-ZapLedgerPath $sync) $line
    if (-not $ok) { return $null }

    # copia specchio: fuori dal progetto, cosi' una cancellazione non porta via tutto
    $mir = Get-EzapperoMirrorDir $sync
    if ($mir) {
        try { [void](Write-ZapUtf8Append (Join-Path $mir 'ledger.jsonl') $line) } catch { }
    }

    Save-ZapLedgerHead $sync $n $h
    Set-ZapFileProtetto (Get-ZapLedgerPath $sync) $true
    return $rec
}

function Read-ZapLedger {
    # Legge le ultime righe del registro (dalla coda, per non caricare tutto).
    param($sync, [int]$Ultime = 200)
    $p = Get-ZapLedgerPath $sync
    $out = New-Object System.Collections.ArrayList
    if (-not (Test-Path -LiteralPath $p)) { return @() }
    try {
        $tutte = [System.IO.File]::ReadAllLines($p)
        $start = [Math]::Max(0, $tutte.Count - $Ultime)
        for ($i = $start; $i -lt $tutte.Count; $i++) {
            $r = $tutte[$i]
            if (-not $r -or -not $r.Trim()) { continue }
            try { [void]$out.Add(($r | ConvertFrom-Json)) } catch { }
        }
    } catch { }
    return @($out.ToArray())
}

function Test-ZapIntegrita {
    # Verifica l'intera catena di hash. Rileva righe modificate, cancellate o aggiunte a mano.
    # -Percorso permette di verificare anche la copia specchio (ripristino sicuro).
    param($sync, [string]$Percorso = '')
    $p = $Percorso
    if (-not $p) { $p = Get-ZapLedgerPath $sync }
    $rep = @{ ok = $true; totale = 0; rotte = @(); mancanti = @(); messaggio = '' }
    if (-not (Test-Path -LiteralPath $p)) {
        $rep.ok = $false
        $rep.messaggio = 'Registro assente: la memoria non e'' stata ancora inizializzata.'
        return $rep
    }
    $prev = ('0' * 64)
    $atteso = 1
    $i = 0
    foreach ($riga in [System.IO.File]::ReadAllLines($p)) {
        $i++
        if (-not $riga -or -not $riga.Trim()) { continue }
        $rep.totale++
        $o = $null
        try { $o = $riga | ConvertFrom-Json } catch { $o = $null }
        if (-not $o) {
            $rep.ok = $false
            $rep.rotte += "riga ${i}: JSON illeggibile (manomissione?)"
            continue
        }
        if ([int]$o.n -ne $atteso) {
            $rep.ok = $false
            $rep.mancanti += "atteso evento $atteso, trovato $($o.n) alla riga $i"
        }
        if ([string]$o.prev -ne $prev) {
            $rep.ok = $false
            $rep.rotte += "riga $i (evento $($o.n)): catena spezzata (prev non coincide)"
        }
        $ms = ''
        try { $ms = [string]$o.ts } catch { $ms = '' }
        if (-not $ms) { $ms = '0' }
        $materiale = "$($o.prev)|$($o.n)|$ms|$($o.tipo)|$($o.tag)|$($o.testo)"
        $calc = Get-Sha256Hex $materiale
        if ($calc -ne [string]$o.h) {
            $rep.ok = $false
            $rep.rotte += "riga $i (evento $($o.n)): contenuto modificato (hash diverso)"
        }
        $prev = [string]$o.h
        $atteso = [int]$o.n + 1
    }
    if ($rep.ok) {
        $rep.messaggio = "Memoria integra: $($rep.totale) eventi, catena di hash valida."
    } else {
        $dettagli = @(@($rep.rotte) + @($rep.mancanti))
        $primi = @($dettagli | Select-Object -First 3)
        $rep.messaggio = "MEMORIA MANOMESSA: " + ($primi -join ' | ')
    }
    return $rep
}

function Repair-ZapDaSpecchio {
    # Ripristina il registro locale dallo specchio, SOLO se lo specchio e' piu' lungo e valido.
    param($sync)
    $loc = Get-ZapLedgerPath $sync
    $mir = Get-EzapperoMirrorDir $sync
    if (-not $mir) { return 'Nessuna copia specchio configurata.' }
    $mirLed = Join-Path $mir 'ledger.jsonl'
    if (-not (Test-Path -LiteralPath $mirLed)) { return 'Lo specchio non contiene un registro: niente da ripristinare.' }

    $nl = 0; $nm = 0
    try { if (Test-Path -LiteralPath $loc) { $nl = @([System.IO.File]::ReadAllLines($loc)).Count } } catch { $nl = 0 }
    try { $nm = @([System.IO.File]::ReadAllLines($mirLed)).Count } catch { $nm = 0 }

    # Ripristino se: lo specchio e' piu' completo OPPURE il locale e' manomesso e lo specchio e' valido.
    $specchioValido = $false
    try { $specchioValido = [bool](Test-ZapIntegrita $sync $mirLed).ok } catch { $specchioValido = $false }
    $localeValido = $false
    try { $localeValido = [bool](Test-ZapIntegrita $sync $loc).ok } catch { $localeValido = $false }
    if ($nm -le $nl -and -not (($localeValido -eq $false) -and ($specchioValido -eq $true))) {
        return ("Nessun ripristino: locale $nl righe (integra: $localeValido), specchio $nm righe (integro: $specchioValido).")
    }
    if (-not $specchioValido) { return 'Lo specchio non e'' integro: non lo uso per il ripristino.' }

    # salvo comunque una copia del locale prima di toccarlo
    try {
        if ($nl -gt 0) {
            $bkp = Join-Path (Get-EzapperoDir $sync) ('ledger.sostituito-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.jsonl')
            [System.IO.File]::Copy($loc, $bkp, $true)
        }
    } catch { }

    try {
        Set-ZapFileProtetto $loc $false
        [System.IO.File]::Copy($mirLed, $loc, $true)
        $ultima = @([System.IO.File]::ReadAllLines($loc))[-1]
        $o = $ultima | ConvertFrom-Json
        Save-ZapLedgerHead $sync ([int]$o.n) ([string]$o.h)
        Set-ZapFileProtetto $loc $true
        return "Ripristinati $nm eventi dallo specchio ($mir)."
    } catch {
        return ('Ripristino non riuscito: ' + $_.Exception.Message)
    }
}

function Protect-Ezappero {
    # Protezione fisica: attributi su tutto + ACL che NEGA la cancellazione.
    # L'ACL richiede diritti da amministratore (AVVIA_ADMIN.bat). Se non li ha, resta la parte attributi.
    param($sync)
    $dir = Get-EzapperoDir $sync
    $esiti = @()
    if (-not (Test-Path -LiteralPath $dir)) { return 'Cartella Ezappero non presente.' }

    try {
        Get-ChildItem -LiteralPath $dir -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Set-ZapFileProtetto $_.FullName $true
        }
        $esiti += 'Attributi sola-lettura + nascosto applicati a tutti i file.'
    } catch { $esiti += 'Attributi: errore ' + $_.Exception.Message }

    try {
        $usr = $env:USERNAME
        if (-not $usr) { $usr = [System.Environment]::UserName }
        $out = & icacls.exe $dir /deny "${usr}:(OI)(CI)(DE,DC)" 2>&1
        if ($LASTEXITCODE -eq 0) { $esiti += "ACL: cancellazione NEGATA a $usr (serve amministratore per toglierla)." }
        else { $esiti += 'ACL non applicata (serve AVVIA_ADMIN.bat): ' + (($out | Out-String).Trim()) }
    } catch { $esiti += 'ACL: ' + $_.Exception.Message }

    try {
        $mir = Get-EzapperoMirrorDir $sync
        if ($mir -and (Test-Path -LiteralPath $mir)) {
            Get-ChildItem -LiteralPath $mir -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
                Set-ZapFileProtetto $_.FullName $true
            }
            $esiti += 'Specchio protetto.'
        }
    } catch { }

    $msg = ($esiti -join "`r`n")
    [void](Add-ZapLedgerEvento $sync 'sistema' ('Protezione Ezappero: ' + $msg) 'protezione')
    return $msg
}

function Sblocca-Ezappero {
    # Toglie la negazione ACL (per riparazioni o se devi spostare la cartella).
    param($sync)
    $dir = Get-EzapperoDir $sync
    try {
        $usr = $env:USERNAME
        if (-not $usr) { $usr = [System.Environment]::UserName }
        & icacls.exe $dir /remove:d $usr 2>&1 | Out-Null
        Get-ChildItem -LiteralPath $dir -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Set-ZapFileProtetto $_.FullName $false
        }
        return 'Ezappero sbloccata (attributi e ACL rimossi).'
    } catch { return ('Errore: ' + $_.Exception.Message) }
}

function Sync-EzapperoSpecchio {
    # Copia completa del registro e degli appunti nello specchio (backup esterno).
    param($sync)
    $dir = Get-EzapperoDir $sync
    $mir = Get-EzapperoMirrorDir $sync
    if (-not $mir) { return 'Specchio non configurato.' }
    $n = 0
    try {
        foreach ($rel in @('ledger.jsonl', 'ledger.head.json', 'lezioni\lezioni.md', 'appunti\appunti.txt')) {
            $src = Join-Path $dir $rel
            if (Test-Path -LiteralPath $src) {
                $dst = Join-Path $mir $rel
                $dd = Split-Path -Parent $dst
                if (-not (Test-Path -LiteralPath $dd)) { New-Item -ItemType Directory -Path $dd -Force | Out-Null }
                [System.IO.File]::Copy($src, $dst, $true)
                $n++
            }
        }
    } catch { return ('Specchio: errore ' + $_.Exception.Message) }

    # v9: anche TRACCE e SESSIONI finiscono fuori dal progetto. Sono le cose che l'utente
    # ha chiesto esplicitamente ("in una cartella esterna, cosi' lui poi non puo' eliminarla").
    $nCopie = 0
    foreach ($coppia in @(@{ da = 'tracce'; a = 'tracce' }, @{ da = 'sessioni'; a = 'sessioni' }, @{ da = 'documenti'; a = 'documenti' })) {
        $sorgente = Join-Path $dir $coppia.da
        if (-not (Test-Path -LiteralPath $sorgente)) { continue }
        $destinazione = Join-Path $mir $coppia.a
        try {
            if (-not (Test-Path -LiteralPath $destinazione)) { New-Item -ItemType Directory -Path $destinazione -Force | Out-Null }
            Get-ChildItem -LiteralPath $sorgente -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
                $relativo = $_.FullName.Substring($sorgente.Length).TrimStart('\', '/')
                $dst = Join-Path $destinazione $relativo
                $dd = Split-Path -Parent $dst
                if ($dd -and -not (Test-Path -LiteralPath $dd)) { New-Item -ItemType Directory -Path $dd -Force | Out-Null }
                [System.IO.File]::Copy($_.FullName, $dst, $true)
                $nCopie++
            }
        } catch { }
    }
    return "Specchio aggiornato ($n file base + $nCopie file di tracce/sessioni) in $mir"
}

function Format-ZapEvento {
    param($Ev)
    $t = [string]$Ev.tipo
    $data = ''
    try { $data = ([datetime]$Ev.t).ToString('dd/MM/yyyy HH:mm') } catch { $data = [string]$Ev.t }
    $txt = [string]$Ev.testo
    $txt = $txt -replace "`r?`n", ' '
    if ($txt.Length -gt 180) { $txt = $txt.Substring(0, 180) + '...' }
    $pin = ''
    if ($Ev.perm) { $pin = ' [PERMANENTE]' }
    return "- $data [$t]$pin $txt"
}

function Get-ZapMemoriaPrompt {
    # Il blocco che ZAP legge nel prompt di sistema: quello che ha fatto, imparato e notato.
    param($sync)
    $c = Get-EzapperoConfig $sync
    $max = [int]$c.max_righe_prompt
    if ($max -le 0) { $max = 18 }

    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('MEMORIA INDELEBILE (cartella Ezappero: append-only + catena di hash + copia specchio)')
    [void]$righe.Add('Questi ricordi NON sono stati inventati: stanno nel registro di ZAP da cui li leggi.')

    $idx = @()
    try { $idx = @(Read-ZapLedger $sync 400) } catch { $idx = @() }

    $perm = @($idx | Where-Object { $_.perm -eq $true })
    if ($perm.Count -gt 0) {
        [void]$righe.Add('')
        [void]$righe.Add('REGOLE PERMANENTI DELL''UTENTE (valgono sempre):')
        $k = 0
        foreach ($e in @($perm | Select-Object -Last 20)) {
            [void]$righe.Add((Format-ZapEvento $e))
            $k++
            if ($k -ge 20) { break }
        }
    }

    $recenti = @($idx | Where-Object { $_.perm -ne $true } | Select-Object -Last $max)
    if ($recenti.Count -gt 0) {
        [void]$righe.Add('')
        [void]$righe.Add('ULTIMI LAVORI ED EVENTI (dal piu'' vecchio al piu'' recente):')
        foreach ($e in $recenti) { [void]$righe.Add((Format-ZapEvento $e)) }
    }

    $lez = Join-Path (Get-EzapperoDir $sync) 'lezioni\lezioni.md'
    if (Test-Path -LiteralPath $lez) {
        try {
            $t = [string](Get-Content -LiteralPath $lez -Raw -Encoding UTF8)
            if ($t.Trim()) {
                if ($t.Length -gt 2500) { $t = $t.Substring($t.Length - 2500) }
                [void]$righe.Add('')
                [void]$righe.Add('LEZIONI IMPARATE (errori da non ripetere):')
                [void]$righe.Add($t.Trim())
            }
        } catch { }
    }

    $app = Join-Path (Get-ZapProjectBase $sync) 'appunti\appunti.txt'
    if (Test-Path -LiteralPath $app) {
        try {
            $t = [string](Get-Content -LiteralPath $app -Raw -Encoding UTF8)
            if ($t.Trim()) {
                if ($t.Length -gt 1800) { $t = $t.Substring($t.Length - 1800) }
                [void]$righe.Add('')
                [void]$righe.Add('APPUNTI DELL''UTENTE (salvati e versionati, non si perdono):')
                [void]$righe.Add($t.Trim())
            }
        } catch { }
    }

    $ps = Get-PsLibreriaDir $sync
    if ($ps -and (Test-Path -LiteralPath $ps)) {
        try {
            $files = @(Get-ChildItem -LiteralPath $ps -Recurse -File -Filter *.ps1 -ErrorAction SilentlyContinue)
            if ($files.Count -gt 0) {
                [void]$righe.Add('')
                [void]$righe.Add("LIBRERIA POWERSHELL: hai gia' $($files.Count) script archiviati in Ezappero\powershell-script.")
                [void]$righe.Add('Prima di scrivere uno script nuovo, cerca_script: se esiste gia'' riusalo invece di inventarlo.')
            }
        } catch { }
    }

    return ($righe -join "`r`n")
}

function Get-ZapRichiamo {
    # RICHIAMO PROATTIVO: cerca nei lavori passati quelli legati a quello che l'utente sta chiedendo.
    # E' il pezzo che fa dire a ZAP "questo l'avevamo gia' fatto, riprendo da li'".
    param($sync, [string]$Testo, [int]$Max = 5)
    if (-not $Testo) { return '' }
    $stop = @('che','con','per','del','della','dei','delle','gli','una','uno','sono','come','cosa','quando',
              'dove','perche','fare','fatto','molto','anche','questo','questa','quello','quella','the','and','for','with','you','your','non','piu','gia','gia','essere','avere','voglio','vorrei','puoi','mi','ti','si','il','lo','la','le','un','una','di','da','in','su','al','alla','ai','e','o','a')
    $parole = @()
    foreach ($w in ([string]$Testo).ToLowerInvariant() -split '[^a-z0-9aeeiou]+') {
        if ($w.Length -lt 4) { continue }
        if ($stop -contains $w) { continue }
        if ($parole -notcontains $w) { $parole += $w }
    }
    if ($parole.Count -eq 0) { return '' }

    $idx = @()
    try { $idx = @(Read-ZapLedger $sync 600) } catch { $idx = @() }
    if ($idx.Count -eq 0) { return '' }

    $punti = @()
    foreach ($e in $idx) {
        $t = ([string]$e.testo).ToLowerInvariant()
        $s = 0
        foreach ($w in $parole) { if ($t.Contains($w)) { $s++ } }
        if ($e.perm -eq $true) { $s += 2 }
        if ($s -ge 1) {
            $punti += [pscustomobject]@{ Score = $s; Ev = $e }
        }
    }
    if ($punti.Count -eq 0) { return '' }
    $top = @($punti | Sort-Object -Property Score -Descending | Select-Object -First $Max)

    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('LAVORI PASSATI CORRELATI A QUESTA RICHIESTA (usali: non ricominciare da zero)')
    foreach ($p in $top) { [void]$righe.Add((Format-ZapEvento $p.Ev)) }
    [void]$righe.Add('Se uno di questi e'' pertinente, dillo all''utente e RIPARTI da li'' (o chiedi se vuole aggiornarlo).')
    return ($righe -join "`r`n")
}

function Test-MemoriaAuto {
    # v9.6 -- La memoria e' MANUALE di fabbrica: si scrive solo quando premi MEMORIA
    # (o quando metti config.json -> memoria.salvataggio = "auto").
    param($sync)
    $v = 'manuale'
    try { if ($sync.Config.memoria.salvataggio) { $v = ([string]$sync.Config.memoria.salvataggio).Trim().ToLower() } } catch { }
    return ($v -eq 'auto')
}

function Save-ZapSessione {
    # Salva TUTTA la conversazione (non solo l'ultimo scambio) come file datato.
    param($sync, $Messaggi, [string]$Motivo = 'fine-turno')
    try {
        $dir = Join-Path (Get-EzapperoDir $sync) ('sessioni\' + (Get-Date -Format 'yyyy-MM-dd'))
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $p = Join-Path $dir ('sessione-' + (Get-Date -Format 'HHmmss') + '.json')
        $obj = @{
            salvato = (Get-Date -Format 'o')
            motivo  = $Motivo
            messaggi = @($Messaggi)
        }
        $testo = (ConvertTo-Json -InputObject $obj -Depth 12)
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($p, $testo, $enc)

        # copia IMMEDIATA fuori dal progetto (le sessioni sono la memoria delle conversazioni)
        try {
            $mir = Get-EzapperoMirrorDir $sync
            if ($mir) {
                $mirDir = Join-Path (Join-Path $mir 'sessioni') (Get-Date -Format 'yyyy-MM-dd')
                if (-not (Test-Path -LiteralPath $mirDir)) { New-Item -ItemType Directory -Path $mirDir -Force | Out-Null }
                [System.IO.File]::WriteAllText((Join-Path $mirDir (Split-Path -Leaf $p)), $testo, $enc)
            }
        } catch { }
        return $p
    } catch { return '' }
}

function Add-ZapLezione {
    # Una lezione = un errore fatto + la regola per non ripeterlo.
    param($sync, [string]$Testo)
    if (-not $Testo) { return 'Nessun testo.' }
    $p = Join-Path (Get-EzapperoDir $sync) 'lezioni\lezioni.md'
    $riga = '- [' + (Get-Date -Format 'yyyy-MM-dd HH:mm') + '] ' + ([string]$Testo -replace "`r?`n", ' ')
    [void](Write-ZapUtf8Append $p $riga)
    Set-ZapFileProtetto $p $true
    [void](Add-ZapLedgerEvento $sync 'lezione' $Testo 'lezioni' $false)
    return 'Lezione salvata: non la dimentichero'' (finisce nel prompt di ogni risposta).'
}

function Save-AppuntiVersionato {
    # Prima di sovrascrivere gli appunti, ne salva una copia datata. Nulla si perde MAI.
    param($sync, [string]$Testo)
    try {
        $vdir = Join-Path (Get-EzapperoDir $sync) 'appunti\versioni'
        if (-not (Test-Path -LiteralPath $vdir)) { New-Item -ItemType Directory -Path $vdir -Force | Out-Null }
        $p = Join-Path $vdir ('appunti-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($p, [string]$Testo, $enc)
        $cur = Join-Path (Get-EzapperoDir $sync) 'appunti\appunti.txt'
        [System.IO.File]::WriteAllText($cur, [string]$Testo, $enc)
        return $p
    } catch { return '' }
}

function Get-ZapDiario {
    # Diario del giorno: cosa e' successo oggi, preso dal registro.
    param($sync, [string]$Giorno = '')
    if (-not $Giorno) { $Giorno = (Get-Date -Format 'yyyy-MM-dd') }
    $tutti = @(Read-ZapLedger $sync 2000)
    $righe = @($tutti | Where-Object {
        $d = ''
        try { $d = ([datetime]$_.t).ToString('yyyy-MM-dd') } catch { $d = '' }
        $d -eq $Giorno
    })
    if ($righe.Count -eq 0) { return "Diario $Giorno : nessun evento registrato." }
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("DIARIO $Giorno -- $($righe.Count) eventi")
    foreach ($e in $righe) { [void]$out.Add((Format-ZapEvento $e)) }
    return ($out -join "`r`n")
}

function Get-EzapperoStato {
    param($sync)
    $dir = Get-EzapperoDir $sync
    $mir = Get-EzapperoMirrorDir $sync
    $head = Get-ZapLedgerHead $sync
    $rep = Test-ZapIntegrita $sync
    $nScript = 0
    try {
        $psd = Join-Path $dir 'powershell-script'
        if (Test-Path -LiteralPath $psd) { $nScript = @(Get-ChildItem -LiteralPath $psd -Recurse -File -Filter *.ps1 -ErrorAction SilentlyContinue).Count }
    } catch { }
    $nSess = 0
    try {
        $sd = Join-Path $dir 'sessioni'
        if (Test-Path -LiteralPath $sd) { $nSess = @(Get-ChildItem -LiteralPath $sd -Recurse -File -Filter *.json -ErrorAction SilentlyContinue).Count }
    } catch { }
    return @{
        cartella   = $dir
        specchio   = $mir
        eventi     = [int]$head.n
        integrita  = [bool]$rep.ok
        messaggio  = [string]$rep.messaggio
        script     = $nScript
        sessioni   = $nSess
    }
}
