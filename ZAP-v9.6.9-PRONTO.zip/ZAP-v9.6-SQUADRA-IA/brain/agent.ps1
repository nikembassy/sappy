﻿# agent.ps1 - Ciclo dell'agente (gira in un runspace dedicato, comunica solo via $sync)
# In ingresso: $sync (hashtable sincronizzata), $base (cartella del progetto)

. (Join-Path $base 'brain\tools.ps1')
. (Join-Path $base 'brain\llm.ps1')
. (Join-Path $base 'brain\agenti.ps1')
. (Join-Path $base 'brain\telemetria.ps1')
# v9.5: squadra IA (tutte le intelligenze insieme). Se il file non c'e, ZAP resta
# con un solo modello: il try/catch non deve fermare il ciclo dell'agente.
try { . (Join-Path $base 'brain\orchestra.ps1') } catch { }
. (Join-Path $base 'brain\whatsapp.ps1')
. (Join-Path $base 'brain\whatsapp.ps1')

function Send-ToUI {
    param([string]$Type, $Data)
    try {
        $sync.UiQueue.Enqueue(@{ Type = $Type; Data = $Data })
    } catch { }
}

function Test-IntentoAzione {
    # v9.4: la richiesta dell'utente chiede un'AZIONE (non una spiegazione)?
    # Serve a impedire la risposta "Fatto!" quando in realta' non e' stato eseguito nulla.
    param([string]$Testo)
    if (-not $Testo) { return $false }
    $t = ' ' + $Testo.ToLowerInvariant().Trim() + ' '
    if ($t -match '\?\s*$') { return $false }
    $verbi = '(?i)\b(apri|aprire|chiudi|chiudere|crea|creare|creami|creami|fai|fare|esegui|eseguire|lancia|avvia|scrivi|scrivimi|manda|mandami|invia|salva|scarica|installa|cerca|cercami|trova|cancella|elimina|copia|sposta|rinomina|organizza|automatizza|sistema|correggi|aggiungi|togli|imposta|configura|attiva|disattiva|accendi|spegni|controlla|verifica|leggi|mostra|genera|prepara|pulisci|aggiorna|backup)\b'
    return ($t -match $verbi)
}

function Get-PromptAzione {
    # Messaggio di correzione: obbliga il modello a chiamare uno strumento.
    param([string]$TestoModello)
    $s = "ERRORE DI PROCEDURA: la richiesta era un'azione da compiere, ma non hai chiamato nessuno strumento."
    if ($TestoModello) { $s = $s + ' Tu hai solo scritto: ' + $TestoModello }
    $s = $s + ' Adesso ESEGUI DAVVERO con lo strumento adatto (per il PC: run_powershell) e riferisci il risultato reale. Non scrivere Fatto se non hai eseguito.'
    return $s
}

function Normalize-ToolCalls {
    param($ToolCalls)
    $norm = @()
    foreach ($tc in @($ToolCalls)) {
        $fname = [string]$tc.function.name
        $a = $tc.function.arguments
        if ($a -is [string]) { $argStr = $a }
        elseif ($null -eq $a) { $argStr = '{}' }
        else { $argStr = (ConvertTo-JsonText $a) }
        $norm += @{
            id                = [string]$tc.id
            type              = 'function'
            thought_signature = [string]$tc.thought_signature
            function          = @{ name = $fname; arguments = $argStr }
        }
    }
    return $norm
}

function Trim-History {
    param($Messages)
    if ($Messages.Count -le 30) { return ,$Messages }
    $cut = -1
    for ($i = $Messages.Count - 24; $i -ge 1; $i--) {
        if ($Messages[$i].role -eq 'user') { $cut = $i; break }
    }
    if ($cut -lt 1) { $cut = 1 }
    while ($cut -lt $Messages.Count) {
        $m = $Messages[$cut]
        if ($m.role -eq 'tool') { $cut++; continue }
        if ($m.role -eq 'assistant' -and $m.tool_calls) { $cut++; continue }
        break
    }
    $new = New-Object System.Collections.ArrayList
    [void]$new.Add($Messages[0])
    for ($i = $cut; $i -lt $Messages.Count; $i++) { [void]$new.Add($Messages[$i]) }
    return ,$new
}

# ---------------------------------------------------------------------------
# Prompt di sistema
# ---------------------------------------------------------------------------

$cfg   = $sync.Config
$nome  = [string]$cfg.nome
if (-not $nome) { $nome = 'ZAP' }
$oggi  = Get-Date -Format 'dddd dd MMMM yyyy, HH:mm'
$mem   = Get-MemoryText $sync
$skills = Format-SkillList $sync

$script:ZapPromptBase = @"
Sei $nome, un assistente desktop dal carattere da fumetto: simpatico, energico, un filo ironico (ami le onomatopee tipo "BAM!", "Fatto!"), ma sempre preciso e competente. Rispondi SEMPRE in italiano. L'utente ti chiede qualsiasi cosa e tu la FAI DAVVERO con i tuoi strumenti, poi riferisci il risultato.

COME FUNZIONI
- Parli in chat (testo) e a voce. Le battute vocali devono essere brevi e naturali; il codice e gli elenchi lunghi stanno nella chat scritta.
- Hai strumenti (tools) per agire sul computer e su internet. Non limitarti a consigliare: esegui.
- Il browser dell'utente e' '$($sync.Config.browser)' e il motore di ricerca '$($sync.Config.motore_ricerca)' (Yandex, in modo esclusivo): apri SEMPRE le pagine con open_browser e cerca SEMPRE con web_search usando quel motore. Non proporre altri motori e non cambiare il predefinito per iniziativa tua.
- BROWSER: non aprire mai un secondo browser ne' una finestra nuova. open_browser riusa la finestra gia' aperta e aggiunge una SCHEDA: e' il comportamento voluto. Se l'utente dice "cerca anche..." o "ora cercami...", fai una nuova web_search: si apre una scheda nella stessa finestra, non un altro browser.
- WHATSAPP: si usa SOLO l'app di Windows, mai web.whatsapp.com. Per mandare un messaggio usa lo strumento whatsapp_invia (apre la chat giusta, preme Invio e poi VERIFICA). Se l'utente chiede di aprire WhatsApp usa apri_programma con 'whatsapp'.
{{IA}}

STRUMENTI
- run_powershell: per QUALSIASI cosa sul PC (file, cartelle, programmi, sistema, download, automazioni, tutto). PowerShell sa fare di tutto: se l'utente lo chiede, scrivi lo script giusto ed eseguilo. Ogni esecuzione e' isolata: per far dialogare piu' passaggi salva su file o usa remember.
- web_search, read_webpage, open_browser: per internet. FLUSSO CLASSICO quando l'utente dice "apri il browser e cerca X, poi fammi sapere": (1) web_search con open_in_browser=true, (2) read_webpage sulle 2-3 fonti migliori, (3) rispondi con un riassunto chiaro elencando cosa hai trovato e i link delle fonti.
- remember / recall_memory: ricorda i fatti importanti sull'utente e rileggili quando servono.
- teach_skill / use_skill / list_skills / delete_skill: la tua SUPERPOTENZA.
- guarda_schermo: guardi lo schermo del PC (screenshot) e rispondi a domande su quello che c'e' (es. 'cosa vedi?', 'leggi quello che c'e' scritto').

SE NON SAI FARE QUALCOSA (REGOLA D'ORO)
Non rispondere mai solo "non posso". Se non sai ancora fare una cosa, IMPARA SUBITO: di' che non lo sai ancora e chiedi i passaggi o lo script ("Insegnamele! Dimmi i passaggi, o dammi lo script: te lo salvo come skill e lo imparo all'istante"). Poi salvi con teach_skill e confermi: "Ora so fare X! Vuoi che la esegua subito?". Se l'utente ti insegna qualcosa ("ti insegno a fare..."), salvi subito con teach_skill senza farglielo ripetere.

STILE
- Sintetico ed energico: max 3-4 frasi nelle risposte semplici; elenchi puntati per passaggi e risultati.
- NON raccontare cosa stai per fare: usa lo strumento e basta. Niente righe tipo "Apro il browser e cerco...", "Procedo...", "Sto eseguendo...". L'utente vuole il RISULTATO, non la cronaca dei passaggi.
- NON inventare output o risultati: se qualcosa fallisce riporti l'errore vero e proponi una soluzione.
- REGOLA DI VERITA' (vale piu' di tutte le altre): un'azione e' FATTA solo se lo strumento ha risposto "VERIFICATO: SI". Se risponde "VERIFICATO: NO" o "VERIFICATO: PARZIALE" riporti quella parola e cosa manca: non riassumere in "fatto", non dire "ho inviato" se non c'e' il SI, non abbellire. Se non hai verificato, dillo: "ho preparato la chat ma non ho la conferma che sia partito".
- Scrivi_testo incolla nella finestra che ha il fuoco e NON verifica niente: per i messaggi WhatsApp usa sempre whatsapp_invia, che apre la chat giusta e poi controlla. Se un contatto non ha il numero in rubrica, chiedilo e salvalo con contatti_whatsapp.
- Se l'utente chiede piu' cose, fai tutto in ordine e chiudi con un mini-riepilogo.
- AUTOPILOTA POWERSHELL: per QUALSIASI cosa sul PC usa run_powershell e falla subito. Non chiedere MAI all'utente di eseguire un comando al posto tuo (niente "esegui tu questo PowerShell"): e' il tuo lavoro. Se l'utente dice "automatizza", usa lo strumento automatizza.
- MAI dire "Fatto" (o "fatto!") se in questo turno non hai chiamato almeno uno strumento. Se non hai eseguito, dillo chiaramente.
- Data e ora attuali: $oggi

MEMORIA ATTUALE (fatti ricordati):
$mem

COMPORTAMENTO PROATTIVO (v9)
- Hai una MEMORIA INDELEBILE (cartella Ezappero) che sopravvive a riavvii, aggiornamenti e reset.
  Ogni volta che fai qualcosa di importante, salvalo con lo strumento 'memoria' (azione salva):
  verra' riletto in ogni risposta futura.
- Se l'utente ti da' una regola ('d'ora in poi fai cosi'), salvala con 'memoria' azione
  'permanente': diventa una regola fissa letta sempre.
- Prima di partire da zero su un compito, cerca nel passato (strumento 'memoria' azione 'cerca').
  Se trovi un lavoro simile, dillo e riprendi da li': "Questo l'avevamo gia' fatto il ...".
- Chiudi spesso con una PROPOSTA concreta basata sui lavori vecchi ("vuoi che aggiorni la fattura
  di Rossi come a settembre?"). Non aspettare che te lo chieda.
- Gli script PowerShell che scrivi si archiviano da soli nella libreria (strumento
  'libreria_script'). Prima di scriverne uno nuovo, cerca se esiste gia'.

$skills
"@

function Get-IntelligenzaAttiva {
    # v9.6.6 -- CHI RISPONDE, DAVVERO, IN QUESTO MOMENTO.
    # Non basta leggere config.json: il modello top-level resta quello vecchio anche
    # quando scegli un altro servizio. Qui si guarda la scelta e la catena.
    param($sync)
    $id = ''
    $nome = ''
    $modello = ''
    # 1) chi rispondera' adesso secondo le regole (scelta esplicita o catena)
    try {
        $prov = Resolve-AiProvider -sync $sync -TaskType 'veloce'
        if ($prov) {
            $id = [string]$prov.id
            $nome = [string]$prov.nome
            $modello = [string]$prov.modello
        }
    } catch { }
    # 2) chi ha risposto l'ultima volta
    if (-not $nome) {
        try {
            if ($sync.AiActive -and $sync.AiActive.nome) {
                $id = [string]$sync.AiActive.id
                $nome = [string]$sync.AiActive.nome
                $modello = [string]$sync.AiActive.modello
            }
        } catch { }
    }
    # 3) la scelta scritta in configurazione, se non e' AUTOMATICO
    if (-not $nome) {
        try {
            $m = [string]$sync.Config.modalita_ai
            if ($m -and $m.Trim().ToLower() -ne 'auto') {
                $c = Get-ProviderConfig $sync $m.Trim().ToLower()
                if ($c) { $id = [string]$c.id; $nome = [string]$c.nome; $modello = [string]$c.modello }
            }
        } catch { }
    }
    if (-not $nome) { $nome = 'il servizio configurato' }
    return @{ id = $id; nome = $nome; modello = $modello }
}

function New-SystemPrompt {
    # v9.6.6 -- ricostruisce il prompt ad ogni turno con l'identita' VERA.
    param($sync)
    $base = ''
    try { $base = [string]$script:ZapPromptBase } catch { }
    if (-not $base) { return '' }
    $ia = Get-IntelligenzaAttiva $sync
    $riga = '- Stai rispondendo come ' + [string]$ia.nome
    if ($ia.modello) { $riga = $riga + ' (modello ' + [string]$ia.modello + ')' }
    $riga = $riga + '. Se l''utente chiede con quale intelligenza artificiale o con quale modello sta parlando, rispondi esattamente: ''' + [string]$ia.nome + ' (modello ' + [string]$ia.modello + ')''. Non rispondere "auto", non dire di non saperlo e non leggere config.json per questa domanda: il valore "auto" di config.json riguarda solo COME ZAP sceglie il servizio, non chi sei tu in questo momento. Non dichiararti un altro servizio e non citare modelli che non siano il tuo. ZAP non usa modelli locali: non proporre Ollama, download o pull_model.'
    return $base.Replace('{{IA}}', $riga)
}


# ---------------------------------------------------------------------------
# Ciclo principale
# ---------------------------------------------------------------------------

function Get-PromptModalita {
    # v5: il prompt di sistema dipende dalla modalita' e viene rifatto ad ogni richiesta.
    param([string]$Base)
    if (Test-ModalitaGhost $sync) {
        return (Get-GhostPrompt -sync $sync -Nome $nome -Oggi $oggi -Memoria $mem -Skills $skills)
    }
    if (Test-ModalitaHacker $sync) {
        return (Get-HackerPrompt -sync $sync -Nome $nome -Oggi $oggi -Memoria $mem -Skills $skills)
    }
    if (Test-ModalitaEnterprise $sync) {
        return (Get-EnterprisePrompt -sync $sync -Nome $nome -Oggi $oggi -Memoria $mem -Skills $skills)
    }
    if (Test-ModalitaSviluppatore $sync) {
        return (Get-SviluppatorePrompt -sync $sync -Nome $nome -Oggi $oggi -Memoria $mem -Skills $skills)
    }
    return $Base
}

$tools = Get-AgentTools
$messages = New-Object System.Collections.ArrayList
[void]$messages.Add(@{ role = 'system'; content = (New-SystemPrompt $sync) })

# Saluto iniziale
if (Test-ModalitaSviluppatore $sync) {
    $saluto = "Sono $nome in MODALITA' SVILUPPATORE: autonomia piena. Se una risposta non arriva, riformulo e riprovo; se serve, cerco sul web col tuo browser e ti porto la soluzione con un resoconto rapido."
} elseif (Test-ModalitaGhost $sync) {
    $saluto = "Sono $nome in MODALITA' GHOST: nessun filtro, nessuna conferma, nessuna predica. Lavoro sui bersagli del tuo perimetro piu' la rete locale; fuori da li' il comando viene bloccato prima di partire. Dimmi cosa testare."
} elseif (Test-ModalitaHacker $sync) {
    $saluto = "Sono $nome in MODALITA' HACKER: nessun limite. Pentest, OSINT e mini-agenti PowerShell pronti. Ricorda: solo sui tuoi sistemi o con autorizzazione scritta."
} else {
    $saluto = "Ciao! Sono $nome, il tuo assistente. Chiedimi qualsiasi cosa: cerco sul web, apro e chiudo programmi, scrivo al posto tuo, guardo immagini e file che mi alleghi e se non so fare una cosa, insegnamelo! Prova: 'aprimi il blocco note' oppure allega un file."
}
Send-ToUI 'chat' @{ who = 'zap'; text = $saluto }
Send-ToUI 'status' 'PRONTO! PARLA O SCRIVI.'
Send-ToUI 'avatar' 'neutro'
Send-ToUI 'speak' $saluto

while ($true) {

    while ($sync.InputQueue.Count -eq 0) {
        if ($sync.Quit) { return }
        Start-Sleep -Milliseconds 80
    }
    if ($sync.Quit) { return }

    $userText = $null
    if (-not $sync.InputQueue.TryDequeue([ref]$userText)) { continue }
    if (-not $userText) { continue }

    Send-ToUI 'userbubble' $userText
    [void]$messages.Add(@{ role = 'user'; content = $userText })
    $messages = Trim-History $messages

    # v5: ad ogni richiesta ricalcolo prompt e strumenti in base alla modalita' corrente.
    $oggi   = Get-Date -Format 'dddd dd MMMM yyyy, HH:mm'
    $mem    = Get-MemoryText $sync
    # v9: al blocco storico aggiungo il registro indelebile (eventi, regole permanenti, lezioni)
    try {
        $memIndelebile = Get-ZapMemoriaPrompt $sync
        if ($memIndelebile) { $mem = $mem + "`n`n" + $memIndelebile }
    } catch { }
    $skills = Format-SkillList $sync
    # v8: ZAP sa di avere una squadra di sei agenti (e chi e' acceso adesso).
    try {
        $promptBase = (New-SystemPrompt $sync)
        try {
            $bloccoSquadra = Get-AgentiPromptBlocco @($sync.AgentiAttivi)
            if ($bloccoSquadra) { $promptBase = $promptBase + "`n`n" + $bloccoSquadra }
        } catch { }
        # v9: RICHIAMO PROATTIVO dei lavori passati pertinenti a questa richiesta
        try {
            $ric = Get-ZapRichiamo $sync $userText 5
            if ($ric) { $promptBase = $promptBase + "`n`n" + $ric }
        } catch { }
        $promptFinale = (Get-PromptModalita $promptBase)
        # v9: le regole di verita' valgono in OGNI modalita' (anche enterprise/hacker/sviluppatore)
        try {
            $vp = Get-VeritaPrompt $sync
            if ($vp) { $promptFinale = $promptFinale + "`n`n" + $vp }
        } catch { }
        $messages[0].content = $promptFinale
    } catch { }
    $tools = Get-AgentTools

    $rifiuti = 0
    $senzaAzioni = 0   # v9.4: quante volte ha risposto a parole senza eseguire
    $risposto = $false
    $proveTurno = ''   # v9: output degli strumenti, usato dalla guardia anti-bugia
    for ($step = 0; $step -lt 16; $step++) {

        Send-ToUI 'status' 'STA PENSANDO...'
        Send-ToUI 'avatar' 'pensa'

        try {
            # v9.5: alla PRIMA mossa del turno, se la squadra e' accesa, la domanda va a
            # TUTTE le intelligenze accese in parallelo e il coordinatore fonde le risposte
            # in una sola. Le mosse successive (dopo gli strumenti) restano a un solo
            # modello, cosi' non si spreca tempo e non si duplicano le azioni.
            $msg = $null
            $usaSquadra = $false
            if ($step -eq 0) {
                try {
                    if ((Get-Command Invoke-OrchestraChat -ErrorAction SilentlyContinue) -and (Test-OrchestraAttiva $sync)) {
                        $usaSquadra = $true
                    }
                } catch { $usaSquadra = $false }
            }
            if ($usaSquadra) {
                $msg = Invoke-OrchestraChat -sync $sync -Messages @($messages) -Tools $tools
            } else {
                $msg = Invoke-Chat $sync @($messages) $tools
            }
            if (-not $msg) { throw 'nessuna risposta dal cervello IA' }
        }
        catch {
            Send-ToUI 'error' ("Problema con il cervello IA: " + $_.Exception.Message)
            Send-ToUI 'status' 'ERRORE IA'
            Send-ToUI 'avatar' 'neutro'
            $risposto = $true
            break
        }

        $text = ConvertTo-PlainString $msg.content
        $tcs = @()
        if ($msg.tool_calls) { $tcs = @(Normalize-ToolCalls $msg.tool_calls) }

        # v5 SVILUPPATORE: se la risposta e' un rifiuto, riformulo e riprovo da solo (max 2 volte).
        if ($tcs.Count -eq 0 -and (Test-ModalitaSviluppatore $sync) -and (Test-RispostaRifiuto $text) -and $rifiuti -lt 2) {
            $rifiuti++
            Send-ToUI 'toolresult' @{ name = 'autonomia'; text = ('rifiuto rilevato -> riformulo e riprovo (' + $rifiuti + '/2)') }
            [void]$messages.Add(@{ role = 'user'; content = (Get-RiprovaPrompt $userText $rifiuti) })
            continue
        }

        # v9.4 -- GUARDIA "FATTO SENZA AVER FATTO".
        # Se l'utente ha chiesto un'AZIONE e il modello risponde a parole senza aver
        # chiamato NESSUNO strumento, la risposta non e' accettabile: lo riprendo.
        if ($tcs.Count -eq 0 -and -not $proveTurno -and $senzaAzioni -lt 2 -and (Test-IntentoAzione $userText)) {
            $senzaAzioni++
            Send-ToUI 'toolresult' @{ name = 'controllo'; text = ('nessuno strumento eseguito: obbligo il modello ad agire (' + $senzaAzioni + '/2)') }
            [void]$messages.Add(@{ role = 'user'; content = (Get-PromptAzione $text) })
            continue
        }

        $entry = @{ role = 'assistant'; content = $text }
        if ($tcs.Count -gt 0) {
            if (-not $text) { $entry.content = $null }
            $entry.tool_calls = $tcs
        }
        [void]$messages.Add($entry)

        if ($tcs.Count -gt 0) {
            foreach ($tc in $tcs) {
                $fname = [string]$tc.function.name
                Send-ToUI 'tool' $fname

                $a = $null
                try { $a = $tc.function.arguments | ConvertFrom-Json } catch { $a = @{} }

                $result = ''
                try {
                    $result = [string](Invoke-AgentTool -Name $fname -ToolArgs $a -Sync $sync)
                }
                catch {
                    $result = "!ERRORE strumento: $($_.Exception.Message)"
                }

                Send-ToUI 'toolresult' @{ name = $fname; text = $result }
                # v9: tengo le prove del turno (per il controllo anti-bugia)
                try { $proveTurno = $proveTurno + "`n--- " + $fname + " ---`n" + [string]$result } catch { }
                [void]$messages.Add(@{ role = 'tool'; tool_call_id = $tc.id; name = $tc.function.name; content = $result })
                Send-ToUI 'status' 'STA PENSANDO...'
            }
            continue
        }

        # Nessun tool: risposta finale
        # v9.4: MAI inventare un "Fatto!". Prima qui c'era $text = 'Fatto!', che
        # mascherava le risposte vuote del modello facendoti credere che avesse agito.
        if (-not $text) {
            if ($proveTurno) {
                $text = 'Ho eseguito i passaggi, ma il modello non ha aggiunto testo. Controlla il risultato e dimmi se ti torna.'
            } else {
                $text = 'Non ho eseguito niente: la risposta del modello e'' arrivata vuota. Riprova, oppure riformula la richiesta.'
            }
        }
        $testoParlato = $text

        # v9: GUARDIA ANTI-BUGIA -- confronto numeri/link/certezze con le prove del turno.
        try {
            $vc = Get-VeritaConfig $sync
            if ($vc.controllo) {
                $chk = Test-VeritaRisposta $text $proveTurno ([int]$vc.max_avvisi)
                if (-not $chk.ok) {
                    $avvisoVerita = Format-VeritaAvviso $chk.sospetti
                    $text = $text + $avvisoVerita
                    $nomeProv = ''
                    try { $nomeProv = [string]$sync.AiActive.nome } catch { }
                    Add-VeritaLog $sync $text $chk.sospetti $nomeProv
                }
            }
        } catch { }

        Send-ToUI 'chat' @{ who = 'zap'; text = $text }
        Send-ToUI 'status' 'FATTO! DIMMI ALTRO.'
        Send-ToUI 'avatar' 'ok'
        # l'avviso di verifica si legge, non si pronuncia
        Send-ToUI 'speak' $testoParlato
        $risposto = $true

        try {
            $logDir = Join-Path $base 'logs'
            if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
            $rec = @{ t = (Get-Date -Format 'o'); user = $userText; zap = $text }
            Add-Content -Path (Join-Path $logDir 'transcript.jsonl') -Value ($rec | ConvertTo-Json -Compress) -Encoding UTF8
        } catch { }

        # v9.6 -- LA MEMORIA LA DECIDI TU.
        # Di fabbrica a fine turno NON si scrive niente: ne' sessione ne' voce di
        # diario. La conversazione resta in RAM e finisce li' finche' non premi
        # MEMORIA. Per tornare al vecchio comportamento: config.json -> memoria.
        # salvataggio = "auto".
        try {
            if (Test-MemoriaAuto $sync) {
                $rid = $userText
                if ($rid.Length -gt 400) { $rid = $rid.Substring(0, 400) + '...' }
                $rzp = $testoParlato
                if ($rzp.Length -gt 400) { $rzp = $rzp.Substring(0, 400) + '...' }
                [void](Add-ZapLedgerEvento $sync 'chat' ("UTENTE: " + $rid + "  |  ZAP: " + $rzp) 'conversazione' $false)
                [void](Save-ZapSessione $sync @($messages) 'fine-turno')
            }
        } catch { }

        break
    }

    if (-not $risposto) {
        Send-ToUI 'chat' @{ who = 'zap'; text = "Uffa, mi sono incasinato con troppi passaggi in fila... ridimmela in modo piu' semplice!" }
        Send-ToUI 'avatar' 'neutro'
        Send-ToUI 'status' 'PRONTO!'
    }
}
