﻿# office.ps1 -- DOCUMENTI: fatture e buste paga (v9).
#
# ZAP genera documenti HTML impaginati A4 (apribili e stampabili subito) e, se sul PC c'e'
# Edge o Chrome, li converte in PDF con la stampa headless del browser (nessuna libreria esterna).
#
# ONESTA' (obbligatoria, e' il motivo per cui questi documenti sono utili e non pericolosi):
#   - La fattura e' un documento commerciale: i dati fiscali (P.IVA, regime, numerazione)
#     devono essere corretti e la numerazione deve essere progressiva. ZAP la numera da sola,
#     ma i dati del mittente li prendi da config.json -> documenti.mittente.
#   - La busta paga e' una SIMULAZIONE con parametri modificabili. Le aliquote cambiano ogni
#     anno e per CCNL: il documento lo dice a chiare lettere in testa. Non sostituisce un
#     consulente del lavoro. Se i parametri non sono aggiornati, il risultato e' indicativo.

function Get-SimboloEuro {
    # Il carattere non sta nel sorgente: si genera a runtime (vedi nota in verita.ps1).
    return [string][char]0x20AC
}

function Get-DocumentiDir { param($sync) return (Join-Path (Get-EzapperoDir $sync) 'documenti') }

function Get-DocumentiConfig {
    param($sync)
    $d = @{
        mittente = @{ nome = ''; piva = ''; cf = ''; indirizzo = ''; cap = ''; citta = ''; email = ''; telefono = ''; iban = '' }
        iva_default = 22
        valuta = 'EUR'
        busta = @{
            inps_dipendente = 9.19
            irpef = @(@(28000, 23), @(50000, 35), @(1000000000, 43))
            detrazione_mensile = 0
            note = ''
        }
        prefisso_fattura = 'FATT'
        prefisso_busta = 'BUSTA'
    }
    try {
        $c = $sync.Config.documenti
        if ($c) {
            if ($c.mittente) {
                foreach ($k in @('nome','piva','cf','indirizzo','cap','citta','email','telefono','iban')) {
                    try { if ($c.mittente.$k) { $d.mittente[$k] = [string]$c.mittente.$k } } catch { }
                }
            }
            try { if ($c.iva_default) { $d.iva_default = [double]$c.iva_default } } catch { }
            try { if ($c.prefisso_fattura) { $d.prefisso_fattura = [string]$c.prefisso_fattura } } catch { }
            try { if ($c.prefisso_busta) { $d.prefisso_busta = [string]$c.prefisso_busta } } catch { }
            if ($c.busta) {
                try { if ($null -ne $c.busta.inps_dipendente) { $d.busta.inps_dipendente = [double]$c.busta.inps_dipendente } } catch { }
                try { if ($null -ne $c.busta.detrazione_mensile) { $d.busta.detrazione_mensile = [double]$c.busta.detrazione_mensile } } catch { }
                try {
                    if ($c.busta.irpef) {
                        $sc = @()
                        foreach ($s in @($c.busta.irpef)) { $sc += ,@([double]$s[0], [double]$s[1]) }
                        if ($sc.Count -gt 0) { $d.busta.irpef = $sc }
                    }
                } catch { }
            }
        }
    } catch { }
    return $d
}

function Get-NumerazionePath { param($sync) return (Join-Path (Get-DocumentiDir $sync) 'numerazione.json') }

function Read-Numerazione {
    param($sync)
    $p = Get-NumerazionePath $sync
    $out = @{}
    if (Test-Path -LiteralPath $p) {
        try {
            $j = Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($a in @($j.PSObject.Properties)) {
                $inner = @{}
                foreach ($b in @($a.Value.PSObject.Properties)) { $inner[[string]$b.Name] = [int]$b.Value }
                $out[[string]$a.Name] = $inner
            }
        } catch { }
    }
    return $out
}

function Save-Numerazione {
    param($sync, $Num)
    $p = Get-NumerazionePath $sync
    try {
        $dir = Split-Path -Parent $p
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Set-ZapFileProtetto $p $false
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($p, (ConvertTo-Json -InputObject $Num -Depth 6), $enc)
        Set-ZapFileProtetto $p $true
    } catch { }
}

function Get-ProssimoNumero {
    # Numerazione PROGRESSIVA per anno (requisito di legge per le fatture).
    param($sync, [string]$Tipo = 'fattura')
    $anno = (Get-Date -Format 'yyyy')
    $num = Read-Numerazione $sync
    if (-not $num.ContainsKey($anno)) { $num[$anno] = @{} }
    $ult = 0
    if ($num[$anno].ContainsKey($Tipo)) { $ult = [int]$num[$anno][$Tipo] }
    $nuovo = $ult + 1
    $num[$anno][$Tipo] = $nuovo
    Save-Numerazione $sync $num
    return $nuovo
}

function ConvertTo-HtmlSafe {
    param([string]$Testo)
    if ($null -eq $Testo) { return '' }
    return ([string]$Testo).Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;').Replace('"', '&quot;')
}

function Get-HtmlIntestazione {
    param([string]$Titolo, [string]$Sottotitolo = '')
    return @"
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"/>
<title>$Titolo</title>
<style>
  @page { size: A4; margin: 18mm 16mm; }
  * { box-sizing: border-box; }
  body { font-family: "Segoe UI", Arial, sans-serif; color:#111; font-size:12px; margin:0; }
  h1 { font-size:22px; margin:0 0 2px 0; letter-spacing:.5px; }
  .sub { color:#666; font-size:11px; margin-bottom:14px; }
  .riga { display:flex; justify-content:space-between; gap:20px; margin-bottom:14px; }
  .box { border:1px solid #ddd; border-radius:6px; padding:10px 12px; flex:1; }
  .box h2 { font-size:11px; text-transform:uppercase; letter-spacing:.8px; color:#888; margin:0 0 6px 0; }
  table { width:100%; border-collapse:collapse; margin-top:8px; }
  th { text-align:left; font-size:11px; text-transform:uppercase; color:#666; border-bottom:2px solid #333; padding:6px 4px; }
  td { padding:7px 4px; border-bottom:1px solid #eee; }
  .num { text-align:right; white-space:nowrap; }
  .tot { font-size:15px; font-weight:bold; }
  .banner { background:#fff6d6; border:1px solid #e8c86a; border-radius:6px; padding:9px 12px; font-size:11px; margin-bottom:14px; }
  .firma { margin-top:26px; display:flex; justify-content:space-between; }
  .firma div { width:45%; border-top:1px solid #999; padding-top:6px; font-size:11px; color:#666; }
  .piede { margin-top:18px; font-size:9px; color:#999; border-top:1px solid #eee; padding-top:8px; }
</style></head><body>
"@
}

function Export-DocumentoPdf {
    # Converte un HTML in PDF usando Edge/Chrome in modalita' headless (gia' presenti su Windows).
    param([string]$HtmlPath)
    if (-not $HtmlPath -or -not (Test-Path -LiteralPath $HtmlPath)) { return '' }
    $candidati = @(
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    $exe = ''
    foreach ($c in $candidati) { if ($c -and (Test-Path -LiteralPath $c)) { $exe = $c; break } }
    if (-not $exe) { return '' }
    $pdf = [System.IO.Path]::ChangeExtension($HtmlPath, '.pdf')
    try {
        $arg = '--headless=new --disable-gpu --no-pdf-header-footer --print-to-pdf="' + $pdf + '" "' + $HtmlPath + '"'
        $p = Start-Process -FilePath $exe -ArgumentList $arg -PassThru -WindowStyle Hidden
        $ok = $p.WaitForExit(25000)
        if (Test-Path -LiteralPath $pdf) { return $pdf }
    } catch { }
    return ''
}

function Save-DocumentoHtml {
    param([string]$Html, [string]$Cartella, [string]$NomeBase)
    $dir = $Cartella
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $p = Join-Path $dir ($NomeBase + '.html')
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($p, $Html, $enc)
    return $p
}

function New-Fattura {
    # Voci: elenco di hashtable @{ descrizione; quantita; prezzo; iva (opzionale) }
    param(
        $sync,
        [string]$Cliente = '',
        $Voci = $null,
        [double]$AliquotaIva = -1,
        [string]$Note = '',
        [string]$Numero = '',
        [string]$DataDocumento = '',
        [switch]$NoPdf
    )

    $cfg = Get-DocumentiConfig $sync
    if ($AliquotaIva -lt 0) { $AliquotaIva = [double]$cfg.iva_default }
    if (-not $DataDocumento) { $DataDocumento = (Get-Date -Format 'dd/MM/yyyy') }

    $elenco = @()
    if ($Voci) { $elenco = @($Voci) }
    if ($elenco.Count -eq 0) {
        $elenco = @(@{ descrizione = 'Prestazione (descrizione da completare)'; quantita = 1; prezzo = 0 })
    }

    if (-not $Numero) {
        $n = Get-ProssimoNumero $sync 'fattura'
        $Numero = ([string]$cfg.prefisso_fattura) + '/' + (Get-Date -Format 'yyyy') + '/' + ('{0:0000}' -f $n)
    }

    $imponibile = 0.0
    $righe = New-Object System.Text.StringBuilder
    $i = 1
    foreach ($v in $elenco) {
        $desc = [string]$v.descrizione
        $q = 1.0
        $pr = 0.0
        try { if ($null -ne $v.quantita) { $q = [double]$v.quantita } } catch { }
        try { if ($null -ne $v.prezzo) { $pr = [double]$v.prezzo } } catch { }
        $tot = $q * $pr
        $imponibile += $tot
        [void]$righe.AppendLine('<tr><td>' + $i + '</td><td>' + (ConvertTo-HtmlSafe $desc) + '</td><td class="num">' + $q + '</td><td class="num">' + ('{0:N2}' -f $pr) + '</td><td class="num">' + ('{0:N2}' -f $tot) + '</td></tr>')
        $i++
    }

    $iva = [Math]::Round($imponibile * ($AliquotaIva / 100.0), 2)
    $totale = [Math]::Round($imponibile + $iva, 2)

    $m = $cfg.mittente
    $html = (Get-HtmlIntestazione ('Fattura ' + $Numero) 'Documento generato da ZAP')
    $html += '<h1>FATTURA</h1><div class="sub">N. ' + (ConvertTo-HtmlSafe $Numero) + ' &nbsp;-&nbsp; ' + (ConvertTo-HtmlSafe $DataDocumento) + '</div>'
    $html += '<div class="riga">'
    $html += '<div class="box"><h2>Cedente / Prestatore</h2><b>' + (ConvertTo-HtmlSafe $m.nome) + '</b><br/>'
    if ($m.indirizzo) { $html += (ConvertTo-HtmlSafe $m.indirizzo) + '<br/>' }
    if ($m.cap -or $m.citta) { $html += (ConvertTo-HtmlSafe ($m.cap + ' ' + $m.citta)) + '<br/>' }
    if ($m.piva) { $html += 'P.IVA ' + (ConvertTo-HtmlSafe $m.piva) + '<br/>' }
    if ($m.cf) { $html += 'C.F. ' + (ConvertTo-HtmlSafe $m.cf) + '<br/>' }
    if ($m.email) { $html += (ConvertTo-HtmlSafe $m.email) + '<br/>' }
    if ($m.telefono) { $html += (ConvertTo-HtmlSafe $m.telefono) + '<br/>' }
    $html += '</div>'
    $html += '<div class="box"><h2>Cliente / Committente</h2><b>' + (ConvertTo-HtmlSafe $Cliente) + '</b><br/><span style="color:#999">(dati del cliente da completare se necessario)</span></div>'
    $html += '</div>'
    $html += '<table><thead><tr><th>#</th><th>Descrizione</th><th class="num">Q.ta</th><th class="num">Prezzo</th><th class="num">Totale</th></tr></thead><tbody>'
    $html += $righe.ToString()
    $html += '</tbody></table>'
    $html += '<div style="margin-top:14px; text-align:right">'
    $html += '<div>Imponibile: <b>' + ('{0:N2}' -f $imponibile) + ' ' + (Get-SimboloEuro) + '</b></div>'
    $html += '<div>IVA ' + $AliquotaIva + '%: <b>' + ('{0:N2}' -f $iva) + ' ' + (Get-SimboloEuro) + '</b></div>'
    $html += '<div class="tot">TOTALE: ' + ('{0:N2}' -f $totale) + ' ' + (Get-SimboloEuro) + '</div>'
    $html += '</div>'
    if ($Note) { $html += '<div class="banner" style="margin-top:16px">' + (ConvertTo-HtmlSafe $Note) + '</div>' }
    if ($m.iban) { $html += '<div style="margin-top:12px">Pagamento: bonifico su IBAN <b>' + (ConvertTo-HtmlSafe $m.iban) + '</b></div>' }
    $html += '<div class="piede">Documento generato da ZAP. Verifica dati fiscali, regime IVA e numerazione prima dell''invio: la responsabilita'' del documento resta del contribuente.</div>'
    $html += '</body></html>'

    $cart = Join-Path (Join-Path (Get-DocumentiDir $sync) 'fatture') (Get-Date -Format 'yyyy')
    $nomeBase = 'fattura-' + ((ConvertTo-PsSlug $Numero) -replace '^-', '')
    $p = Save-DocumentoHtml $html $cart $nomeBase
    $pdf = ''
    if (-not $NoPdf) { $pdf = Export-DocumentoPdf $p }

    [void](Add-ZapLedgerEvento $sync 'documento' ("Fattura $Numero per $Cliente - totale " + ('{0:N2}' -f $totale) + " EUR (imponibile " + ('{0:N2}' -f $imponibile) + ", IVA $AliquotaIva%) -> $p") 'fattura' $false)

    $out = "Fattura $Numero creata.`nFile: $p"
    if ($pdf) { $out += "`nPDF: $pdf" } else { $out += "`nPDF non generato (Edge/Chrome non trovati): il file HTML si apre e si stampa comunque." }
    $out += "`nTotale: " + ('{0:N2}' -f $totale) + ' EUR (imponibile ' + ('{0:N2}' -f $imponibile) + ' + IVA ' + ('{0:N2}' -f $iva) + ')'
    return $out
}

function Get-IrpefLorda {
    # Scaglioni da configurazione (default: 23% / 35% / 43%). PURA, testabile.
    param([double]$Imponibile, $Scaglioni)
    $resto = $Imponibile
    $prec = 0.0
    $tot = 0.0
    foreach ($s in @($Scaglioni)) {
        $limite = [double]$s[0]
        $aliquota = [double]$s[1]
        if ($resto -le 0) { break }
        $fascia = [Math]::Min($resto, $limite - $prec)
        if ($fascia -gt 0) {
            $tot += $fascia * ($aliquota / 100.0)
            $resto -= $fascia
            $prec = $limite
        }
    }
    return [Math]::Round($tot, 2)
}

function New-BustaPaga {
    param(
        $sync,
        [string]$Dipendente = '',
        [double]$Lordo = 0,
        [string]$Mese = '',
        [string]$Qualifica = '',
        [switch]$NoPdf
    )
    if ($Lordo -le 0) { return '!Serve il lordo mensile (es. 1800).' }
    if (-not $Mese) { $Mese = (Get-Date -Format 'MMMM yyyy') }

    $cfg = Get-DocumentiConfig $sync
    $b = $cfg.busta
    $inps = [Math]::Round($Lordo * ([double]$b.inps_dipendente / 100.0), 2)
    $imponibileFiscale = [Math]::Round($Lordo - $inps, 2)
    $irpef = Get-IrpefLorda $imponibileFiscale $b.irpef
    $detr = [double]$b.detrazione_mensile
    $netto = [Math]::Round($imponibileFiscale - $irpef + $detr, 2)

    $n = Get-ProssimoNumero $sync 'busta'
    $numero = ([string]$cfg.prefisso_busta) + '/' + (Get-Date -Format 'yyyy') + '/' + ('{0:0000}' -f $n)
    $m = $cfg.mittente

    $html = (Get-HtmlIntestazione ('Busta paga ' + $Mese) 'Simulazione generata da ZAP')
    $html += '<div class="banner"><b>DOCUMENTO DIMOSTRATIVO.</b> Calcolo con parametri semplificati (INPS dipendente '
    $html += [string]$b.inps_dipendente + '%, scaglioni IRPEF da configurazione, detrazione mensile ' + $detr + ' ' + (Get-SimboloEuro) + '). '
    $html += 'Non tiene conto di CCNL, conguagli, addizionali regionali/comunali, bonus e detrazioni personali. '
    $html += 'Non sostituisce il cedolino di un consulente del lavoro.</div>'
    $html += '<h1>PROSPETTO PAGA</h1><div class="sub">' + (ConvertTo-HtmlSafe $numero) + ' &nbsp;-&nbsp; ' + (ConvertTo-HtmlSafe $Mese) + '</div>'
    $html += '<div class="riga"><div class="box"><h2>Datore di lavoro</h2><b>' + (ConvertTo-HtmlSafe $m.nome) + '</b>'
    if ($m.piva) { $html += '<br/>P.IVA ' + (ConvertTo-HtmlSafe $m.piva) }
    $html += '</div><div class="box"><h2>Dipendente</h2><b>' + (ConvertTo-HtmlSafe $Dipendente) + '</b>'
    if ($Qualifica) { $html += '<br/>' + (ConvertTo-HtmlSafe $Qualifica) }
    $html += '</div></div>'
    $html += '<table><thead><tr><th>Voce</th><th class="num">Importo</th></tr></thead><tbody>'
    $html += '<tr><td>Retribuzione lorda</td><td class="num">' + ('{0:N2}' -f $Lordo) + ' ' + (Get-SimboloEuro) + '</td></tr>'
    $html += '<tr><td>Contributi INPS a carico dipendente (' + [string]$b.inps_dipendente + '%)</td><td class="num">-' + ('{0:N2}' -f $inps) + ' ' + (Get-SimboloEuro) + '</td></tr>'
    $html += '<tr><td>Imponibile fiscale</td><td class="num">' + ('{0:N2}' -f $imponibileFiscale) + ' ' + (Get-SimboloEuro) + '</td></tr>'
    $html += '<tr><td>IRPEF lorda (scaglioni)</td><td class="num">-' + ('{0:N2}' -f $irpef) + ' ' + (Get-SimboloEuro) + '</td></tr>'
    if ($detr -ne 0) { $html += '<tr><td>Detrazioni / crediti (parametro)</td><td class="num">+' + ('{0:N2}' -f $detr) + ' ' + (Get-SimboloEuro) + '</td></tr>' }
    $html += '</tbody></table>'
    $html += '<div style="margin-top:14px; text-align:right"><div class="tot">NETTO STIMATO: ' + ('{0:N2}' -f $netto) + ' ' + (Get-SimboloEuro) + '</div></div>'
    $html += '<div class="firma"><div>Firma datore di lavoro</div><div>Firma per ricevuta</div></div>'
    $html += '<div class="piede">Generato da ZAP il ' + (Get-Date -Format 'dd/MM/yyyy HH:mm') + '. Parametri modificabili in config.json -> documenti.busta.</div>'
    $html += '</body></html>'

    $cart = Join-Path (Join-Path (Get-DocumentiDir $sync) 'buste-paga') (Get-Date -Format 'yyyy')
    $nomeBase = 'busta-' + ((ConvertTo-PsSlug ($Dipendente + '-' + $Mese)))
    $p = Save-DocumentoHtml $html $cart $nomeBase
    $pdf = ''
    if (-not $NoPdf) { $pdf = Export-DocumentoPdf $p }

    [void](Add-ZapLedgerEvento $sync 'documento' ("Busta paga $Dipendente $Mese - lordo " + ('{0:N2}' -f $Lordo) + " netto stimato " + ('{0:N2}' -f $netto) + " -> $p") 'busta-paga' $false)

    $out = "Prospetto paga creato per $Dipendente ($Mese).`nFile: $p"
    if ($pdf) { $out += "`nPDF: $pdf" }
    $out += "`nLordo " + ('{0:N2}' -f $Lordo) + ' -> netto stimato ' + ('{0:N2}' -f $netto) + ' EUR'
    $out += "`nAttenzione: e' una SIMULAZIONE con parametri semplificati, non un cedolino ufficiale."
    return $out
}
