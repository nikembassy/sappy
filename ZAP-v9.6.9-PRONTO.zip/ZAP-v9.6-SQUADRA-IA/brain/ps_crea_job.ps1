﻿# ps_crea_job.ps1 -- generatore di script PowerShell per il pannello PS (v9.2.1)
# ---------------------------------------------------------------------------
#  Gira in un RUNSPACE DEDICATO: l'interfaccia non si blocca mai, nemmeno
#  mentre il servizio IA scrive lo script (che puo' richiedere decine di secondi).
#
#  In ingresso (impostate dal runspace): $sync, $base, $domanda, $sysprompt
#  In uscita: un messaggio nella coda UI con Type = 'pscrea'
#     Data = @{ ok = $true/$false; codice = '...'; errore = '...'; domanda = '...' }
# ---------------------------------------------------------------------------

$esito = @{ ok = $false; codice = ''; errore = ''; domanda = [string]$domanda }

# 1) carico i moduli che servono SOLO per parlare col modello
$ErrorActionPreference = 'Stop'
try {
    . (Join-Path $base 'brain\log.ps1')
    . (Join-Path $base 'brain\provider_ai.ps1')
    . (Join-Path $base 'brain\llm.ps1')
} catch {
    $esito.errore = 'moduli IA non caricati: ' + $_.Exception.Message
}

# 2) chiedo lo script e ripulisco l'eventuale contorno markdown
if (-not $esito.errore) {
    $ErrorActionPreference = 'Continue'
    try {
        $messaggi = @(
            @{ role = 'system'; content = [string]$sysprompt },
            @{ role = 'user';   content = [string]$domanda }
        )
        $risposta = Invoke-Chat -sync $sync -Messages $messaggi -Tools $null
        $codice = [string]$risposta
        $codice = $codice -replace '```[a-zA-Z0-9]*', ''
        $codice = $codice -replace '```', ''
        $codice = $codice.Trim()
        if ($codice) {
            $esito.ok = $true
            $esito.codice = $codice
        } else {
            $esito.errore = 'il servizio IA ha risposto senza codice'
        }
    } catch {
        $esito.errore = $_.Exception.Message
    }
}

# 3) rispondo SEMPRE all'interfaccia (anche in caso di errore)
try { $sync.UiQueue.Enqueue(@{ Type = 'pscrea'; Data = $esito }) } catch { }
