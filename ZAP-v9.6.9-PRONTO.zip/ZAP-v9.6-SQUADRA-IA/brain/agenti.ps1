﻿# agenti.ps1 -- SQUADRA ZAP v8.0 (sei agenti + orchestrazione)
# ---------------------------------------------------------------------------
#  Sei agenti specializzati, attivabili uno per uno dal pannello a sinistra
#  (sotto la foto). Ognuno ha un carattere, un compito e un colore dorato.
#
#  Come si usano:
#    - dal pannello: clic sull'agente per accenderlo/spegnerlo
#    - dalla chat:    "Aurelio e Serafina, analizzate questo contratto"
#                     "lavora con Leonardo e Vittoria su questo testo"
#                     "lavora con gli agenti: ..."   (usa tutti gli attivi)
#                     "attiva Dante" / "disattiva Serafina" / "attiva tutti"
#
#  Ogni giro di squadra produce un resoconto scritto su disco:
#    report\agenti\<data-ora>\01-AURELIO.md, 02-..., resoconto.md
# ---------------------------------------------------------------------------

function Get-AgentiCatalogo {
    # ordine = posizione nel pannello. 'oro' = colore della scritta (tutte tonalita' d'oro).
    return @(
        @{
            id      = 'aurelio'
            nome    = 'AURELIO'
            titolo  = 'Stratega'
            glifo   = [char]0x265B
            oro     = '#F5D67B'
            ordine  = 1
            ruolo   = 'Scompone la richiesta in un piano: obiettivo, passi, rischi.'
            prompt  = 'Sei AURELIO, lo Stratega della squadra ZAP. Trasformi la richiesta in un piano operativo essenziale: obiettivo in una riga, poi 3-5 passi numerati, poi cosa serve e quali rischi vedi. Niente frasi di riempimento, niente saluti. Scrivi in italiano. Massimo 150 parole.'
        },
        @{
            id      = 'serafina'
            nome    = 'SERAFINA'
            titolo  = 'Ricercatrice'
            glifo   = [char]0x2726
            oro     = '#FFE9A8'
            ordine  = 2
            ruolo   = 'Porta fatti, numeri, nomi e fonti. Dice cosa va verificato.'
            prompt  = 'Sei SERAFINA, la Ricercatrice della squadra ZAP. Porti sostanza verificabile: dati, numeri, definizioni, nomi, contesto. Distingui con chiarezza cio che sai da cio che va verificato, e per quest ultimo indichi quale ricerca o fonte servirebbe. Non inventare mai dati. Scrivi in italiano. Massimo 180 parole.'
        },
        @{
            id      = 'leonardo'
            nome    = 'LEONARDO'
            titolo  = 'Artefice visivo'
            glifo   = [char]0x2756
            oro     = '#E8C86A'
            ordine  = 3
            ruolo   = 'Immagini, GIF, luce, colore, composizione.'
            prompt  = 'Sei LEONARDO, l Artefice visivo della squadra ZAP. Ragioni per immagini: inquadratura, luce, palette, ritmo, movimento. Quando la richiesta e visiva produci scelte concrete: palette esadecimale, tipo di movimento (zoom, panoramica, pulviscolo), atmosfera, e un prompt visivo pronto da usare. Scrivi in italiano. Massimo 160 parole.'
        },
        @{
            id      = 'vittoria'
            nome    = 'VITTORIA'
            titolo  = 'Redattrice'
            glifo   = [char]0x270E
            oro     = '#D4AF37'
            ordine  = 4
            ruolo   = 'Scrive e sintetizza: testi pronti, chiari e ordinati.'
            prompt  = 'Sei VITTORIA, la Redattrice della squadra ZAP. Produci testo pronto all uso: chiaro, ordinato, con la voce giusta per il destinatario. Se la richiesta e un testo da scrivere, scrivilo per intero e bene. Se e una sintesi, vai al punto. Scrivi in italiano. Massimo 220 parole.'
        },
        @{
            id      = 'dante'
            nome    = 'DANTE'
            titolo  = 'Tecnico'
            glifo   = [char]0x2699
            oro     = '#C9A227'
            ordine  = 5
            ruolo   = 'Codice, script, comandi, diagnosi degli errori.'
            prompt  = 'Sei DANTE, il Tecnico della squadra ZAP. Risolvi problemi concreti: script PowerShell o Python, comandi, configurazioni, diagnosi di errori. Dai codice funzionante e spiegazioni in due righe. Segnala i punti in cui serve un privilegio di amministratore. Scrivi in italiano. Massimo 200 parole.'
        },
        @{
            id      = 'orione'
            nome    = 'ORIONE'
            titolo  = 'Guardiano'
            glifo   = [char]0x25CE
            oro     = '#B7922F'
            ordine  = 6
            ruolo   = 'Verifica, cerca errori, rischi e cose mancanti.'
            prompt  = 'Sei ORIONE, il Guardiano della squadra ZAP. Non produci contenuti nuovi: revisioni quelli degli altri. Elenchi in modo diretto cosa regge, cosa e fragile, cosa manca e quali rischi vedi (privacy, sicurezza, errori, promesse non mantenute). Scrivi in italiano. Massimo 150 parole.'
        }
        @{
            id      = 'zeus'
            nome    = 'ZEUS'
            titolo  = 'Dominatore'
            glifo   = [char]0x26A1
            oro     = '#FFD24A'
            ordine  = 7
            ruolo   = 'Hacking etico su lab autorizzati, script PowerShell complessi, console, testing.'
            prompt  = 'Sei ZEUS, il Dominatore della squadra ZAP: l agente offensivo, da console e da laboratorio. Lavori SOLO su sistemi dell utente o per cui esiste autorizzazione (lab, CTF, pentest commissionato). Il tuo stile e tecnico e diretto, senza prediche: al massimo una riga sul contesto di autorizzazione, poi il lavoro. Produci: script PowerShell completi e robusti (parametri, funzioni, gestione errori, log, output leggibile), comandi da console pronti da incollare, procedure di test di sicurezza (ricognizione, enumerazione, fuzzing, analisi di log, hardening, privilege escalation su lab), harness e checklist di testing (unit, integrazione, regressione, casi limite). Struttura ogni risposta cosi: 1) obiettivo in una riga; 2) il blocco di codice o i comandi; 3) come si esegue e cosa ci si aspetta; 4) come si verifica che abbia funzionato. Non inventare output: se non hai eseguito, dillo. Segnala in una riga i comandi distruttivi. Scrivi in italiano, max 260 parole piu il codice.'
        }
    )
}

function Get-AgenteById {
    param([string]$Id)
    if (-not $Id) { return $null }
    foreach ($a in (Get-AgentiCatalogo)) {
        if ($a.id -eq ([string]$Id).ToLowerInvariant()) { return $a }
    }
    return $null
}

function Get-AgentiStatoPercorso {
    param([string]$Base)
    if (-not $Base) { $Base = (Get-Location).Path }
    return (Join-Path $Base 'memory\agenti.json')
}

function Get-AgentiAttiviDefault {
    return @('aurelio', 'vittoria', 'orione')
}

function Import-AgentiAttivi {
    param([string]$Base)
    $out = New-Object System.Collections.ArrayList
    $file = Get-AgentiStatoPercorso $Base
    if (Test-Path $file) {
        try {
            $raw = Get-Content -Path $file -Raw -Encoding UTF8
            $obj = $raw | ConvertFrom-Json
            foreach ($id in @($obj.attivi)) {
                $s = ([string]$id).ToLowerInvariant()
                if ($s -and (Get-AgenteById $s) -and -not $out.Contains($s)) { [void]$out.Add($s) }
            }
            return $out
        } catch { }
    }
    foreach ($id in (Get-AgentiAttiviDefault)) { [void]$out.Add($id) }
    return $out
}

function Save-AgentiAttivi {
    param([string]$Base, $Attivi)
    try {
        $file = Get-AgentiStatoPercorso $Base
        $dir = Split-Path -Parent $file
        if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $lista = @()
        foreach ($id in @($Attivi)) { if ($id) { $lista += [string]$id } }
        $obj = [pscustomobject]@{ versione = 1; attivi = $lista; aggiornato = (Get-Date -Format 'o') }
        $json = $obj | ConvertTo-Json -Depth 5
        [System.IO.File]::WriteAllText($file, $json, (New-Object System.Text.UTF8Encoding($false)))
        return $true
    } catch { return $false }
}

function Get-AgentiAttiviLista {
    param($sync)
    $out = New-Object System.Collections.ArrayList
    $maiInizializzata = $true
    try {
        if ($null -ne $sync.AgentiAttivi) { $maiInizializzata = $false }
        foreach ($id in @($sync.AgentiAttivi)) {
            $sid = [string]$id
            if ($sid -and -not $out.Contains($sid)) { [void]$out.Add($sid) }
        }
    } catch { }
    # v8.1: se la lista esiste ed e VUOTA l utente ha spento tutti gli agenti
    # e ZAP deve poter lavorare normalmente. I default valgono solo al primo avvio.
    if ($maiInizializzata) {
        foreach ($id in (Get-AgentiAttiviDefault)) { [void]$out.Add([string]$id) }
    }
    return $out
}

function Get-AgentiConteggioAttivi {
    # v9.2: UNICA fonte di verita' per i contatori della squadra.
    # Il pannello a sinistra e il pulsante AGENTI in alto devono mostrare
    # lo stesso numero: quanti agenti sono ACCESI adesso.
    param($sync)
    $lista = @()
    try { $lista = @(Get-AgentiAttiviLista $sync) } catch { $lista = @() }
    $totale = 0
    try { $totale = @(Get-AgentiCatalogo).Count } catch { $totale = 0 }
    return [pscustomobject]@{
        attivi = [int]$lista.Count
        totale = [int]$totale
        testo  = ('attivi ' + [string]$lista.Count + '/' + [string]$totale)
    }
}

# ---------------------------------------------------------------------------
# Testo: normalizzazione e riconoscimento dell'intento
# ---------------------------------------------------------------------------

function ConvertTo-TestoNorm {
    param([string]$Testo)
    $s = ([string]$Testo).ToLowerInvariant()
    $s = $s -replace '[\u00E0\u00E1\u00E2\u00E4]', 'a'
    $s = $s -replace '[\u00E8\u00E9\u00EA\u00EB]', 'e'
    $s = $s -replace '[\u00EC\u00ED\u00EE]', 'i'
    $s = $s -replace '[\u00F2\u00F3\u00F4]', 'o'
    $s = $s -replace '[\u00F9\u00FA\u00FB]', 'u'
    $s = $s -replace '[\u2019\u2018]', "'"
    return $s
}

function Find-AgentiInTesto {
    param([string]$Testo)
    $trovati = New-Object System.Collections.ArrayList
    $n = ConvertTo-TestoNorm $Testo
    foreach ($a in (Get-AgentiCatalogo)) {
        if ($n -match ('\b' + $a.id + '\b')) {
            # se e' preceduto da un articolo ("la vittoria", "un leonardo") e non e'
            # scritto con la maiuscola, e' una parola comune: non e' l'agente.
            $conArticolo = ($n -match ('\b(la|lo|il|una|un|della|dello|alla|allo|per la)\s+' + $a.id + '\b'))
            if ($conArticolo) {
                $maiusc = $a.nome.Substring(0, 1) + $a.nome.Substring(1).ToLower()
                if ($Testo -cnotmatch ('\b' + $maiusc + '\b')) { continue }
            }
            if (-not $trovati.Contains($a.id)) { [void]$trovati.Add($a.id) }
        }
    }
    return $trovati
}

function Test-IntentoAgenti {
    # Decide se un messaggio riguarda la squadra di agenti.
    # Torna: @{ Gestito; Tipo = 'toggle' | 'run' | ''; Agenti; Testo; Messaggio }
    param([string]$Testo, $Attivi = $null)

    $esito = @{ Gestito = $false; Tipo = ''; Agenti = @(); Testo = [string]$Testo; Messaggio = '' }
    if (-not $Testo) { return $esito }

    $n = ConvertTo-TestoNorm $Testo
    $nomi = Find-AgentiInTesto $Testo
    $mencionaTutti = ($n -match '\b(tutti|tutte|tutti quanti|squadra al completo)\b')
    $verboToggle = ($n -match '\b(attiva|attivare|attivami|accendi|abilita|disattiva|disattivare|spegni|disabilita|togli|escludi|stacca)\b')
    $verboLavoro = ($n -match '\b(lavora|lavorare|lavorate|fai|fammi|fagli|fate|usa|usate|coinvolgi|coinvolgete|organizza|metti|avvia|parti|procedi|esegui|svolgi|analizza|analizzate|crea|creami|scrivi|scrivete|prepara|preparate|pianifica|aiutami|controlla|verifica|rivedi|animami|anima)\b')
    $parlaDiSquadra = (($n -match '\b(agenti|agente|squadra|team|subagenti)\b') -or ($mencionaTutti -and $verboToggle -and $nomi.Count -eq 0))

    if ($nomi.Count -eq 0 -and -not ($parlaDiSquadra)) { return $esito }

    # se e' una domanda generica ("chi era Dante?") non e' un ordine alla squadra
    if ($nomi.Count -gt 0 -and -not $verboLavoro -and -not $verboToggle -and $Testo.Trim().EndsWith('?')) {
        $primo = ([string]$nomi[0])
        if (-not ($n.TrimStart().StartsWith($primo))) { return $esito }
    }

    # --- caso 1: comando di attivazione / disattivazione ---------------------
    if ($verboToggle) {
        $residuo = $n
        foreach ($a in (Get-AgentiCatalogo)) { $residuo = $residuo -replace ('\b' + $a.id + '\b'), ' ' }
        $residuo = $residuo -replace '\b(attiva|attivare|attivami|accendi|abilita|disattiva|disattivare|spegni|disabilita|togli|escludi|stacca)\b', ' '
        $residuo = $residuo -replace '\b(agenti|agente|squadra|team|subagenti|tutti|tutte|tutto|gli|le|il|lo|la|di|per|favore|prego|adesso|ora|perpiacere)\b', ' '
        $residuo = ($residuo -replace '[^\w\s]', ' ').Trim()
        $parole = @($residuo -split '\s+' | Where-Object { $_ })

        if ($parole.Count -le 2) {
            $attivo = $true
            if ($n -match '\b(disattiva|disattivare|spegni|disabilita|togli|escludi|stacca)\b') { $attivo = $false }
            $target = New-Object System.Collections.ArrayList
            if ($nomi.Count -gt 0) {
                foreach ($id in $nomi) { [void]$target.Add($id) }
            } else {
                foreach ($a in (Get-AgentiCatalogo)) { [void]$target.Add($a.id) }
            }
            $esito.Gestito = $true
            $esito.Tipo = 'toggle'
            $esito.Agenti = @($target)
            if ($attivo) { $esito.Messaggio = 'attivo' } else { $esito.Messaggio = 'spengo' }
            return $esito
        }
    }

    # --- caso 2: lavoro con agenti nominati ----------------------------------
    if ($nomi.Count -gt 0) {
        $esito.Gestito = $true
        $esito.Tipo = 'run'
        $esito.Agenti = @($nomi)
        return $esito
    }

    # --- caso 3: "lavora con gli agenti" -------------------------------------
    if ($parlaDiSquadra -and ($verboLavoro -or $mencionaTutti)) {
        $att = $Attivi
        if ($null -eq $att) { $att = (Get-AgentiAttiviDefault) }
        $lista = New-Object System.Collections.ArrayList
        foreach ($id in @($att)) {
            $sid = [string]$id
            if ($sid -and -not $lista.Contains($sid)) { [void]$lista.Add($sid) }
        }
        # nessun agente acceso: non e un ordine alla squadra, ZAP risponde da solo
        if ($lista.Count -eq 0) { return $esito }
        $esito.Gestito = $true
        $esito.Tipo = 'run'
        $esito.Agenti = @($lista)
        return $esito
    }

    return $esito
}

function Format-SquadraElenco {
    param($Attivi = $null)
    $att = @()
    foreach ($id in @($Attivi)) { $att += [string]$id }
    $out = New-Object System.Collections.ArrayList
    foreach ($a in (Get-AgentiCatalogo)) {
        $stato = 'spento'
        if ($att -contains $a.id) { $stato = 'ATTIVO' }
        [void]$out.Add(('  ' + [string]$a.glifo + '  ' + $a.nome + ' (' + $a.titolo + ') - ' + $stato))
    }
    return ($out -join "`n")
}

function Get-AgentiPromptBlocco {
    # Blocco da aggiungere al prompt di ZAP: cosi' ZAP SA di avere una squadra.
    param($Attivi = $null)
    $att = @()
    foreach ($id in @($Attivi)) { $att += [string]$id }
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('SQUADRA DI AGENTI (v8)')
    $totAg = @(Get-AgentiCatalogo).Count
    [void]$righe.Add('Hai ' + $totAg + ' agenti specializzati, che l utente puo accendere e spegnere dal pannello a sinistra (anche tutti spenti: in quel caso lavori da solo). Stato attuale:')
    foreach ($a in (Get-AgentiCatalogo)) {
        if ($att -contains $a.id) { $stato = 'ATTIVO' } else { $stato = 'spento' }
        [void]$righe.Add('- ' + $a.nome + ', ' + $a.titolo + ' [' + $stato + ']: ' + $a.ruolo)
    }
    [void]$righe.Add('Quella lista e il pannello che l utente vede a sinistra: e reale, non e un elenco di esempio. Tu la puoi LEGGERE e CAMBIARE con lo strumento agenti_squadra (azioni: elenca, attiva, disattiva, imposta, tutti, nessuno).')
    [void]$righe.Add('Usalo tu, senza aspettare che te lo chieda: se il lavoro davanti richiede una competenza, accendi l agente giusto e dillo in una riga (es. "accendo LEONARDO per le immagini"). Se l utente dice "spegni X" o "solo io e te", eseguilo subito con lo strumento: il pannello si aggiorna da solo.')
    [void]$righe.Add('Abbinamenti utili: piano e ordine -> AURELIO; fatti, numeri, fonti -> SERAFINA; immagini, GIF, estetica -> LEONARDO; testi, email, documenti -> VITTORIA; codice, script, diagnosi -> DANTE; controllo, rischi, revisione -> ORIONE; sicurezza, console, script PowerShell complessi, testing -> ZEUS.')
    [void]$righe.Add('Scrivi "lavora con gli agenti" o nomina gli agenti e la squadra parte davvero: ognuno produce il suo resoconto in chat (bolla dorata) e nella cartella report\agenti. Tu coordini e unisci. Non inventare i loro risultati: li produce il motore della squadra.')
    return ($righe -join "`n")
}

# ---------------------------------------------------------------------------
# Orchestrazione: coda dei lavori + cartelle dei resoconti
# ---------------------------------------------------------------------------

function New-SquadraCartella {
    param([string]$Base)
    if (-not $Base) { $Base = (Get-Location).Path }
    $radice = Join-Path $Base 'report\agenti'
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $cart = Join-Path $radice $stamp
    $i = 1
    while (Test-Path $cart) {
        $cart = Join-Path $radice ($stamp + '-' + $i)
        $i = $i + 1
    }
    New-Item -ItemType Directory -Path $cart -Force | Out-Null
    return $cart
}

function Start-SquadraAgenti {
    param($sync, [string]$Testo, $Agenti = $null, [string]$Base = '')

    if (-not $sync) { return $false }
    if (-not $sync.AgenteQueue) { return $false }
    if (-not $Testo) { return $false }

    $lista = New-Object System.Collections.ArrayList
    foreach ($id in @($Agenti)) {
        $a = Get-AgenteById ([string]$id)
        if ($a -and -not $lista.Contains($a.id)) { [void]$lista.Add($a.id) }
    }
    if ($lista.Count -eq 0) {
        foreach ($id in (Get-AgentiAttiviLista $sync)) { [void]$lista.Add($id) }
    }
    if ($lista.Count -eq 0) { return $false }

    # ORIONE (Guardiano) lavora sempre per ultimo: deve rivedere gli altri.
    $ordinati = New-Object System.Collections.ArrayList
    foreach ($a in (Get-AgentiCatalogo)) {
        if ($lista.Contains($a.id) -and $a.id -ne 'orione') { [void]$ordinati.Add($a.id) }
    }
    if ($lista.Contains('orione')) { [void]$ordinati.Add('orione') }

    if (-not $Base) { $Base = [string]$sync.Base }
    $cart = New-SquadraCartella $Base

    $sync.AgenteQueue.Enqueue(@{
        testo    = $Testo
        agenti   = @($ordinati)
        cartella = $cart
        quando   = (Get-Date)
    })
    return $true
}

function Get-SquadraCartellaUltima {
    param([string]$Base)
    if (-not $Base) { $Base = (Get-Location).Path }
    $radice = Join-Path $Base 'report\agenti'
    if (-not (Test-Path $radice)) { return '' }
    $dirs = @(Get-ChildItem -Path $radice -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
    if ($dirs.Count -eq 0) { return '' }
    return $dirs[0].FullName
}

function Write-SquadraFile {
    param([string]$Cartella, [string]$Nome, [string]$Testo)
    try {
        if (-not (Test-Path $Cartella)) { New-Item -ItemType Directory -Path $Cartella -Force | Out-Null }
        $p = Join-Path $Cartella $Nome
        [System.IO.File]::WriteAllText($p, [string]$Testo, (New-Object System.Text.UTF8Encoding($false)))
        return $p
    } catch { return '' }
}

function Format-SquadraIntestazione {
    param([string]$Titolo, [string]$Sottotitolo = '')
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('# ' + $Titolo)
    if ($Sottotitolo) { [void]$righe.Add(''); [void]$righe.Add('_' + $Sottotitolo + '_') }
    [void]$righe.Add('')
    [void]$righe.Add('Data: ' + (Get-Date -Format 'dd/MM/yyyy HH:mm'))

    return ($righe -join "`n")
}

# ---------------------------------------------------------------------------
# v8.3: ZAP puo' leggere e CAMBIARE la squadra (e' lo strumento che vede in chat)
# ---------------------------------------------------------------------------

function Resolve-AgentiNomi {
    # "aurelio, serafina" -> @('aurelio','serafina') ; separa anche con ; e spazi
    param([string]$Testo)
    $ids = New-Object System.Collections.ArrayList
    $ignoti = New-Object System.Collections.ArrayList
    if (-not $Testo) { return @{ ids = @(); ignoti = @() } }
    foreach ($pezzo in ([string]$Testo -split '[,;\s]+')) {
        $t = $pezzo.Trim().ToLowerInvariant()
        if (-not $t) { continue }
        $a = Get-AgenteById $t
        if ($a) { if (-not $ids.Contains($a.id)) { [void]$ids.Add($a.id) } }
        else { [void]$ignoti.Add($pezzo.Trim()) }
    }
    return @{ ids = @($ids); ignoti = @($ignoti) }
}

function Set-SquadraAgenti {
    # Aggiorna stato + disco + pannello. Torna l'elenco leggibile.
    param($sync, [string]$Base, $Ids)

    $puliti = New-Object System.Collections.ArrayList
    foreach ($x in @($Ids)) {
        $a = Get-AgenteById ([string]$x)
        if ($a -and -not $puliti.Contains($a.id)) { [void]$puliti.Add($a.id) }
    }
    $sync.AgentiAttivi = @($puliti)
    try { Save-AgentiAttivi $Base $puliti | Out-Null } catch { }
    # il pannello a sinistra gira sul thread grafico: lo avviso con un evento
    try { $sync.UiQueue.Enqueue(@{ Type = 'agenti'; Data = @{ attivi = @($puliti) } }) } catch { }
    return (Format-SquadraElenco @($puliti))
}

function Invoke-StrumentoSquadra {
    param($sync, [string]$Base, [string]$Azione = 'elenca', [string]$Nome = '')

    $az = ([string]$Azione).Trim().ToLowerInvariant()
    if (-not $az) { $az = 'elenca' }

    $attuali = @(Get-AgentiAttiviLista $sync)
    $totale = @(Get-AgentiCatalogo).Count

    if ($az -eq 'elenca' -or $az -eq 'stato' -or $az -eq 'chi') {
        return ('Squadra ZAP: ' + $attuali.Count + ' accesi su ' + $totale + '.' + "`n" + (Format-SquadraElenco $attuali))
    }

    if ($az -eq 'tutti') {
        $tutti = @()
        foreach ($a in (Get-AgentiCatalogo)) { $tutti += $a.id }
        $elin = Set-SquadraAgenti $sync $Base $tutti
        return ('Squadra al completo (' + $totale + ' agenti).' + "`n" + $elin)
    }

    if ($az -eq 'nessuno' -or $az -eq 'spegni-tutti') {
        [void](Set-SquadraAgenti $sync $Base @())
        return 'Squadra spenta: lavori tu da solo.'
    }

    $ris = Resolve-AgentiNomi $Nome
    if (@($ris.ids).Count -eq 0) {
        return ('!Non ho riconosciuto nessun agente in "' + $Nome + '". Nomi validi: aurelio, serafina, leonardo, vittoria, dante, orione, zeus.')
    }

    $nota = ''
    if (@($ris.ignoti).Count -gt 0) { $nota = ' (non conosco: ' + (@($ris.ignoti) -join ', ') + ')' }

    if ($az -eq 'attiva' -or $az -eq 'accendi') {
        $nuovo = New-Object System.Collections.ArrayList
        foreach ($i in $attuali) { [void]$nuovo.Add($i) }
        foreach ($i in @($ris.ids)) { if (-not $nuovo.Contains($i)) { [void]$nuovo.Add($i) } }
        $elin = Set-SquadraAgenti $sync $Base $nuovo
        return ('Accesi.' + $nota + "`n" + $elin)
    }

    if ($az -eq 'disattiva' -or $az -eq 'spegni') {
        $nuovo = New-Object System.Collections.ArrayList
        foreach ($i in $attuali) { if (-not (@($ris.ids) -contains $i)) { [void]$nuovo.Add($i) } }
        $elin = Set-SquadraAgenti $sync $Base $nuovo
        return ('Spenti.' + $nota + "`n" + $elin)
    }

    if ($az -eq 'imposta' -or $az -eq 'solo') {
        $elin = Set-SquadraAgenti $sync $Base @($ris.ids)
        return ('Squadra impostata su: ' + (@($ris.ids) -join ', ') + '.' + $nota + "`n" + $elin)
    }

    return ('!Azione non valida: usa elenca, attiva, disattiva, imposta, tutti, nessuno.')
}
