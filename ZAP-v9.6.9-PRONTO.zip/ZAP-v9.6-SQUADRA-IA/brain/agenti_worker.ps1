﻿# agenti_worker.ps1 -- motore della SQUADRA (v8.0, strumentato v9.1)
# ---------------------------------------------------------------------------
#  Gira in un runspace dedicato (quindi l'interfaccia non si blocca mai).
#  Riceve i lavori da $sync.AgenteQueue, chiama un agente alla volta,
#  scrive i resoconti su disco e manda alla chat quello che produce.
#
#  v9.1: ogni passo viene pubblicato in brain\telemetria.ps1, cosi' la CABINA
#  DI REGIA mostra in tempo reale chi lavora, a che punto e', da quanti secondi
#  e con quale strumento. Inoltre il worker OBBEDISCE agli stop:
#     $sync.SquadraStop        -> ferma tutta la squadra
#     $sync.AgenteStop[<id>]   -> ferma quel singolo agente (watchdog o pulsante)
#     $sync.SquadraPausa       -> mette in pausa tra un passo e l'altro
#
#  Variabili attese dal runspace: $sync, $base
# ---------------------------------------------------------------------------

$ErrorActionPreference = 'Continue'

. (Join-Path $base 'brain\log.ps1')
. (Join-Path $base 'brain\provider_ai.ps1')
. (Join-Path $base 'brain\llm.ps1')
. (Join-Path $base 'brain\agenti.ps1')
. (Join-Path $base 'brain\telemetria.ps1')

function Send-SquadraUI {
    param([string]$Tipo, $Dati)
    try { $sync.UiQueue.Enqueue(@{ Type = $Tipo; Data = $Dati }) } catch { }
}

function Send-Telemetria {
    # Scrittura "best effort": la telemetria non deve MAI rompere il lavoro.
    param([string]$Id, [string]$Stato = '', [string]$Azione = '', [string]$Dettaglio = '',
          [int]$Passo = -1, [int]$Totale = -1, [int]$Ms = -1, [string]$File = '',
          [string]$UltimaRiga = '', [string]$Strumento = '', [string]$Comando = '', [string]$Errore = '')
    try {
        if (-not $Id) { return }
        [void](Write-TelemetriaEvento -Base $base -Id $Id -Stato $Stato -Azione $Azione -Dettaglio $Dettaglio `
            -Passo $Passo -Totale $Totale -Ms $Ms -File $File -UltimaRiga $UltimaRiga `
            -Strumento $Strumento -Comando $Comando -Errore $Errore)
    } catch { }
}

function Test-AgenteDaFermare {
    # Tutti i motivi per cui un agente deve smettere SUBITO di iniziare un nuovo passo.
    param([string]$Id = '')
    try { if ($sync.Quit) { return $true } } catch { }
    try { if ($sync.SquadraStop) { return $true } } catch { }
    if ($Id) {
        try {
            if ($sync.AgenteStop -and $sync.AgenteStop.ContainsKey($Id) -and [bool]$sync.AgenteStop[$Id]) { return $true }
        } catch { }
    }
    return $false
}

function Wait-SquadraPausa {
    # Pausa cooperativa: non consuma CPU e si interrompe appena arriva uno stop.
    param([string]$Id = '')
    $giri = 0
    while ($true) {
        try { if (-not $sync.SquadraPausa) { return } } catch { return }
        if (Test-AgenteDaFermare $Id) { return }
        Start-Sleep -Milliseconds 200
        $giri++
        if ($giri -gt 900) { return }   # 3 minuti di pausa massima, poi riparte
    }
}

function Get-SquadraRisposta {
    param($reply)
    if ($null -eq $reply) { return '' }
    if ($reply -is [string]) { return $reply }
    $c = $null
    try { $c = $reply.content } catch { }
    if ($null -eq $c) { try { $c = $reply.text } catch { } }
    if ($null -eq $c) { return [string]$reply }
    return [string](ConvertTo-PlainString $c)
}

function Invoke-SquadraAgente {
    param($Agente, [string]$Testo, $Contributi, [int]$Numero, [int]$Totale)

    $sys = [string]$Agente.prompt
    $sys = $sys + "`n`nFai parte della squadra di ZAP, un assistente desktop italiano. La richiesta arriva dall utente. Rispondi SOLO con il tuo contributo: non ripetere la richiesta, non presentarti, non scrivere frasi di raccordo."

    $user = "Richiesta dell utente:`n" + $Testo + "`n"

    if ($Contributi -and $Contributi.Count -gt 0) {
        $user = $user + "`nCosa hanno gia detto gli altri agenti (sintesi):`n"
        $i = 0
        foreach ($c in $Contributi) {
            $i = $i + 1
            $breve = [string]$c.testo
            if ($breve.Length -gt 500) { $breve = $breve.Substring(0, 500) + '...' }
            $user = $user + '- ' + [string]$c.nome + ': ' + ($breve -replace "`r?`n", ' ') + "`n"
        }
    }
    if ($Agente.id -eq 'orione') {
        $user = $user + "`nIl tuo compito adesso: rivedere i contributi qui sopra. Di cosa regge, cosa e fragile, cosa manca e quali rischi vedi."
    }

    $msg = @(
        @{ role = 'system'; content = $sys },
        @{ role = 'user'; content = $user }
    )

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $reply = Invoke-Chat -sync $sync -Messages $msg -Tools $null
    $sw.Stop()

    $testo = (Get-SquadraRisposta $reply).Trim()
    if (-not $testo) { $testo = '(nessun testo restituito dal modello)' }

    return [pscustomobject]@{ testo = $testo; ms = $sw.ElapsedMilliseconds }
}

function Invoke-SquadraSintesi {
    param([string]$Testo, $Contributi)

    $nome = 'ZAP'
    try { if ($sync.Config.nome) { $nome = [string]$sync.Config.nome } } catch { }

    $sys = "Sei $nome, il coordinatore della squadra. Devi unire i contributi degli agenti in UNA risposta sola, per l utente: ordinata, concreta, in italiano, senza ripetere i nomi degli agenti come intestazioni. Massimo 260 parole. Se gli agenti si contraddicono, scegli la versione piu prudente e dillo in una riga."

    $user = "Richiesta dell utente:`n" + $Testo + "`n`nContributi degli agenti:`n"
    foreach ($c in $Contributi) {
        $user = $user + "`n## " + [string]$c.nome + " (" + [string]$c.titolo + ")`n" + [string]$c.testo + "`n"
    }

    $msg = @(
        @{ role = 'system'; content = $sys },
        @{ role = 'user'; content = $user }
    )
    $reply = Invoke-Chat -sync $sync -Messages $msg -Tools $null
    $t = (Get-SquadraRisposta $reply).Trim()
    return $t
}

function Invoke-SquadraLavoro {
    param($job)

    $cart = [string]$job.cartella
    $testo = [string]$job.testo
    $ids = @($job.agenti)
    if ($ids.Count -eq 0) { return }

    # --- v9.1: la cabina parte pulita, con la richiesta in chiaro -----------
    try { [void](Reset-TelemetriaAgenti $base) } catch { }
    try { [void](Set-TelemetriaSquadra -Base $base -Stato 'al_lavoro' -Richiesta $testo -Cartella $cart -Totale $ids.Count) } catch { }
    foreach ($x in $ids) { Send-Telemetria -Id ([string]$x) -Stato 'in_coda' -Azione 'in attesa del turno' -Totale $ids.Count }

    Send-SquadraUI 'status' 'SQUADRA AL LAVORO...'

    # file della richiesta
    $intestazione = Format-SquadraIntestazione 'Richiesta alla squadra' ('Resoconto generato da ZAP v8')
    $corpo = $intestazione + "`n`n" + $testo + "`n`n" + "Agenti impiegati:`n" + (Format-SquadraElenco $ids)
    Write-SquadraFile $cart '00-richiesta.md' $corpo | Out-Null

    Send-SquadraUI 'agente' @{
        fase     = 'inizio'
        agenti   = $ids
        cartella = $cart
        totale   = $ids.Count
    }

    $contributi = New-Object System.Collections.ArrayList
    $numero = 0

    foreach ($id in $ids) {
        if ($sync.Quit) { break }
        if ($sync.SquadraStop) { break }

        $a = Get-AgenteById $id
        if (-not $a) { continue }
        $numero = $numero + 1

        # stop del singolo agente deciso dalla cabina o dal watchdog
        if (Test-AgenteDaFermare $a.id) {
            Send-Telemetria -Id $a.id -Stato 'fermato' -Azione 'fermato prima di iniziare' -Passo $numero -Totale $ids.Count
            Send-SquadraUI 'agente' @{ fase = 'fermato'; id = $a.id; nome = $a.nome; titolo = $a.titolo; glifo = [string]$a.glifo; oro = $a.oro; numero = $numero; totale = $ids.Count }
            continue
        }

        Wait-SquadraPausa $a.id
        if (Test-AgenteDaFermare $a.id) {
            Send-Telemetria -Id $a.id -Stato 'fermato' -Azione 'fermato in pausa' -Passo $numero -Totale $ids.Count
            continue
        }

        Send-SquadraUI 'agente' @{
            fase    = 'start'
            id      = $a.id
            nome    = $a.nome
            titolo  = $a.titolo
            glifo   = [string]$a.glifo
            oro     = $a.oro
            ruolo   = $a.ruolo
            numero  = $numero
            totale  = $ids.Count
        }
        Send-SquadraUI 'status' ('SQUADRA: ' + $a.nome + ' al lavoro (' + $numero + '/' + $ids.Count + ')')

        Send-Telemetria -Id $a.id -Stato 'pensa' -Azione ('analisi e risposta: ' + [string]$a.titolo) `
            -Dettaglio 'richiesta inviata al modello' -Passo $numero -Totale $ids.Count

        try { $sync.AgenteCorrente = [string]$a.id } catch { }

        $risultato = $null
        $errore = ''
        try {
            $risultato = Invoke-SquadraAgente $a $testo $contributi $numero $ids.Count
        } catch {
            $errore = $_.Exception.Message
        }

        try { $sync.AgenteCorrente = '' } catch { }

        if ($errore) {
            $testoAgente = 'Non ho potuto completare il mio passaggio: ' + $errore
            Send-Telemetria -Id $a.id -Stato 'errore' -Azione 'errore durante la risposta' -Errore $errore -Passo $numero -Totale $ids.Count
        } else {
            $testoAgente = [string]$risultato.testo
        }
        $ms = 0
        if ($risultato) { $ms = [int]$risultato.ms }

        [void]$contributi.Add(@{
            id     = $a.id
            nome   = $a.nome
            titolo = $a.titolo
            oro    = $a.oro
            testo  = $testoAgente
        })

        $file = ('{0:00}-{1}.md' -f $numero, $a.nome)
        $md = '# ' + $a.nome + ' - ' + $a.titolo + "`n`n"
        $md = $md + '_' + $a.ruolo + '_' + "`n`n"
        $md = $md + 'Data: ' + (Get-Date -Format 'dd/MM/yyyy HH:mm') + "`n`n"
        $md = $md + $testoAgente + "`n"
        Write-SquadraFile $cart $file $md | Out-Null

        if (-not $errore) {
            $prima = [string]$testoAgente
            if ($prima.Length -gt 200) { $prima = $prima.Substring(0, 200) + '...' }
            Send-Telemetria -Id $a.id -Stato 'fatto' -Azione 'risposta pronta' -Ms $ms -File $file `
                -UltimaRiga $prima -Passo $numero -Totale $ids.Count
        }

        Send-SquadraUI 'agente' @{
            fase   = 'fine'
            id     = $a.id
            nome   = $a.nome
            titolo = $a.titolo
            glifo  = [string]$a.glifo
            oro    = $a.oro
            testo  = $testoAgente
            ms     = $ms
            file   = $file
            numero = $numero
            totale = $ids.Count
        }
    }

    if ($contributi.Count -eq 0) {
        try { [void](Set-TelemetriaSquadra -Base $base -Stato 'nessun_risultato') } catch { }
        Send-SquadraUI 'agente' @{ fase = 'errore'; messaggio = 'La squadra non ha prodotto contributi.'; cartella = $cart }
        Send-SquadraUI 'status' 'SQUADRA: nessun risultato.'
        return
    }

    # ---- sintesi finale affidata al coordinatore ----------------------------
    try { [void](Set-TelemetriaSquadra -Base $base -Stato 'sintesi') } catch { }
    Send-SquadraUI 'status' 'SQUADRA: sintesi finale...'
    Send-SquadraUI 'agente' @{ fase = 'sintesi'; totale = $contributi.Count }

    $sintesi = ''
    try { $sintesi = Invoke-SquadraSintesi $testo $contributi } catch { $sintesi = '' }
    if (-not $sintesi) {
        $pezzi = @()
        foreach ($c in $contributi) { $pezzi += ('**' + [string]$c.nome + '** - ' + [string]$c.testo) }
        $sintesi = ($pezzi -join "`n`n")
    }

    # ---- resoconto completo su disco ---------------------------------------
    $full = Format-SquadraIntestazione 'Resoconto della squadra' ('Richiesta: ' + $testo)
    $full = $full + "`n`n## Sintesi`n`n" + $sintesi + "`n"
    foreach ($c in $contributi) {
        $full = $full + "`n## " + [string]$c.nome + ' - ' + [string]$c.titolo + "`n`n" + [string]$c.testo + "`n"
    }
    Write-SquadraFile $cart 'resoconto.md' $full | Out-Null

    try { [void](Set-TelemetriaSquadra -Base $base -Stato 'fatto' -Passo $contributi.Count -Totale $ids.Count) } catch { }
    Send-SquadraUI 'agente' @{
        fase     = 'completo'
        sintesi  = $sintesi
        cartella = $cart
        totale   = $contributi.Count
    }
    Send-SquadraUI 'status' 'SQUADRA: fatto.'
}

# ---------------------------------------------------------------------------

while (-not $sync.Quit) {
    $job = $null
    $preso = $false
    try { $preso = $sync.AgenteQueue.TryDequeue([ref]$job) } catch { $preso = $false }

    if ($preso -and $job) {
        $sync.SquadraStop = $false
        # nuovamente in piedi: azzero gli stop dei singoli agenti decisi prima
        try {
            if ($sync.AgenteStop) {
                foreach ($k in @($sync.AgenteStop.Keys)) { $sync.AgenteStop[$k] = $false }
            }
        } catch { }
        try {
            Invoke-SquadraLavoro $job
        } catch {
            Send-SquadraUI 'agente' @{ fase = 'errore'; messaggio = $_.Exception.Message }
            Send-SquadraUI 'status' 'SQUADRA: errore.'
            try { [void](Set-TelemetriaSquadra -Base $base -Stato 'errore') } catch { }
        }
        $sync.SquadraStop = $false
    } else {
        Start-Sleep -Milliseconds 120
    }
}
