﻿# strumenti.ps1 -- v9.1 L'OFFICINA: mette in piedi gli strumenti e li verifica DAVVERO.
# ---------------------------------------------------------------------------
#  Perche' non stanno dentro lo ZIP: sqlmap, hydra, aircrack-ng, nikto, gobuster,
#  dirb, Metasploit e Wireshark (versione Kali) sono pacchetti Linux da centinaia
#  di MB, e Metasploit esiste solo su Linux. Nel pacchetto non ci possono stare.
#  Quello che ci sta - ed e' la parte utile - e' il meccanismo che li installa
#  dalle fonti ufficiali (repository Kali e Wireshark) e poi verifica uno per uno
#  che si avviino davvero. Questo file e' quel meccanismo.
#
#  Due mondi, e va detto chiaro perche' in classe conta:
#    - WIRESHARK (Windows): cattura il traffico del PC. E' la versione da usare.
#    - KALI (WSL): sqlmap, hydra, nikto, gobuster, dirb, Metasploit, aircrack-ng.
#      WSL2 NON vede la scheda WiFi: aircrack-ng si installa e parte, ma il
#      monitor mode non funziona. Per il wireless serve hardware dedicato o un
#      Kali nativo / live USB. Meglio saperlo prima della lezione che durante.
#
#  Funzioni PURE (testabili senza Windows): ConvertFrom-StrumentiOutput,
#  Get-StrumentiRiepilogo. Tutte le altre leggono lo stato reale del PC.
# ---------------------------------------------------------------------------

function Get-StrumentiRichiesti {
    # Gli otto che hai chiesto. 'dove' = windows | wsl. 'pkg' = pacchetto ufficiale.
    return @(
        @{ id='wireshark'; nome='Wireshark';           dove='windows'; pkg='WiresharkFoundation.Wireshark'; bin='Wireshark.exe'; essenziale=$true;
           nota='Cattura del traffico dal PC. Installa anche Npcap. Da usare in versione Windows.' }
        @{ id='sqlmap';    nome='sqlmap';              dove='wsl'; pkg='sqlmap';               bin='sqlmap';     essenziale=$true;
           nota='Verifica e sfruttamento di SQL injection.' }
        @{ id='hydra';     nome='Hydra';               dove='wsl'; pkg='hydra';                bin='hydra';      essenziale=$true;
           nota='Verifica la robustezza delle password di login (solo su sistemi tuoi).' }
        @{ id='aircrack';  nome='Aircrack-ng';         dove='wsl'; pkg='aircrack-ng';          bin='aircrack-ng'; essenziale=$true;
           nota='Si installa e parte, ma in WSL2 NON vede la scheda WiFi: il monitor mode richiede hardware dedicato o un Kali nativo/live USB.' }
        @{ id='nikto';     nome='Nikto';               dove='wsl'; pkg='nikto';                bin='nikto';      essenziale=$true;
           nota='Scansione di vulnerabilita web.' }
        @{ id='gobuster';  nome='Gobuster';            dove='wsl'; pkg='gobuster';             bin='gobuster';   essenziale=$true;
           nota='Directory e vhost nascosti.' }
        @{ id='dirb';      nome='DIRB';                dove='wsl'; pkg='dirb';                 bin='dirb';       essenziale=$true;
           nota='Scansione dei contenuti web.' }
        @{ id='metasploit'; nome='Metasploit';         dove='wsl'; pkg='metasploit-framework'; bin='msfconsole'; essenziale=$true;
           nota='Circa 1 GB. Esiste solo su Linux: dentro Kali (WSL).' }
        @{ id='tshark';    nome='tshark';              dove='wsl'; pkg='tshark';               bin='tshark';     essenziale=$true;
           nota='Wireshark da riga di comando: analizza i .pcap catturati.' }
    )
}

function Get-StrumentiConsigliati {
    # Servono al catalogo pentest di ZAP: senza questi, meta' dei comandi non parte.
    return @(
        @{ id='nmap';     nome='Nmap';      dove='wsl'; pkg='nmap';       bin='nmap';     essenziale=$false; nota='Porte e servizi.' }
        @{ id='ffuf';     nome='ffuf';      dove='wsl'; pkg='ffuf';       bin='ffuf';     essenziale=$false; nota='Fuzzing di URL e parametri.' }
        @{ id='whatweb';  nome='WhatWeb';   dove='wsl'; pkg='whatweb';    bin='whatweb';  essenziale=$false; nota='Tecnologie di un sito.' }
        @{ id='wafw00f';  nome='wafw00f';   dove='wsl'; pkg='wafw00f';    bin='wafw00f';  essenziale=$false; nota='Rileva il WAF.' }
        @{ id='nuclei';   nome='Nuclei';    dove='wsl'; pkg='nuclei';     bin='nuclei';   essenziale=$false; nota='Controlli CVE gia pronti.' }
        @{ id='dig';      nome='DNS (dig)'; dove='wsl'; pkg='dnsutils';   bin='dig';      essenziale=$false; nota='Interrogazioni DNS.' }
        @{ id='wordlists'; nome='Wordlist'; dove='wsl'; pkg='wordlists';  bin='';         essenziale=$false; nota='/usr/share/wordlists per gobuster, dirb, ffuf.' }
    )
}

function Get-StrumentiTutti {
    return @(Get-StrumentiRichiesti) + @(Get-StrumentiConsigliati)
}

# ---------------------------------------------------------------------------
# Lettura dello stato reale
# ---------------------------------------------------------------------------

function ConvertFrom-StrumentiOutput {
    # [PURA] Legge le righe prodotte dallo script bash di verifica.
    #   BINOK:sqlmap      -> il comando esiste nel PATH di Kali
    #   BINNO:sqlmap      -> non c'e'
    #   PKG:sqlmap:1.7.2  -> pacchetto installato, con versione
    param([string]$Testo)
    $bin = @{}
    $pkg = @{}
    if (-not $Testo) { return @{ bin = $bin; pkg = $pkg } }
    foreach ($ln in ([string]$Testo -split "\r?\n")) {
        $r = $ln.Trim()
        if (-not $r) { continue }
        if ($r -match '^BINOK:([^\s:]+)$') { $bin[$Matches[1]] = $true; continue }
        if ($r -match '^BINNO:([^\s:]+)$') { $bin[$Matches[1]] = $false; continue }
        if ($r -match '^PKG:([^:]+):(.+)$') { $pkg[$Matches[1]] = $Matches[2].Trim(); continue }
    }
    return @{ bin = $bin; pkg = $pkg }
}

function Get-StrumentiStatoWsl {
    # UNA sola chiamata a WSL: controllo di tutti i binari e di tutte le versioni.
    # Restituisce @{ ok; bin; pkg; nota }
    param($Voci)
    $bins = @($Voci | Where-Object { $_.dove -eq 'wsl' -and $_.bin } | ForEach-Object { [string]$_.bin } | Select-Object -Unique)
    $pkgs = @($Voci | Where-Object { $_.dove -eq 'wsl' } | ForEach-Object { [string]$_.pkg } | Select-Object -Unique)
    $esito = @{ ok = $false; bin = @{}; pkg = @{}; nota = '' }
    if (-not (Get-Command Get-KaliDistro -ErrorAction SilentlyContinue)) {
        $esito.nota = 'modulo Kali non caricato'
        return $esito
    }
    try {
        if (-not (Get-KaliDistro)) {
            $esito.nota = 'Kali non installato (nessuna distro WSL con nome kali)'
            return $esito
        }
    } catch {
        $esito.nota = 'WSL non disponibile'
        return $esito
    }

    # bash senza virgolette doppie: Invoke-KaliRaw le riscrive, e cosi' evitiamo sorprese.
    $script = @'
for b in __BINS__; do
  if command -v $b >/dev/null 2>&1; then echo BINOK:$b; else echo BINNO:$b; fi
done
for p in __PKGS__; do
  v=$(dpkg-query -W -f='${Version}' $p 2>/dev/null)
  if [ -n "$v" ]; then echo PKG:$p:$v; fi
done
'@
    $script = $script.Replace('__BINS__', ($bins -join ' ')).Replace('__PKGS__', ($pkgs -join ' '))

    try {
        $r = Invoke-KaliRaw $script 90
    } catch {
        $esito.nota = ('errore WSL: ' + $_.Exception.Message)
        return $esito
    }
    if (-not $r.ok) {
        $esito.nota = 'Kali non risponde'
        return $esito
    }
    $letto = ConvertFrom-StrumentiOutput ([string]$r.out)
    $esito.bin = $letto.bin
    $esito.pkg = $letto.pkg
    $esito.ok = $true
    return $esito
}

function Find-WiresharkWindows {
    # Percorsi ufficiali + PATH. Restituisce '' se non c'e'.
    $candidati = @()
    try { if ($env:ProgramFiles) { $candidati += (Join-Path $env:ProgramFiles 'Wireshark\Wireshark.exe') } } catch { }
    try { if (${env:ProgramFiles(x86)}) { $candidati += (Join-Path ${env:ProgramFiles(x86)} 'Wireshark\Wireshark.exe') } } catch { }
    $candidati += 'C:\Program Files\Wireshark\Wireshark.exe'
    foreach ($c in $candidati) {
        try { if ($c -and (Test-Path -LiteralPath $c)) { return $c } } catch { }
    }
    try {
        $cmd = Get-Command 'wireshark' -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source) { return [string]$cmd.Source }
    } catch { }
    return ''
}

function Get-StrumentiStato {
    # Tabella completa: per ogni strumento dice se c'e', dove e con quale versione.
    param($sync)
    $voci = @(Get-StrumentiTutti)
    $statoWsl = Get-StrumentiStatoWsl $voci
    $wireshark = ''
    try { $wireshark = Find-WiresharkWindows } catch { $wireshark = '' }

    $out = New-Object System.Collections.ArrayList
    foreach ($v in $voci) {
        $pronto = $false
        $dove = ''
        $versione = ''
        if ([string]$v.dove -eq 'windows') {
            if ($wireshark) { $pronto = $true; $dove = $wireshark }
        } else {
            if ($statoWsl.bin.ContainsKey([string]$v.bin)) { $pronto = [bool]$statoWsl.bin[[string]$v.bin] }
            if ($statoWsl.pkg.ContainsKey([string]$v.pkg)) { $versione = [string]$statoWsl.pkg[[string]$v.pkg] }
            if ($pronto) { $dove = 'Kali (WSL)' }
            # wordlists non ha un binario: conta il pacchetto
            if (-not $v.bin -and $statoWsl.pkg.ContainsKey([string]$v.pkg)) { $pronto = $true; $dove = 'Kali (WSL)' }
        }
        [void]$out.Add(@{
            id        = [string]$v.id
            nome      = [string]$v.nome
            dove      = [string]$v.dove
            pronto    = $pronto
            percorso  = $dove
            versione  = $versione
            essenziale = [bool]$v.essenziale
            nota      = [string]$v.nota
        })
    }
    return @{ voci = @($out); kali = [bool]$statoWsl.ok; nota = [string]$statoWsl.nota }
}

function Get-StrumentiRiepilogo {
    # [PURA] Conta pronti/mancanti e separa essenziali da consigliati.
    param($Voci)
    $eTot = 0; $eOk = 0; $cTot = 0; $cOk = 0
    foreach ($v in @($Voci)) {
        if ($v.essenziale) { $eTot++; if ($v.pronto) { $eOk++ } }
        else { $cTot++; if ($v.pronto) { $cOk++ } }
    }
    return @{ essenziali_pronti = $eOk; essenziali_totali = $eTot; consigliati_pronti = $cOk; consigliati_totali = $cTot }
}

function Get-StrumentiMancanti2 {
    # Nomi degli strumenti essenziali che mancano (per il prompt e per la chat).
    param($Stato)
    $out = New-Object System.Collections.ArrayList
    foreach ($v in @($Stato.voci)) {
        if ($v.essenziale -and -not $v.pronto) { [void]$out.Add([string]$v.nome) }
    }
    return @($out)
}

function Format-StrumentiStato {
    param($sync, [switch]$ConNote)
    $s = Get-StrumentiStato $sync
    $r = Get-StrumentiRiepilogo $s.voci
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('STRUMENTI DI PENTEST')
    [void]$righe.Add('')
    [void]$righe.Add('  essenziali : ' + $r.essenziali_pronti + '/' + $r.essenziali_totali + ' pronti')
    [void]$righe.Add('  consigliati: ' + $r.consigliati_pronti + '/' + $r.consigliati_totali + ' pronti')
    if (-not $s.kali) {
        [void]$righe.Add('')
        [void]$righe.Add('  KALI NON E PRONTO' + $(if ($s.nota) { ' (' + $s.nota + ')' } else { '' }))
        [void]$righe.Add('  -> doppio clic su PREPARA_STRUMENTI_v9.1.bat (installa WSL Kali e gli strumenti)')
    }
    [void]$righe.Add('')
    $primaEss = $true
    foreach ($v in @($s.voci)) {
        if ($primaEss -and -not $v.essenziale) { [void]$righe.Add(''); [void]$righe.Add('  -- consigliati (servono al catalogo ZAP) --'); $primaEss = $false }
        $segno = 'MANCA '
        if ($v.pronto) { $segno = 'PRONTO' }
        $extra = ''
        if ($v.versione) { $extra = '  v' + $v.versione }
        elseif ($v.percorso) { $extra = '  ' + $v.percorso }
        [void]$righe.Add('  [' + $segno + '] ' + ([string]$v.nome).PadRight(14) + ' ' + ([string]$v.dove).PadRight(8) + $extra)
        if ($ConNote -and $v.nota) { [void]$righe.Add('           ' + $v.nota) }
    }
    [void]$righe.Add('')
    [void]$righe.Add('  comandi: /strumenti installa | /strumenti verifica | /strumenti wireshark')
    return ($righe -join "`n")
}

function Save-StrumentiStato {
    param($sync, $Stato)
    try {
        $b = ''
        try { $b = [string]$sync.Base } catch { $b = '' }
        if (-not $b) { $b = (Get-Location).Path }
        $p = Join-Path $b 'memory\strumenti.json'
        $dir = Split-Path -Parent $p
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $dati = @{
            aggiornato = (Get-Date -Format 'o')
            kali       = [bool]$Stato.kali
            voci       = @($Stato.voci)
        }
        [System.IO.File]::WriteAllText($p, ($dati | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
        return $p
    } catch { return '' }
}

# ---------------------------------------------------------------------------
# Installazione
# ---------------------------------------------------------------------------

function Test-WingetDisponibile {
    try {
        $c = Get-Command 'winget' -ErrorAction SilentlyContinue
        return [bool]$c
    } catch { return $false }
}

function Installa-WiresharkWindows {
    param([switch]$Rumoroso)
    $gia = Find-WiresharkWindows
    if ($gia) { return ('Wireshark gia installato: ' + $gia) }

    if (Test-WingetDisponibile) {
        if ($Rumoroso) { Write-Host '   installo Wireshark con winget (qualche minuto)...' -ForegroundColor Cyan }
        try {
            $p = Start-Process -FilePath 'winget' -ArgumentList @(
                'install', '--id', 'WiresharkFoundation.Wireshark', '-e',
                '--accept-source-agreements', '--accept-package-agreements', '--silent'
            ) -Wait -PassThru -NoNewWindow
            if ((Find-WiresharkWindows)) { return 'Wireshark installato (winget), Npcap compreso.' }
            return ('winget ha risposto con codice ' + $p.ExitCode + ': Wireshark non risulta installato. Scaricalo da https://www.wireshark.org/download.html')
        } catch {
            return ('winget non riuscito: ' + $_.Exception.Message + '. Scarica da https://www.wireshark.org/download.html')
        }
    }
    return 'winget non disponibile: scarica Wireshark da https://www.wireshark.org/download.html (spunta Npcap)'
}

function Installa-StrumentiTutti {
    # Installa quello che manca, dalle fonti ufficiali, e riverifica tutto alla fine.
    param($sync, [string[]]$Solo = @(), [switch]$SenzaExtra, [switch]$SenzaWireshark, [switch]$Rumoroso)
    $rapporto = New-Object System.Collections.ArrayList
    $fare = { param($t) if ($Rumoroso) { Write-Host $t -ForegroundColor Cyan } }

    [void]$rapporto.Add('INSTALLAZIONE STRUMENTI')
    [void]$rapporto.Add('')

    # --- 1) Wireshark (Windows) ------------------------------------------
    if (-not $SenzaWireshark) {
        $w = Find-WiresharkWindows
        if ($w) {
            [void]$rapporto.Add('  Wireshark : gia presente')
        } else {
            & $fare '  Wireshark: installazione su Windows...'
            $esito = Installa-WiresharkWindows -Rumoroso:$Rumoroso
            [void]$rapporto.Add('  Wireshark : ' + $esito)
        }
    }

    # --- 2) Kali pronto? ---------------------------------------------------
    $distro = ''
    try { $distro = [string](Get-KaliDistro) } catch { $distro = '' }
    if (-not $distro) {
        [void]$rapporto.Add('')
        [void]$rapporto.Add('  KALI NON INSTALLATO: gli strumenti Linux non si possono mettere adesso.')
        [void]$rapporto.Add('  1. chiudi ZAP')
        [void]$rapporto.Add('  2. doppio clic su PREPARA_STRUMENTI_v9.1.bat (fa tutto, anche Kali)')
        [void]$rapporto.Add('  3. se chiede di riavviare, riavvia e rilancia lo stesso file')
        return ($rapporto -join "`n")
    }

    # --- 3) cosa manca -----------------------------------------------------
    $voci = @(Get-StrumentiRichiesti)
    if (-not $SenzaExtra) { $voci += @(Get-StrumentiConsigliati) }
    if ($Solo.Count -gt 0) {
        $voci = @($voci | Where-Object { $Solo -contains [string]$_.id })
    }
    $stato = Get-StrumentiStato $sync
    $mancanti = @()
    foreach ($v in $voci) {
        $trovato = @($stato.voci | Where-Object { $_.id -eq [string]$v.id })
        $pronto = $false
        if ($trovato.Count -gt 0) { $pronto = [bool]$trovato[0].pronto }
        if (-not $pronto -and [string]$v.dove -eq 'wsl') { $mancanti += [string]$v.pkg }
    }
    $mancanti = @($mancanti | Select-Object -Unique)

    if ($mancanti.Count -eq 0) {
        [void]$rapporto.Add('')
        [void]$rapporto.Add('  Niente da installare: e tutto gia a posto.')
        return ($rapporto -join "`n")
    }

    [void]$rapporto.Add('')
    [void]$rapporto.Add('  Da installare in Kali: ' + ($mancanti -join ', '))
    [void]$rapporto.Add('  (Metasploit da solo pesa circa 1 GB: la prima volta puo servire un quarto d ora)')
    [void]$rapporto.Add('')

    # --- 4) apt update -----------------------------------------------------
    & $fare '  apt-get update...'
    $up = $null
    try { $up = Invoke-KaliRaw 'apt-get update' 1200 -ComeRoot } catch { $up = $null }
    if (-not $up -or -not $up.ok) {
        [void]$rapporto.Add('  ERRORE su apt-get update: ' + $(if ($up) { [string]$up.out } else { 'nessuna risposta da WSL' }))
        return ($rapporto -join "`n")
    }
    [void]$rapporto.Add('  apt-get update: fatto')

    # --- 5) installazione a blocchi ---------------------------------------
    # In due giri: prima gli essenziali (se uno dei pacchetti grossi fallisce,
    # non si porta dietro tutto il resto), poi i consigliati.
    $essenzialiPkg = @()
    foreach ($v in @(Get-StrumentiRichiesti)) { if ($mancanti -contains [string]$v.pkg) { $essenzialiPkg += [string]$v.pkg } }
    $extraPkg = @($mancanti | Where-Object { $essenzialiPkg -notcontains $_ })

    $giri = @()
    if ($essenzialiPkg.Count -gt 0) { $giri += ,@('essenziali', $essenzialiPkg) }
    if ($extraPkg.Count -gt 0) { $giri += ,@('consigliati', $extraPkg) }

    foreach ($g in $giri) {
        $etichetta = [string]$g[0]
        $pkgs = @($g[1])
        if ($pkgs.Count -eq 0) { continue }
        & $fare ('  installo ' + $etichetta + ': ' + ($pkgs -join ', '))
        $cmd = 'DEBIAN_FRONTEND=noninteractive apt-get install -y ' + ($pkgs -join ' ')
        $r = $null
        try { $r = Invoke-KaliRaw $cmd 5400 -ComeRoot } catch { $r = $null }
        if ($r -and $r.ok) {
            [void]$rapporto.Add('  ' + $etichetta + ': installati -> ' + ($pkgs -join ', '))
        } else {
            $dett = 'nessuna risposta'
            if ($r) { $dett = ([string]$r.out) }
            if ($dett.Length -gt 400) { $dett = $dett.Substring($dett.Length - 400) }
            [void]$rapporto.Add('  ' + $etichetta + ': ERRORE -> ' + $dett)
        }
    }

    # --- 6) riverifica -----------------------------------------------------
    & $fare '  riverifico...'
    $dopo = Get-StrumentiStato $sync
    try { [void](Save-StrumentiStato $sync $dopo) } catch { }
    $ria = Get-StrumentiRiepilogo $dopo.voci
    [void]$rapporto.Add('')
    [void]$rapporto.Add('  Dopo l installazione: ' + $ria.essenziali_pronti + '/' + $ria.essenziali_totali + ' essenziali pronti')
    foreach ($v in @($dopo.voci)) {
        if (-not $v.essenziale) { continue }
        $segno = 'MANCA'
        if ($v.pronto) { $segno = 'OK' }
        $ver = ''
        if ($v.versione) { $ver = ' v' + $v.versione }
        [void]$rapporto.Add('    [' + $segno + '] ' + $v.nome + $ver)
    }
    $ancora = @($dopo.voci | Where-Object { $_.essenziale -and -not $_.pronto })
    if ($ancora.Count -gt 0) {
        [void]$rapporto.Add('')
        [void]$rapporto.Add('  Ancora mancanti: ' + (($ancora | ForEach-Object { $_.nome }) -join ', '))
        [void]$rapporto.Add('  Riprova con: /strumenti installa   (oppure PREPARA_STRUMENTI_v9.1.bat)')
    } else {
        [void]$rapporto.Add('')
        [void]$rapporto.Add('  Tutti gli strumenti richiesti rispondono.')
    }
    return ($rapporto -join "`n")
}

function Get-StrumentiPromptBlocco {
    # Riga sintetica per il prompt: ZAP sa cosa ha e non propone comandi impossibili.
    param($sync)
    try {
        $s = Get-StrumentiStato $sync
        $r = Get-StrumentiRiepilogo $s.voci
        $manc = Get-StrumentiMancanti2 $s
        $t = 'STRUMENTI: ' + $r.essenziali_pronti + '/' + $r.essenziali_totali + ' essenziali pronti'
        if ($manc.Count -gt 0) { $t += ' (mancano: ' + ($manc -join ', ') + ' -> /strumenti installa)' }
        return $t
    } catch { return '' }
}
