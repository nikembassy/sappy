﻿# tools.ps1 - Strumenti che l'agente puo' usare (function calling)
# v5 - i moduli di brain\ vengono caricati qui, uno per uno, in ordine esplicito.

. (Join-Path $PSScriptRoot 'log.ps1')
. (Join-Path $PSScriptRoot 'audit.ps1')
. (Join-Path $PSScriptRoot 'policy.ps1')
. (Join-Path $PSScriptRoot 'sandbox.ps1')
. (Join-Path $PSScriptRoot 'errori.ps1')
. (Join-Path $PSScriptRoot 'ui_wait.ps1')
. (Join-Path $PSScriptRoot 'tema.ps1')
. (Join-Path $PSScriptRoot 'modalita.ps1')
. (Join-Path $PSScriptRoot 'autonomia.ps1')
. (Join-Path $PSScriptRoot 'programmi.ps1')
. (Join-Path $PSScriptRoot 'pc_controllo.ps1')
. (Join-Path $PSScriptRoot 'tools_v7.ps1')
# --- v9: memoria indelebile, libreria PowerShell, guardia anti-bugia, traccia, documenti, posta
# Caricati uno per uno e protetti: se un modulo ha un problema, l'agente funziona lo stesso
# (perde solo gli strumenti di quel modulo) invece di non partire affatto.
foreach ($__mod in @('memoria_v9.ps1', 'ps_libreria.ps1', 'verita.ps1', 'traccia.ps1', 'office.ps1', 'email_gmail.ps1', 'ghost.ps1', 'pentest_tools.ps1')) {
    $__mp = Join-Path $PSScriptRoot $__mod
    if (-not (Test-Path -LiteralPath $__mp)) { continue }
    try { . $__mp } catch { }
}

# v9.4: il motore delle skin serve anche all'agente (strumento 'skin')
try { $__sk = Join-Path $PSScriptRoot 'skins.ps1'; if (Test-Path -LiteralPath $__sk) { . $__sk } } catch { }

function Get-CfgBool {
    # v9.4: legge un'opzione booleana anche se nel config.json non esiste ancora.
    param($Cfg, [string]$Nome, [bool]$Default = $false)
    try {
        if ($null -eq $Cfg) { return $Default }
        $p = $Cfg.PSObject.Properties[$Nome]
        if ($p -and $null -ne $p.Value) { return [bool]$p.Value }
    } catch { }
    return $Default
}

function Set-CfgBool {
    param($Cfg, [string]$Nome, [bool]$Valore)
    try {
        if ($null -eq $Cfg) { return $false }
        if ($Cfg.PSObject.Properties[$Nome]) { $Cfg.$Nome = $Valore }
        else { $Cfg | Add-Member -NotePropertyName $Nome -NotePropertyValue $Valore -Force }
        return $true
    } catch { return $false }
}

function Get-AgentTools {
    return @(
        @{
            type = 'function'
            function = @{
                name = 'skin'
                description = "Cambia l'interfaccia (skin) di ZAP: classica, astronave, universo, ologramma, fantasy, cyberpunk. Senza nome elenca le interfacce disponibili."
                parameters = @{
                    type = 'object'
                    properties = @{ nome = @{ type = 'string'; description = 'nome della skin (vuoto = elenco)' } }
                    required = @()
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'nastro_notizie'
                description = "Mostra o nasconde la barra delle notizie che scorre sotto il titolo. stato: on | off | inverti."
                parameters = @{
                    type = 'object'
                    properties = @{ stato = @{ type = 'string'; description = 'on | off | inverti' } }
                    required = @('stato')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'automatizza'
                description = "Esegue SUBITO uno script PowerShell senza chiedere conferma e, se indichi un orario, lo ripete ogni giorno da solo. Usalo quando l'utente dice 'automatizza', 'fallo da solo', 'senza chiedermi'."
                parameters = @{
                    type = 'object'
                    properties = @{
                        script = @{ type = 'string'; description = 'codice PowerShell da eseguire' }
                        orario = @{ type = 'string'; description = 'HH:mm per ripeterlo ogni giorno (vuoto = solo adesso)' }
                    }
                    required = @('script')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'apri_programma'
                description = "Apre un programma o un'app di Windows (blocco note, calcolatrice, paint, chrome, word, whatsapp, impostazioni...). Usalo quando l'utente dice 'apri ...'. Restituisce una conferma oppure l'errore vero."
                parameters = @{
                    type = 'object'
                    properties = @{ nome = @{ type = 'string'; description = 'nome del programma o dell app da aprire' } }
                    required = @('nome')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'gestisci_finestre'
                description = "Gestisce le finestre aperte: azione 'elenca' (cosa e' aperto), 'chiudi' (chiude una finestra o la scheda/pagina attiva), 'minimizza', 'massimizza', 'attiva'. Usa 'chiudi' quando l'utente dice 'chiudi questa pagina' o 'chiudi questa finestra'."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione = @{ type = 'string'; description = 'elenca | chiudi | minimizza | massimizza | attiva' }
                        filtro = @{ type = 'string'; description = 'parte del titolo o nome processo (vuoto = finestra attiva)' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'scrivi_testo'
                description = "Scrive testo nella finestra attiva, come se digitassi. Usalo dopo aver aperto o attivato la finestra giusta (es. scrivere in Blocco note o in una chat). Il testo passa dagli appunti e viene incollato."
                parameters = @{
                    type = 'object'
                    properties = @{ testo = @{ type = 'string'; description = 'testo da scrivere' } }
                    required = @('testo')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'lancia_programma'
                description = "Elenco e avvio dei programmi dell'utente: azione 'elenco' mostra cosa c'e' nella cartella 'programmi', azione 'lancia' con il nome avvia quel programma."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione = @{ type = 'string'; description = 'elenco | lancia' }
                        nome   = @{ type = 'string'; description = 'nome del programma da lanciare' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'run_powershell'
                description = "Esegue codice PowerShell sul computer dell'utente e restituisce l'output. Usa questo strumento per QUALSIASI operazione sul PC: file, cartelle, programmi, download, sistema, automazioni. Ogni esecuzione e' isolata in una sessione unica: se ti serve ricordare qualcosa tra un'esecuzione e l'altra, salvala su file o usa remember. L'utente vede cosa esegui e, se serve, l'interfaccia gli chiede conferma."
                parameters = @{
                    type = 'object'
                    properties = @{
                        code   = @{ type = 'string'; description = 'Codice PowerShell da eseguire' }
                        motivo = @{ type = 'string'; description = 'Breve frase in italiano che spiega all''utente cosa stai facendo' }
                    }
                    required = @('code')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'open_browser'
                description = "Apre una URL nel browser dell'utente. Se l'utente chiede di aprire il browser, di fare una ricerca visibile o di visitare un sito, usa questo strumento (per le ricerche web_search con open_in_browser=true apre gia' il browser)."
                parameters = @{
                    type = 'object'
                    properties = @{
                        url = @{ type = 'string'; description = 'URL completo da aprire (https://...)' }
                    }
                    required = @('url')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'web_search'
                description = "Cerca su internet (DuckDuckGo). Restituisce titoli, link e snippet dei primi risultati. Se l'utente chiede di aprire il browser o di fare una ricerca sul browser, imposta open_in_browser=true: si apre anche il browser con i risultati. Dopo la ricerca, usa read_webpage sulle 2-3 fonti migliori e riassumi cosa hai trovato con i link."
                parameters = @{
                    type = 'object'
                    properties = @{
                        query            = @{ type = 'string'; description = 'La ricerca da fare (in italiano va benissimo)' }
                        open_in_browser  = @{ type = 'boolean'; description = 'true per aprire anche il browser con i risultati' }
                    }
                    required = @('query')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'read_webpage'
                description = "Legge il contenuto testuale di una pagina web (titolo + testo, troncato). Usala sui risultati di web_search per approfondire prima di riassumere all'utente."
                parameters = @{
                    type = 'object'
                    properties = @{
                        url        = @{ type = 'string'; description = 'URL della pagina da leggere' }
                        max_chars  = @{ type = 'integer'; description = 'Massimo di caratteri da restituire (default 6000)' }
                    }
                    required = @('url')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'remember'
                description = "Salva nella memoria permanente un fatto importante sull'utente (nome, preferenze, progetti, abitudini). Verra' ricordato nelle conversazioni future."
                parameters = @{
                    type = 'object'
                    properties = @{
                        nota = @{ type = 'string'; description = 'Il fatto da ricordare, in una frase chiara' }
                    }
                    required = @('nota')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'recall_memory'
                description = "Rilegge la memoria salvata su file. Usala se l'utente chiede cosa ricordi di lui."
                parameters = @{
                    type = 'object'
                    properties = @{}
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'teach_skill'
                description = "INSEGNA a ZAP una nuova procedura riutilizzabile e la salva su disco. Usala quando: (1) l'utente ti insegna qualcosa ('ti insegno a fare X: prima fai A poi B'), (2) non sai fare una cosa e l'utente ti da' i passaggi o lo script, (3) hai appena risolto una cosa complessa che varra' la pena ripetere. La skill resta per sempre. Il codice deve essere PowerShell completo ed eseguibile. Subito dopo, conferma all'utente: 'Ora so fare X' e proponi di provarla."
                parameters = @{
                    type = 'object'
                    properties = @{
                        name        = @{ type = 'string'; description = 'Nome breve in minuscolo senza spazi (es. backup_documenti)' }
                        description = @{ type = 'string'; description = 'Cosa fa la skill, in italiano' }
                        when_to_use = @{ type = 'string'; description = 'Quando richiamarla: frasi o situazioni tipiche dell''utente' }
                        codice      = @{ type = 'string'; description = 'Script PowerShell completo. Puo''iniziare con un blocco param(). Deve restituire output testuale utile.' }
                    }
                    required = @('name', 'description', 'when_to_use', 'codice')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'use_skill'
                description = "Esegue una skill gia' imparata (vedi list_skills per l'elenco)."
                parameters = @{
                    type = 'object'
                    properties = @{
                        nome       = @{ type = 'string'; description = 'Nome della skill' }
                        argomenti  = @{ type = 'array'; items = @{ type = 'string' }; description = 'Argomenti opzionali da passare alla skill' }
                    }
                    required = @('nome')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'list_skills'
                description = "Elenca tutte le skill imparate fino ad ora (nome, descrizione, quando usarle)."
                parameters = @{
                    type = 'object'
                    properties = @{}
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'delete_skill'
                description = "Elimina una skill imparata. Usala solo se l'utente lo chiede esplicitamente."
                parameters = @{
                    type = 'object'
                    properties = @{
                        nome = @{ type = 'string'; description = 'Nome della skill da eliminare' }
                    }
                    required = @('nome')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'list_browsers'
                description = "Elenca i browser installati sul PC e quale e' quello predefinito dell'utente."
                parameters = @{ type = 'object'; properties = @{} }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'set_browser'
                description = "Imposta il browser predefinito in cui aprire le pagine. Valori: thorium, yandex, chrome, edge, brave, firefox. Usalo quando l'utente dice quale browser preferisce."
                parameters = @{
                    type = 'object'
                    properties = @{ key = @{ type = 'string'; description = 'thorium | yandex | chrome | edge | brave | firefox' } }
                    required = @('key')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'list_search_engines'
                description = "Elenca i motori di ricerca disponibili (DuckDuckGo, Google, Bing, Yandex, Startpage) e quello predefinito."
                parameters = @{ type = 'object'; properties = @{} }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'set_search_engine'
                description = "Imposta il motore di ricerca predefinito. Valori: duckduckgo, google, bing, yandex, startpage."
                parameters = @{
                    type = 'object'
                    properties = @{ key = @{ type = 'string'; description = 'duckduckgo | google | bing | yandex | startpage' } }
                    required = @('key')
                }
            }
        }
        @{
            type = 'function'
            function = @{
                name = 'guarda_schermo'
                description = "Guarda lo schermo del PC (fa uno screenshot) e risponde a una domanda su quello che c'e'. Usalo quando l'utente chiede 'cosa vedi?', 'leggi quello che c'e' scritto', 'aiutami con questa finestra', 'cosa devo cliccare'."
                parameters = @{
                    type = 'object'
                    properties = @{ domanda = @{ type = 'string'; description = 'cosa vuoi sapere guardando lo schermo' } }
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'impara_dallo_schermo'
                description = "Impara guardando lo schermo: fa uno screenshot, capisce cosa sta facendo l'utente e salva la procedura nella memoria, cosi' la sai rifare. Usalo quando l'utente dice 'impara guardando', 'guarda come faccio', 'impara questa procedura'."
                parameters = @{
                    type = 'object'
                    properties = @{ domanda = @{ type = 'string'; description = 'cosa deve imparare osservando lo schermo' } }
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'consigli_miglioramento'
                description = "Restituisce trucchi e opzioni concrete per migliorare ZAP (skill da insegnare, comandi da usare, impostazioni). Usalo quando l'utente chiede come renderti migliore o piu' potente."
                parameters = @{
                    type = 'object'
                    properties = @{ argomento = @{ type = 'string'; description = 'su cosa vuole migliorarti (opzionale)' } }
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'stato_amministratore'
                description = "Dice se ZAP sta girando come amministratore e come ottenerlo. Usalo quando l'utente chiede se hai i permessi di amministratore."
                parameters = @{ type = 'object'; properties = @{} }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'aggiungi_appunto'
                description = "Aggiunge una riga agli APPUNTI dell'utente (salvati su file, non si perdono). Usalo quando l'utente dice 'annota', 'scrivi negli appunti', 'segnati'."
                parameters = @{
                    type = 'object'
                    properties = @{ testo = @{ type = 'string'; description = 'cosa annotare' } }
                    required = @('testo')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'agenti_squadra'
                description = "Legge e CAMBIA la squadra di agenti che si vede nel pannello a sinistra (AURELIO, SERAFINA, LEONARDO, VITTORIA, DANTE, ORIONE, ZEUS). Usalo quando l'utente chiede chi sono, quando vuole accendere o spegnere un agente, oppure quando decidi TU che per il lavoro in corso servono certi agenti. Azioni: elenca, attiva, disattiva, imposta (lista esatta), tutti, nessuno."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione = @{ type = 'string'; description = "elenca | attiva | disattiva | imposta | tutti | nessuno" }
                        nome = @{ type = 'string'; description = "nome o nomi degli agenti separati da virgola (aurelio, serafina, leonardo, vittoria, dante, orione, zeus)" }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'leggi_appunti'
                description = "Legge gli APPUNTI salvati dall'utente. Usalo quando chiede 'leggi i miei appunti' o 'cosa ho scritto'."
                parameters = @{ type = 'object'; properties = @{} }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'whatsapp_invia'
                description = "Manda un messaggio WhatsApp a un contatto. Apre la chat giusta con il testo gia dentro e preme Invio, POI VERIFICA. La risposta comincia con 'VERIFICATO: SI', 'PARZIALE' o 'NO': riporta quello, non inventare. Serve il numero: se il contatto non e in rubrica chiedi il numero e salvalo con contatti_whatsapp."
                parameters = @{
                    type = 'object'
                    properties = @{
                        contatto = @{ type = 'string'; description = 'nome del contatto (es. Marco) oppure il numero' }
                        testo    = @{ type = 'string'; description = 'testo esatto del messaggio da inviare' }
                        telefono = @{ type = 'string'; description = 'numero, se lo conosci e non e in rubrica (opzionale)' }
                        invia    = @{ type = 'boolean'; description = 'true (default) = manda subito; false = prepara la chat senza premere Invio' }
                    }
                    required = @('contatto', 'testo')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'contatti_whatsapp'
                description = "Gestisce la RUBRICA WhatsApp di ZAP (nome -> numero). Azioni: salva (nome + telefono), elenca, cerca (nome), elimina (nome), stato. Salvare il numero una volta rende gli invii affidabili per sempre: usa 'salva' appena l'utente dice il numero di qualcuno."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione   = @{ type = 'string'; description = 'salva | elenca | cerca | elimina | stato' }
                        nome     = @{ type = 'string'; description = 'nome del contatto' }
                        telefono = @{ type = 'string'; description = 'numero di telefono (per salva)' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'memoria'
                description = "MEMORIA INDELEBILE (cartella Ezappero, non si cancella e ogni modifica e' rilevabile). Azioni: 'salva' (scrive un evento: cosa hai fatto, un fatto sull'utente, un risultato), 'permanente' (regola/fatto che vale SEMPRE e va ricordato in ogni risposta), 'cerca' (cerca nel passato), 'stato' (eventi + integrita), 'integra' (verifica la catena di hash), 'diario' (cosa e' successo oggi). Usala ogni volta che fai qualcosa di importante: e' la tua memoria vera, quella che non si perde."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione = @{ type = 'string'; description = 'salva | permanente | cerca | stato | integra | diario' }
                        testo  = @{ type = 'string'; description = 'il contenuto da salvare o la ricerca' }
                        tag    = @{ type = 'string'; description = 'etichetta libera (cliente, progetto, argomento)' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'libreria_script'
                description = "LIBRERIA POWERSHELL di ZAP (sezione POWERSHELL SCRIPT). Ogni script generato si archivia qui, ordinato da solo per categoria. Azioni: 'salva' (codice + titolo), 'cerca' (parola chiave), 'elenca', 'stato'. REGOLA: prima di scrivere uno script nuovo cerca qui: se esiste gia' riusalo. Salva SEMPRE gli script trovati sul web o scritti da te."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione      = @{ type = 'string'; description = 'salva | cerca | elenca | stato' }
                        codice      = @{ type = 'string'; description = 'codice PowerShell completo (per salva)' }
                        titolo      = @{ type = 'string'; description = 'titolo breve (per salva)' }
                        fonte       = @{ type = 'string'; description = 'web | chat | documento | manuale' }
                        descrizione = @{ type = 'string'; description = 'a cosa serve' }
                        query       = @{ type = 'string'; description = 'parola chiave (per cerca)' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'documento'
                description = "Crea documenti veri in Ezappero\documenti. Azioni: 'fattura' (voci + cliente -> HTML+PDF con numerazione progressiva), 'busta_paga' (lordo + dipendente -> prospetto paga DIMOSTRATIVO con parametri semplificati), 'pdf' (converte un HTML in PDF). Digli sempre all'utente che la busta paga e' una simulazione."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione    = @{ type = 'string'; description = 'fattura | busta_paga | pdf' }
                        cliente   = @{ type = 'string'; description = 'nome del cliente (fattura)' }
                        dipendente = @{ type = 'string'; description = 'nome del dipendente (busta_paga)' }
                        lordo     = @{ type = 'number'; description = 'lordo mensile in euro (busta_paga)' }
                        mese      = @{ type = 'string'; description = 'mese di competenza (busta_paga)' }
                        iva       = @{ type = 'number'; description = 'aliquota IVA % (fattura, default 22)' }
                        voci      = @{ type = 'array'; description = 'voci della fattura: [{descrizione, quantita, prezzo}]' }
                        note      = @{ type = 'string'; description = 'note in fattura' }
                        percorso  = @{ type = 'string'; description = 'file HTML da convertire (pdf)' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'email'
                description = "POSTA (Gmail/SMTP). Azioni: 'stato' (e' configurata?), 'configura' (mittente + password per le app), 'invia' (a, oggetto, corpo, allegati), 'bozza' (prepara senza inviare). Di default ZAP crea BOZZE e non invia: manda solo se l'utente te lo chiede esplicitamente."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione    = @{ type = 'string'; description = 'stato | configura | invia | bozza' }
                        a         = @{ type = 'string'; description = 'destinatario' }
                        oggetto   = @{ type = 'string'; description = 'oggetto' }
                        corpo     = @{ type = 'string'; description = 'testo della email' }
                        cc        = @{ type = 'string'; description = 'in copia (opzionale)' }
                        allegati  = @{ type = 'array'; description = 'percorsi dei file da allegare' }
                        mittente  = @{ type = 'string'; description = 'indirizzo Gmail (per configura)' }
                        password  = @{ type = 'string'; description = 'password per le app Gmail (per configura)' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'traccia'
                description = "MODALITA' TRACCIA: ZAP guarda cosa fa l'utente sul PC (finestra in primo piano + programma) e prende nota in Ezappero\tracce. Azioni: 'avvia', 'ferma', 'stato', 'oggi' (riassunto del tempo per programma). E' spenta di default: avviala solo se l'utente lo chiede."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione = @{ type = 'string'; description = 'avvia | ferma | stato | oggi' }
                        giorno = @{ type = 'string'; description = 'data aaaa-mm-gg (per oggi)' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'verifica'
                description = "GUARDIA ANTI-BUGIA. Azione 'controlla': analizza un testo e dice quali numeri/link/certezze NON risultano dalle fonti. Azione 'registra': annota un'affermazione con la sua prova (o 'nessuna prova') nel registro. Usala prima di dichiarare un risultato importante."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione       = @{ type = 'string'; description = 'controlla | registra' }
                        testo        = @{ type = 'string'; description = 'la frase o la risposta da verificare' }
                        prove        = @{ type = 'string'; description = 'output degli strumenti / fonti a supporto' }
                        affermazione = @{ type = 'string'; description = 'affermazione da registrare' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'ghost'
                description = "MODALITA GHOST: gestisce il perimetro dei bersagli autorizzati. Azioni: 'stato' (perimetro e consenso), 'aggiungi' (voce = dominio/IP/rete, es. miosito.it o 192.168.1.0/24), 'togli', 'elenco', 'consenti' (registra che i bersagli sono tuoi), 'attiva' / 'spegni'. In modalita GHOST ogni comando che tocca un bersaglio fuori dal perimetro viene bloccato PRIMA di essere eseguito."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione = @{ type = 'string'; description = 'stato | aggiungi | togli | elenco | consenti | attiva | spegni | perimetro | perimetro-on | perimetro-off' }
                        voce   = @{ type = 'string'; description = 'dominio, IP o rete da aggiungere o togliere' }
                    }
                    required = @('azione')
                }
            }
        },
        @{
            type = 'function'
            function = @{
                name = 'strumenti'
                description = "CASSETTA DEGLI ATTREZZI (modalita GHOST): elenca gli strumenti di pentest realmente installati su questo PC e le ricette pronte per ogni fase. Azioni: 'elenca' (strumenti per categoria), 'ricette' (comandi pronti, filtrabili per categoria: ricognizione, web, rete, credenziali, sfruttamento, wireless), 'mancanti', 'inventario' (rilegge documentazione\strumenti.json). Usala PRIMA di proporre un comando: non inventare strumenti che l'utente non ha."
                parameters = @{
                    type = 'object'
                    properties = @{
                        azione    = @{ type = 'string'; description = 'elenca | ricette | mancanti | inventario' }
                        categoria = @{ type = 'string'; description = 'ricognizione | web | rete | credenziali | sfruttamento | wireless' }
                    }
                    required = @('azione')
                }
            }
        }
    ) + (Get-AgentToolsV7)
}

# ---------------------------------------------------------------------------
# Utilita'
# ---------------------------------------------------------------------------

function ConvertTo-PlainText {
    param([string]$Html)
    $t = [regex]::Replace($Html, '(?s)<script.*?</script>', ' ')
    $t = [regex]::Replace($t, '(?s)<style.*?</style>', ' ')
    $t = [regex]::Replace($t, '(?s)<!--.*?-->', ' ')
    $t = [regex]::Replace($t, '<[^>]+>', ' ')
    $t = [System.Net.WebUtility]::HtmlDecode($t)
    $t = [regex]::Replace($t, '[ \t]+', ' ')
    $t = [regex]::Replace($t, '(\r?\n\s*){2,}', "`n")
    $t = $t.Trim()
    return $t
}

function Get-WorkDir {
    param($sync)
    $w = [string]$sync.Config.cartella_lavoro
    if ($w -and (Test-Path $w)) { return $w }
    $d = [Environment]::GetFolderPath('Desktop')
    if ($d -and (Test-Path $d)) { return $d }
    return $env:USERPROFILE
}

function Get-SkillsDir {
    param($sync)
    return (Join-Path $sync.Base 'skills')
}

function Get-SkillList {
    param($sync)
    $regPath = Join-Path (Get-SkillsDir $sync) 'registry.json'
    if (-not (Test-Path $regPath)) { return @() }
    try {
        $raw = Get-Content $regPath -Raw -Encoding UTF8
        if (-not $raw) { return @() }
        return @(ConvertFrom-Json $raw)
    } catch { return @() }
}

function Save-SkillList {
    param($sync, [array]$Items)
    $regPath = Join-Path (Get-SkillsDir $sync) 'registry.json'
    ($Items | ConvertTo-Json -Depth 6) | Set-Content -Path $regPath -Encoding UTF8
}

function ConvertTo-SkillSlug {
    param([string]$Name)
    $s = $Name.ToLower().Trim()
    $s = $s -replace '\s+', '-'
    $s = $s -replace '[^a-z0-9_\-]', ''
    $s = $s -replace '-+', '-'
    $s = $s.Trim('-')
    return $s
}

# ---------------------------------------------------------------------------
# Esecuzione PowerShell (sessione persistente + timeout + stop)
# ---------------------------------------------------------------------------

function Initialize-Executor {
    param($sync)
    $rs = [runspacefactory]::CreateRunspace()
    $rs.ApartmentState  = 'STA'
    $rs.ThreadOptions   = 'ReuseThread'
    $rs.Open()
    try { $rs.SessionStateProxy.Path.SetLocation((Get-WorkDir $sync)) } catch { }
    $sync.ExecutorRunspace = $rs
}

function Reset-Executor {
    param($sync)
    try { if ($sync.ExecutorRunspace) { $sync.ExecutorRunspace.Close() } } catch { }
    Initialize-Executor $sync
}

function Get-PatternRischi {
    # L'elenco dei comandi "da confermare" vive in un file di dati accanto a questo
    # modulo: si aggiorna senza toccare il codice ed evita falsi positivi antivirus.
    $f = Join-Path $PSScriptRoot 'comandi_pericolosi.txt'
    if (Test-Path $f) {
        $righe = @(Get-Content -Path $f -Encoding UTF8 -ErrorAction SilentlyContinue |
                   Where-Object { $_ -and $_.Trim() -and -not $_.Trim().StartsWith('#') } |
                   ForEach-Object { $_.Trim() })
        if ($righe.Count -gt 0) { return ($righe -join '|') }
    }
    # rete di sicurezza se il file manca
    return 'Remove-Item|Stop-Process|Stop-Computer|Restart-Computer|Set-ExecutionPolicy'
}

function Test-RiskyCode {
    param([string]$Code)
    return ($Code -match (Get-PatternRischi))
}

function Ask-UserConfirm {
    # Protocollo a dati: l'agente lascia la richiesta in $sync, la UI mostra il
    # dialogo e risveglia l'agente via evento. Nessun codice UI attraverso i thread.
    param($sync, [string]$Message)
    $done = New-Object System.Threading.ManualResetEventSlim($false)
    $sync.ConfirmResult  = $false
    $sync.ConfirmDone    = $done
    $sync.ConfirmRequest = @{ Text = $Message }
    try {
        [void]$done.Wait(300000)
    } catch { }
    $sync.ConfirmRequest = $null
    return [bool]$sync.ConfirmResult
}

# ---------------------------------------------------------------------------
# v7.9: amministratore SU RICHIESTA (usato da AVVIA_ADMIN.bat)
# La finestra di ZAP resta NON elevata cosi' il trascinamento dei file funziona; se
# un comando fallisce per mancanza di privilegi lo riprovo elevato (consenso UAC).
# ---------------------------------------------------------------------------

function Test-BisognoAdmin {
    param([string]$Esito)
    if (-not $Esito) { return $false }
    return ($Esito -match "(?i)accesso negato|access is denied|permesso negato|operazione non consentita|non autorizzato|richiede privilegi|requires elevation|elevation required|unauthorizedaccess|requested registry access|requested operation requires elevation|\bnegato\b")
}

function Invoke-PsToolElevato {
    param($sync, [string]$Code, [int]$TimeoutSec = 0)
    if ($TimeoutSec -le 0) { $TimeoutSec = [int]$sync.Config.timeout_powershell_sec }
    if ($TimeoutSec -le 0) { $TimeoutSec = 120 }
    $g = [guid]::NewGuid().ToString('N')
    $dir = $env:TEMP
    if (-not $dir) { $dir = (Get-Location).Path }
    $scriptF = Join-Path $dir ('zap_admin_' + $g + '.ps1')
    $outF    = Join-Path $dir ('zap_admin_' + $g + '.out')
    $head = "`$ErrorActionPreference='Continue'; `$__zapOut = (& {`r`n"
    $tail = "`r`n} *>&1 | Out-String); [System.IO.File]::WriteAllText('" + ($outF -replace "'", "''") + "', `$__zapOut, (New-Object System.Text.UTF8Encoding(`$false)))"
    try {
        [System.IO.File]::WriteAllText($scriptF, ($head + $Code + $tail), (New-Object System.Text.UTF8Encoding($false)))
    } catch { return '!Non riesco a preparare il comando elevato.' }
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -WindowStyle Hidden -Wait -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File', $scriptF)
    } catch {
        foreach ($f in @($scriptF,$outF)) { try { Remove-Item $f -Force -ErrorAction SilentlyContinue } catch { } }
        return '!Elevazione annullata o non riuscita (nessun consenso UAC): ' + $_.Exception.Message
    }
    $out = ''
    try { if (Test-Path $outF) { $out = [System.IO.File]::ReadAllText($outF) } } catch { }
    foreach ($f in @($scriptF,$outF)) { try { Remove-Item $f -Force -ErrorAction SilentlyContinue } catch { } }
    if (-not $out.Trim()) { $out = '(eseguito come amministratore, senza output)' }
    if ($out.Length -gt 8000) { $out = $out.Substring(0, 7800) + "`n...[output troncato]" }
    return $out
}

function Invoke-PsTool {
    param($sync, [string]$Code, [int]$TimeoutSec = 0)

    if ($TimeoutSec -le 0) { $TimeoutSec = [int]$sync.Config.timeout_powershell_sec }
    if ($TimeoutSec -le 0) { $TimeoutSec = 120 }

    if (-not $sync.ExecutorRunspace) { Initialize-Executor $sync }

    $ps = [powershell]::Create()
    $ps.Runspace = $sync.ExecutorRunspace
    [void]$ps.AddScript($Code)
    $sync.CurrentExec = $ps

    $timedOut = $false
    $stopMsg  = ''
    $outColl  = $null
    try {
        $h = $ps.BeginInvoke()
        if (-not $h.AsyncWaitHandle.WaitOne($TimeoutSec * 1000)) {
            $timedOut = $true
            try { $ps.Stop() } catch { }
            try { $outColl = $ps.EndInvoke($h) } catch { }
        }
        else {
            try { $outColl = $ps.EndInvoke($h) } catch { $stopMsg = $_.Exception.Message }
        }
    }
    catch {
        $stopMsg = $_.Exception.Message
    }
    finally {
        $sync.CurrentExec = $null
    }

    $outText = ''
    try {
        $objs = @($ps.Streams.Information | ForEach-Object {
            if ($_.MessageData) { [string]$_.MessageData } else { $_.ToString() }
        })
        if ($objs.Count -gt 0) { $outText += ($objs -join [Environment]::NewLine) + [Environment]::NewLine }
    } catch { }

    try {
        if ($null -ne $outColl) {
            $std = ($outColl | Out-String -Width 200).Trim()
            if ($std) { $outText += $std }
        }
    } catch { }

    $errText = ''
    try {
        $es = @($ps.Streams.Error | ForEach-Object { $_.ToString() })
        if ($es.Count -gt 0) { $errText = ($es -join [Environment]::NewLine) }
    } catch { }

    try { $ps.Dispose() } catch { }

    if ($timedOut) {
        Reset-Executor $sync
        return "!TIMEOUT dopo $TimeoutSec secondi: esecuzione interrotta. Se serve piu' tempo, spezza il lavoro in passi piu' piccoli."
    }

    $result = ''
    if ($outText.Trim())  { $result += $outText.Trim() }
    if ($errText) {
        if ($result) { $result += "`n" }
        $result += "!ERRORI:`n$errText"
    }
    if ($stopMsg -and -not $errText) {
        if ($result) { $result += "`n" }
        $result += "!INTERROTTO: $stopMsg"
    }
    if (-not $result) { $result = '(eseguito senza output)' }

    if ($result.Length -gt 8000) {
        $result = $result.Substring(0, 7800) + "`n...[output troncato]"
    }
    return $result
}

# ---------------------------------------------------------------------------
# Web
# ---------------------------------------------------------------------------

function ConvertFrom-DdgUrl {
    param([string]$u)
    if ($u -match 'uddg=([^&"]+)') {
        return [uri]::UnescapeDataString($Matches[1])
    }
    if ($u.StartsWith('//')) { return 'https:' + $u }
    return $u
}

function Invoke-WebSearch {
    param($sync, [string]$Query, [bool]$OpenInBrowser = $false, [string]$Engine = '')

    $eng = $Engine
    if (-not $eng) { $eng = [string]$sync.Config.motore_ricerca }
    if (-not $eng) { $eng = 'duckduckgo' }
    $reg = Get-EngineRegistry
    $ek = $eng.Trim().ToLower()
    if (-not $reg.Contains($ek)) { $ek = 'duckduckgo' }

    try { Start-Sleep -Milliseconds (Get-Random -Minimum 400 -Maximum 1300) } catch { }

    $searchUrl = Get-EngineUrl $ek $Query
    $q = [uri]::EscapeDataString($Query)
    $html = ''
    if ($ek -eq 'duckduckgo') {
        $html = Invoke-WebFetch ($reg[$ek].html.Replace('{q}', $q)) $reg[$ek].home
        if (-not $html) { $html = Invoke-WebFetch ("https://lite.duckduckgo.com/lite/?q=$q") $reg[$ek].home }
    } else {
        $html = Invoke-WebFetch $searchUrl $reg[$ek].home
    }

    if ($OpenInBrowser) {
        try { Open-UrlInBrowser $sync $searchUrl } catch { }
    }

    if (-not $html) {
        return "Ricerca su $($reg[$ek].name) non riuscita (il sito potrebbe aver bloccato la richiesta). La ricerca e' aperta qui: $searchUrl"
    }

    $results = @()
    $m = [regex]::Matches($html, '<a[^>]*class="result__a"[^>]*href="(?<url>[^"]+)"[^>]*>(?<title>.*?)</a>')
    if ($m.Count -eq 0) { $m = [regex]::Matches($html, '<a[^>]*class="result-link"[^>]*href="(?<url>[^"]+)"[^>]*>(?<title>.*?)</a>') }
    $snips = [regex]::Matches($html, 'class="result__snippet"[^>]*>(?<s>.*?)</a>')
    if ($snips.Count -eq 0) { $snips = [regex]::Matches($html, 'class="result-snippet"[^>]*>(?<s>.*?)</td>') }

    for ($i = 0; $i -lt $m.Count -and $i -lt 8; $i++) {
        $url   = ConvertFrom-DdgUrl $m[$i].Groups['url'].Value
        $title = ConvertTo-PlainText $m[$i].Groups['title'].Value
        $snip  = ''
        if ($i -lt $snips.Count) { $snip = ConvertTo-PlainText $snips[$i].Groups['s'].Value }
        $results += "### $($i+1). $title`nURL: $url`n$snip"
    }

    if ($results.Count -eq 0) {
        $bloccato = ($html -match '(?i)captcha|showcaptcha|are you a robot|non sei un robot|verifica')
        # la lettura automatica non e' bastata: apro la ricerca nel browser, cosi'
        # l'utente vede i risultati veri (Yandex blocca spesso le richieste automatiche)
        try { if (-not $OpenInBrowser) { [void](Open-UrlInBrowser $sync $searchUrl) } } catch { }
        if ($bloccato) {
            return ("$($reg[$ek].name) ha chiesto una verifica automatica (captcha): la ricerca l ho aperta nel browser, guardala li.`n$searchUrl")
        }
        $text = ConvertTo-PlainText $html
        if ($text.Length -gt 1500) { $text = $text.Substring(0, 1500) + '...' }
        if ($text.Trim()) {
            return "Risultati da $($reg[$ek].name) per '$Query' (estratto). Ho anche aperto la ricerca nel browser:`n`n$text`n`nPagina: $searchUrl"
        }
        return "Nessun risultato letto da $($reg[$ek].name) per '$Query'. Ho aperto la ricerca nel browser: $searchUrl"
    }

    return ("Risultati della ricerca '$Query' ($($reg[$ek].name)):`n`n" + ($results -join "`n`n") + "`n`n(Ricorda: apri le fonti migliori con read_webpage e riassumi con i link.)")
}

function Open-UrlInBrowser {
    param($sync, [string]$Url, [string]$Browser = '')
    if (-not $Url) { return 'URL mancante.' }
    if ($Url -notmatch '^[a-z]+://') { $Url = 'https://' + $Url }

    $key = $Browser
    if (-not $key) { $key = [string]$sync.Config.browser }
    if (-not $key) { $key = 'thorium' }
    $key = $key.Trim().ToLower()

    $exe = Resolve-BrowserPath $sync $key
    if ($exe) {
        try {
            # v8.5: si passa SOLO l'URL all'eseguibile. Se il browser e' gia'
            # aperto, l'istanza in corso lo intercetta e apre una SCHEDA nella
            # finestra esistente. "--new-window" (usato prima) apriva una
            # finestra nuova ogni volta: era quello il problema.
            if ($key -eq 'firefox') { $spargs = @('-new-tab', $Url) }
            else { $spargs = @($Url) }
            Start-Process -FilePath $exe -ArgumentList $spargs | Out-Null
            return ("Aperto in $key (nuova scheda nella finestra gia' aperta): " + $Url)
        } catch { }
    }
    Start-Process $Url
    return "Browser aperto su: $Url (nota: '$key' non trovato, ho usato il browser predefinito)"
}

function Invoke-ReadWebpage {
    param([string]$Url, [int]$MaxChars = 6000)
    if ($Url -notmatch '^[a-z]+://') { $Url = 'https://' + $Url }
    if ($MaxChars -le 0) { $MaxChars = 6000 }

    $html = Invoke-WebFetch $Url
    if (-not $html) {
        return "Non sono riuscito a leggere $Url (forse ha bloccato la richiesta). Prova ad aprirla nel browser."
    }

    $title = ''
    $tm = [regex]::Match($html, '(?is)<title[^>]*>(?<t>.*?)</title>')
    if ($tm.Success) { $title = ConvertTo-PlainText $tm.Groups['t'].Value }

    $text = ConvertTo-PlainText $html
    if ($text.Length -gt $MaxChars) { $text = $text.Substring(0, $MaxChars) + ' ...[testo troncato]' }
    return "PAGINA: $title`nURL: $Url`n`n$text"
}

# ---------------------------------------------------------------------------
# Memoria
# ---------------------------------------------------------------------------

function Get-MemoryPath {
    param($sync)
    return (Join-Path $sync.Base 'memory\notes.md')
}

function Add-Memory {
    param($sync, [string]$Nota)
    $p = Get-MemoryPath $sync
    $line = "- [$(Get-Date -Format 'yyyy-MM-dd HH:mm')] $Nota"
    Add-Content -Path $p -Value $line -Encoding UTF8
    return "Memorizzato: $Nota"
}

function Get-MemoryText {
    param($sync)
    $p = Get-MemoryPath $sync
    if (Test-Path $p) { return (Get-Content $p -Raw -Encoding UTF8) }
    return '(memoria vuota)'
}

# ---------------------------------------------------------------------------
# Skill (impara / esegui / elenca / elimina)
# ---------------------------------------------------------------------------

function Save-Skill {
    param($sync, [string]$Name, [string]$Description, [string]$WhenToUse, [string]$Code)

    $slug = ConvertTo-SkillSlug $Name
    if (-not $slug) { return '!Nome skill non valido: usa lettere minuscole e numeri.' }
    if (-not $Code -or $Code.Trim().Length -lt 2) { return '!Codice skill vuoto.' }

    $dir = Get-SkillsDir $sync
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    $path = Join-Path $dir "$slug.ps1"

    $header = @"
# skill: $slug
# descrizione: $Description
# quando: $WhenToUse
# creato: $(Get-Date -Format 'yyyy-MM-dd')
"@
    Set-Content -Path $path -Value ($header + "`r`n" + $Code) -Encoding UTF8

    $list = @(Get-SkillList $sync | Where-Object { $_.name -ne $slug })
    $list += [PSCustomObject]@{
        name        = $slug
        description = $Description
        when_to_use = $WhenToUse
        file        = "$slug.ps1"
        created     = (Get-Date -Format 'yyyy-MM-dd')
    }
    Save-SkillList $sync $list

    return "Skill '$slug' salvata in skills\$slug.ps1. Da ora in poi so farlo: richiamala con use_skill quando serve."
}

function Invoke-Skill {
    param($sync, [string]$Name, [array]$Argomenti)

    $slug = ConvertTo-SkillSlug $Name
    $item = Get-SkillList $sync | Where-Object { $_.name -eq $slug } | Select-Object -First 1
    $dir  = Get-SkillsDir $sync
    $path = Join-Path $dir "$slug.ps1"

    if (-not (Test-Path $path)) {
        $alt = Get-ChildItem $dir -Filter '*.ps1' -ErrorAction SilentlyContinue |
            Where-Object { $_.BaseName -eq $slug } | Select-Object -First 1
        if ($alt) { $path = $alt.FullName }
        else { return "!Skill '$Name' non trovata. Usa list_skills per vedere quelle disponibili." }
    }

    $quoted = @()
    if ($Argomenti) {
        foreach ($a in @($Argomenti)) {
            $s = ([string]$a) -replace "'", "''"
            $quoted += "'$s'"
        }
    }
    $cmd = "& '$($path -replace "'", "''")'"
    if ($quoted.Count -gt 0) { $cmd += ' ' + ($quoted -join ' ') }

    $out = Invoke-PsTool $sync $cmd
    return "Risultato della skill '$slug':`n$out"
}

function Remove-Skill {
    param($sync, [string]$Name)
    $slug = ConvertTo-SkillSlug $Name
    $dir  = Get-SkillsDir $sync
    $path = Join-Path $dir "$slug.ps1"
    $removed = $false
    if (Test-Path $path) {
        Remove-Item $path -Force
        $removed = $true
    }
    $list = @(Get-SkillList $sync | Where-Object { $_.name -ne $slug })
    Save-SkillList $sync $list
    if ($removed) { return "Skill '$slug' eliminata." }
    return "Skill '$slug' non trovata (elenco aggiornato)."
}

function Format-SkillList {
    param($sync)
    $list = @(Get-SkillList $sync)
    if ($list.Count -eq 0) { return 'Nessuna skill imparata ancora.' }
    $rows = @()
    foreach ($s in $list) {
        $rows += "- $($s.name): $($s.description) [quando: $($s.when_to_use)]"
    }
    return ("Skill imparate:`n" + ($rows -join "`n"))
}

# ---------------------------------------------------------------------------
# Dispatcher degli strumenti
# ---------------------------------------------------------------------------

function ConvertTo-JsonTextSicuro {
    param($o)
    try { if (Get-Command ConvertTo-JsonText -ErrorAction SilentlyContinue) { return (ConvertTo-JsonText $o) } } catch { }
    try { return ($o | ConvertTo-Json -Compress -Depth 6) } catch { }
    return '.'
}

# v7.9.4 -- AUDIT TRAIL: registro ogni chiamata di strumento (nome, argomenti, esito, durata).
function Invoke-AgentTool {
    param([string]$Name, $ToolArgs, $sync)
    if ($null -eq $ToolArgs) { $ToolArgs = @{} }
    $t0 = Get-Date
    # v9.1: telemetria - la cabina vede chi sta usando quale strumento, in tempo reale.
    $agenteCorrente = ''
    try { $agenteCorrente = [string]$sync.AgenteCorrente } catch { }
    if ($agenteCorrente) {
        try {
            [void](Write-TelemetriaEvento -Base ([string]$sync.Base) -Id $agenteCorrente -Stato 'strumento' `
                -Azione ('strumento: ' + $Name) -Strumento $Name -Comando (ConvertTo-JsonTextSicuro $ToolArgs))
        } catch { }
    }
    $ris = $null
    try {
        $ris = Invoke-AgentToolInterno -Name $Name -ToolArgs $ToolArgs -sync $sync
    } catch {
        try { Add-AuditEvent -sync $sync -Tipo 'tool' -Azione ($Name + ' ' + (ConvertTo-JsonTextSicuro $ToolArgs)) -Esito 'eccezione' -Dettagli $_.Exception.Message } catch { }
        throw
    }
    try {
        $ms = 0
        try { $ms = [int]((Get-Date) - $t0).TotalMilliseconds } catch { }
        $rtxt = [string]$ris
        $es = 'ok'
        if ($rtxt -match '(?i)^\[SIMULAZIONE\]') { $es = 'simulato' }
        elseif ($rtxt -match '^!TIMEOUT') { $es = 'timeout' }
        elseif ($rtxt -match '^!') { $es = 'errore' }
        Add-AuditEvent -sync $sync -Tipo 'tool' -Azione ($Name + ' ' + (ConvertTo-JsonTextSicuro $ToolArgs)) -Esito $es -DurataMs $ms -Dettagli $rtxt
    } catch { }
    if ($agenteCorrente) {
        try {
            $breve = [string]$ris
            if ($breve.Length -gt 180) { $breve = $breve.Substring(0, 180) + '...' }
            [void](Write-TelemetriaEvento -Base ([string]$sync.Base) -Id $agenteCorrente -Stato 'pensa' `
                -Azione ('strumento ' + $Name + ' concluso') -UltimaRiga $breve)
        } catch { }
    }
    return $ris
}

function Invoke-AgentToolInterno {
    param([string]$Name, $ToolArgs, $sync)

    if ($null -eq $ToolArgs) { $ToolArgs = @{} }

    $v7 = Invoke-AgentToolV7 -Name $Name -ToolArgs $ToolArgs -sync $sync
    if ($null -ne $v7) { return $v7 }

    switch ($Name) {

        'apri_programma' {
            return (Start-Programma $sync ([string]$ToolArgs.nome) '')
        }

        'gestisci_finestre' {
            $az = ([string]$ToolArgs.azione).Trim().ToLower()
            $fi = [string]$ToolArgs.filtro
            switch ($az) {
                'elenca'     { return (Format-Finestre) }
                'chiudi'     { return (Close-Finestra $fi) }
                'minimizza'  { return (Show-FinestraStato $fi 6) }
                'massimizza' { return (Show-FinestraStato $fi 3) }
                'attiva'     { if (Focus-Finestra $fi) { return 'Finestra attivata.' } else { return 'Finestra non trovata.' } }
                default      { return 'Azione non valida: usa elenca, chiudi, minimizza, massimizza o attiva.' }
            }
        }

        'scrivi_testo' {
            return (Send-TestoAttivo ([string]$ToolArgs.testo))
        }

        'lancia_programma' {
            $az = ([string]$ToolArgs.azione).Trim().ToLower()
            if ($az -eq 'elenco' -or $az -eq 'lista') { return (Format-ProgrammiElenco $sync) }
            return (Start-Programma $sync ([string]$ToolArgs.nome) '')
        }

        'run_powershell' {
            $code   = [string]$ToolArgs.code
            $motivo = [string]$ToolArgs.motivo
            if (-not $code) { return '!Codice mancante.' }

            # v9 GHOST: il perimetro si controlla PRIMA di eseguire. Fuori da li' non parte niente.
            try {
                if ((Get-Command Test-ModalitaGhost -ErrorAction SilentlyContinue) -and (Test-ModalitaGhost $sync)) {
                    $g = Test-GhostConsentito $sync $code
                    if (-not $g.ok) {
                        try { [void](Add-ZapLedgerEvento $sync 'ghost' ('COMANDO BLOCCATO (fuori perimetro): ' + $g.motivo) 'perimetro' $false) } catch { }
                        return ('!GHOST BLOCCATO -- ' + $g.motivo)
                    }
                    if ($g.avviso) {
                        # modo AULA: comando passivo fuori elenco -> consentito ma scritto
                        try { [void](Add-ZapLedgerEvento $sync 'ghost' ('FUORI PERIMETRO ma passivo: ' + $g.avviso) 'perimetro' $false) } catch { }
                    } elseif ([string]$g.modo -eq 'aperto') {
                        # modo APERTO: nessun blocco, ma il bersaglio resta scritto
                        $bers = @(Get-BersagliDaComando $code)
                        if ($bers.Count -gt 0) {
                            try { [void](Add-ZapLedgerEvento $sync 'ghost' ('PERIMETRO APERTO - bersaglio/i: ' + ($bers -join ', ')) 'perimetro' $false) } catch { }
                        }
                    }
                }
            } catch { }

            # v9: ogni comando/script non banale finisce nella LIBRERIA POWERSHELL e nel registro.
            try {
                $righeCodice = @(([string]$code) -split "`r?`n" | Where-Object { $_.Trim() })
                if ($code.Trim().Length -gt 60 -and $righeCodice.Count -ge 2) {
                    [void](Save-PsScriptArchivio $sync $code $motivo 'chat' 'eseguito' '' $true)
                }
            } catch { }

            # v7.9.4: MODALITA' SIMULAZIONE (dry-run). Non eseguo: mostro cosa farei.
            try {
                if ([bool]$sync.Config.simulazione) {
                    $ant = ''
                    try { $ant = Get-AnteprimaPowerShell $code } catch { }
                    $bloc = ''
                    if ($motivo) { $bloc = " (motivo: $motivo)" }
                    $out = "[SIMULAZIONE] Non ho eseguito nulla$bloc.`n--- COMANDO CHE AVREI ESEGUITO ---`n" + $code
                    if ($ant) { $out += "`n--- ANTEPRIMA ---`n" + $ant }
                    $out += "`n(Per eseguire davvero: scrivi /simula per disattivare la modalita simulazione.)"
                    return $out
                }
            } catch { }

            # v7.9.8: MODALITA' HACKER -- NESSUN LIMITE: esegue SUBITO, senza policy e senza conferme.
            # Ogni azione resta comunque registrata nella scatola nera (audit).
            if (Test-ModalitaHacker $sync) {
                try { Add-AuditEvent -sync $sync -Tipo 'comando' -Azione $code -Esito 'hacker' -Dettagli $motivo } catch { }
                $usb = $false; try { if ($sync.Config.sandbox -and [bool]$sync.Config.sandbox.attivo) { $usb = $true } } catch { }
                if ($usb) { return (Invoke-InSandbox $sync $code) }
                return (Invoke-PsTool $sync $code)
            }

            # v7.9.5: PERMESSI GRANULARI (policy) -- controllo PRIMA di eseguire
            $polVerdetto = 'consenti'; $polMotivo = ''
            try { $pv = Test-PolicyComando $sync $code; $polVerdetto = [string]$pv.Verdetto; $polMotivo = [string]$pv.Motivo } catch { }
            if ($polVerdetto -eq 'blocca') {
                try { Add-AuditEvent -sync $sync -Tipo 'comando' -Azione $code -Esito 'bloccato' -Dettagli $polMotivo } catch { }
                return ("!BLOCCATO DALLE REGOLE (permessi/ruoli): " + $polMotivo + ". Non insistere: chiedi all'utente oppure modifica le regole con /policy.")
            }

            # v7.9.7: MODALITA' PENTEST AUTORIZZATO -- gate di scope + conferma + audit
            try {
                if ($sync.Config.pentest -and [bool]$sync.Config.pentest.attivo) {
                    return (Invoke-Pentest $sync $code $motivo)
                }
            } catch { }

            $mode = [string]$sync.Config.sicurezza
            $risky = Test-RiskyCode $code
            if ($polVerdetto -eq 'chiedi') { $risky = $true }   # v7.9.5: la policy puo' far scattare la conferma
            # ENTERPRISE: tutto automatico TRANNE i comandi distruttivi, che chiedono sempre conferma
            # v9.4 -- AUTOPILOTA: ZAP esegue e basta, non chiede il permesso.
            # I BLOCCHI di sicurezza (policy, modalita ghost) restano attivi: qui si
            # salta SOLO il dialogo di conferma. Ogni comando resta nella scatola nera.
            $autopilota = Get-CfgBool $sync.Config 'autopilota' $true
            if (-not $autopilota -and ($mode -eq 'prudente' -or ($mode -eq 'smart' -and $risky) -or ($mode -eq 'enterprise' -and $risky))) {
                $msg = "ZAP vuole eseguire questo comando PowerShell"
                if ($motivo) { $msg += " ($motivo)" }
                $msg += ":`n`n$code`n`nEseguo?"
                $ok = Ask-UserConfirm $sync $msg
                if (-not $ok) { return "L'utente ha rifiutato l'esecuzione. Non insistere: chiedi come vuole procedere." }
            }

            # v7.9.6: MODALITA' ISOLATA (sandbox) -- processo separato con limiti + chiusura garantita
            $esito = $null
            $usaSandbox = $false
            try { if ($sync.Config.sandbox -and [bool]$sync.Config.sandbox.attivo) { $usaSandbox = $true } } catch { }
            if ($usaSandbox) {
                try { Add-AuditEvent -sync $sync -Tipo 'comando' -Azione $code -Esito 'sandbox' } catch { }
                $esito = Invoke-InSandbox $sync $code
            } else {
                $esito = Invoke-PsTool $sync $code
            }
            if ($sync.Config.admin_su_richiesta -and -not (Test-Admin) -and (Test-BisognoAdmin $esito)) {
                $elev = Invoke-PsToolElevato $sync $code
                return ("(comando senza privilegi: rieseguito come AMMINISTRATORE)`n" + $elev)
            }
            # v7.9.5: AUTODIAGNOSI -- se e' un errore, aggiungo un suggerimento per correggersi
            try {
                if ([string]$esito -match '^!ERRORI|^!TIMEOUT|^!INTERROTTO') {
                    $dg = Get-DiagnosiErrore ([string]$esito)
                    if ($dg) { $esito = [string]$esito + "`n[DIAGNOSI ZAP] " + $dg }
                }
            } catch { }
            return $esito
        }

        'open_browser' {
            return (Open-UrlInBrowser $sync ([string]$ToolArgs.url))
        }

        'web_search' {
            $open = $false
            if ($ToolArgs.open_in_browser -eq $true -or "$($ToolArgs.open_in_browser)" -eq 'true') { $open = $true }
            return (Invoke-WebSearch $sync ([string]$ToolArgs.query) $open)
        }

        'read_webpage' {
            $mc = 6000
            try { if ($ToolArgs.max_chars) { $mc = [int]$ToolArgs.max_chars } } catch { }
            return (Invoke-ReadWebpage ([string]$ToolArgs.url) $mc)
        }

        'remember' {
            return (Add-Memory $sync ([string]$ToolArgs.nota))
        }

        'recall_memory' {
            return ("Memoria attuale:`n" + (Get-MemoryText $sync))
        }

        'teach_skill' {
            return (Save-Skill $sync ([string]$ToolArgs.name) ([string]$ToolArgs.description) ([string]$ToolArgs.when_to_use) ([string]$ToolArgs.codice))
        }

        'use_skill' {
            $skillArgs = @()
            if ($ToolArgs.argomenti) { $skillArgs = @($ToolArgs.argomenti | ForEach-Object { [string]$_ }) }
            return (Invoke-Skill $sync ([string]$ToolArgs.nome) $skillArgs)
        }

        'list_skills' {
            return (Format-SkillList $sync)
        }

        'delete_skill' {
            return (Remove-Skill $sync ([string]$ToolArgs.nome))
        }

        'list_browsers' { return (Format-BrowserList $sync) }
        'set_browser' {
            $k = ([string]$ToolArgs.key).Trim().ToLower()
            if (-not $k) { return '!Specifica il browser: thorium, yandex, chrome, edge, brave o firefox.' }
            $sync.Config.browser = $k
            Save-ConfigJson $sync
            return "Browser predefinito impostato: $k"
        }
        'list_search_engines' { return (Format-EngineList $sync) }
        'set_search_engine' {
            $k = ([string]$ToolArgs.key).Trim().ToLower()
            if (-not $k) { return '!Specifica il motore: duckduckgo, google, bing, yandex o startpage.' }
            $sync.Config.motore_ricerca = $k
            Save-ConfigJson $sync
            return "Motore di ricerca impostato: $k"
        }
        'model_status' { return (Get-ModelStatusText $sync) }
        'pull_model' {
            $m = [string]$ToolArgs.model
            if (-not $m) { $m = [string]$sync.Config.modello }
            Start-ModelPull $sync $m
            return "Nessun modello locale da scaricare: ZAP usa solo servizi cloud. Ho verificato il servizio configurato (vedi chat)."
        }

        'guarda_schermo' { return (Invoke-LookAtScreen $sync ([string]$ToolArgs.domanda)) }
        'impara_dallo_schermo' { return (Invoke-ImparaDalloSchermo $sync ([string]$ToolArgs.domanda)) }
        'consigli_miglioramento' { return (Invoke-ConsigliMiglioramento $sync ([string]$ToolArgs.argomento)) }
        'stato_amministratore' { return (Get-AdminStatus) }
        'aggiungi_appunto' { return (Add-Appunto $sync ([string]$ToolArgs.testo)) }
        'leggi_appunti' { return (Get-AppuntiText $sync) }

        'agenti_squadra' {
            return (Invoke-StrumentoSquadra -sync $sync -Base $base -Azione ([string]$ToolArgs.azione) -Nome ([string]$ToolArgs.nome))
        }

        'whatsapp_invia' {
            $invia = $true
            try { if ($null -ne $ToolArgs.invia) { $invia = [bool]$ToolArgs.invia } } catch { }
            $r = Invoke-WhatsAppInvia -sync $sync -Contatto ([string]$ToolArgs.contatto) -Testo ([string]$ToolArgs.testo) -Telefono ([string]$ToolArgs.telefono) -NonInviare:(-not $invia)
            return [string]$r.Testo
        }

        'contatti_whatsapp' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            $nm = [string]$ToolArgs.nome
            $tp = [string]$ToolArgs.telefono
            if ($az -eq 'salva') {
                if (-not $nm -or -not $tp) { return '!Per salvare un contatto servono nome e telefono.' }
                $r = Set-Contatto $base $nm $tp
                if (-not $r.ok) { return ('!Non salvato: ' + [string]$r.messaggio) }
                return ('Salvato: ' + $nm + ' = ' + [string]$r.telefono + '. Da adesso posso mandargli messaggi senza chiedere il numero.')
            }
            if ($az -eq 'elenca') { return (Format-Contatti $base) }
            if ($az -eq 'cerca') {
                $c = Find-Contatto $base $nm
                if (-not $c) { return ('Non ho in rubrica "' + $nm + '". Dimmi il numero e lo salvo.') }
                return ([string]$c.nome + ' -> ' + [string]$c.telefono)
            }
            if ($az -eq 'elimina') {
                $k = ConvertTo-ChiaveContatto $nm
                $tutti = Get-Contatti $base
                if (-not $tutti.ContainsKey($k)) { return ('Non c e "' + $nm + '" in rubrica.') }
                $tutti.Remove($k)
                [void](Save-Contatti $base $tutti)
                return ('Rimosso: ' + $nm)
            }
            if ($az -eq 'stato') { return (Get-StatoWhatsApp $sync) }
            return '!Azione non valida: salva | elenca | cerca | elimina | stato'
        }

        'strumenti' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            $cat = ([string]$ToolArgs.categoria).Trim().ToLowerInvariant()
            switch ($az) {
                'elenca'     { return (Format-StrumentiReport $sync) }
                'mancanti'   {
                    $m = @(Get-StrumentiMancanti $sync)
                    if (-not $m.Count) { return 'Nessuno strumento del catalogo manca: hai tutto.' }
                    return ('Non installati: ' + ($m -join ', '))
                }
                'inventario' {
                    $inv = @(Read-InventarioStrumenti $sync)
                    if (-not $inv.Count) { return ('Nessun inventario trovato in ' + (Get-InventarioPath $sync) + '. Lancia RACCOGLI_STRUMENTI.bat nella cartella di ZAP.') }
                    $righe = @('Inventario letto: ' + $inv.Count + ' strumenti censiti sul PC')
                    foreach ($i in $inv) { $righe += ('  ' + $i.nome + ' [' + $i.dove + '] -> ' + $i.percorso) }
                    return ($righe -join "`r`n")
                }
                'ricette'    {
                    $r = @(Get-RicettePentest $sync $cat)
                    if (-not $r.Count) {
                        if ($cat) { return ('Nessuna ricetta per la categoria "' + $cat + '": non hai strumenti installati in quella fascia. Prova elenca.') }
                        return 'Nessuna ricetta disponibile.'
                    }
                    $righe = @('RICETTE PRONTE' + $(if ($cat) { ' (' + $cat + ')' } else { '' }))
                    foreach ($x in $r) { $righe += ('  [' + $x.categoria + '] ' + $x.strumento + ': ' + $x.comando) }
                    $righe += 'Ricorda: adatta <host>, <ip>, <wordlist> al caso reale.'
                    return ($righe -join "`r`n")
                }
                default      { return '!Azione non valida: elenca | ricette | mancanti | inventario' }
            }
        }

        'ghost' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            $vo = [string]$ToolArgs.voce
            switch ($az) {
                'stato'    { return (Get-GhostStato $sync) }
                'elenco'   {
                    $a = @(Get-GhostAmbiti $sync)
                    if (-not $a.Count) { return 'Perimetro vuoto: solo rete locale (localhost, 10.x, 172.16-31.x, 192.168.x).' }
                    return ('Perimetro GHOST (' + $a.Count + '): ' + ($a -join ', '))
                }
                'aggiungi' { return (Add-GhostAmbito $sync $vo) }
                'togli'    { return (Remove-GhostAmbito $sync $vo) }
                'consenti' { return (Set-GhostConsenso $sync $true) }
                'perimetro'      {
                    $c = Get-GhostConfig $sync
                    $a = @(Get-GhostAmbiti $sync)
                    $righe = @()
                    $righe += ('Perimetro: ' + $(if ($c.blocca_fuori_ambito) { 'ACCESO (blocca fuori ambito)' } else { 'SPENTO (nessun blocco)' }))
                    $righe += ('Bersagli ammessi: ' + $(if ($a.Count) { ($a -join ', ') } else { 'nessuno' }) + ' + rete locale')
                    return ($righe -join "`r`n")
                }
                'perimetro-on'   { return (Set-GhostPerimetro $sync $true) }
                'perimetro-off'  { return (Set-GhostPerimetro $sync $false) }
                'attiva'   { try { $sync.Config.sicurezza = 'ghost' } catch { }; return 'Modalita GHOST attiva.' }
                'spegni'   { try { $sync.Config.sicurezza = 'smart' } catch { }; return 'Modalita GHOST spenta (torno a SMART).' }
                default    { return '!Azione non valida: stato | aggiungi | togli | elenco | consenti | attiva | spegni' }
            }
        }

        # ---------------- v9 ----------------
        'memoria' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            $tx = [string]$ToolArgs.testo
            $tg = [string]$ToolArgs.tag
            switch ($az) {
                'salva' {
                    if (-not $tx) { return '!Mi serve il testo da salvare.' }
                    $r = Add-ZapLedgerEvento $sync 'nota' $tx $tg $false
                    if ($r) { return "Salvato nella memoria indelebile (evento #$($r.n)). Non si puo' cancellare senza lasciare traccia." }
                    return '!Non sono riuscito a scrivere nella memoria: controlla la cartella Ezappero.'
                }
                'permanente' {
                    if (-not $tx) { return '!Mi serve la regola da ricordare sempre.' }
                    $r = Add-ZapLedgerEvento $sync 'regola' $tx $tg $true
                    if ($r) { return "Regola permanente salvata (#$($r.n)): la leggero' in OGNI risposta." }
                    return '!Non sono riuscito a salvare la regola.'
                }
                'cerca' {
                    if (-not $tx) { return (Format-ZapEvento ((Read-ZapLedger $sync 20)[-1])) }
                    $rc = Get-ZapRichiamo $sync $tx 10
                    if (-not $rc) { return 'Nessun ricordo pertinente trovato.' }
                    return $rc
                }
                'stato' {
                    $st = Get-EzapperoStato $sync
                    return ("MEMORIA INDELEBILE`n  cartella: $($st.cartella)`n  copia specchio: $($st.specchio)`n  eventi: $($st.eventi)`n  script archiviati: $($st.script)`n  sessioni salvate: $($st.sessioni)`n  integrita: $($st.messaggio)")
                }
                'integra' {
                    $rep = Test-ZapIntegrita $sync
                    if ($rep.ok) { return ("Integrita OK: $($rep.totale) eventi, catena di hash valida. Nessuna manomissione.") }
                    $fix = Repair-ZapDaSpecchio $sync
                    return ("PROBLEMA: $($rep.messaggio)`nTentativo di ripristino: $fix")
                }
                'diario' { return (Get-ZapDiario $sync) }
                default { return '!Azione non valida: salva | permanente | cerca | stato | integra | diario' }
            }
        }

        'libreria_script' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            switch ($az) {
                'salva' {
                    $r = Save-PsScriptArchivio $sync ([string]$ToolArgs.codice) ([string]$ToolArgs.titolo) ([string]$ToolArgs.fonte) '' ([string]$ToolArgs.descrizione) $false
                    return [string]$r.messaggio
                }
                'cerca' {
                    $v = Find-PsScriptArchivio $sync ([string]$ToolArgs.query) '' 10
                    return (Format-PsScriptElenco $sync $v)
                }
                'elenca' {
                    $v = Find-PsScriptArchivio $sync '' '' 400
                    return (Format-PsScriptElenco $sync $v)
                }
                'stato' {
                    $s2 = Get-PsLibreriaStats $sync
                    $righe = @("Libreria PowerShell: $($s2.totale) script in Ezappero\powershell-script")
                    foreach ($k in @($s2.categorie.Keys | Sort-Object)) { $righe += "  - $k : $($s2.categorie[$k])" }
                    return ($righe -join "`r`n")
                }
                default { return '!Azione non valida: salva | cerca | elenca | stato' }
            }
        }

        'documento' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            if ($az -eq 'fattura') {
                $iva = -1.0
                try { if ($null -ne $ToolArgs.iva) { $iva = [double]$ToolArgs.iva } } catch { }
                $voci = @()
                try { if ($ToolArgs.voci) { $voci = @($ToolArgs.voci) } } catch { }
                return (New-Fattura $sync ([string]$ToolArgs.cliente) $voci $iva ([string]$ToolArgs.note) '' '' )
            }
            if ($az -eq 'busta_paga' -or $az -eq 'busta') {
                $lordo = 0.0
                try { if ($null -ne $ToolArgs.lordo) { $lordo = [double]$ToolArgs.lordo } } catch { }
                return (New-BustaPaga $sync ([string]$ToolArgs.dipendente) $lordo ([string]$ToolArgs.mese) '')
            }
            if ($az -eq 'pdf') {
                $p = Export-DocumentoPdf ([string]$ToolArgs.percorso)
                if ($p) { return "PDF creato: $p" }
                return '!PDF non creato: serve Edge o Chrome installati, oppure il file HTML non esiste.'
            }
            return '!Azione non valida: fattura | busta_paga | pdf'
        }

        'email' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            if ($az -eq 'stato') { return (Get-EmailStato $sync) }
            if ($az -eq 'configura') {
                $sb = $null
                return (Set-EmailConfig $sync ([string]$ToolArgs.mittente) ([string]$ToolArgs.password) '' '' $sb)
            }
            if ($az -eq 'invia' -or $az -eq 'bozza') {
                $allegati = @()
                try { if ($ToolArgs.allegati) { $allegati = @($ToolArgs.allegati) } } catch { }
                $davvero = ($az -eq 'invia')
                return (Send-Email $sync ([string]$ToolArgs.a) ([string]$ToolArgs.oggetto) ([string]$ToolArgs.corpo) ([string]$ToolArgs.cc) $allegati -InviaDavvero:$davvero)
            }
            return '!Azione non valida: stato | configura | invia | bozza'
        }

        'traccia' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            if ($az -eq 'avvia') { return (Start-Traccia $sync) }
            if ($az -eq 'ferma' -or $az -eq 'stop') { return (Stop-Traccia $sync) }
            if ($az -eq 'stato') {
                $st = Get-TracciaStato $sync
                $on = 'spenta'
                if ($st.attiva) { $on = 'ATTIVA dal ' + $st.dal }
                return ("Modalita traccia: $on - campioni raccolti: $($st.campioni)`nCartella: $(Get-TracciaDir $sync)")
            }
            if ($az -eq 'oggi') { return (Get-TracciaRiassunto $sync ([string]$ToolArgs.giorno)) }
            return '!Azione non valida: avvia | ferma | stato | oggi'
        }

        'verifica' {
            $az = ([string]$ToolArgs.azione).Trim().ToLowerInvariant()
            if ($az -eq 'controlla') {
                $r = Test-VeritaRisposta ([string]$ToolArgs.testo) ([string]$ToolArgs.prove) 5
                if ($r.ok) { return 'Controllo: nessun numero, link o certezza assoluta risulta privo di riscontro. OK.' }
                return ("PUNTI NON VERIFICATI:`n" + (($r.sospetti | ForEach-Object { '  * ' + $_ }) -join "`r`n") + "`nNon presentarli come fatti: dichiara che sono ipotesi o verificali adesso.")
            }
            if ($az -eq 'registra') {
                $af = [string]$ToolArgs.affermazione
                $pr = [string]$ToolArgs.prove
                if (-not $af) { return '!Mi serve l''affermazione da registrare.' }
                $senzaProva = 'SI'
                if ($pr -and $pr.Trim() -and $pr.Trim().ToLowerInvariant() -ne 'nessuna') { $senzaProva = 'no' }
                $t = "Affermazione: $af | prova: $(if ($pr) { $pr } else { 'nessuna' })"
                [void](Add-ZapLedgerEvento $sync 'verifica' $t 'verita' $false)
                if ($senzaProva -eq 'SI') { return 'Registrata. NON ha una prova: non presentarla come fatto verificato.' }
                return 'Registrata con la sua prova.'
            }
            return '!Azione non valida: controlla | registra'
        }

        'skin' {
            $nome = ([string]$ToolArgs.nome).Trim()
            if (-not $nome) {
                $nn = @()
                try { $nn = @(Get-SkinDefinizioni | ForEach-Object { [string]$_.nome }) } catch { $nn = @('classica','astronave','universo','ologramma','fantasy','cyberpunk') }
                return ("Interfacce disponibili: " + ($nn -join ', ') + ". Richiamami con skin e nome=<uno di questi>.")
            }
            try { $sync.UiQueue.Enqueue(@{ Type = 'skin'; Data = $nome }) } catch { }
            return ("Interfaccia cambiata in: " + $nome)
        }
        'nastro_notizie' {
            $s = ([string]$ToolArgs.stato).Trim().ToLowerInvariant()
            $v = $true
            if ($s -match '^(off|nascondi|spento|hide|no)$') { $v = $false }
            elseif ($s -match '^(on|mostra|acceso|show|si|sì)$') { $v = $true }
            else {
                $corr = $true
                try {
                    $f = Join-Path ([string]$sync.Base) 'ui\ticker.json'
                    $j = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
                    if ($null -ne $j.visibile) { $corr = [bool]$j.visibile }
                } catch { }
                $v = -not $corr
            }
            try { $sync.UiQueue.Enqueue(@{ Type = 'nastro'; Data = $v }) } catch { }
            if ($v) { return 'Nastro notizie: VISIBILE.' }
            return 'Nastro notizie: NASCOSTO (motore fermo, nessun download).'
        }
        'automatizza' {
            $cod = [string]$ToolArgs.script
            if (-not $cod) { return '!Mi serve lo script PowerShell da automatizzare.' }
            $orario = ([string]$ToolArgs.orario).Trim()
            $esito = ''
            try { $esito = [string](Invoke-AgentToolInterno -Name 'run_powershell' -ToolArgs @{ code = $cod; motivo = 'automatizza' } -sync $sync) }
            catch { $esito = '!Errore: ' + $_.Exception.Message }
            if ($orario) {
                try {
                    if (Get-Command Tool-PianificaTask -ErrorAction SilentlyContinue) {
                        $r = Tool-PianificaTask -base $sync.Base -nome ('ZAP auto: ' + $cod.Substring(0, [Math]::Min(32, $cod.Length))) -tipo 'orario' -quando '' -azione '' -orario $orario -script $cod
                        $esito = $esito + "`nAutomazione giornaliera attiva alle " + $orario + ": " + [string]$r
                    } else {
                        $esito = $esito + "`n(eseguito ora; la pianificazione giornaliera non e' disponibile in questo avvio)"
                    }
                } catch { $esito = $esito + "`n!Pianificazione non riuscita: " + $_.Exception.Message }
            }
            return $esito
        }
        default {
            return "!Strumento sconosciuto: $Name"
        }
    }
}


# ---------------------------------------------------------------------------
# Browser dell'utente (Thorium di default) e motori di ricerca web
# ---------------------------------------------------------------------------

function Join-SafePath {
    param([string]$Root, [string]$Rel)
    if (-not $Root) { return $null }
    try { return (Join-Path $Root $Rel) } catch { return $null }
}

function Get-BrowserRegistry {
    $la   = $env:LOCALAPPDATA
    $pf   = $env:ProgramFiles
    $pf86 = ${env:ProgramFiles(x86)}
    return [ordered]@{
        thorium = @{ name = 'Thorium'; paths = @(
            (Join-SafePath $la   'Thorium\Application\thorium.exe'),
            (Join-SafePath $pf   'Thorium\Application\thorium.exe'),
            (Join-SafePath $pf86 'Thorium\Application\thorium.exe')) }
        yandex  = @{ name = 'Yandex Browser'; paths = @(
            (Join-SafePath $la   'Yandex\YandexBrowser\Application\browser.exe'),
            (Join-SafePath $pf   'Yandex\YandexBrowser\Application\browser.exe'),
            (Join-SafePath $pf86 'Yandex\YandexBrowser\Application\browser.exe')) }
        chrome  = @{ name = 'Google Chrome'; paths = @(
            (Join-SafePath $pf   'Google\Chrome\Application\chrome.exe'),
            (Join-SafePath $pf86 'Google\Chrome\Application\chrome.exe'),
            (Join-SafePath $la   'Google\Chrome\Application\chrome.exe')) }
        edge    = @{ name = 'Microsoft Edge'; paths = @(
            (Join-SafePath $pf86 'Microsoft\Edge\Application\msedge.exe'),
            (Join-SafePath $pf   'Microsoft\Edge\Application\msedge.exe')) }
        brave   = @{ name = 'Brave'; paths = @(
            (Join-SafePath $pf   'BraveSoftware\Brave-Browser\Application\brave.exe'),
            (Join-SafePath $la   'BraveSoftware\Brave-Browser\Application\brave.exe')) }
        firefox = @{ name = 'Mozilla Firefox'; paths = @(
            (Join-SafePath $pf   'Mozilla Firefox\firefox.exe'),
            (Join-SafePath $pf86 'Mozilla Firefox\firefox.exe')) }
    }
}

function Resolve-BrowserPath {
    param($sync, [string]$Key)
    if (-not $Key) { $Key = [string]$sync.Config.browser }
    if (-not $Key) { $Key = 'thorium' }
    $Key = $Key.Trim().ToLower()

    try {
        $bp = $sync.Config.browser_paths
        if ($bp) {
            $custom = ''
            try { $custom = [string]$bp[$Key] } catch { $custom = '' }
            if (-not $custom) { try { $custom = [string]$bp.$Key } catch { $custom = '' } }
            if ($custom -and (Test-Path $custom)) { return $custom }
        }
    } catch { }

    $reg = Get-BrowserRegistry
    if ($reg.Contains($Key)) {
        foreach ($path in $reg[$Key].paths) {
            if ($path -and (Test-Path $path)) { return $path }
        }
    }
    # v6.4: il browser preferito non c'e' -> prova automaticamente gli altri preferiti
    # (di default Yandex e poi Thorium), cosi' la navigazione non si blocca.
    $fb = @()
    try { if ($sync.Config.browser_fallbacks) { $fb = @($sync.Config.browser_fallbacks) } } catch { }
    if ($fb.Count -eq 0) { $fb = @('yandex', 'thorium') }
    foreach ($k2 in $fb) {
        $k2 = ([string]$k2).Trim().ToLower()
        if (-not $k2 -or $k2 -eq $Key) { continue }
        if ($reg.Contains($k2)) {
            foreach ($path in $reg[$k2].paths) {
                if ($path -and (Test-Path $path)) { return $path }
            }
        }
    }
    if ($Key -match '\.exe$' -and (Test-Path $Key)) { return $Key }
    return $null
}

function Get-InstalledBrowsers {
    param($sync)
    $found = [ordered]@{}
    $reg = Get-BrowserRegistry
    foreach ($k in $reg.Keys) {
        # v9.4.1-fix: controlla solo il percorso DIRETTO del browser (niente fallback),
        # cosi' "installato" indica solo i browser realmente presenti.
        $path = $null
        foreach ($p in $reg[$k].paths) {
            if ($p -and (Test-Path $p)) { $path = $p; break }
        }
        if ($path) { $found[$k] = $path }
    }
    return $found
}

function Format-BrowserList {
    param($sync)
    $reg = Get-BrowserRegistry
    $found = Get-InstalledBrowsers $sync
    $lines = @()
    foreach ($k in $reg.Keys) {
        if ($found.Contains($k)) { $lines += "- $k ($($reg[$k].name)) installato: $($found[$k])" }
        else { $lines += "- $k ($($reg[$k].name)) non trovato" }
    }
    $def = [string]$sync.Config.browser
    if (-not $def) { $def = 'thorium' }
    return ("Browser predefinito: $def`n" + ($lines -join "`n") + "`nUsa set_browser (thorium, yandex, chrome, edge, brave, firefox).")
}

function Get-EngineRegistry {
    return [ordered]@{
        duckduckgo = @{ name = 'DuckDuckGo'; home = 'https://duckduckgo.com/'; url = 'https://duckduckgo.com/?q={q}'; html = 'https://html.duckduckgo.com/html/?q={q}' }
        google     = @{ name = 'Google'; home = 'https://www.google.com/'; url = 'https://www.google.com/search?q={q}' }
        bing       = @{ name = 'Bing'; home = 'https://www.bing.com/'; url = 'https://www.bing.com/search?q={q}' }
        yandex     = @{ name = 'Yandex (yandex.ru)'; home = 'https://yandex.ru/'; url = 'https://yandex.ru/search/?text={q}' }
        startpage  = @{ name = 'Startpage'; home = 'https://www.startpage.com/'; url = 'https://www.startpage.com/sp/search?query={q}' }
    }
}

function Get-EngineUrl {
    param([string]$Engine, [string]$Query)
    $reg = Get-EngineRegistry
    $k = ([string]$Engine).Trim().ToLower()
    if (-not $reg.Contains($k)) { $k = 'duckduckgo' }
    return $reg[$k].url.Replace('{q}', [uri]::EscapeDataString($Query))
}

function Format-EngineList {
    param($sync)
    $reg = Get-EngineRegistry
    $lines = @()
    foreach ($k in $reg.Keys) { $lines += "- $k : $($reg[$k].name)" }
    $def = [string]$sync.Config.motore_ricerca
    if (-not $def) { $def = 'duckduckgo' }
    return ("Motore di ricerca predefinito: $def`n" + ($lines -join "`n") + "`nUsa set_search_engine per cambiarlo.")
}

function Get-BrowserHeaders {
    param([string]$Referer = '')
    $h = [ordered]@{
        'User-Agent'                = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
        'Accept'                    = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
        'Accept-Language'           = 'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7'
        'Upgrade-Insecure-Requests' = '1'
        'Sec-Fetch-Dest'            = 'document'
        'Sec-Fetch-Mode'            = 'navigate'
        'Sec-Fetch-Site'            = 'cross-site'
    }
    if ($Referer) { $h['Referer'] = $Referer }
    return $h
}

function Invoke-WebFetch {
    param([string]$Url, [string]$Referer = '', [int]$TimeoutSec = 25)
    $headers = Get-BrowserHeaders $Referer

    $curl = Join-SafePath $env:SystemRoot 'System32\curl.exe'
    if ($curl -and (Test-Path $curl)) {
        try {
            $cargs = @('-s', '-L', '--compressed', '--max-time', "$TimeoutSec",
                       '-A', $headers['User-Agent'],
                       '-H', ('Accept: ' + $headers['Accept']),
                       '-H', ('Accept-Language: ' + $headers['Accept-Language']))
            if ($Referer) { $cargs += @('-e', $Referer) }
            $cargs += @($Url)
            $out = & $curl @cargs 2>$null
            $text = ($out | Out-String)
            if ($text -and $text.Trim().Length -gt 0) { return $text }
        } catch { }
    }

    try {
        $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec $TimeoutSec -Headers $headers
        return [string]$r.Content
    } catch {
        return ''
    }
}


function Get-ModelStatusText {
    param($sync)
    $prov = [string]$sync.Config.provider
    $mod  = [string]$sync.Config.modello
    $cat  = 'gemini -> deepseek'
    try { $cat = (@(Get-MotoreCatena $sync) -join ' -> ') } catch { }
    return ('Cervello: ' + $prov + ' (' + $mod + ', cloud). Motore: ' + $cat + '. Nessun modello locale su questo PC.')
}

function Save-ConfigJson {
    # Salva config.json SENZA segreti e SENZA BOM; i segreti vanno in config.local.json.
    param($sync)
    try {
        $enc = New-Object System.Text.UTF8Encoding($false)
        $copia = @{}
        foreach ($k in @($sync.Config.Keys)) { $copia[$k] = $sync.Config[$k] }
        $copia['api_key'] = ''
        $paPub = @{}
        $paSeg = @{}
        foreach ($k in @($sync.Config.provider_ai.Keys)) {
            $blk = $sync.Config.provider_ai[$k]
            $pub = @{}
            foreach ($f in @($blk.Keys)) { if ($f -ne 'chiave') { $pub[$f] = $blk[$f] } }
            $pub['chiave'] = ''
            $paPub[$k] = $pub
            if (([string]$blk['chiave']).Trim()) { $paSeg[$k] = @{ chiave = [string]$blk['chiave'] } }
        }
        $copia['provider_ai'] = $paPub
        # v9: anche la password della posta resta SOLO in config.local.json.
        # Prima questo salvataggio la cancellava (la gestiva solo la funzione dell'interfaccia).
        $paSegGmail = $null
        try {
            if ($copia.ContainsKey('gmail') -and $copia['gmail']) {
                $gp = @{}
                foreach ($f in @($copia['gmail'].Keys)) { if ($f -ne 'password') { $gp[$f] = $copia['gmail'][$f] } }
                $gp['password'] = ''
                $copia['gmail'] = $gp
                if (([string]$sync.Config.gmail['password']).Trim()) {
                    $paSegGmail = @{ password = [string]$sync.Config.gmail['password'] }
                }
            }
        } catch { }
        [System.IO.File]::WriteAllText($sync.CfgPath, ($copia | ConvertTo-Json -Depth 6), $enc)
        if (($paSeg.Count -gt 0 -or $paSegGmail) -and $sync.Base) {
            $lp = Join-Path $sync.Base 'config.local.json'
            $locale = @{ provider_ai = $paSeg }
            if ($paSegGmail) { $locale['gmail'] = $paSegGmail }
            [System.IO.File]::WriteAllText($lp, ($locale | ConvertTo-Json -Depth 6), $enc)
        }
    } catch { }
}

function Start-ModelPull {
    param($sync, [string]$Model)
    # v9.6 -- Non si scarica piu' niente in locale: si verifica che il servizio
    # configurato risponda davvero.
    $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = 'PROVO IL SERVIZIO IA...' })
    try {
        $msgs = @( @{ role = 'user'; content = 'ping (rispondi solo con: OK)' } )
        $r = Invoke-Chat $sync $msgs @()
        $t = ConvertTo-PlainStringSafe $r.content
        $sync.UiQueue.Enqueue(@{ Type = 'chat'; Data = @{ who = 'zap'; text = ("Servizio IA attivo. Risposta di prova: " + $t) } })
    } catch {
        $sync.UiQueue.Enqueue(@{ Type = 'chat'; Data = @{ who = 'zap'; text = ("Il servizio IA non risponde: " + $_.Exception.Message) } })
    }
    $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = 'PRONTO!' })
}

function ConvertTo-PlainStringSafe {
    param($v)
    if ($null -eq $v) { return '' }
    if (Get-Command ConvertTo-PlainString -ErrorAction SilentlyContinue) { try { return [string](ConvertTo-PlainString $v) } catch { } }
    return [string]$v
}

function Get-ScreenshotBase64 {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    Add-Type -AssemblyName System.Drawing -ErrorAction Stop
    $b = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($b.Left, $b.Top, 0, 0, $bmp.Size)
    $ms = New-Object System.IO.MemoryStream
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $bytes = $ms.ToArray()
    $g.Dispose(); $bmp.Dispose(); $ms.Dispose()
    return [Convert]::ToBase64String($bytes)
}

function Invoke-LookAtScreen {
    param($sync, [string]$Domanda)
    if (-not $Domanda) { $Domanda = "Descrivi in italiano cosa c'e' sullo schermo e cosa sta facendo l'utente, in modo utile e breve." }
    $b64 = ''
    try { $b64 = Get-ScreenshotBase64 } catch {
        return "Non riesco a fare lo screenshot: $($_.Exception.Message) (serve Windows)."
    }
    try {
        $answer = Invoke-GeminiVision $sync $Domanda $b64 'image/png'
        return "Ecco cosa vedo sullo schermo:`n$answer"
    } catch {
        return "Errore nella lettura dello schermo: $($_.Exception.Message)"
    }
}


# ---------------------------------------------------------------------------
# APPUNTI (sessione appunti: salvata su file, non si perde)
# ---------------------------------------------------------------------------

function Get-AppuntiPath {
    param($sync)
    $base = ''
    try { $base = [string]$sync.Base } catch { }
    if (-not $base) { $base = $PSScriptRoot }
    return (Join-Path $base 'appunti\appunti.txt')
}

function Get-AppuntiText {
    param($sync)
    $p = Get-AppuntiPath $sync
    if (Test-Path $p) {
        try { return [string](Get-Content -Path $p -Raw -Encoding UTF8) } catch { return '' }
    }
    return ''
}

function Set-Appunti {
    param($sync, [string]$Testo)
    $p = Get-AppuntiPath $sync
    $d = Split-Path -Parent $p
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    # v9: PRIMA di sovrascrivere salvo una copia datata in Ezappero\appunti\versioni.
    # Gli appunti non si perdono mai: ogni salvataggio e' una nuova versione, per sempre.
    try {
        if (Get-Command Save-AppuntiVersionato -ErrorAction SilentlyContinue) {
            [void](Save-AppuntiVersionato $sync ([string]$Testo))
        }
    } catch { }
    Set-Content -Path $p -Value ([string]$Testo) -Encoding UTF8
    return 'Appunti salvati (versione archiviata in Ezappero).'
}

function Add-Appunto {
    param($sync, [string]$Testo)
    if (-not $Testo) { return '!Nessun testo da annotare.' }
    $p = Get-AppuntiPath $sync
    $d = Split-Path -Parent $p
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    $riga = '[' + (Get-Date -Format 'yyyy-MM-dd HH:mm') + '] ' + [string]$Testo
    Add-Content -Path $p -Value $riga -Encoding UTF8
    # v9: la nota finisce anche nel registro indelebile (ricerca + prompt + copia specchio)
    try {
        if (Get-Command Add-ZapLedgerEvento -ErrorAction SilentlyContinue) {
            [void](Add-ZapLedgerEvento $sync 'appunto' ([string]$Testo) 'appunti' $false)
        }
    } catch { }
    return 'Nota aggiunta agli appunti (e archiviata in Ezappero).'
}

# ---------------------------------------------------------------------------
# AMMINISTRATORE
# ---------------------------------------------------------------------------

function Test-Admin {
    try {
        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object System.Security.Principal.WindowsPrincipal($id)
        return [bool]$pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Get-AdminStatus {
    if (Test-Admin) { return 'ZAP sta girando come AMMINISTRATORE: puo eseguire qualunque comando sul PC.' }
    try {
        if ($sync.Config.admin_su_richiesta) {
            return 'ZAP e in modalita AMMINISTRATORE SU RICHIESTA: la finestra resta non elevata (il trascinamento dei file funziona) e i comandi che richiedono i privilegi vengono rieseguiti elevati al momento (apparira il consenso UAC).'
        }
    } catch { }
    return 'ZAP NON e amministratore. Per i pieni permessi avvia ZAP con AVVIA_ADMIN.bat (i comandi che servono vengono elevati al momento, con consenso UAC). Nel frattempo posso fare tutto il resto.'
}

# ---------------------------------------------------------------------------
# ENTERPRISE: imparare dallo schermo + consigli di miglioramento
# ---------------------------------------------------------------------------

function Invoke-ImparaDalloSchermo {
    param($sync, [string]$Domanda)
    if (-not $Domanda) { $Domanda = "Osserva cosa sta facendo l'utente in questo momento e descrivi la procedura passo per passo, in modo che si possa ripetere." }
    $b64 = ''
    try { $b64 = Get-ScreenshotBase64 } catch {
        return "Non riesco a fare lo screenshot: $($_.Exception.Message) (serve Windows)."
    }
    $lettura = ''
    try {
        $lettura = [string](Invoke-GeminiVision $sync ('Stai imparando da uno screenshot. ' + $Domanda + ' Elenca: 1) cosa si vede; 2) i passaggi per rifarlo; 3) programmi o percorsi usati. In italiano, conciso.') $b64 'image/png')
    } catch {
        return "Ho fatto lo screenshot ma non sono riuscito a leggerlo: $($_.Exception.Message)"
    }
    try { [void](Add-Memory $sync ('Imparato guardando lo schermo: ' + $lettura)) } catch { }
    return ("Ho imparato questo dallo schermo:`n" + $lettura + "`n`n(l'ho salvato in memoria, ora me lo ricordo)")
}

function Invoke-ConsigliMiglioramento {
    param($sync, [string]$Argomento)
    $a = [string]$Argomento
    if (-not $a) { $a = 'in generale' }
    $elenco = 'comandi: /mode, /appunti, /impara-schermo, /migliorati, /allegati, /foto, /video, /skills, /insegna; ' +
              'strumenti: run_powershell, web_search, read_webpage, guarda_schermo, impara_dallo_schermo, teach_skill, aggiungi_appunto; ' +
              'modalita: prudente, smart, libera, sviluppatore, enterprise'
    $q = 'Sei ZAP in modalita ENTERPRISE. Dai trucchi e opzioni CONCRETE per migliorarmi (' + $a + '). ' +
         'Ecco cosa so fare: ' + $elenco + '. ' +
         'Rispondi in italiano con massimo 8 punti brevi e azionabili: cosa insegnarmi come skill, quali comandi usare, quali impostazioni cambiare.'
    try {
        $msg = @( @{ role = 'user'; content = $q } )
        $r = Invoke-ChatGemini $sync $msg @()
        $t = [string]$r.content
        if ($t) { return $t }
        return 'Non ho ricevuto consigli in questo momento.'
    } catch {
        return ("Non riesco a generare i consigli adesso: " + $_.Exception.Message)
    }
}


# ---------------------------------------------------------------------------
# v6.6 -- memoria del modello che funziona (condivisa fra i due motori, su file)
# ---------------------------------------------------------------------------

function Set-ModelloOk {
    param($sync, [string]$Modello)
    if (-not $Modello) { return }
    try { $sync.ModelloOk = $Modello } catch { }
    try {
        $p = Join-Path $sync.Base 'memory\modello_scelto.txt'
        $d = Split-Path -Parent $p
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        Set-Content -Path $p -Value ([string]$Modello) -Encoding UTF8
    } catch { }
}

function Get-ModelloSalvato {
    param($sync)
    try {
        $p = Join-Path $sync.Base 'memory\modello_scelto.txt'
        if (Test-Path $p) { return ([string](Get-Content -Path $p -Raw -Encoding UTF8)).Trim() }
    } catch { }
    return ''
}
