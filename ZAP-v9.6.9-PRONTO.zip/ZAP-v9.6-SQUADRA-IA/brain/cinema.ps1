﻿# cinema.ps1 -- ZAP CINEMA ENGINE v8.0
# ---------------------------------------------------------------------------
#  Motore grafico che anima una FOTO in una GIF cinematografica.
#  Funziona 100% in locale: nessun servizio esterno, nessun ffmpeg, nessun
#  pacchetto da scaricare. Usa solo WPF (gia' usato dall'interfaccia).
#
#  Cosa fa, fotogramma per fotogramma:
#    - Ken Burns: zoom e panoramica con curva morbida (smoothstep doppio)
#    - respiro: micro-oscillazione della scala (l'immagine "vive")
#    - deriva: micro-tremolio da pellicola (gate weave)
#    - bloom:  aloni luminosi sulle zone chiare
#    - luce:   un fascio di luce che attraversa la scena (light sweep)
#    - pulviscolo: particelle dorate con profondita' diverse
#    - color grade: tinta calda sulle luci + ombre fredde
#    - vignettatura cinematografica
#    - grana pellicola
#
#  Le funzioni sono PURE (nessuna dipendenza da $sync): si possono provare e
#  richiamare anche da un runspace di lavoro.
# ---------------------------------------------------------------------------

function New-CinemaColore {
    param([string]$Hex, [int]$Alfa = 255)
    try {
        $h = ([string]$Hex).Trim().TrimStart('#')
        if ($h.Length -eq 3) { $h = ($h[0] + $h[0] + $h[1] + $h[1] + $h[2] + $h[2]) }
        if ($h.Length -ne 6) { return [System.Windows.Media.Color]::FromArgb($Alfa, 255, 255, 255) }
        $r = [Convert]::ToByte($h.Substring(0, 2), 16)
        $g = [Convert]::ToByte($h.Substring(2, 2), 16)
        $b = [Convert]::ToByte($h.Substring(4, 2), 16)
        if ($Alfa -lt 0) { $Alfa = 0 }
        if ($Alfa -gt 255) { $Alfa = 255 }
        return [System.Windows.Media.Color]::FromArgb([byte]$Alfa, $r, $g, $b)
    } catch {
        return [System.Windows.Media.Color]::FromArgb(255, 255, 255, 255)
    }
}

function Get-CinemaPresetNomi {
    return @('aura', 'cinema', 'ritratto', 'neon', 'sogno', 'vintage')
}

function Get-CinemaPreset {
    # Restituisce il preset richiesto. Ogni preset e' una "regia" diversa.
    param([string]$Nome = 'aura')

    $p = @{
        id               = 'aura'
        nome             = 'AURA DORATA'
        descrizione      = 'Zoom lento, luce che attraversa la scena, pulviscolo d oro.'
        durata           = 3.0     # secondi
        fps              = 20
        zoomInizio       = 1.03
        zoomFine         = 1.16
        panX             = 0.16    # frazione di larghezza, totale nel clip
        panY             = -0.10   # frazione di altezza
        luce             = 0.60
        particelle       = 20
        coloreParticelle = '#FFE9A8'
        grana            = 0.070
        vignetta         = 0.60
        bloom            = 0.35
        tinta            = '#FFB45A'
        ombra            = '#08101E'
        tintaForza       = 0.10
        respiro          = 1.0
        deriva           = 0.8
    }

    switch (([string]$Nome).ToLowerInvariant()) {
        'cinema' {
            $p.nome = 'CINEMA 2.5D'
            $p.descrizione = 'Il movimento piu ampio: spinta in avanti, luce laterale, grana da sala.'
            $p.durata = 4.0
            $p.zoomInizio = 1.02
            $p.zoomFine = 1.26
            $p.panX = 0.28
            $p.panY = 0.12
            $p.luce = 0.75
            $p.particelle = 10
            $p.grana = 0.095
            $p.vignetta = 0.75
            $p.bloom = 0.40
            $p.tinta = '#FFC27A'
            $p.ombra = '#050A14'
            $p.tintaForza = 0.13
            $p.respiro = 0.6
            $p.deriva = 1.2
        }
        'ritratto' {
            $p.nome = 'RITRATTO ELEGANTE'
            $p.descrizione = 'Quasi fermo: respiro leggerissimo, luce morbida, nessun pulviscolo.'
            $p.durata = 3.5
            $p.zoomInizio = 1.06
            $p.zoomFine = 1.10
            $p.panX = 0.04
            $p.panY = -0.03
            $p.luce = 0.32
            $p.particelle = 0
            $p.grana = 0.035
            $p.vignetta = 0.70
            $p.bloom = 0.22
            $p.tinta = '#FFD8A8'
            $p.ombra = '#0A0F18'
            $p.tintaForza = 0.07
            $p.respiro = 1.4
            $p.deriva = 0.35
        }
        'neon' {
            $p.nome = 'NOTTE NEON'
            $p.descrizione = 'Freddo e magnetico: tinte ciano e magenta, pulviscolo elettrico.'
            $p.durata = 3.0
            $p.zoomInizio = 1.08
            $p.zoomFine = 1.02
            $p.panX = -0.20
            $p.panY = 0.10
            $p.luce = 0.85
            $p.particelle = 30
            $p.coloreParticelle = '#8FE9FF'
            $p.grana = 0.065
            $p.vignetta = 0.80
            $p.bloom = 0.55
            $p.tinta = '#55D4FF'
            $p.ombra = '#1A0330'
            $p.tintaForza = 0.15
            $p.respiro = 1.2
            $p.deriva = 1.5
        }
        'sogno' {
            $p.nome = 'SOGNO SOFT'
            $p.descrizione = 'Morbido e luminoso: aloni larghi, orbite lente, colori pastello.'
            $p.durata = 4.0
            $p.zoomInizio = 1.04
            $p.zoomFine = 1.13
            $p.panX = -0.10
            $p.panY = -0.08
            $p.luce = 0.45
            $p.particelle = 34
            $p.coloreParticelle = '#FFFFFF'
            $p.grana = 0.030
            $p.vignetta = 0.35
            $p.bloom = 0.85
            $p.tinta = '#FFD9F0'
            $p.ombra = '#0B1430'
            $p.tintaForza = 0.12
            $p.respiro = 1.8
            $p.deriva = 0.5
        }
        'vintage' {
            $p.nome = 'PELLICOLA VINTAGE'
            $p.descrizione = 'Sepia, grana forte, tremolio da proiettore anni 70.'
            $p.durata = 3.0
            $p.zoomInizio = 1.05
            $p.zoomFine = 1.12
            $p.panX = 0.10
            $p.panY = 0.04
            $p.luce = 0.30
            $p.particelle = 14
            $p.coloreParticelle = '#FFD9A0'
            $p.grana = 0.150
            $p.vignetta = 0.85
            $p.bloom = 0.25
            $p.tinta = '#E8B471'
            $p.ombra = '#120B04'
            $p.tintaForza = 0.22
            $p.respiro = 0.8
            $p.deriva = 2.2
        }
        default { }
    }
    return $p
}

function Get-CinemaPresetElenco {
    $out = New-Object System.Collections.ArrayList
    foreach ($id in (Get-CinemaPresetNomi)) {
        $p = Get-CinemaPreset $id
        [void]$out.Add([pscustomobject]@{ id = $id; nome = $p.nome; descrizione = $p.descrizione })
    }
    return $out
}

# ---------------------------------------------------------------------------
# Caricamento immagine
# ---------------------------------------------------------------------------

function Get-CinemaImmagine {
    param([string]$Percorso, [int]$LatoMax = 1400)

    if (-not $Percorso) { throw 'Nessuna immagine indicata.' }
    if (-not (Test-Path $Percorso)) { throw ('File non trovato: ' + $Percorso) }

    $uri = New-Object System.Uri($Percorso, [System.UriKind]::Absolute)

    $probe = New-Object System.Windows.Media.Imaging.BitmapImage
    $probe.BeginInit()
    $probe.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $probe.CreateOptions = [System.Windows.Media.Imaging.BitmapCreateOptions]::IgnoreColorProfile
    $probe.UriSource = $uri
    $probe.EndInit()

    $pw = [int]$probe.PixelWidth
    $ph = [int]$probe.PixelHeight
    if ($pw -le 0 -or $ph -le 0) { throw 'Immagine non leggibile (formato non supportato).' }

    $lato = [Math]::Max($pw, $ph)
    if ($lato -le $LatoMax) {
        $probe.Freeze()
        return $probe
    }

    # immagine grande: la decodifico gia' ridimensionata (meno RAM, piu' veloce)
    $img = New-Object System.Windows.Media.Imaging.BitmapImage
    $img.BeginInit()
    $img.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $img.CreateOptions = [System.Windows.Media.Imaging.BitmapCreateOptions]::IgnoreColorProfile
    $img.UriSource = $uri
    if ($pw -ge $ph) {
        $img.DecodePixelWidth = $LatoMax
    } else {
        $img.DecodePixelHeight = $LatoMax
    }
    $img.EndInit()
    $img.Freeze()
    return $img
}

function Get-CinemaFormato {
    # Calcola larghezza/altezza della GIF mantenendo le proporzioni.
    param([int]$Larghezza, [int]$Altezza, [int]$LatoMax = 640)
    if ($Larghezza -le 0 -or $Altezza -le 0) { return @{ larghezza = 640; altezza = 640 } }
    $s = 1.0
    $lato = [Math]::Max($Larghezza, $Altezza)
    if ($lato -gt $LatoMax) { $s = $LatoMax / [double]$lato }
    $w = [int][Math]::Round($Larghezza * $s)
    $h = [int][Math]::Round($Altezza * $s)
    # le GIF con lati dispari a volte "ballano": pari e multipli di 2
    $w = [Math]::Max(2, [int]($w / 2) * 2)
    $h = [Math]::Max(2, [int]($h / 2) * 2)
    return @{ larghezza = $w; altezza = $h }
}

# ---------------------------------------------------------------------------
# Elementi di scena (grana e particelle) -- costruiti una volta per clip
# ---------------------------------------------------------------------------

function New-CinemaGrana {
    param([int]$Lato = 96, [int]$Seme = 7)
    $rnd = New-Object System.Random($Seme)
    $tot = $Lato * $Lato * 4
    $buf = New-Object 'byte[]' $tot
    for ($i = 0; $i -lt $tot; $i += 4) {
        # meta' puntini neri, meta' bianchi: e' cosi' che nasce la grana
        $v = [byte]255
        if ($rnd.Next(0, 2) -eq 0) { $v = [byte]0 }
        $buf[$i] = $v
        $buf[$i + 1] = $v
        $buf[$i + 2] = $v
        $buf[$i + 3] = [byte]255
    }
    $src = [System.Windows.Media.Imaging.BitmapSource]::Create(
        $Lato, $Lato, 96, 96,
        [System.Windows.Media.PixelFormats]::Bgra32,
        $null, $buf, ($Lato * 4))
    $src.Freeze()
    return $src
}

function New-CinemaGrane {
    param([int]$Quante = 4)
    $lista = New-Object System.Collections.ArrayList
    for ($i = 0; $i -lt $Quante; $i++) {
        [void]$lista.Add((New-CinemaGrana 96 (17 + $i * 31)))
    }
    return $lista
}

function New-CinemaParticelle {
    param([int]$Numero = 18, [int]$Seme = 11)
    $lista = New-Object System.Collections.ArrayList
    if ($Numero -le 0) { return $lista }
    $rnd = New-Object System.Random($Seme)
    for ($i = 0; $i -lt $Numero; $i++) {
        [void]$lista.Add(@{
            x = $rnd.NextDouble()
            y = $rnd.NextDouble()
            r = 0.005 + $rnd.NextDouble() * 0.026
            v = 0.10 + $rnd.NextDouble() * 0.35
            s = 0.5 + $rnd.NextDouble() * 1.5
            f = $rnd.NextDouble() * 6.283
            a = 0.10 + $rnd.NextDouble() * 0.40
            d = 0.30 + $rnd.NextDouble() * 0.70
        })
    }
    return $lista
}

# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

function New-CinemaSfocato {
    param($Bitmap, [double]$Raggio = 14)
    if ($Raggio -lt 0.5) { return $Bitmap }
    $dv = New-Object System.Windows.Media.DrawingVisual
    $ef = New-Object System.Windows.Media.Effects.BlurEffect
    $ef.Radius = $Raggio
    $ef.KernelType = [System.Windows.Media.Effects.KernelType]::Gaussian
    try { $dv.Effect = $ef } catch { return $Bitmap }
    $dc = $dv.RenderOpen()
    $dc.DrawImage($Bitmap, (New-Object System.Windows.Rect(0, 0, $Bitmap.PixelWidth, $Bitmap.PixelHeight)))
    $dc.Close()
    $out = New-Object System.Windows.Media.Imaging.RenderTargetBitmap(
        [int]$Bitmap.PixelWidth, [int]$Bitmap.PixelHeight, 96, 96,
        [System.Windows.Media.PixelFormats]::Pbgra32)
    $out.Render($dv)
    try { $out.Freeze() } catch { }
    return $out
}

function New-CinemaFrame {
    # Disegna UN fotogramma. $T va da 0 a 1 (posizione nel clip).
    param(
        $Immagine,
        [int]$Larghezza,
        [int]$Altezza,
        [double]$T,
        $Preset,
        $Particelle = $null,
        $Grane = $null
    )

    $p = $Preset
    if ($null -eq $p) { $p = Get-CinemaPreset 'aura' }
    if ($T -lt 0) { $T = 0 }
    if ($T -gt 1) { $T = 1 }

    $W = [double]$Larghezza
    $H = [double]$Altezza
    $rect = New-Object System.Windows.Rect(0, 0, $W, $H)

    # --- curva morbida: parte piano, accelera, finisce piano -----------------
    $e = $T * $T * (3 - 2 * $T)
    $e = $e * $e * (3 - 2 * $e)

    $zoom = $p.zoomInizio + ($p.zoomFine - $p.zoomInizio) * $e
    $respiro = 1.0 + 0.0045 * $p.respiro * [Math]::Sin(2 * [Math]::PI * $T * 1.2)
    $scala = $zoom * $respiro

    $cx = $W / 2.0
    $cy = $H / 2.0
    $dx = ($p.panX * $W * ($e - 0.5)) + (0.7 * $p.deriva * [Math]::Sin(2 * [Math]::PI * $T * 2.1))
    $dy = ($p.panY * $H * ($e - 0.5)) + (0.5 * $p.deriva * [Math]::Cos(2 * [Math]::PI * $T * 1.7))

    $mat = New-Object System.Windows.Media.Matrix($scala, 0, 0, $scala, ($cx * (1 - $scala) + $dx), ($cy * (1 - $scala) + $dy))

    # --- 1) scena (immagine mossa) ------------------------------------------
    $dv = New-Object System.Windows.Media.DrawingVisual
    $dc = $dv.RenderOpen()
    $dc.PushTransform((New-Object System.Windows.Media.MatrixTransform($mat)))
    $dc.DrawImage($Immagine, $rect)
    $dc.Pop()
    $dc.Close()

    $scena = New-Object System.Windows.Media.Imaging.RenderTargetBitmap(
        [int]$W, [int]$H, 96, 96, [System.Windows.Media.PixelFormats]::Pbgra32)
    $scena.Render($dv)
    try { $scena.Freeze() } catch { }

    $alone = $null
    if ($p.bloom -gt 0.03) {
        $alone = New-CinemaSfocato $scena (7.0 + 16.0 * $p.bloom)
    }

    # --- 2) composizione finale ---------------------------------------------
    $dv2 = New-Object System.Windows.Media.DrawingVisual
    $dc2 = $dv2.RenderOpen()

    # fondo pieno (evita trasparenze strane nella GIF)
    $fondo = New-Object System.Windows.Media.SolidColorBrush((New-CinemaColore $p.ombra 255))
    $fondo.Freeze()
    $dc2.DrawRectangle($fondo, $null, $rect)

    # immagine
    $dc2.DrawImage($scena, $rect)

    # bloom: aloni luminosi
    if ($alone) {
        $op = [Math]::Min(0.90, $p.bloom * 0.95)
        $dc2.PushOpacity($op)
        $dc2.DrawImage($alone, $rect)
        $dc2.Pop()
    }

    # color grade: luci calde, ombre fredde
    $grade = New-Object System.Windows.Media.LinearGradientBrush
    $grade.StartPoint = New-Object System.Windows.Point(0.1, 0.0)
    $grade.EndPoint = New-Object System.Windows.Point(0.6, 1.0)
    $alfaLuce = [int][Math]::Round(255 * $p.tintaForza * 0.85)
    $alfaOmbra = [int][Math]::Round(255 * $p.tintaForza * 1.10)
    $grade.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore $p.tinta $alfaLuce), 0.0)))
    $grade.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore $p.ombra $alfaOmbra), 1.0)))
    $grade.Freeze()
    $dc2.DrawRectangle($grade, $null, $rect)

    # light sweep: un fascio che attraversa la scena
    if ($p.luce -gt 0.02) {
        $off = -0.75 + 2.1 * $e
        $band = New-Object System.Windows.Media.LinearGradientBrush
        $band.StartPoint = New-Object System.Windows.Point(0, 0)
        $band.EndPoint = New-Object System.Windows.Point(1, 1)
        $picco = [int][Math]::Round(255 * 0.55 * $p.luce)
        $band.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#FFFFFF' 0), 0.00)))
        $band.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#FFFFFF' 0), 0.38)))
        $band.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#FFF3D6' $picco), 0.50)))
        $band.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#FFFFFF' 0), 0.62)))
        $band.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#FFFFFF' 0), 1.00)))
        $band.RelativeTransform = New-Object System.Windows.Media.TranslateTransform($off, ($off * 0.35))
        $band.Freeze()
        $dc2.PushOpacity([Math]::Min(1.0, $p.luce + 0.35))
        $dc2.DrawRectangle($band, $null, $rect)
        $dc2.Pop()
    }

    # pulviscolo dorato
    if ($Particelle -and $Particelle.Count -gt 0) {
        foreach ($pt in $Particelle) {
            $yy = $pt.y - ($T * $pt.v * $pt.d)
            $yy = $yy - [Math]::Floor($yy)
            $xx = $pt.x + 0.025 * $pt.s * [Math]::Sin((2 * [Math]::PI * $T * $pt.s) + $pt.f)
            if ($xx -lt -0.1) { $xx = $xx + 1.0 }
            if ($xx -gt 1.1) { $xx = $xx - 1.0 }
            $px = $xx * $W
            $py = $yy * $H
            $rad = $pt.r * $W * (0.65 + 0.45 * $pt.d)
            if ($rad -lt 0.7) { $rad = 0.7 }
            $alfa = [int][Math]::Round(255 * $pt.a)
            $br = New-Object System.Windows.Media.RadialGradientBrush
            $br.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore $p.coloreParticelle $alfa), 0.0)))
            $br.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore $p.coloreParticelle ([int]($alfa * 0.35))), 0.45)))
            $br.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore $p.coloreParticelle 0), 1.0)))
            $br.Freeze()
            $dc2.DrawEllipse($br, $null, (New-Object System.Windows.Point($px, $py)), $rad, $rad)
        }
    }

    # vignettatura
    if ($p.vignetta -gt 0.02) {
        $alfaV = [int][Math]::Round(215 * $p.vignetta)
        $vg = New-Object System.Windows.Media.RadialGradientBrush
        $vg.Center = New-Object System.Windows.Point(0.5, 0.45)
        $vg.GradientOrigin = New-Object System.Windows.Point(0.5, 0.45)
        $vg.RadiusX = 0.80
        $vg.RadiusY = 0.92
        $vg.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#000000' 0), 0.00)))
        $vg.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#000000' 0), 0.55)))
        $vg.GradientStops.Add((New-Object System.Windows.Media.GradientStop((New-CinemaColore '#000000' $alfaV), 1.00)))
        $vg.Freeze()
        $dc2.DrawRectangle($vg, $null, $rect)
    }

    # grana pellicola
    if ($p.grana -gt 0.004 -and $Grane -and $Grane.Count -gt 0) {
        $idx = [int]([Math]::Round($T * 60)) % $Grane.Count
        $ib = New-Object System.Windows.Media.ImageBrush
        $ib.ImageSource = $Grane[$idx]
        $ib.TileMode = [System.Windows.Media.TileMode]::Tile
        $ib.Stretch = [System.Windows.Media.Stretch]::Fill
        $ib.ViewportUnits = [System.Windows.Media.BrushMappingMode]::Absolute
        $ib.Viewport = New-Object System.Windows.Rect(0, 0, 96, 96)
        $ib.Freeze()
        $dc2.PushOpacity([Math]::Min(1.0, [Math]::Max(0.0, $p.grana)))
        $dc2.DrawRectangle($ib, $null, $rect)
        $dc2.Pop()
    }

    $dc2.Close()
    $out = New-Object System.Windows.Media.Imaging.RenderTargetBitmap(
        [int]$W, [int]$H, 96, 96, [System.Windows.Media.PixelFormats]::Pbgra32)
    $out.Render($dv2)
    $out.Freeze()
    return $out
}

function New-CinemaAnteprima {
    # Un solo fotogramma (per mostrarlo nell'interfaccia): torna il percorso del PNG.
    param($Immagine, [string]$Preset = 'aura', [string]$Percorso = '', [double]$T = 0.25,
        [int]$LatoMax = 640)

    $p = Get-CinemaPreset $Preset
    $f = Get-CinemaFormato $Immagine.PixelWidth $Immagine.PixelHeight $LatoMax
    $foto = New-CinemaFrame $Immagine $f.larghezza $f.altezza $T $p (New-CinemaParticelle ([int]$p.particelle) 11) (New-CinemaGrane 4)

    if (-not $Percorso) {
        $Percorso = Join-Path $env:TEMP ('zap_anteprima_' + [guid]::NewGuid().ToString('N') + '.png')
    }
    $dir = Split-Path -Parent $Percorso
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $enc = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
    $enc.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($foto))
    $fs = [System.IO.File]::Create($Percorso)
    try { $enc.Save($fs) } finally { $fs.Dispose() }
    return $Percorso
}

# ---------------------------------------------------------------------------
# GIF: scrittura + verifica del ciclo infinito
# ---------------------------------------------------------------------------

function Save-CinemaGif {
    param($Frames, [string]$Percorso, [int]$RitardoMs = 50)

    if (-not $Frames -or $Frames.Count -eq 0) { throw 'Nessun fotogramma da salvare.' }
    $dir = Split-Path -Parent $Percorso
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    $enc = New-Object System.Windows.Media.Imaging.GifBitmapEncoder
    $ritardoCs = [UInt16][Math]::Max(2.0, [Math]::Round([double]$RitardoMs / 10.0))
    $primo = $true

    foreach ($bmp in $Frames) {
        $meta = New-Object System.Windows.Media.Imaging.BitmapMetadata('gif')
        try { $meta.SetQuery('/grctlext/Delay', $ritardoCs) } catch { }
        if ($primo) {
            try {
                $meta.SetQuery('/appext/Application', [System.Text.Encoding]::ASCII.GetBytes('NETSCAPE2.0'))
                $meta.SetQuery('/appext/Data', [byte[]](3, 1, 0, 0, 0))
            } catch { }
            $primo = $false
        }
        $fr = [System.Windows.Media.Imaging.BitmapFrame]::Create($bmp, $null, $meta, $null)
        $enc.Frames.Add($fr)
    }

    $fs = [System.IO.File]::Create($Percorso)
    try { $enc.Save($fs) } finally { $fs.Dispose() }

    # Rete di sicurezza: se l'estensione di ciclo non fosse stata scritta,
    # la inserisco io direttamente nei byte della GIF (blocco NETSCAPE2.0).
    try { [void](Repair-CinemaGifLoop $Percorso) } catch { }
    return $Percorso
}

function Test-CinemaGifLoop {
    param([string]$Percorso)
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Percorso)
        $needle = [System.Text.Encoding]::ASCII.GetBytes('NETSCAPE2.0')
        $n = $needle.Length
        for ($i = 0; $i -le ($bytes.Length - $n); $i++) {
            $ok = $true
            for ($j = 0; $j -lt $n; $j++) {
                if ($bytes[$i + $j] -ne $needle[$j]) { $ok = $false; break }
            }
            if ($ok) { return $true }
        }
        return $false
    } catch { return $false }
}

function Repair-CinemaGifLoop {
    # Inserisce il blocco applicativo NETSCAPE2.0 (ciclo infinito) subito dopo
    # la tavolozza globale, se non c'e' gia'.
    param([string]$Percorso)
    if (-not (Test-Path $Percorso)) { return $false }
    if (Test-CinemaGifLoop $Percorso) { return $false }

    $bytes = [System.IO.File]::ReadAllBytes($Percorso)
    if ($bytes.Length -lt 14) { return $false }
    $sig = [System.Text.Encoding]::ASCII.GetString($bytes, 0, 6)
    if ($sig -ne 'GIF89a' -and $sig -ne 'GIF87a') { return $false }

    $packed = [int]$bytes[10]
    $offset = 13
    if (($packed -band 0x80) -eq 0x80) {
        $bits = ($packed -band 0x07) + 1
        $offset = 13 + (3 * [int][Math]::Pow(2, $bits))
    }
    if ($offset -ge $bytes.Length) { return $false }

    $blocco = [byte[]](0x21, 0xFF, 0x0B, 0x4E, 0x45, 0x54, 0x53, 0x43, 0x41, 0x50, 0x45, 0x32, 0x2E, 0x30,
                       0x03, 0x01, 0x00, 0x00, 0x00)
    $nuovo = New-Object 'byte[]' ($bytes.Length + $blocco.Length)
    [Array]::Copy($bytes, 0, $nuovo, 0, $offset)
    [Array]::Copy($blocco, 0, $nuovo, $offset, $blocco.Length)
    [Array]::Copy($bytes, $offset, $nuovo, ($offset + $blocco.Length), ($bytes.Length - $offset))
    [System.IO.File]::WriteAllBytes($Percorso, $nuovo)
    return $true
}

# ---------------------------------------------------------------------------
# Motore: anima una foto
# ---------------------------------------------------------------------------

function Invoke-CinemaAnima {
    param(
        [Parameter(Mandatory = $true)][string]$Sorgente,
        [string]$CartellaUscita = '',
        [string]$Preset = 'aura',
        [int]$LatoMax = 640,
        [int]$FrameMassimi = 0,
        [double]$Secondi = 0,
        [string]$NomeFile = '',
        $Notifica = $null,      # scriptblock(indice, totale)
        $Annulla = $null        # scriptblock -> $true per fermare
    )

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    $p = Get-CinemaPreset $Preset
    if ($Secondi -gt 0) { $p.durata = $Secondi }

    $img = Get-CinemaImmagine $Sorgente 1600
    $f = Get-CinemaFormato $img.PixelWidth $img.PixelHeight $LatoMax
    $W = [int]$f.larghezza
    $H = [int]$f.altezza

    $tot = [int][Math]::Round($p.durata * $p.fps)
    if ($FrameMassimi -gt 0) { $tot = $FrameMassimi }
    if ($tot -lt 6) { $tot = 6 }
    if ($tot -gt 120) { $tot = 120 }
    # tetto di memoria: ogni fotogramma occupa larghezza*altezza*4 byte.
    # Oltre ~260 MB conviene ridurre il numero di fotogrammi (GIF piu' leggera).
    $byteFrame = [double]$W * [double]$H * 4.0
    $maxFrame = [int][Math]::Floor(260000000.0 / [Math]::Max(1.0, $byteFrame))
    if ($maxFrame -lt 12) { $maxFrame = 12 }
    if ($tot -gt $maxFrame) { $tot = $maxFrame }

    if (-not $CartellaUscita) {
        $CartellaUscita = Join-Path (Get-Location).Path 'output\cinema'
    }
    if (-not (Test-Path $CartellaUscita)) { New-Item -ItemType Directory -Path $CartellaUscita -Force | Out-Null }

    if (-not $NomeFile) {
        $base = [System.IO.Path]::GetFileNameWithoutExtension($Sorgente)
        $base = ($base -replace '[^\w\-]+', '_')
        if ($base.Length -gt 40) { $base = $base.Substring(0, 40) }
        $NomeFile = $base + '_' + $p.id + '_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.gif'
    }
    $uscita = Join-Path $CartellaUscita $NomeFile

    $particelle = New-CinemaParticelle ([int]$p.particelle) 11
    $grane = New-CinemaGrane 4
    $frames = New-Object System.Collections.ArrayList

    for ($i = 0; $i -lt $tot; $i++) {
        if ($Annulla) {
            $stop = $false
            try { $stop = [bool](& $Annulla) } catch { $stop = $false }
            if ($stop) { throw 'ANNULLATO' }
        }
        $t = 0.0
        if ($tot -gt 1) { $t = $i / [double]($tot - 1) }
        $fr = New-CinemaFrame $img $W $H $t $p $particelle $grane
        [void]$frames.Add($fr)
        if ($Notifica) { try { & $Notifica ($i + 1) $tot } catch { } }
    }

    $ritardo = [int][Math]::Round(1000.0 / [double]$p.fps)
    Save-CinemaGif $frames $uscita $ritardo | Out-Null

    $sw.Stop()
    return [pscustomobject]@{
        ok        = $true
        file      = $uscita
        preset    = $p.nome
        presetId  = $p.id
        frames    = $tot
        larghezza = $W
        altezza   = $H
        fps       = $p.fps
        ms        = $sw.ElapsedMilliseconds
        byte      = (Get-Item $uscita).Length
    }
}

function Get-CinemaCartella {
    param([string]$Base)
    if (-not $Base) { $Base = (Get-Location).Path }
    return (Join-Path $Base 'output\cinema')
}
