﻿# email_gmail.ps1 -- POSTA: invio email da Gmail (o qualsiasi SMTP) con ZAP (v9).
#
# Per Gmail NON si usa la password dell'account (Google la blocca): serve una
# "Password per le app" (16 caratteri), che si crea SOLO se l'account ha la verifica in
# due passaggi attiva: https://myaccount.google.com/apppasswords
#
# La password dell'app va in config.local.json (file che .gitignore esclude), MAI in config.json
# e MAI nel registro Ezappero: qui si annota "email inviata a X con oggetto Y", non il contenuto
# delle credenziali.

function Get-EmailConfig {
    param($sync)
    $d = @{
        mittente    = ''
        nome        = ''
        password    = ''
        smtp        = 'smtp.gmail.com'
        porta       = 587
        ssl         = $true
        firma       = ''
        solo_bozze  = $true   # sicurezza: di default ZAP prepara la bozza e NON invia
    }
    try {
        $c = $sync.Config.gmail
        if ($c) {
            try { if ($c.mittente) { $d.mittente = [string]$c.mittente } } catch { }
            try { if ($c.nome) { $d.nome = [string]$c.nome } } catch { }
            try { if ($c.password) { $d.password = [string]$c.password } } catch { }
            try { if ($c.smtp) { $d.smtp = [string]$c.smtp } } catch { }
            try { if ($c.porta) { $d.porta = [int]$c.porta } } catch { }
            try { if ($null -ne $c.ssl) { $d.ssl = [bool]$c.ssl } } catch { }
            try { if ($c.firma) { $d.firma = [string]$c.firma } } catch { }
            try { if ($null -ne $c.solo_bozze) { $d.solo_bozze = [bool]$c.solo_bozze } } catch { }
        }
    } catch { }
    return $d
}

function Get-EmailStato {
    param($sync)
    $c = Get-EmailConfig $sync
    $righe = New-Object System.Collections.ArrayList
    [void]$righe.Add('POSTA (SMTP)')
    if (-not $c.mittente) {
        [void]$righe.Add('  non configurata: manca l''indirizzo del mittente (config.local.json -> gmail.mittente)')
        return ($righe -join "`r`n")
    }
    [void]$righe.Add("  mittente: $($c.mittente)")
    [void]$righe.Add("  server:   $($c.smtp):$($c.porta) (ssl: $($c.ssl))")
    if ($c.password) { [void]$righe.Add('  password per le app: presente') } else { [void]$righe.Add('  password per le app: MANCANTE -> le email non possono partire') }
    if ($c.solo_bozze) { [void]$righe.Add('  modalita: SOLO BOZZE (ZAP prepara, tu invii). Per l''invio diretto: gmail.solo_bozze = false') }
    else { [void]$righe.Add('  modalita: INVIO DIRETTO attivo') }
    return ($righe -join "`r`n")
}

function Save-EmailBozza {
    # Bozza su file: sempre, anche quando l'invio va a buon fine. Cosi' resta la prova.
    param($sync, [string]$A, [string]$Oggetto, [string]$Corpo, [string]$Cc = '', $Allegati = @())
    try {
        $dir = Join-Path (Get-EzapperoDir $sync) ('email\' + (Get-Date -Format 'yyyy-MM-dd'))
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $p = Join-Path $dir ('email-' + (Get-Date -Format 'HHmmss') + '.html')
        $h = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' + (ConvertTo-HtmlSafe $Oggetto) + '</title></head><body style="font-family:Segoe UI,Arial,sans-serif;max-width:760px;margin:24px auto">'
        $h += '<div style="border-bottom:2px solid #d4af37;padding-bottom:8px;margin-bottom:14px">'
        $h += '<div><b>A:</b> ' + (ConvertTo-HtmlSafe $A) + '</div>'
        if ($Cc) { $h += '<div><b>CC:</b> ' + (ConvertTo-HtmlSafe $Cc) + '</div>' }
        $h += '<div><b>Oggetto:</b> ' + (ConvertTo-HtmlSafe $Oggetto) + '</div>'
        $h += '<div style="color:#888;font-size:12px">Bozza preparata da ZAP il ' + (Get-Date -Format 'dd/MM/yyyy HH:mm') + '</div></div>'
        $h += '<div>' + ([string]$Corpo -replace "`r?`n", '<br/>') + '</div>'
        if (@($Allegati).Count -gt 0) {
            $h += '<div style="margin-top:18px;color:#666;font-size:12px"><b>Allegati:</b><br/>'
            foreach ($al in @($Allegati)) { $h += (ConvertTo-HtmlSafe ([string]$al)) + '<br/>' }
            $h += '</div>'
        }
        $h += '</body></html>'
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($p, $h, $enc)
        return $p
    } catch { return '' }
}

function Send-Email {
    param(
        $sync,
        [string]$A = '',
        [string]$Oggetto = '',
        [string]$Corpo = '',
        [string]$Cc = '',
        $Allegati = @(),
        [switch]$InviaDavvero
    )
    if (-not $A -or $A -notmatch '@') { return '!Serve l''indirizzo del destinatario (es. mario@example.com).' }
    if (-not $Oggetto) { $Oggetto = '(senza oggetto)' }

    $c = Get-EmailConfig $sync
    $corpoFinale = [string]$Corpo
    if ($c.firma) { $corpoFinale = $corpoFinale + "`r`n`r`n" + $c.firma }

    $bozza = Save-EmailBozza $sync $A $Oggetto $corpoFinale $Cc $Allegati

    $manca = ''
    if (-not $c.mittente) { $manca = 'manca il mittente (config.local.json -> gmail.mittente)' }
    elseif (-not $c.password) { $manca = 'manca la password per le app di Gmail (config.local.json -> gmail.password)' }

    if ($manca) {
        [void](Add-ZapLedgerEvento $sync 'email' ("Bozza email per $A - $Oggetto (NON inviata: $manca) -> $bozza") 'email' $false)
        return ("NON ho inviato nulla: $manca.`nBozza pronta qui: $bozza`nPer configurare: pannello IA/Impostazioni, oppure chiedimi `"configura la posta`".")
    }

    if ((-not $InviaDavvero) -and $c.solo_bozze) {
        [void](Add-ZapLedgerEvento $sync 'email' ("Bozza email per $A - $Oggetto (modalita solo bozze) -> $bozza") 'email' $false)
        return ("Bozza pronta: $bozza`nNON ho inviato: la modalita' e' 'solo bozze'. Dimmi `"inviala`" e la mando davvero.")
    }

    try {
        $msg = New-Object System.Net.Mail.MailMessage
        $from = New-Object System.Net.Mail.MailAddress($c.mittente, $(if ($c.nome) { $c.nome } else { $c.mittente }))
        $msg.From = $from
        foreach ($dest in @($A -split '[;,]')) {
            $d = $dest.Trim()
            if ($d) { $msg.To.Add($d) }
        }
        if ($Cc) { foreach ($x in @($Cc -split '[;,]')) { $t = $x.Trim(); if ($t) { $msg.CC.Add($t) } } }
        $msg.Subject = $Oggetto
        $msg.Body = $corpoFinale
        $msg.IsBodyHtml = $false
        $msg.BodyEncoding = [System.Text.Encoding]::UTF8
        $msg.SubjectEncoding = [System.Text.Encoding]::UTF8
        foreach ($al in @($Allegati)) {
            $p = [string]$al
            if ($p -and (Test-Path -LiteralPath $p)) {
                $msg.Attachments.Add((New-Object System.Net.Mail.Attachment($p)))
            }
        }

        $smtp = New-Object System.Net.Mail.SmtpClient($c.smtp, [int]$c.porta)
        $smtp.EnableSsl = [bool]$c.ssl
        $smtp.UseDefaultCredentials = $false
        $smtp.Credentials = New-Object System.Net.NetworkCredential($c.mittente, $c.password)
        $smtp.Timeout = 30000
        $smtp.Send($msg)
        $msg.Dispose()

        [void](Add-ZapLedgerEvento $sync 'email' ("Email INVIATA a $A - oggetto: $Oggetto (bozza: $bozza)") 'email' $false)
        return "Email inviata a $A (oggetto: $Oggetto). Copia della bozza: $bozza"
    } catch {
        $e = $_.Exception.Message
        $aiuto = ''
        if ($e -match '5\.7\.8|Authentication') { $aiuto = "`nSuggerimento: Gmail richiede una PASSWORD PER LE APP (16 caratteri), non la password dell'account. Attiva la verifica in due passaggi e creala su https://myaccount.google.com/apppasswords" }
        [void](Add-ZapLedgerEvento $sync 'email' ("Invio email a $A FALLITO: $e") 'email' $false)
        return ("Invio NON riuscito: $e$aiuto`nLa bozza resta qui: $bozza")
    }
}

function Set-EmailConfig {
    param($sync, [string]$Mittente = '', [string]$Password = '', [string]$Nome = '', [string]$Firma = '', $SoloBozze = $null)
    try {
        if (-not $sync.Config.ContainsKey('gmail')) { $sync.Config['gmail'] = @{} }
        $g = $sync.Config['gmail']
        if ($Mittente) { $g['mittente'] = $Mittente }
        if ($Password) { $g['password'] = $Password }
        if ($Nome) { $g['nome'] = $Nome }
        if ($Firma) { $g['firma'] = $Firma }
        if ($null -ne $SoloBozze) { $g['solo_bozze'] = [bool]$SoloBozze }
        return (Get-EmailStato $sync)
    } catch { return ('Configurazione posta non aggiornata: ' + $_.Exception.Message) }
}
