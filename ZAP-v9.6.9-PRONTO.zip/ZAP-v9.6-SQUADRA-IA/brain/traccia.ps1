﻿# traccia.ps1 -- "GUARDA QUELLO CHE FACCIO E PRENDI NOTA" (modalita' traccia, v9).
#
# Quando e' attiva, ZAP campiona a intervalli regolari:
#   - la finestra in primo piano (titolo + programma),
#   - quindi cosa stai facendo davvero (Word, Chrome, gestionale, WhatsApp...).
# Tutto finisce in Ezappero\tracce\traccia-AAAA-MM-GG.jsonl, con i secondi accumulati per
# programma: alla sera ZAP sa dire "hai passato 2h su Word e 40m su Chrome".
#
# Privacy e controllo (importante, e detto chiaramente):
#   - e' SPENTA di default: si accende solo quando lo chiedi (pannello MEMORIA o tool traccia);
#   - registra titoli di finestra, NON tasti premuti e NON contenuti di pagine;
#   - gli scatti dello schermo sono opzionali (traccia.scatti = $true) e restano in locale;
#   - /traccia stop la spegne subito e non resta niente acceso.
#
# Non c'e' nessun keylogger: registrare i tasti sarebbe illegale e inutile.

function Get-TracciaConfig {
    param($sync)
    $d = @{
        attiva      = $false
        intervallo  = 15      # secondi tra due campioni
        scatti      = $false  # salva anche uno screenshot ogni N campioni
        ogni_scatti = 120     # un'immagine ogni 120 campioni (~30 minuti con intervallo 15s)
        cartella    = ''
    }
    try {
        $c = $sync.Config.traccia
        if ($c) {
            try { if ($null -ne $c.attiva) { $d.attiva = [bool]$c.attiva } } catch { }
            try { if ($c.intervallo) { $d.intervallo = [int]$c.intervallo } } catch { }
            try { if ($null -ne $c.scatti) { $d.scatti = [bool]$c.scatti } } catch { }
            try { if ($c.ogni_scatti) { $d.ogni_scatti = [int]$c.ogni_scatti } } catch { }
            try { if ($c.cartella) { $d.cartella = [string]$c.cartella } } catch { }
        }
    } catch { }
    if ($d.intervallo -lt 5) { $d.intervallo = 5 }
    return $d
}

function Get-TracciaDir {
    param($sync)
    $c = Get-TracciaConfig $sync
    if ($c.cartella) {
        if ([System.IO.Path]::IsPathRooted([string]$c.cartella)) { return [string]$c.cartella }
        return (Join-Path (Get-EzapperoDir $sync) [string]$c.cartella)
    }
    return (Join-Path (Get-EzapperoDir $sync) 'tracce')
}

function Get-TracciaStatoPath { param($sync) return (Join-Path (Get-EzapperoDir $sync) 'traccia.stato.json') }

function Get-TracciaStato {
    param($sync)
    $p = Get-TracciaStatoPath $sync
    $s = @{ attiva = (Get-TracciaConfig $sync).attiva; dal = ''; campioni = 0 }
    if (Test-Path -LiteralPath $p) {
        try {
            $j = Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($j) {
                if ($null -ne $j.attiva) { $s.attiva = [bool]$j.attiva }
                if ($j.dal) { $s.dal = [string]$j.dal }
                if ($null -ne $j.campioni) { $s.campioni = [int]$j.campioni }
            }
        } catch { }
    }
    return $s
}

function Save-TracciaStato {
    param($sync, [bool]$Attiva, [int]$Campioni = -1, [string]$Dal = '')
    $p = Get-TracciaStatoPath $sync
    try {
        $b = Get-TracciaStato $sync
        if ($Campioni -lt 0) { $Campioni = [int]$b.campioni }
        if (-not $Dal) { if ($Attiva) { if ($b.dal) { $Dal = [string]$b.dal } else { $Dal = (Get-Date -Format 'o') } } }
        $o = @{ attiva = $Attiva; dal = $Dal; campioni = $Campioni }
        $enc = New-Object System.Text.UTF8Encoding($false)
        Set-ZapFileProtetto $p $false
        [System.IO.File]::WriteAllText($p, (ConvertTo-Json -InputObject $o -Compress), $enc)
        Set-ZapFileProtetto $p $true
    } catch { }
    try { if ($sync.Config.ContainsKey('traccia')) { $sync.Config['traccia']['attiva'] = $Attiva } } catch { }
}

function Start-Traccia {
    param($sync)
    [void](Initialize-Ezappero $sync)
    Save-TracciaStato $sync $true 0 ''
    $d = Get-TracciaDir $sync
    if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    [void](Add-ZapLedgerEvento $sync 'sistema' 'Modalita traccia ATTIVATA: registro cosa faccio sul PC (finestre e programmi).' 'traccia' $false)
    return "Traccia attiva. Registro ogni $((Get-TracciaConfig $sync).intervallo) secondi la finestra in primo piano in: $d"
}

function Stop-Traccia {
    param($sync)
    Save-TracciaStato $sync $false
    [void](Add-ZapLedgerEvento $sync 'sistema' 'Modalita traccia DISATTIVATA.' 'traccia' $false)
    return 'Traccia spenta.'
}

function Get-TracciaFinestraAttiva {
    # Titolo della finestra in primo piano + programma che la possiede.
    $res = @{ titolo = ''; processo = '' }
    try {
        if (-not ('ZapTraccia.Win' -as [type])) {
            Add-Type -ErrorAction SilentlyContinue -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
namespace ZapTraccia {
    public class Win {
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint id);
    }
}
'@
        }
        $h = [ZapTraccia.Win]::GetForegroundWindow()
        if ($h -ne [IntPtr]::Zero) {
            $sb = New-Object System.Text.StringBuilder 512
            [void][ZapTraccia.Win]::GetWindowText($h, $sb, 512)
            $res.titolo = $sb.ToString()
            $pid2 = [uint32]0
            [void][ZapTraccia.Win]::GetWindowThreadProcessId($h, [ref]$pid2)
            if ($pid2 -gt 0) {
                try { $res.processo = (Get-Process -Id ([int]$pid2) -ErrorAction SilentlyContinue).ProcessName } catch { }
            }
        }
    } catch { }
    return $res
}

function Write-TracciaCampione {
    # Un campione. La chiama un timer dell'interfaccia (nessun thread extra, nessun rischio).
    param($sync)
    $st = Get-TracciaStato $sync
    if (-not $st.attiva) { return }
    $c = Get-TracciaConfig $sync
    $w = Get-TracciaFinestraAttiva
    if (-not $w.titolo -and -not $w.processo) { return }

    $dir = Get-TracciaDir $sync
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $file = Join-Path $dir ('traccia-' + (Get-Date -Format 'yyyy-MM-dd') + '.jsonl')

    # se l'ultimo campione e' identico, aggiorno solo i secondi (file compatto e leggibile)
    $ultimo = $null
    try {
        if (Test-Path -LiteralPath $file) {
            $righe = [System.IO.File]::ReadAllLines($file)
            if ($righe.Count -gt 0) { $ultimo = $righe[$righe.Count - 1] | ConvertFrom-Json }
        }
    } catch { }

    $sec = [int]$c.intervallo
    if ($ultimo -and ([string]$ultimo.processo -eq [string]$w.processo) -and ([string]$ultimo.titolo -eq [string]$w.titolo)) {
        $nuovo = [ordered]@{
            t        = [string]$ultimo.t
            fine     = (Get-Date -Format 'o')
            processo = [string]$w.processo
            titolo   = [string]$w.titolo
            secondi  = ([int]$ultimo.secondi + $sec)
        }
        try {
            $tutte = [System.IO.File]::ReadAllLines($file)
            $tutte[$tutte.Count - 1] = (ConvertTo-Json -InputObject $nuovo -Compress)
            $enc = New-Object System.Text.UTF8Encoding($false)
            Set-ZapFileProtetto $file $false
            [System.IO.File]::WriteAllLines($file, $tutte, $enc)
            Set-ZapFileProtetto $file $true
        } catch { }
    } else {
        $nuovo = [ordered]@{
            t        = (Get-Date -Format 'o')
            fine     = (Get-Date -Format 'o')
            processo = [string]$w.processo
            titolo   = [string]$w.titolo
            secondi  = $sec
        }
        [void](Write-ZapUtf8Append $file ((ConvertTo-Json -InputObject $nuovo -Compress)))
    }

    # COPIA ESTERNA IMMEDIATA: ogni campione va anche fuori dal progetto, cosi' cancellare
    # la cartella ZAP non porta via la traccia di cosa hai fatto.
    try {
        $mir = Get-EzapperoMirrorDir $sync
        if ($mir) {
            $mirTracce = Join-Path $mir 'tracce'
            if (-not (Test-Path -LiteralPath $mirTracce)) { New-Item -ItemType Directory -Path $mirTracce -Force | Out-Null }
            $mirFile = Join-Path $mirTracce (Split-Path -Leaf $file)
            [void](Write-ZapUtf8Append $mirFile ((ConvertTo-Json -InputObject $nuovo -Compress)))
        }
    } catch { }

    $camp = [int]$st.campioni + 1
    Save-TracciaStato $sync $true $camp ''

    # scatti opzionali (solo se l'utente li ha chiesti)
    if ($c.scatti -and $c.ogni_scatti -gt 0 -and ($camp % [int]$c.ogni_scatti) -eq 0) {
        try { Save-TracciaScatto $sync $dir } catch { }
    }
}

function Save-TracciaScatto {
    param($sync, [string]$Dir)
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        $b = [System.Windows.Forms.SystemInformation]::VirtualScreen
        $bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($b.Left, $b.Top, 0, 0, $bmp.Size)
        $dirScatti = Join-Path $Dir 'scatti'
        if (-not (Test-Path -LiteralPath $dirScatti)) { New-Item -ItemType Directory -Path $dirScatti -Force | Out-Null }
        $p = Join-Path $dirScatti ('scatto-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.png')
        $bmp.Save($p, [System.Drawing.Imaging.ImageFormat]::Png)
        $g.Dispose()
        $bmp.Dispose()
        return $p
    } catch { return '' }
}

function Read-Traccia {
    param($sync, [string]$Giorno = '')
    if (-not $Giorno) { $Giorno = (Get-Date -Format 'yyyy-MM-dd') }
    $file = Join-Path (Get-TracciaDir $sync) ('traccia-' + $Giorno + '.jsonl')
    $out = New-Object System.Collections.ArrayList
    if (-not (Test-Path -LiteralPath $file)) { return @() }
    try {
        foreach ($r in [System.IO.File]::ReadAllLines($file)) {
            if (-not $r -or -not $r.Trim()) { continue }
            try { [void]$out.Add(($r | ConvertFrom-Json)) } catch { }
        }
    } catch { }
    return @($out.ToArray())
}

function Get-TracciaRiassunto {
    # "Cosa ho fatto oggi": totale per programma, in ordine di tempo.
    param($sync, [string]$Giorno = '')
    if (-not $Giorno) { $Giorno = (Get-Date -Format 'yyyy-MM-dd') }
    $camp = @(Read-Traccia $sync $Giorno)
    if ($camp.Count -eq 0) { return "Nessuna traccia per il $Giorno (la modalita traccia era spenta)." }

    $per = @{}
    foreach ($c in $camp) {
        $k = [string]$c.processo
        if (-not $k) { $k = '(sconosciuto)' }
        if (-not $per.ContainsKey($k)) { $per[$k] = @{ sec = 0; titoli = @() } }
        $per[$k].sec = [int]$per[$k].sec + [int]$c.secondi
        $t = [string]$c.titolo
        if ($t -and ($per[$k].titoli.Count -lt 6) -and ($per[$k].titoli -notcontains $t)) {
            $per[$k].titoli += $t
        }
    }

    $out = New-Object System.Collections.ArrayList
    [void]$out.Add("COSA HAI FATTO IL $Giorno (dalla modalita traccia)")
    $ordinati = @($per.Keys | Sort-Object -Property @{ Expression = { $per[$_].sec }; Descending = $true } )
    foreach ($k in $ordinati) {
        $sec = [int]$per[$k].sec
        $h = [int][Math]::Floor($sec / 3600)
        $m = [int][Math]::Floor(($sec % 3600) / 60)
        $durata = ''
        if ($h -gt 0) { $durata = "${h}h " }
        $durata = $durata + "${m}m"
        [void]$out.Add("- $k : $durata")
        foreach ($t in @($per[$k].titoli | Select-Object -First 3)) {
            $tt = $t
            if ($tt.Length -gt 90) { $tt = $tt.Substring(0, 90) + '...' }
            [void]$out.Add("    - $tt")
        }
    }
    return ($out -join "`r`n")
}

function Set-TracciaConfig {
    param($sync, [string]$Campo, $Valore)
    try {
        if (-not $sync.Config.ContainsKey('traccia')) { $sync.Config['traccia'] = @{} }
        $sync.Config['traccia'][$Campo] = $Valore
        return "Traccia: $Campo = $Valore"
    } catch { return 'Configurazione traccia non aggiornata.' }
}
