﻿# llm.ps1 - Client per il "cervello" (registro multi-servizio in brain\provider_ai.ps1).

# Se provider_ai.ps1 non e' ancora caricato (es. uso standalone), lo carica adesso.
if (-not (Get-Command Get-ProviderRegistry -ErrorAction SilentlyContinue)) {
    $__prov = Join-Path (Split-Path -Parent $PSCommandPath) 'provider_ai.ps1'
    if (Test-Path $__prov) { . $__prov }
}

# v9.6.5 -- Set-ModelloOk vive in brain\tools.ps1. Se quel file non si carica (o un suo
# modulo interno fallisce), la funzione sparisce e Invoke-GeminiRaw interpreta il -Errore
# come "modello fallito": Google risponde 200 ma ZAP scarta la risposta e alla fine dice
# "Nessun modello Gemini ha risposto". Qui la rendiamo sempre disponibile.
if (-not (Get-Command Set-ModelloOk -ErrorAction SilentlyContinue)) {
    function Set-ModelloOk {
        param($sync, [string]$Modello)
        if (-not $Modello) { return }
        try { $sync.ModelloOk = $Modello } catch { }
        try {
            $p = Join-Path $sync.Base 'memory\modello_scelto.txt'
            $d = Split-Path -Parent $p
            if (-not (Test-Path $d)) { [void][System.IO.Directory]::CreateDirectory($d) }
            [System.IO.File]::WriteAllText($p, [string]$Modello, (New-Object System.Text.UTF8Encoding($false)))
        } catch { }
    }
}

function Invoke-Chat {
    param(
        $sync,
        [array]$Messages,
        [array]$Tools
    )

    # v9.6 -- UN SERVIZIO ALLA VOLTA.
    # 1) Risponde SOLO il servizio scelto in INTELLIGENZE AI (o, in AUTOMATICO, il
    #    primario: Gemini, poi il secondario: DeepSeek).
    # 2) Il ripiego scatta solo su errore vero e solo verso il secondario.
    # 3) La risposta di ripiego lo dichiara in testa: sai sempre chi ha parlato.
    $taskType = 'veloce'
    try { $taskType = Get-AiTaskType (Get-UltimoTestoUtente $Messages) } catch { }

    $prov = $null
    $percheNo = ''
    try { $prov = Resolve-AiProvider -sync $sync -TaskType $taskType }
    catch { $prov = $null; $percheNo = $_.Exception.Message }
    try { $sync.AiActive = $prov } catch { }
    if (-not $prov) {
        if ($percheNo) { throw $percheNo }
        throw 'Nessun servizio IA pronto: apri INTELLIGENZE AI e inserisci una chiave + un modello.'
    }

    $nomePrimario = [string]$prov.nome
    try {
        return (Invoke-ChatSuProvider $sync $Messages $Tools $prov $taskType)
    } catch {
        $errorePrimario = $_.Exception.Message
        # v9.6.2 -- NESSUNO PARLA AL POSTO DI CHI HAI SCELTO.
        # Se in INTELLIGENZE AI c'e' un servizio preciso (non AUTOMATICO), il ripiego
        # non esiste: si segnala l'errore e si resta su quel servizio.
        $automatico = $true
        try {
            $m = [string]$sync.Config.modalita_ai
            if ($m -and $m.Trim().ToLower() -ne 'auto') { $automatico = $false }
        } catch { }
        if (-not $automatico) {
            throw ('Il servizio scelto (' + $nomePrimario + ') non ha risposto: ' + $errorePrimario + ' Nessun ripiego: la scelta e'' tua. Riprova, oppure correggi chiave/modello in INTELLIGENZE AI, oppure metti AUTOMATICO.')
        }
        $alt = $null
        try { $alt = Get-ProviderAlternativo $sync ([string]$prov.id) } catch { $alt = $null }
        if (-not $alt) { throw }
        $nomeAlt = [string]$alt.nome
        try { $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = ('RIPIEGO SU ' + $nomeAlt) }) } catch { }
        $msg = Invoke-ChatSuProvider $sync $Messages $Tools $alt $taskType
        try { $sync.AiActive = $alt } catch { }
        return (Add-EtichettaRipiego $msg $nomePrimario $nomeAlt $errorePrimario $sync)
    }
}

function Invoke-ChatSuProvider {
    # Smista verso il client giusto. Ogni client parla la sua lingua, nessuno
    # conosce gli altri: cosi' non si formano catene di ripiego nascoste.
    param($sync, [array]$Messages, [array]$Tools, $prov, [string]$taskType = 'veloce')
    $tipo = ''
    try { $tipo = [string]$prov.tipo } catch { }
    $id = ''
    try { $id = [string]$prov.id } catch { }
    if ($tipo -eq 'gemini')    { return (Invoke-ChatGemini $sync $Messages $Tools) }
    if ($tipo -eq 'anthropic') { return (Invoke-ChatAnthropic $sync $Messages $Tools $taskType) }
    if ($id -eq 'perplexity')  { return (Invoke-ChatPerplexity $sync $Messages $prov $Tools) }
    return (Invoke-OpenAiCompat $sync $Messages $Tools $prov)
}

function Add-EtichettaRipiego {
    # Mette in testa alla risposta chi l'ha data davvero. Se la configurazione
    # disattiva l'etichetta (motore.etichetta_ripiego = false) non tocca nulla.
    param($msg, [string]$Da, [string]$A, [string]$Errore, $sync)
    if (-not $msg) { return $msg }
    $etichetta = $true
    try { if ($sync.Config.motore.etichetta_ripiego -eq $false) { $etichetta = $false } } catch { }
    if (-not $etichetta) { return $msg }
    $breve = [string]$Errore
    if ($breve.Length -gt 160) { $breve = $breve.Substring(0, 160) + '...' }
    $testo = ''
    try { $testo = ConvertTo-PlainString $msg.content } catch { $testo = [string]$msg.content }
    $nota = '[ripiego: ' + $Da + ' non ha risposto (' + $breve + '). Questa risposta e'' di ' + $A + '.]'
    try { $msg.content = ($nota + [Environment]::NewLine + [Environment]::NewLine + $testo) } catch { }
    return $msg
}

function Invoke-OpenAiCompat {
    # Client per i servizi con API "compatibile OpenAI" (DeepSeek, Perplexity
    # quando serve, Qwen, Anthropic-compat, ecc.).
    param($sync, [array]$Messages, [array]$Tools, $prov)
    $uri   = [string]$prov.endpoint
    $model = [string]$prov.modello
    $key   = [string]$prov.chiave
    $nome  = [string]$prov.nome
    if (-not $uri) { throw ('Servizio senza endpoint: ' + $nome) }
    if (Get-Command Test-MotoreLocale -ErrorAction SilentlyContinue) {
        if (Test-MotoreLocale $uri) { throw ('Motore locale disattivato: ZAP non contatta ' + $uri + '. Scegli un servizio cloud in INTELLIGENZE AI.') }
    }
    if (-not $model) { throw ('Servizio senza modello: ' + $nome) }

    $body = @{
        model       = $model
        messages    = $Messages
        temperature = 0.4
        max_tokens  = 2048
    }
    if ($Tools -and $Tools.Count -gt 0) {
        $body.tools       = $Tools
        $body.tool_choice = 'auto'
    }

    $json = ConvertTo-JsonText $body

    $headers = @{}
    if ($key) { $headers.Authorization = "Bearer $key" }
    # v8.7: alcuni servizi dietro Cloudflare rispondono 403 agli User-Agent automatici.
    $headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

    try {
        $resp = Invoke-RestMethod `
            -Uri $uri `
            -Method Post `
            -Headers $headers `
            -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) `
            -ContentType 'application/json; charset=utf-8' `
            -TimeoutSec 90
    } catch {
        $msgErrore = $_.Exception.Message
        if ($_.Exception.Response) {
            try {
                $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                $detail = $sr.ReadToEnd()
                $sr.Close()
                if ($detail) { $msgErrore = $msgErrore + ' - ' + $detail }
            } catch { }
        }
        throw ("Errore API ($nome, modello '$model'): $msgErrore.")
    }

    if (-not $resp.choices -or $resp.choices.Count -eq 0) {
        throw "Risposta API vuota. Modello: $model."
    }

    return (ConvertTo-MessaggioPulito $resp.choices[0].message)
}

function ConvertTo-MessaggioPulito {
    # v9: i modelli "reasoning" (DeepSeek V4, o1-like...) restituiscono campi extra
    # (reasoning_content) che NON vanno rimandati indietro nella richiesta successiva.
    # Qui si tiene solo cio' che serve all'agente: role, content, tool_calls.
    param($Messaggio)
    if (-not $Messaggio) { return $Messaggio }
    $d = @{}
    try {
        foreach ($p in @($Messaggio.PSObject.Properties)) { $d[[string]$p.Name] = $p.Value }
    } catch { return $Messaggio }
    foreach ($k in @('reasoning_content', 'reasoning', 'refusal', 'annotations', 'audio', 'logprobs')) {
        if ($d.ContainsKey($k)) { $d.Remove($k) }
    }
    if (-not $d.ContainsKey('content') -or $null -eq $d['content']) { $d['content'] = '' }
    return $d
}

function Invoke-ChatAnthropic {
    # v9.4 -- Claude ORA HA LE MANI.
    # Prima questa funzione non passava gli strumenti: Claude rispondeva a parole
    # ("Fatto!") senza poter fare nulla. Era UNA delle cause del "Fatto" a vuoto.
    # Ora usa il formato Anthropic /v1/messages con i blocchi tool_use / tool_result.
    param($sync, [array]$Messages, [array]$Tools, [string]$TaskType = 'veloce')

    $prov = $null
    try { $prov = $sync.AiActive } catch { }
    if (-not $prov -or ([string]$prov.tipo -ne 'anthropic')) { $prov = Get-ProviderConfig $sync 'anthropic' }
    $key = [string]$prov.chiave
    if (-not $key) { throw 'Manca la chiave di Anthropic (Claude). Inseriscila nel pannello INTELLIGENZE AI.' }

    $system = ''
    $blocchi = New-Object System.Collections.ArrayList

    foreach ($m in $Messages) {
        $role = [string]$m.role
        if ($role -eq 'system') { $system = ConvertTo-PlainString $m.content; continue }

        $corpo = New-Object System.Collections.ArrayList

        if ($role -eq 'tool') {
            $contenuto = ConvertTo-PlainString $m.content
            if (-not $contenuto) { $contenuto = '(nessun output)' }
            [void]$corpo.Add(@{ type = 'tool_result'; tool_use_id = [string]$m.tool_call_id; content = $contenuto })
        }
        elseif ($role -eq 'assistant' -or $role -eq 'model') {
            $txt = ConvertTo-PlainString $m.content
            if ($txt) { [void]$corpo.Add(@{ type = 'text'; text = $txt }) }
            foreach ($tc in @($m.tool_calls)) {
                if (-not $tc) { continue }
                $nome = [string]$tc.function.name
                if (-not $nome) { continue }
                $arg = $tc.function.arguments
                $inp = @{}
                if ($arg -is [string]) {
                    if ($arg.Trim()) { try { $inp = $arg | ConvertFrom-Json } catch { $inp = @{} } }
                } elseif ($null -ne $arg) { $inp = $arg }
                [void]$corpo.Add(@{ type = 'tool_use'; id = [string]$tc.id; name = $nome; input = $inp })
            }
        }
        else {
            $txt = ConvertTo-PlainString $m.content
            if ($txt) { [void]$corpo.Add(@{ type = 'text'; text = $txt }) }
        }

        if ($corpo.Count -eq 0) { continue }

        $ruoloAnth = 'user'
        if ($role -eq 'assistant' -or $role -eq 'model') { $ruoloAnth = 'assistant' }

        # Anthropic vuole ruoli alternati: accodo i blocchi se il ruolo si ripete.
        if ($blocchi.Count -gt 0 -and [string]$blocchi[$blocchi.Count - 1].role -eq $ruoloAnth) {
            foreach ($b in $corpo) { [void]$blocchi[$blocchi.Count - 1].content.Add($b) }
        } else {
            [void]$blocchi.Add(@{ role = $ruoloAnth; content = $corpo })
        }
    }

    if ($blocchi.Count -eq 0) { [void]$blocchi.Add(@{ role = 'user'; content = @(@{ type = 'text'; text = '(vuoto)' }) }) }
    # il primo messaggio deve essere dell'utente
    if ([string]$blocchi[0].role -ne 'user') { [void]$blocchi.Insert(0, @{ role = 'user'; content = @(@{ type = 'text'; text = '(continua)' }) }) }

    $msgs = @()
    foreach ($b in $blocchi) { $msgs += @{ role = $b.role; content = @($b.content.ToArray()) } }

    # --- strumenti: da formato OpenAI a formato Anthropic ---
    $atools = @()
    foreach ($t in @($Tools)) {
        if (-not $t) { continue }
        $f = $t.function
        if (-not $f) { continue }
        if (-not [string]$f.name) { continue }
        $schema = $f.parameters
        if (-not $schema) { $schema = @{ type = 'object'; properties = @{} } }
        $atools += @{ name = [string]$f.name; description = [string]$f.description; input_schema = $schema }
    }

    $modello = [string]$prov.modello
    try { $m2 = Get-AnthropicModello $sync $TaskType $Messages; if ($m2) { $modello = $m2 } } catch { }
    $body = @{ model = $modello; max_tokens = 4096; messages = $msgs }
    if ($system.Trim()) { $body.system = $system }
    if ($atools.Count -gt 0) {
        $body.tools = $atools
        $body.tool_choice = @{ type = 'auto' }
    }

    $headers = @{ 'x-api-key' = $key; 'anthropic-version' = '2023-06-01' }
    $json = ConvertTo-JsonText $body
    try {
        $resp = Invoke-RestMethod -Uri ([string]$prov.endpoint) -Method Post -Headers $headers `
            -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) `
            -ContentType 'application/json; charset=utf-8' -TimeoutSec 120
    }
    catch {
        $msg = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $msg = $msg + ' | ' + $_.ErrorDetails.Message }
        throw ("Errore Anthropic (modello '" + $modello + "'): $msg")
    }

    $testi = @()
    $chiamate = @()
    foreach ($blk in @($resp.content)) {
        if ($blk.type -eq 'text' -and $blk.text) { $testi += [string]$blk.text }
        elseif ($blk.type -eq 'tool_use') {
            $argJson = '{}'
            try {
                if ($null -ne $blk.input) { $argJson = ConvertTo-JsonText $blk.input }
            } catch { }
            if (-not $argJson -or $argJson -eq '""') { $argJson = '{}' }
            $chiamate += @{
                id       = [string]$blk.id
                type     = 'function'
                function = @{ name = [string]$blk.name; arguments = $argJson }
            }
        }
    }
    return @{ role = 'assistant'; content = ($testi -join "`n"); tool_calls = $chiamate }
}

function ConvertTo-PlainString {
    # Alcuni modelli restituiscono content come array di parti: normalizza a stringa
    param($Content)
    if ($null -eq $Content) { return '' }
    if ($Content -is [string]) { return $Content }
    try {
        $parts = @()
        foreach ($p in $Content) {
            if ($p.text) { $parts += [string]$p.text }
            elseif ($p -is [string]) { $parts += $p }
        }
        return ($parts -join "`n")
    } catch {
        return [string]$Content
    }
}


# ---------------------------------------------------------------------------
# Cervello cloud: Google Gemini (nessun modello locale -> RAM libera)
# ---------------------------------------------------------------------------

function Get-GeminiModelliRapidi {
    # v6.6: per la chat NORMALE si usano al massimo DUE modelli (quello scelto + un ripiego).
    # Non si gira piu' su tutta la catena ad ogni messaggio (era la causa della lentezza/errore).
    param($sync)
    $out = @()
    $ok = ''
    try { if ($sync.ModelloOk) { $ok = [string]$sync.ModelloOk } } catch { }
    if (-not $ok) { try { if ($sync.Config.gemini_model_scelto) { $ok = [string]$sync.Config.gemini_model_scelto } } catch { } }
    if (-not $ok) { try { $ok = [string]$sync.Config.modello } catch { } }
    if ($ok) { $out += $ok }
    foreach ($d in @('gemini-3.1-flash-lite', 'gemini-3.6-flash')) {
        if ($out -notcontains $d) { $out += $d }
    }
    return @($out | Select-Object -First 2)
}

function Get-GeminiModelChain {
    param($sync)
    $chain = @()
    # v6.5 VELOCITA': il modello che ha funzionato l'ultima volta si prova per PRIMO,
    # cosi' non si perde tempo ogni volta a ritentare i modelli a quota esaurita.
    $ok = ''
    try { if ($sync.ModelloOk) { $ok = [string]$sync.ModelloOk } } catch { }
    if ($ok -and ($chain -notcontains $ok)) { $chain += $ok }
    $m = ''
    try { if ($sync.AiActive -and ([string]$sync.AiActive.tipo -eq 'gemini')) { $m = [string]$sync.AiActive.modello } } catch { }
    if (-not $m) { $m = [string]$sync.Config.modello }
    if ($m -and $m -like 'gemini*' -and ($chain -notcontains $m)) { $chain += $m }
    if ($sync.Config.gemini_model_fallbacks) {
        foreach ($f in @($sync.Config.gemini_model_fallbacks)) {
            if ([string]$f -and ($chain -notcontains [string]$f)) { $chain += [string]$f }
        }
    }
    # Rete di sicurezza: molti modelli, cosi' se uno e' occupato (503) o a quota (429)
    # si passa subito al successivo. Solo modelli che esistono davvero su questa API.
    foreach ($d in @('gemini-3.1-flash-lite', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.7-flash',
                     'gemini-3.8-flash', 'gemini-flash-lite-latest', 'gemini-flash-latest',
                     'gemini-3-flash-preview', 'gemini-pro-latest')) {
        if ($chain -notcontains $d) { $chain += $d }
    }
    # v9.6.3 -- massimo 5 tentativi: prima erano 13 con 120s l'uno, cioe' fino a
    # 26 minuti di attesa se Google rispondeva male. Meglio un errore chiaro subito.
    return @($chain | Select-Object -First 5)
}

function Get-PropPairs {
    param($Obj)
    if ($null -eq $Obj) { return @() }
    if ($Obj -is [System.Collections.IDictionary]) {
        return @($Obj.GetEnumerator() | ForEach-Object { @{ Name = [string]$_.Key; Value = $_.Value } })
    }
    return @($Obj.PSObject.Properties | ForEach-Object { @{ Name = $_.Name; Value = $_.Value } })
}

function ConvertTo-GeminiSchema {
    param($Schema)
    if ($null -eq $Schema) { return $null }
    $out = @{}
    $t = [string]$Schema.type
    if ($t) { $out.type = $t.ToUpper() }
    if ($Schema.description) { $out.description = [string]$Schema.description }
    if ($Schema.enum) { $out.enum = @($Schema.enum) }
    if ($Schema.required) { $out.required = @($Schema.required) }
    if ($Schema.items) { $out.items = (ConvertTo-GeminiSchema $Schema.items) }
    if ($Schema.properties) {
        $props = @{}
        foreach ($p in (Get-PropPairs $Schema.properties)) { $props[$p.Name] = (ConvertTo-GeminiSchema $p.Value) }
        $out.properties = $props
    }
    return $out
}

function ConvertTo-GeminiTools {
    param([array]$Tools)
    if (-not $Tools -or $Tools.Count -eq 0) { return $null }
    $decls = New-Object System.Collections.ArrayList
    foreach ($t in $Tools) {
        $f = $t.function
        if (-not $f) { $f = $t }
        if (-not $f.name) { continue }
        $decl = @{ name = [string]$f.name; description = [string]$f.description }
        if ($f.parameters) { $decl.parameters = (ConvertTo-GeminiSchema $f.parameters) }
        [void]$decls.Add($decl)
    }
    if ($decls.Count -eq 0) { return $null }
    return @( @{ functionDeclarations = @($decls.ToArray()) } )
}

function ConvertTo-GeminiContents {
    param([array]$Messages)
    $contents = New-Object System.Collections.ArrayList
    $pending  = New-Object System.Collections.ArrayList

    foreach ($m in $Messages) {
        $role = [string]$m.role
        if ($role -eq 'system') { continue }

        if ($role -eq 'tool') {
            $nm = [string]$m.name
            if (-not $nm) { $nm = 'tool' }
            [void]$pending.Add(@{ functionResponse = @{ name = $nm; response = @{ result = (ConvertTo-PlainString $m.content) } } })
            continue
        }

        if ($pending.Count -gt 0) {
            [void]$contents.Add(@{ role = 'user'; parts = @($pending.ToArray()) })
            $pending.Clear()
        }

        if ($role -eq 'user') {
            $txt = ConvertTo-PlainString $m.content
            if (-not $txt.Trim()) { $txt = '(vuoto)' }
            [void]$contents.Add(@{ role = 'user'; parts = @( @{ text = $txt } ) })
        }
        elseif ($role -eq 'assistant' -or $role -eq 'model') {
            $parts = New-Object System.Collections.ArrayList
            $txt = ConvertTo-PlainString $m.content
            if ($txt -and $txt.Trim()) { [void]$parts.Add(@{ text = $txt }) }
            if ($m.tool_calls) {
                foreach ($tc in @($m.tool_calls)) {
                    $fn = $tc.function
                    $argsObj = @{}
                    try {
                        if ($fn.arguments -is [string]) { $argsObj = ($fn.arguments | ConvertFrom-Json) }
                        elseif ($fn.arguments) { $argsObj = $fn.arguments }
                    } catch { $argsObj = @{} }
                    $callPart = @{ functionCall = @{ name = [string]$fn.name; args = $argsObj } }
                    if ($tc.thought_signature) { $callPart['thoughtSignature'] = [string]$tc.thought_signature }
                    [void]$parts.Add($callPart)
                }
            }
            if ($parts.Count -eq 0) { [void]$parts.Add(@{ text = '(nessun testo)' }) }
            [void]$contents.Add(@{ role = 'model'; parts = @($parts.ToArray()) })
        }
    }

    if ($pending.Count -gt 0) {
        [void]$contents.Add(@{ role = 'user'; parts = @($pending.ToArray()) })
        $pending.Clear()
    }
    return @($contents.ToArray())
}

function ConvertFrom-GeminiReply {
    param($Resp)
    if (-not $Resp.candidates -or $Resp.candidates.Count -eq 0) {
        $why = ''
        if ($Resp.promptFeedback -and $Resp.promptFeedback.blockReason) { $why = ' bloccato: ' + $Resp.promptFeedback.blockReason }
        throw ("Nessuna risposta da Gemini.$why")
    }
    $texts = @()
    $calls = @()
    $i = 0
    foreach ($part in @($Resp.candidates[0].content.parts)) {
        if ($part.text) { $texts += [string]$part.text }
        elseif ($part.functionCall) {
            $i++
            $argsJson = '{}'
            if ($part.functionCall.args) { $argsJson = (ConvertTo-JsonText $part.functionCall.args) }
            $cid = [string]$part.functionCall.id
            if (-not $cid) { $cid = "gemini_$i" }
            $calls += @{
                id                = $cid
                type              = 'function'
                thought_signature = [string]$part.thoughtSignature
                function          = @{ name = [string]$part.functionCall.name; arguments = $argsJson }
            }
        }
    }
    return @{ role = 'assistant'; content = ($texts -join "`n"); tool_calls = $calls }
}

function ConvertFrom-GeminiSseChunk {
    # Interpreta UNA riga SSE di Gemini. Restituisce il testo del pezzo e le
    # eventuali parti speciali (functionCall / immagine). Funzione pura: testabile.
    param([string]$Line)
    $out = @{ Testo = ''; Parti = @() }
    if (-not $Line) { return $out }
    if (-not $Line.StartsWith('data:')) { return $out }
    $payload = $Line.Substring(5).Trim()
    if (-not $payload -or $payload -eq '[DONE]') { return $out }
    $chunk = $null
    try { $chunk = $payload | ConvertFrom-Json } catch { return $out }
    $parts = @()
    try { $parts = @($chunk.candidates[0].content.parts) } catch { }
    $testo = ''
    $spec = @()
    foreach ($p in $parts) {
        if ($p.text) { $testo += [string]$p.text }
        elseif ($p.functionCall) { $spec += $p }
        elseif ($p.inlineData) { $spec += $p }
    }
    return @{ Testo = $testo; Parti = $spec }
}

function Resolve-GeminiEndpoint {
    # PATCH-GEMINI 13/11/2026 -- rende innocuo un endpoint scritto a mano:
    # toglie spazi, ?key=..., ?alt=sse, barre finali e rimette {model} se manca.
    param([string]$Endpoint)
    $e = [string]$Endpoint
    if (-not $e) { $e = 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent' }
    $e = $e.Trim()
    if ($e.Contains('?')) { $e = $e.Substring(0, $e.IndexOf('?')) }
    $e = $e.TrimEnd('/')
    if ($e -notmatch ':generateContent$') {
        if ($e -match '/models/[^/]+$' -and $e -notmatch '\{model\}') {
            $e = [regex]::Replace($e, '/models/[^/]+$', '/models/{model}') + ':generateContent'
        } elseif ($e -match '/models$') { $e = $e + '/{model}:generateContent'
        } elseif ($e -match '\{model\}$') { $e = $e + ':generateContent'
        } elseif ($e -match '/v1beta$') { $e = $e + '/models/{model}:generateContent'
        } else { $e = $e + '/v1beta/models/{model}:generateContent' }
    }
    return $e
}

function Invoke-GeminiStream {
    # Legge la risposta SSE di :streamGenerateContent?alt=sse e la restituisce
    # mentre arriva (il testo compare subito in chat invece di aspettare la fine).
    param($sync, [hashtable]$Body, [string]$Model, [string]$Key, [string]$Endpoint, [bool]$Mostra = $false)
    $Endpoint = Resolve-GeminiEndpoint $Endpoint
    $Model = ([string]$Model).Trim()
    $uri = ($Endpoint.Replace(':generateContent', ':streamGenerateContent') + '?alt=sse').Replace('{model}', $Model)
    $req = [System.Net.HttpWebRequest]::Create($uri)
    $req.Method = 'POST'
    $req.ContentType = 'application/json; charset=utf-8'
    $req.Headers.Add('x-goog-api-key', $Key)
    $req.Timeout = 60000
    $req.ReadWriteTimeout = 60000
    $bytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-JsonText $Body))
    $req.ContentLength = $bytes.Length
    $s = $req.GetRequestStream()
    $s.Write($bytes, 0, $bytes.Length)
    $s.Close()
    $risp = $req.GetResponse()
    $reader = New-Object System.IO.StreamReader($risp.GetResponseStream())
    $testo = ''
    $parti = New-Object System.Collections.ArrayList
    $ultimoInvio = Get-Date
    try {
        while ($true) {
            $line = $reader.ReadLine()
            if ($null -eq $line) { break }
            $pezzo = ConvertFrom-GeminiSseChunk $line
            if ($pezzo.Testo) { $testo += [string]$pezzo.Testo }
            foreach ($p in @($pezzo.Parti)) { [void]$parti.Add($p) }
            if ($Mostra -and $testo -and (((Get-Date) - $ultimoInvio).TotalMilliseconds -gt 120)) {
                try { $sync.UiQueue.Enqueue(@{ Type = 'chatpartial'; Data = $testo }) } catch { }
                $ultimoInvio = Get-Date
            }
        }
    } finally {
        try { $reader.Close() } catch { }
        try { $risp.Close() } catch { }
    }
    $outParts = @()
    if ($testo) { $outParts += @{ text = $testo } }
    foreach ($p in $parti) { $outParts += $p }
    if ($outParts.Count -eq 0) { $outParts += @{ text = '' } }
    if ($Mostra) { try { $sync.UiQueue.Enqueue(@{ Type = 'chatpartial'; Data = $testo }) } catch { } }
    return @{ resp = @{ candidates = @( @{ content = @{ parts = $outParts }; finishReason = 'STOP' } ) }; model = $Model }
}

function Ripara-CorpoGemini {
    # PATCH-GEMINI: se Google risponde 400 conviene rimandare una richiesta minima e ben formata.
    param([hashtable]$Body)
    $b = @{}
    foreach ($k in @($Body.Keys)) { $b[$k] = $Body[$k] }
    $c = $b['contents']
    if ($c -and -not ($c -is [System.Array])) { $b['contents'] = @($c) }
    $b.Remove('tools')
    $b.Remove('toolConfig')
    return $b
}

function Invoke-GeminiModelCall {
    # PATCH-GEMINI 13/11/2026: chiamata CLASSICA, niente streaming.
    # Lo streaming (/streamGenerateContent?alt=sse) falliva con 400 appena l'endpoint
    # o il nome del modello avevano un carattere di troppo, e restituiva un oggetto
    # che il resto di ZAP non riusciva a leggere (risposta vuota -> il turno falliva).
    param($sync, [hashtable]$Body, [string]$Model, [string]$Key, [string]$Endpoint, $Headers, [string]$Json, [bool]$Mostra = $false)
    $Endpoint = Resolve-GeminiEndpoint $Endpoint
    $Model = ([string]$Model).Trim()
    $uri = $Endpoint.Replace('{model}', $Model)
    try {
        $resp = Invoke-RestMethod -Uri $uri -Method Post -Headers $Headers `
            -ContentType 'application/json; charset=utf-8' `
            -Body ([System.Text.Encoding]::UTF8.GetBytes($Json)) -TimeoutSec 30
        return @{ resp = $resp; model = $Model }
    } catch {
        $codice = 0
        try { $codice = [int]$_.Exception.Response.StatusCode } catch { }
        if ($codice -ne 400) { throw }
        # 400 = richiesta non valida: riprovo una volta con corpo ripulito (contents lista, senza strumenti)
        $corpoPulito = Ripara-CorpoGemini $Body
        $jsonPulito = ConvertTo-JsonText $corpoPulito
        $resp = Invoke-RestMethod -Uri $uri -Method Post -Headers $Headers `
            -ContentType 'application/json; charset=utf-8' `
            -Body ([System.Text.Encoding]::UTF8.GetBytes($jsonPulito)) -TimeoutSec 30
        return @{ resp = $resp; model = $Model }
    }
}

function Invoke-GeminiRaw {
    param($sync, [hashtable]$Body, [string]$Model = '', [bool]$Mostra = $false)
    $key = ''
    $endpoint = ''
    try {
        if ($sync.AiActive -and ([string]$sync.AiActive.tipo -eq 'gemini')) {
            $key = [string]$sync.AiActive.chiave
            $endpoint = [string]$sync.AiActive.endpoint
        }
    } catch { }
    if (-not $key) { try { $key = [string](Get-ProviderConfig $sync 'gemini').chiave } catch { } }
    if (-not $key) { $key = [string]$sync.Config.api_key }
    if (-not $key) { $key = $env:GEMINI_API_KEY }
    if (-not $key) { throw 'Manca la chiave Gemini: inseriscila nel pannello INTELLIGENZE AI oppure imposta la variabile GEMINI_API_KEY.' }
    $endpoint = Resolve-GeminiEndpoint $endpoint
    $headers = @{ 'x-goog-api-key' = $key; 'Content-Type' = 'application/json' }
    $json = ConvertTo-JsonText $Body

    if ($Model) { $models = @($Model) } else { $models = Get-GeminiModelliRapidi $sync }

    $lastErr = ''
    $ultimoCodice = 0
    # v6.6: prima il modello scelto, poi UN solo ripiego. Niente piu' caccia a tutti i modelli.
    foreach ($model in $models) {
        $model = ([string]$model).Trim()
        if (-not $model) { continue }
        try {
            try { $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = ('SCRIVO CON ' + $model + '...') }) } catch { }
            $resp = Invoke-GeminiModelCall $sync $Body $model $key $endpoint $headers $json $Mostra
            Set-ModelloOk $sync $model
            return $resp
        } catch {
            $lastErr = [string]$_.Exception.Message
            if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $lastErr = $lastErr + ' | ' + $_.ErrorDetails.Message }
            $code = 0
            try { $code = [int]$_.Exception.Response.StatusCode } catch { }
            if ($code -gt 0) { $ultimoCodice = $code }
        }
    }

    # Nessuno dei due ha risposto: cerco UN modello disponibile (una volta sola) e lo ricordo.
    $trovato = Find-ModelloGemini $sync $Body $headers $endpoint
    if ($trovato) { return $trovato }

    $spiega = 'Google non ha risposto in tempo.'
    if ($ultimoCodice -eq 400 -or $ultimoCodice -eq 401 -or $ultimoCodice -eq 403) {
        $spiega = 'Chiave Gemini non valida o senza permessi (codice ' + $ultimoCodice + '). Controlla provider_ai.gemini.chiave in config.local.json.'
    }
    elseif ($ultimoCodice -eq 404) {
        $spiega = 'Modello non disponibile (404). Controlla i nomi dei modelli in config.json (gemini_model_fallbacks).'
    }
    elseif ($ultimoCodice -eq 429) { $spiega = 'La quota di Google per questo momento e esaurita (429). Aspetta circa un minuto e riprova.' }
    elseif ($ultimoCodice -eq 503) { $spiega = 'I server di Google sono momentaneamente sovraccarichi (503). Aspetta qualche secondo e riprova.' }
    throw ("Nessun modello Gemini ha risposto (provati i preferiti e poi l'intera lista). " + $spiega + " Dettaglio: " + $lastErr)
}

function Find-ModelloGemini {
    # Prova i modelli della catena completa finche' uno risponde, poi lo memorizza.
    # Serve SOLO quando i modelli preferiti non rispondono (quindi raramente).
    param($sync, [hashtable]$Body, $Headers, [string]$Endpoint)
    try { $sync.UiQueue.Enqueue(@{ Type = 'status'; Data = 'CERCO UN MODELLO DISPONIBILE...' }) } catch { }
    $payload = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-JsonText $Body))
    foreach ($model in (Get-GeminiModelChain $sync)) {
        try {
            $uri = $Endpoint.Replace('{model}', $model)
            $resp = Invoke-RestMethod -Uri $uri -Method Post -Headers $Headers `
                -ContentType 'application/json; charset=utf-8' -Body $payload -TimeoutSec 20
            Set-ModelloOk $sync $model
            return @{ resp = $resp; model = $model }
        } catch { }
    }
    return $null
}

function Invoke-ChatGemini {
    param($sync, [array]$Messages, [array]$Tools)
    $system = ''
    foreach ($m in $Messages) { if ($m.role -eq 'system') { $system = (ConvertTo-PlainString $m.content); break } }

    $body = @{
        contents         = (ConvertTo-GeminiContents $Messages)
        generationConfig = @{ temperature = 0.4; maxOutputTokens = 4096 }
    }
    if ($system.Trim()) { $body.systemInstruction = @{ parts = @( @{ text = $system } ) } }
    # v9.6 -- soglia di sicurezza (config.json -> gemini_sicurezza). Di fabbrica
    # BLOCK_ONLY_HIGH: blocca solo cio' che e' davvero esplicito, non i lavori
    # tecnici che contengono parole "sensibili" (pentest, sicurezza, medicina, legal).
    try {
        $sic = $sync.Config.gemini_sicurezza
        if ($sic -and ($sic.attivo -ne $false)) {
            $soglia = 'BLOCK_ONLY_HIGH'
            try { if ([string]$sic.soglia) { $soglia = [string]$sic.soglia } } catch { }
            $cat = @('HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_DANGEROUS_CONTENT')
            try { if ($sic.categorie) { $cat = @($sic.categorie) } } catch { }
            $ss = @()
            foreach ($c in $cat) { $ss += @{ category = [string]$c; threshold = $soglia } }
            $body.safetySettings = $ss
        }
    } catch { }
    $gt = ConvertTo-GeminiTools $Tools
    if ($gt) { $body.tools = $gt }

    $r = Invoke-GeminiRaw $sync $body -Mostra $true
    return (ConvertFrom-GeminiReply $r.resp)
}

function Invoke-GeminiVision {
    param($sync, [string]$Question, [string]$Base64, [string]$Mime = 'image/png')
    $body = @{
        contents = @( @{ role = 'user'; parts = @(
            @{ text = $Question }
            @{ inlineData = @{ mimeType = $Mime; data = $Base64 } } ) } )
        generationConfig = @{ temperature = 0.2; maxOutputTokens = 1024 }
    }
    $r = Invoke-GeminiRaw $sync $body
    $texts = @()
    foreach ($part in @($r.resp.candidates[0].content.parts)) { if ($part.text) { $texts += [string]$part.text } }
    return (($texts -join "`n").Trim())
}


# ---------------------------------------------------------------------------
# Serializzatore JSON "sicuro": Windows PowerShell 5.1, con ConvertTo-Json,
# trasforma le liste di UN SOLO elemento in un valore singolo
# (parts:[{...}] diventa parts:{...}) e Gemini risponde 400. Questo invece
# emette SEMPRE gli array, su 5.1 e su 7.
# ---------------------------------------------------------------------------

function ConvertTo-JsonString {
    param([string]$s)
    if ($null -eq $s) { return '""' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    foreach ($ch in $s.ToCharArray()) {
        $code = [int]$ch
        if     ($code -eq 34) { [void]$sb.Append('\"') }
        elseif ($code -eq 92) { [void]$sb.Append('\\') }
        elseif ($code -eq 8)  { [void]$sb.Append('\b') }
        elseif ($code -eq 12) { [void]$sb.Append('\f') }
        elseif ($code -eq 10) { [void]$sb.Append('\n') }
        elseif ($code -eq 13) { [void]$sb.Append('\r') }
        elseif ($code -eq 9)  { [void]$sb.Append('\t') }
        elseif ($code -lt 32) { [void]$sb.Append('\u' + $code.ToString('x4')) }
        else                  { [void]$sb.Append($ch) }
    }
    [void]$sb.Append('"')
    return $sb.ToString()
}

function ConvertTo-JsonText {
    param($Value)

    if ($null -eq $Value) { return 'null' }
    if ($Value -is [bool]) { if ($Value) { return 'true' } else { return 'false' } }
    if ($Value -is [string]) { return (ConvertTo-JsonString $Value) }
    if ($Value -is [int] -or $Value -is [long] -or $Value -is [double] -or
        $Value -is [decimal] -or $Value -is [float] -or $Value -is [int16] -or $Value -is [int32]) {
        return [string]([Convert]::ToDouble($Value)).ToString([System.Globalization.NumberFormatInfo]::InvariantInfo)
    }

    if ($Value -is [System.Collections.IDictionary]) {
        $items = @()
        foreach ($key in $Value.Keys) {
            $items += (ConvertTo-JsonString ([string]$key)) + ':' + (ConvertTo-JsonText $Value[$key])
        }
        return '{' + ($items -join ',') + '}'
    }

    if ($Value -is [System.Collections.IEnumerable]) {
        $items = @()
        foreach ($element in $Value) { $items += (ConvertTo-JsonText $element) }
        return '[' + ($items -join ',') + ']'
    }

    $props = @($Value.PSObject.Properties)
    if ($props.Count -gt 0) {
        $items = @()
        foreach ($p in $props) { $items += (ConvertTo-JsonString $p.Name) + ':' + (ConvertTo-JsonText $p.Value) }
        return '{' + ($items -join ',') + '}'
    }
    return (ConvertTo-JsonString ([string]$Value))
}

function Get-AnthropicModello {
    # Picks the Claude model from the task type AND the "weight" of the prompt:
    #   task testo/codice  -> Sonnet (balanced default)
    #   short, light prompt -> Haiku  (cheapest / fastest)
    #   long or complex     -> Opus   (strongest reasoning)
    #   explicit TaskType   -> the matching entry of the map
    # Names can be overridden in config.json: provider_ai.anthropic.modelli.
    param($sync, [string]$TaskType, [array]$Messages)

    $def = @{
        veloce  = 'claude-haiku-5-5'
        testo   = 'claude-sonnet-5-5'
        codice  = 'claude-sonnet-5-5'
        ricerca = 'claude-sonnet-5-5'
        pesante = 'claude-opus-5-5'
    }

    $testo = ''
    try { $testo = [string](Get-UltimoTestoUtente $Messages) } catch { }

    # Escalate to Opus for genuinely heavy work (long prompt or complex keywords).
    $pesante = $false
    if ($testo.Length -gt 1800) { $pesante = $true }
    if ($testo -match 'approfondi|a fondo|architett|progett|refactor|riscrivi tutto|analizza tutto|ragiona|passo passo|da zero|ottimizz') { $pesante = $true }

    $chiave = [string]$TaskType
    if ($pesante) { $chiave = 'pesante' }
    $scelto = [string]$def[$chiave]
    if (-not $scelto) { $scelto = [string]$def['testo'] }

    # Short, light request that still lands on Claude -> cheapest tier (Haiku).
    if (-not $pesante -and $testo.Length -lt 240) { $scelto = [string]$def['veloce'] }

    # Optional user override written in config.json.
    try {
        $stored = Get-CfgValue $sync.Config.provider_ai 'anthropic'
        $mappa  = Get-CfgValue $stored 'modelli'
        if ($mappa) {
            $mx = [string](Get-CfgValue $mappa $chiave)
            if (-not $mx) { $mx = [string](Get-CfgValue $mappa 'testo') }
            if ($mx) { $scelto = $mx }
        }
    } catch { }

    return $scelto
}

# ===========================================================================
# PATCH-CHIAVI 13/11/2026 -- Perplexity Agent API
# Perplexity ha ritirato /chat/completions ("Sonar is now the Agent API"):
# ora si chiama POST /v1/agent con il formato "Responses". Questa funzione
# traduce andata (messages -> input) e ritorno (output -> role/content/tool_calls)
# cosi' il resto di ZAP non si accorge di nulla. Se il servizio rifiuta gli
# strumenti si riprova senza: meglio una risposta che un errore.
# ===========================================================================
function Invoke-ChatPerplexity {
    param($sync, [array]$Messages, $Prov, [array]$Tools)

    $chiave  = [string]$Prov.chiave
    $modello = [string]$Prov.modello
    if (-not $modello) { $modello = 'perplexity/sonar' }

    $uri = [string]$Prov.endpoint
    if (-not $uri) { $uri = 'https://api.perplexity.ai/v1/agent' }
    $uri = $uri.TrimEnd('/')
    if ($uri -match '/chat/completions$') { $uri = $uri.Substring(0, $uri.Length - 17) }
    if ($uri -notmatch '/v1/(agent|responses)$') {
        if ($uri -match '/v1$') { $uri = $uri + '/agent' } else { $uri = $uri + '/v1/agent' }
    }

    $istruzioni = ''
    $voci = @()
    foreach ($m in @($Messages)) {
        if (-not $m) { continue }
        $ruolo = [string]$m.role
        $testo = ''
        if ($m.content -is [string]) {
            $testo = [string]$m.content
        } else {
            $pezzi = @()
            foreach ($p in @($m.content)) {
                if ($p -is [string]) { $pezzi += [string]$p }
                elseif ($p -and $p.text) { $pezzi += [string]$p.text }
            }
            $testo = ($pezzi -join "`n")
        }
        if (-not $testo -or -not $testo.Trim()) { continue }
        if ($ruolo -eq 'system' -or $ruolo -eq 'developer') {
            $istruzioni = ($istruzioni + "`n" + $testo).Trim()
            continue
        }
        if ($ruolo -eq 'tool') { $testo = 'Risultato dello strumento: ' + $testo; $ruolo = 'user' }
        if ($ruolo -ne 'assistant') { $ruolo = 'user' }
        $voci += @{ role = $ruolo; content = @(@{ type = 'input_text'; text = $testo }) }
    }
    if ($voci.Count -eq 0) { throw 'Perplexity: nessun messaggio da inviare.' }

    $corpo = @{ model = $modello; input = $voci; max_output_tokens = 4096 }
    if ($istruzioni) { $corpo['instructions'] = $istruzioni }

    $usaStrumenti = $false
    if ($Tools -and (@($Tools).Count -gt 0)) {
        $strumenti = @()
        foreach ($t in @($Tools)) {
            $f = $null
            try { $f = $t.function } catch { $f = $null }
            if ($f) {
                $strumenti += @{ type = 'function'; name = [string]$f.name; description = [string]$f.description; parameters = $f.parameters }
            }
        }
        if ($strumenti.Count -gt 0) {
            $corpo['tools'] = $strumenti
            $corpo['tool_choice'] = 'auto'
            $usaStrumenti = $true
        }
    }

    $intestazioni = @{ Authorization = "Bearer $chiave"; 'User-Agent' = 'ZAP/9.4.1' }
    $risposta = $null
    $ultimoErrore = $null
    for ($i = 0; $i -lt 2; $i++) {
        try {
            $json = ConvertTo-JsonText $corpo
            $risposta = Invoke-RestMethod -Uri $uri -Method Post -Headers $intestazioni `
                -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) `
                -ContentType 'application/json; charset=utf-8' -TimeoutSec 120
            break
        } catch {
            $ultimoErrore = $_
            if ($usaStrumenti) {
                $corpo.Remove('tools')
                $corpo.Remove('tool_choice')
                $usaStrumenti = $false
                continue
            }
            break
        }
    }
    if (-not $risposta) {
        $dettaglio = ''
        if ($ultimoErrore) { $dettaglio = [string]$ultimoErrore.Exception.Message }
        throw ("Errore API (Perplexity, modello '$modello'): $dettaglio")
    }

    $testoRisposta = ''
    $chiamate = @()
    foreach ($o in @($risposta.output)) {
        if (-not $o) { continue }
        $tipo = [string]$o.type
        if ($tipo -eq 'message') {
            foreach ($c in @($o.content)) { if ($c -and $c.text) { $testoRisposta = $testoRisposta + [string]$c.text } }
        } elseif ($tipo -eq 'function_call') {
            $argomenti = [string]$o.arguments
            if (-not $argomenti) { $argomenti = '{}' }
            $chiamate += @{ id = [string]$o.call_id; type = 'function'; function = @{ name = [string]$o.name; arguments = $argomenti } }
        }
    }
    if (-not $testoRisposta -and $chiamate.Count -eq 0) { throw ("Risposta API vuota (Perplexity, modello '$modello').") }

    $messaggio = @{ role = 'assistant'; content = $testoRisposta }
    if ($chiamate.Count -gt 0) { $messaggio['tool_calls'] = $chiamate }
    return $messaggio
}
