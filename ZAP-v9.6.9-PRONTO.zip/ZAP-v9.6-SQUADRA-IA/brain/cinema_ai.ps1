﻿# cinema_ai.ps1 -- ZAP CINEMA v8.2 : MOTORE AI (foto -> video vero)
# ---------------------------------------------------------------------------
#  Il motore offline (cinema.ps1) muove la fotografia: zoom, luce, pulviscolo.
#  Questo invece CHIAMA un modello video: la foto diventa un filmato nuovo,
#  con il soggetto che si muove davvero (respiro, testa, ali, tessuti, vento).
#
#  Modello: Gemini Omni Flash (gemini-omni-1.1-flash) via Interactions API.
#  Endpoint REST verificato il 27/10/2026 sulla documentazione ufficiale:
#     POST https://generativelanguage.googleapis.com/v1beta/interactions?key=API_KEY
#     { "model": "gemini-omni-1.1-flash",
#       "input": [ {"type":"image","data":"<base64>","mime_type":"image/jpeg"},
#                  {"type":"text","text":"<prompt>"} ],
#       "response_format": { "type":"video", "aspect_ratio":"16:9" } }
#  Risposta: steps[] -> type "model_output" -> content[] -> type "video" -> data (base64)
#
#  Nota: Veo 3.1 Preview nella Gemini API e' stato spento il 22/10/2026.
#  Omni Flash richiede un progetto con fatturazione attiva: se la chiave non
#  ha accesso, l'errore viene mostrato in chiaro nella finestra CINEMA.
# ---------------------------------------------------------------------------

function Get-CinemaOmniModello {
    param($sync)
    try {
        if ($sync -and $sync.Config -and $sync.Config.cinema -and $sync.Config.cinema.omni_model) {
            return [string]$sync.Config.cinema.omni_model
        }
    } catch { }
    return 'gemini-omni-1.1-flash'
}

function Get-CinemaGeminiKey {
    param($sync)
    $k = ''
    try { if ($sync.Config.api_key) { $k = [string]$sync.Config.api_key } } catch { }
    if (-not $k) {
        try { if ($sync.Config.provider_ai.gemini.api_key) { $k = [string]$sync.Config.provider_ai.gemini.api_key } } catch { }
    }
    if (-not $k) {
        try { if ($sync.Config.provider_ai.gemini.chiave) { $k = [string]$sync.Config.provider_ai.gemini.chiave } } catch { }
    }
    return $k
}

function Get-CinemaMovimentoNomi {
    return @('vita', 'ali', 'vento', 'acqua', 'camera', 'cinema')
}

function Get-CinemaMovimento {
    # Ogni "movimento" e' un prompt scritto bene: e' questo che decide la qualita'.
    param([string]$Id = 'vita')

    $base = 'Bring this photograph to life as a subtle, photorealistic cinematic shot. ' +
            'Keep the subject identity, framing, lighting and colours exactly as they are. ' +
            'No morphing, no warping, no extra objects, no text, no scene change, no cartoon look. ' +
            'Shallow depth of field, natural colour, fine film grain, 35mm look.'

    switch (([string]$Id).ToLowerInvariant()) {
        'ali' {
            return @{
                id = 'ali'; nome = 'ALI E TESSUTI'
                descrizione = 'Ali che battono piano, mantello e tessuti che ondeggiano, pulviscolo nell aria.'
                prompt = 'Animate this image with natural, believable motion: the wings open and close slowly and smoothly, feathers flex, the cape and fabric ripple in a light breeze, dust and small particles drift through the light. ' + $base
            }
        }
        'vento' {
            return @{
                id = 'vento'; nome = 'VENTO'
                descrizione = 'Capelli e vestiti mossi dal vento, nuvole che scorrono, luce che cambia.'
                prompt = 'Animate this image with a gentle wind: hair and clothing move naturally in the breeze, loose strands sway, clouds drift slowly in the background, the light shifts softly. ' + $base
            }
        }
        'acqua' {
            return @{
                id = 'acqua'; nome = 'ACQUA'
                descrizione = 'Onde, riflessi, superficie che si increspa.'
                prompt = 'Animate this image: water ripples and moves in small natural waves, reflections shimmer and shift, spray and droplets drift slowly. ' + $base
            }
        }
        'camera' {
            return @{
                id = 'camera'; nome = 'SOLO CAMERA'
                descrizione = 'Il soggetto resta fermo, si muove la macchina da presa (dolly lento).'
                prompt = 'Keep the subject almost still and move the camera instead: a very slow, smooth dolly-in with a slight parallax, like a real cinema camera on a slider. ' + $base
            }
        }
        'cinema' {
            return @{
                id = 'cinema'; nome = 'CINEMA EPICO'
                descrizione = 'Movimento ampio e drammatico, atmosfera da trailer.'
                prompt = 'Animate this image as an epic cinematic shot: the subject breathes and moves with intention, fabric and hair flow, light rays sweep across the scene, atmosphere and particles move through depth, a slow push-in builds tension. ' + $base
            }
        }
        default {
            return @{
                id = 'vita'; nome = 'VITA'
                descrizione = 'Respiro, sguardo, piccoli movimenti del corpo: la foto prende vita.'
                prompt = 'Animate this image so the subject comes to life naturally: gentle breathing, small head and shoulder movements, a slow blink, subtle eye movement, hair and clothing shifting slightly, ambient light subtly changing. ' + $base
            }
        }
    }
}

function New-CinemaPromptVideo {
    param([string]$Movimento = 'vita', [string]$Extra = '')

    $m = Get-CinemaMovimento $Movimento
    $p = [string]$m.prompt
    if ($Extra -and $Extra.Trim()) {
        $p = $p + ' Additional direction from the user: ' + $Extra.Trim()
    }
    return $p
}

function ConvertTo-ImmagineApiBase64 {
    # Rimpicciolisce e ricodifica in JPEG: payload leggero, qualita' alta.
    param([string]$Percorso, [int]$LatoMax = 1600, [int]$Qualita = 92)

    $src = Get-CinemaImmagine $Percorso ($LatoMax + 400)
    $w = [int]$src.PixelWidth
    $h = [int]$src.PixelHeight
    $s = 1.0
    $lato = [Math]::Max($w, $h)
    if ($lato -gt $LatoMax) { $s = $LatoMax / [double]$lato }

    $finale = $src
    if ($s -lt 1.0) {
        $tb = New-Object System.Windows.Media.Imaging.TransformedBitmap($src, (New-Object System.Windows.Media.ScaleTransform($s, $s)))
        try { $tb.Freeze() } catch { }
        $finale = $tb
    }

    $enc = New-Object System.Windows.Media.Imaging.JpegBitmapEncoder
    $enc.QualityLevel = [int][Math]::Max(60, [Math]::Min(100, $Qualita))
    $enc.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($finale))
    $ms = New-Object System.IO.MemoryStream
    try {
        $enc.Save($ms)
        $bytes = $ms.ToArray()
    } finally {
        $ms.Dispose()
    }
    return [Convert]::ToBase64String($bytes)
}

function Get-CinemaVideoDaRisposta {
    # Estrae il video base64 dalla risposta della Interactions API.
    param($Risposta)

    if (-not $Risposta) { return $null }
    try {
        foreach ($st in @($Risposta.steps)) {
            if ([string]$st.type -ne 'model_output') { continue }
            foreach ($c in @($st.content)) {
                if ([string]$c.type -eq 'video' -and $c.data) {
                    return @{ dati = [string]$c.data; mime = [string]$c.mime_type }
                }
            }
        }
    } catch { }

    # campo comodo usato dagli SDK (per sicurezza lo proviamo)
    try {
        if ($Risposta.output_video.data) {
            return @{ dati = [string]$Risposta.output_video.data; mime = 'video/mp4' }
        }
    } catch { }

    return $null
}

function Get-CinemaErroreApi {
    # Trasforma un errore HTTP in una frase utile.
    param([string]$Testo, [int]$Codice = 0)

    $t = [string]$Testo
    if ($Codice -eq 401 -or $Codice -eq 403) {
        return 'la chiave non ha accesso a questo modello. Controlla che il progetto Google abbia la fatturazione attiva (il video AI non e compreso nel piano gratuito).'
    }
    if ($Codice -eq 429) {
        return 'troppe richieste o quota esaurita. Aspetta un minuto e riprova, oppure controlla la quota del progetto.'
    }
    if ($Codice -eq 400) {
        return 'richiesta rifiutata dal modello. ' + $t
    }
    if ($t -match '(?i)API key not valid|API_KEY_INVALID') {
        return 'la chiave API non e valida: aprila dal pannello IA e ricontrollala.'
    }
    if ($t -match '(?i)billing|quota|permission|not available|not found') {
        return 'il modello non risponde per questo progetto: ' + $t
    }
    return $t
}

function Invoke-CinemaAiVideo {
    # Foto -> video MP4 tramite Gemini Omni Flash.
    # Notifica: scriptblock(fase, messaggio)
    param(
        [Parameter(Mandatory = $true)]$sync,
        [Parameter(Mandatory = $true)][string]$Sorgente,
        [Parameter(Mandatory = $true)][string]$UscitaMp4,
        [string]$Movimento = 'vita',
        [string]$Extra = '',
        [string]$Rapporto = 'auto',
        [string]$Risoluzione = '720p',
        [int]$TimeoutSec = 900,
        $Notifica = $null,
        $Annulla = $null
    )

    function Noto([string]$f, [string]$m) {
        if ($Notifica) { try { & $Notifica $f $m } catch { } }
    }

    $chiave = Get-CinemaGeminiKey $sync
    if (-not $chiave) {
        throw 'Manca la chiave API di Google. Aprila dal pannello IA (pulsante IA in alto) e incollala.'
    }
    if (-not (Test-Path $Sorgente)) { throw ('Foto non trovata: ' + $Sorgente) }

    $modello = Get-CinemaOmniModello $sync
    $prompt = New-CinemaPromptVideo $Movimento $Extra

    Noto 'prep' 'preparo la foto (ridimensiono e ricodifico in JPEG)...'
    $b64 = ConvertTo-ImmagineApiBase64 $Sorgente 1600 92
    $mb = [Math]::Round(($b64.Length * 0.75) / 1048576.0, 2)
    Noto 'prep' ('foto pronta: circa ' + $mb + ' MB')

    $rap = [string]$Rapporto
    if (-not $rap -or $rap -eq 'auto') {
        $img = Get-CinemaImmagine $Sorgente 900
        if ($img.PixelHeight -gt $img.PixelWidth) { $rap = '9:16' } else { $rap = '16:9' }
    }
    if ($rap -ne '9:16' -and $rap -ne '16:9') { $rap = '16:9' }

    $corpo = @{
        model    = $modello
        input    = @(
            @{ type = 'image'; data = $b64; mime_type = 'image/jpeg' },
            @{ type = 'text'; text = $prompt }
        )
        response_format = @{
            type         = 'video'
            aspect_ratio = $rap
            resolution   = $Risoluzione
        }
    }

    $json = $corpo | ConvertTo-Json -Depth 8 -Compress
    $uri = 'https://generativelanguage.googleapis.com/v1beta/interactions?key=' + [System.Uri]::EscapeDataString($chiave)

    $intestazioni = @{ 'Content-Type' = 'application/json' }
    $p = New-Object System.Diagnostics.Stopwatch
    $p.Start()

    Noto 'invio' ('invio al modello ' + $modello + ' (' + $rap + ', ' + $Risoluzione + '). Puo volerci da 1 a 3 minuti...')

    $risposta = $null
    $errore = ''
    $codice = 0
    try {
        $risposta = Invoke-RestMethod -Uri $uri -Method Post -Headers $intestazioni -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec $TimeoutSec -ErrorAction Stop
    } catch {
        $errore = $_.Exception.Message
        try {
            if ($_.Exception.Response) { $codice = [int]$_.Exception.Response.StatusCode }
        } catch { }
        # il corpo dell'errore contiene la spiegazione vera: provo a leggerlo
        try {
            $rs = $_.Exception.Response.GetResponseStream()
            if ($rs) {
                $sr = New-Object System.IO.StreamReader($rs)
                $testo = $sr.ReadToEnd()
                $sr.Dispose()
                if ($testo) { $errore = $testo }
            }
        } catch { }
    }
    $p.Stop()

    if ($errore) {
        throw (Get-CinemaErroreApi $errore $codice)
    }

    Noto 'attesa' ('risposta ricevuta in ' + [Math]::Round($p.Elapsed.TotalSeconds, 1) + ' s')

    $video = Get-CinemaVideoDaRisposta $risposta
    if (-not $video) {
        throw 'Il modello ha risposto ma senza video. Controlla il prompt o riprova.'
    }

    Noto 'download' 'salvo il video...'
    $dir = Split-Path -Parent $UscitaMp4
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $bytes = [Convert]::FromBase64String([string]$video.dati)
    [System.IO.File]::WriteAllBytes($UscitaMp4, $bytes)

    return [pscustomobject]@{
        ok     = $true
        file   = $UscitaMp4
        byte   = $bytes.Length
        ms     = $p.ElapsedMilliseconds
        modello = $modello
        prompt = $prompt
        rapporto = $rap
    }
}
