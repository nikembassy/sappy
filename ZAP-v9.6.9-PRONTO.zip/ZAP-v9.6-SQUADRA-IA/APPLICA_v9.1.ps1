﻿# APPLICA_v9.1.ps1 -- installa la patch v9.1 in un'installazione ZAP esistente.
# ---------------------------------------------------------------------------
#  Cosa fa, nell'ordine:
#    1. controlla che la cartella di destinazione sia davvero un'installazione ZAP;
#    2. copia i file nuovi/aggiornati in backup_v91_<data>\ (mai sovrascrivere senza copia);
#    3. copia i file della v9.1 sopra quelli vecchi;
#    4. verifica che i .ps1 copiati si compilino (parser PowerShell);
#    5. dice cosa fare adesso.
#
#  NON tocca: config.json, config.local.json, memory\, Ezappero\, report\,
#             programmi\, appunti\, skills\, aula\, logs\.
#
#  Uso:
#     powershell -ExecutionPolicy Bypass -File .\APPLICA_v9.1.ps1 -Da "C:\percorso\ZAP-Gemini-v9.0"
#     powershell -ExecutionPolicy Bypass -File .\APPLICA_v9.1.ps1 -Da "..." -Prova   (simulazione)
# ---------------------------------------------------------------------------

param(
    [string]$Da = '',
    [switch]$Prova
)

$ErrorActionPreference = 'Stop'
$sorgente = $PSScriptRoot
$ok = 0
$ko = 0

function Passo { param([string]$T) Write-Host ''; Write-Host ('== ' + $T) -ForegroundColor Cyan }
function Bene  { param([string]$T) Write-Host ('   OK   ' + $T) -ForegroundColor Green }
function Male  { param([string]$T) Write-Host ('   FAIL ' + $T) -ForegroundColor Red }

# --- 1) destinazione --------------------------------------------------------
if (-not $Da) {
    Write-Host 'Serve la cartella dove e installato ZAP.' -ForegroundColor Yellow
    Write-Host 'Esempio: .\APPLICA_v9.1.ps1 -Da "C:\ZAP-Gemini-v9.0"'
    exit 2
}
if (-not (Test-Path -LiteralPath $Da)) {
    Write-Host ('Cartella non trovata: ' + $Da) -ForegroundColor Red
    exit 2
}
$Da = (Resolve-Path -LiteralPath $Da).Path

Passo '1) Controllo la cartella di destinazione'
$firma = @('AVVIA.ps1', 'brain\ghost.ps1', 'brain\agenti_worker.ps1')
$manca = @()
foreach ($f in $firma) { if (-not (Test-Path -LiteralPath (Join-Path $Da $f))) { $manca += $f } }
if ($manca.Count -gt 0) {
    Male ('non sembra un installazione ZAP: manca ' + ($manca -join ', '))
    exit 2
}
Bene ('installazione trovata: ' + $Da)

# --- 2) elenco dei file -----------------------------------------------------
$file = @(
    'AVVIA.ps1',
    'brain\agent.ps1',
    'brain\ghost.ps1',
    'brain\agenti_worker.ps1',
    'brain\tools.ps1',
    'brain\pentest.ps1',
    'brain\aula.ps1',
    'brain\telemetria.ps1',
    'brain\pentest_ext.ps1',
    'ui\cabina.xaml',
    'tests\test_v91.ps1',
    'LEGGIMI_MODIFICHE_v9.1.txt',
    'MANUALE_LEZIONE_v9.1.md'
)
$presenti = @()
foreach ($f in $file) {
    $p = Join-Path $sorgente $f
    if (Test-Path -LiteralPath $p) { $presenti += $f } else { Write-Host ('   (salto, non presente nel pacchetto: ' + $f + ')') -ForegroundColor DarkYellow }
}
Passo ('2) File da copiare: ' + $presenti.Count)
foreach ($f in $presenti) { Write-Host ('   - ' + $f) }

# --- 2b) config.local.json (le tue chiavi API) ------------------------------
# Regola: questo file NON viene mai sovrascritto con uno vuoto e NON viene mai
# cancellato. Se esiste gia' nella destinazione resta com'e'. Se manca e il
# pacchetto lo porta, viene ripristinato.
$chiaviDest = Join-Path $Da 'config.local.json'
$chiaviSrc  = Join-Path $sorgente 'config.local.json'
Passo '2b) Chiavi API (config.local.json)'
if (Test-Path -LiteralPath $chiaviDest) {
    Bene 'presente nella tua installazione: resta dov e (non lo tocco)'
} elseif (Test-Path -LiteralPath $chiaviSrc) {
    if ($Prova) {
        Write-Host '   [PROVA] ripristinerei config.local.json dal pacchetto' -ForegroundColor Yellow
    } else {
        Copy-Item -LiteralPath $chiaviSrc -Destination $chiaviDest -Force
        Bene 'config.local.json MANCANTE: ripristinato dal pacchetto'
    }
} else {
    Male 'config.local.json non c e e non e nel pacchetto: le chiavi API vanno reinserite a mano'
}

# --- 3) backup --------------------------------------------------------------
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$backup = Join-Path $Da ('backup_v91_' + $stamp)
Passo '3) Backup'
if ($Prova) {
    Write-Host ('   [PROVA] avrei creato ' + $backup) -ForegroundColor Yellow
} else {
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    if (Test-Path -LiteralPath $chiaviDest) { Copy-Item -LiteralPath $chiaviDest -Destination (Join-Path $backup 'config.local.json') -Force }
    foreach ($f in $presenti) {
        $vecchio = Join-Path $Da $f
        if (Test-Path -LiteralPath $vecchio) {
            $dest = Join-Path $backup $f
            $dir = Split-Path -Parent $dest
            if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
            Copy-Item -LiteralPath $vecchio -Destination $dest -Force
        }
    }
    Bene ('copia di sicurezza in ' + $backup)
}

# --- 4) copia ---------------------------------------------------------------
Passo '4) Copia dei file v9.1'
foreach ($f in $presenti) {
    $src = Join-Path $sorgente $f
    $dst = Join-Path $Da $f
    $dir = Split-Path -Parent $dst
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    if ($Prova) {
        Write-Host ('   [PROVA] copierei ' + $f) -ForegroundColor Yellow
        continue
    }
    try {
        Copy-Item -LiteralPath $src -Destination $dst -Force
        Bene $f
        $ok++
    } catch {
        Male ($f + ' -> ' + $_.Exception.Message)
        $ko++
    }
}

if ($Prova) {
    Write-Host ''
    Write-Host 'Simulazione finita: nessun file toccato. Togli -Prova per applicare.' -ForegroundColor Yellow
    exit 0
}

# --- 5) verifica sintassi ---------------------------------------------------
Passo '5) Verifica sintassi dei file copiati'
foreach ($f in $presenti) {
    if ($f -notmatch '\.ps1$') { continue }
    $p = Join-Path $Da $f
    $tok = $null; $err = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($p, [ref]$tok, [ref]$err)
    if ($err -and $err.Count -gt 0) {
        Male ($f + ' L' + $err[0].Extent.StartLineNumber + ': ' + $err[0].Message)
        $ko++
    } else {
        Bene ($f + ' compila')
    }
}

# --- 6) promemoria ----------------------------------------------------------
Write-Host ''
if ($ko -eq 0) {
    Write-Host 'PATCH APPLICATA.' -ForegroundColor Green
} else {
    Write-Host ('PATCH applicata con ' + $ko + ' problemi: leggi sopra.') -ForegroundColor Yellow
}
Write-Host ''
Write-Host 'Adesso:' -ForegroundColor Cyan
Write-Host '  1. avvia ZAP (AVVIA.bat)'
Write-Host '  2. in alto deve comparire il pulsante "AGENTI 0/7" e il pulsante GHOST'
Write-Host '  3. premi GHOST: se e verde, ecco come aprirlo in un clic:'
Write-Host '        /ghost modo aperto'
Write-Host '        oppure cabina AGENTI -> PERIMETRO GHOST -> APERTO -> APPLICA'
Write-Host '  4. verifica tutto con:  powershell -ExecutionPolicy Bypass -File .\tests\test_v91.ps1'
Write-Host ''
Write-Host '  5. se ZAP dice che manca la chiave API: IMPOSTAZIONI -> provider -> incolla la chiave,'
Write-Host '     oppure copia config.local.json da backup_v91_<data>\ (ci finisce sempre una copia).'
Write-Host ''
Write-Host ('Per tornare indietro: copia i file da ' + $backup) -ForegroundColor DarkGray
if ($ko -gt 0) { exit 1 }
exit 0
