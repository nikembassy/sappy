@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ZAP - controllo
echo.
echo   Controllo di ZAP: cerca gli errori nei file .ps1
echo   ===============================================
echo.
where powershell >nul 2>&1
if errorlevel 1 goto nops
powershell -NoProfile -ExecutionPolicy Bypass -Command "$g=0; $f=@(Get-ChildItem -Recurse -Filter *.ps1); foreach($x in $f){ $t=$null;$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($x.FullName,[ref]$t,[ref]$e); if($e -and $e.Count -gt 0){ $g++; Write-Host ('ERRORE ' + $x.Name + ' riga ' + $e[0].Extent.StartLineNumber + ': ' + $e[0].Message) -ForegroundColor Red } }; $d=@(Select-String -Path '.\brain\*.ps1' -Pattern '^\s*function ' -ErrorAction SilentlyContinue); foreach($z in $d){ $g++; Write-Host ('FUNZIONE DECAPITATA ' + $z.Filename + ' riga ' + $z.LineNumber) -ForegroundColor Red }; Write-Host ''; if($g -eq 0){ Write-Host ('Nessun errore in ' + $f.Count + ' file: il codice e'' sano.') -ForegroundColor Green } else { Write-Host ('Trovati ' + $g + ' problemi.') -ForegroundColor Yellow }"
goto chiudi
:nops
echo   ERRORE: PowerShell non trovato su questo PC.
:chiudi
echo.
echo   Premi un tasto per chiudere.
pause >nul
endlocal
