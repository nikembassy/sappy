﻿# PREPARA_STRUMENTI_v9.1.ps1 -- mette in piedi gli strumenti di pentest, uno per uno verificati.
# ---------------------------------------------------------------------------
#  Lo lanci con un doppio clic (PREPARA_STRUMENTI_v9.1.bat). Fa, in ordine:
#    1. chiede i permessi di amministratore (servono a WSL);
#    2. installa Wireshark su Windows (winget, con Npcap);
#    3. se manca WSL/Kali, lo installa e ti dice se serve riavviare;
#    4. dentro Kali installa: sqlmap, hydra, aircrack-ng, nikto, gobuster, dirb,
#       metasploit-framework, tshark (+ nmap, ffuf, whatweb, wafw00f, nuclei, wordlists);
#    5. VERIFICA uno per uno che il comando risponda davvero;
#    6. scrive PREPARA_STRUMENTI.log e ti mostra la tabella finale.
#
#  Solo per controllare cosa c'e' gia:  PREPARA_STRUMENTI_v9.1.bat -Verifica
#  Solo Wireshark:                      PREPARA_STRUMENTI_v9.1.bat -SoloWireshark
#  Senza gli strumenti extra:           PREPARA_STRUMENTI_v9.1.bat -SenzaExtra
# ---------------------------------------------------------------------------

param(
    [switch]$Verifica,
    [switch]$SoloWireshark,
    [switch]$SenzaExtra
)

$ErrorActionPreference = 'Continue'
$io = $PSScriptRoot
$log = Join-Path $io 'PREPARA_STRUMENTI.log'

function Scr {
    param([string]$T, [string]$C = '')
    try { Add-Content -LiteralPath $log -Value $T -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
    if ($C) { Write-Host $T -ForegroundColor $C } else { Write-Host $T }
}

try { if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log -Force -ErrorAction SilentlyContinue } } catch { }

Scr '=========================================================='
Scr ' ZAP - preparazione degli strumenti di pentest (v9.1)'
Scr (' ' + (Get-Date -Format 'dd/MM/yyyy HH:mm'))
Scr '=========================================================='
Scr ''

# --- 1) amministratore ------------------------------------------------------
$eWindows = $true
try { if ($env:OS -ne 'Windows_NT') { $eWindows = $false } } catch { $eWindows = $false }
if ($eWindows) {
    $amm = $false
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object Security.Principal.WindowsPrincipal($id)
        $amm = $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { $amm = $false }

    if (-not $amm) {
        Scr 'Servono i permessi di amministratore: riapro con la finestra di conferma...' 'Yellow'
        $argomenti = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'))
        if ($Verifica) { $argomenti += '-Verifica' }
        if ($SoloWireshark) { $argomenti += '-SoloWireshark' }
        if ($SenzaExtra) { $argomenti += '-SenzaExtra' }
        try {
            Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argomenti | Out-Null
            exit 0
        } catch {
            Scr ('Non ho ottenuto i permessi: ' + $_.Exception.Message) 'Red'
            Scr 'Clic destro sul file .bat -> Esegui come amministratore.' 'Yellow'
            exit 2
        }
    }
    Scr 'Permessi di amministratore: ok' 'Green'
}

# --- 2) moduli di ZAP -------------------------------------------------------
$base = $io
$sync = @{ Base = $io; Config = @{}; CfgPath = (Join-Path $io 'config.json') }

foreach ($m in @('brain\kali.ps1', 'brain\strumenti.ps1')) {
    $p = Join-Path $base $m
    if (-not (Test-Path -LiteralPath $p)) {
        Scr ('Pacchetto incompleto: manca ' + $m) 'Red'
        Scr 'Estrai di nuovo lo ZIP per intero e rilancia.' 'Yellow'
        exit 2
    }
    . $p
}

if (-not (Get-Command Get-StrumentiStato -ErrorAction SilentlyContinue)) {
    Scr 'Non riesco a caricare brain\strumenti.ps1' 'Red'
    exit 2
}

# --- 3) solo verifica -------------------------------------------------------
if ($Verifica) {
    Scr ''
    Scr (Format-StrumentiStato $sync -ConNote)
    Scr ''
    Scr ('Log: ' + $log) 'DarkGray'
    exit 0
}

# --- 4) installazione -------------------------------------------------------
Scr ''
Scr 'Questo passaggio puo durare da 10 a 40 minuti la prima volta'
Scr '(Kali pesa 2-3 GB, Metasploit circa 1 GB). La finestra resta aperta e'
Scr 'mostra i comandi mentre girano: e normale che sembri fermo a tratti.'
Scr ''

$testo = ''
try {
    $testo = Installa-StrumentiTutti -sync $sync -SenzaExtra:$SenzaExtra -SenzaWireshark:$SoloWireshark -Rumoroso
} catch {
    $testo = 'ERRORE durante l installazione: ' + $_.Exception.Message
}
Scr $testo

# --- 5) tabella finale ------------------------------------------------------
Scr ''
Scr (Format-StrumentiStato $sync -ConNote)
try { [void](Save-StrumentiStato $sync (Get-StrumentiStato $sync)) } catch { }

# --- 6) note oneste ---------------------------------------------------------
Scr ''
Scr '----------------------------------------------------------'
Scr ' DA SAPERE PRIMA DELLA LEZIONE'
Scr '----------------------------------------------------------'
Scr ' - Wireshark cattura il traffico (versione Windows, con Npcap).'
Scr ' - Gli altri strumenti girano dentro Kali (WSL).'
Scr ' - aircrack-ng si installa e parte, ma in WSL2 NON vede la scheda'
Scr '   WiFi: il monitor mode richiede hardware dedicato o un Kali'
Scr '   nativo / live USB. In classe: usalo dentro Kali live, oppure'
Scr '   mostra la teoria e passa a Wireshark per la pratica.'
Scr ' - Metasploit: primo avvio lento (prepara il database). Normale.'
Scr ''
Scr (' Log completo: ' + $log) 'DarkGray'
Scr ''
Scr 'Ora apri ZAP e scrivi /strumenti verifica per vedere la tabella dall interno.'

if ($eWindows) {
    try { Read-Host 'Premi INVIO per chiudere' | Out-Null } catch { }
}
exit 0
