﻿# APPLICA_v9.6.ps1 -- aggiorna ZAP dalla 9.5 alla 9.6 sul tuo PC.
# Non cancella niente: prima fa un backup completo, poi sostituisce SOLO i file
# di codice. Alla fine VERIFICA con il parser di PowerShell e, se trova anche un
# solo errore, rimette da sola i file di prima.
#
# Uso: doppio clic su INSTALLA_v9.6.bat (consigliato)
#      oppure: powershell -ExecutionPolicy Bypass -File .\APPLICA_v9.6.ps1 -Destino "C:\...\ZAP"

param([string]$Destino = '')

$ErrorActionPreference = 'Stop'
$patch = $PSScriptRoot

function Riga($t) { Write-Host $t -ForegroundColor Cyan }
function Bene($t) { Write-Host $t -ForegroundColor Green }
function Male($t) { Write-Host $t -ForegroundColor Yellow }

Write-Host ''
Write-Host '  ZAP v9.6 -- applicazione della patch' -ForegroundColor Cyan
Write-Host '  ===================================' -ForegroundColor Cyan
Write-Host ''

if (-not $Destino) {
    $Destino = Read-Host '  Cartella di ZAP da aggiornare (Invio = questa cartella)'
    if (-not $Destino) { $Destino = $patch }
}
if (-not (Test-Path $Destino)) { Male ('  Cartella non trovata: ' + $Destino); exit 1 }
$Destino = (Resolve-Path $Destino).Path

if (-not (Test-Path (Join-Path $Destino 'AVVIA.ps1'))) {
    Male ('  In ' + $Destino + ' non trovo AVVIA.ps1: non sembra una cartella di ZAP.')
    exit 1
}

# --- 1. backup completo ---------------------------------------------------
$stamp  = Get-Date -Format 'yyyyMMdd-HHmmss'
$padre  = Split-Path -Parent $Destino
$backup = Join-Path $padre ('ZAP-backup-' + $stamp)
Riga ('  1. Backup completo in: ' + $backup)
Copy-Item -LiteralPath $Destino -Destination $backup -Recurse -Force
Bene '     fatto'

# --- 2. copia dei file di codice (registro cosa sostituisco) --------------
Riga '  2. Sostituisco i file di codice (config e memoria NON si toccano)'
$sostituiti = New-Object System.Collections.ArrayList
$daCopiare = @('AVVIA.ps1', 'INSTALLA.ps1', 'APPLICA_v9.6.ps1', 'INSTALLA_v9.6.bat',
               'LEGGIMI_v9.6.txt', 'LEGGIMI_PRIMA.txt', 'README.md', 'ISTRUZIONI.txt',
               'ISTRUZIONI_API_KEY.md', 'LEGGIMI_v9.5.txt')
foreach ($f in $daCopiare) {
    $src = Join-Path $patch $f
    if (Test-Path $src) {
        Copy-Item -LiteralPath $src -Destination (Join-Path $Destino $f) -Force
        [void]$sostituiti.Add($f)
    }
}
$brainSrc = Join-Path $patch 'brain'
$brainDst = Join-Path $Destino 'brain'
if (-not (Test-Path $brainDst)) { New-Item -ItemType Directory -Path $brainDst | Out-Null }
$conta = 0
foreach ($f in @(Get-ChildItem -Path $brainSrc -Filter '*.ps1' -File)) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $brainDst $f.Name) -Force
    [void]$sostituiti.Add(('brain\' + $f.Name))
    $conta++
}
Bene ('     ' + $conta + ' moduli .ps1 aggiornati in brain\')

# funzione di ripristino: rimette SOLO i file che ho sostituito
function Ripristina {
    Write-Host '     Sto rimettendo i file di prima...' -ForegroundColor Yellow
    foreach ($rel in $sostituiti) {
        $sorgente = Join-Path $backup $rel
        $destinazione = Join-Path $Destino $rel
        if (Test-Path $sorgente) { Copy-Item -LiteralPath $sorgente -Destination $destinazione -Force }
    }
    Write-Host '     Ripristino completato: ZAP e'' tornato come prima.' -ForegroundColor Yellow
}

# --- 3. config.json: migrazione, conservando le tue chiavi ----------------
Riga '  3. Aggiorno config.json (chiavi e memoria intatte)'
$cp = Join-Path $Destino 'config.json'
if (-not (Test-Path $cp)) {
    Male '     config.json non trovato: apri ZAP una volta e salva le Impostazioni, poi riprova.'
} else {
    try {
        $cfg = Get-Content $cp -Raw -Encoding UTF8 | ConvertFrom-Json

        if ($cfg.provider_ai.PSObject.Properties.Name -contains 'ollama') {
            $cfg.provider_ai.PSObject.Properties.Remove('ollama')
            Bene '     provider_ai.ollama rimosso'
        }

        $cfg.provider_ai.gemini   | Add-Member -NotePropertyName abilitato -NotePropertyValue $true -Force
        $cfg.provider_ai.gemini   | Add-Member -NotePropertyName modello   -NotePropertyValue 'gemini-3.6-flash' -Force
        $cfg.provider_ai.gemini   | Add-Member -NotePropertyName priorita  -NotePropertyValue 100 -Force
        $cfg.provider_ai.deepseek | Add-Member -NotePropertyName abilitato -NotePropertyValue $true -Force
        $cfg.provider_ai.deepseek | Add-Member -NotePropertyName modello   -NotePropertyValue 'deepseek-v4-pro' -Force
        $cfg.provider_ai.deepseek | Add-Member -NotePropertyName priorita  -NotePropertyValue 90 -Force

        $cfg | Add-Member -NotePropertyName provider           -NotePropertyValue 'gemini' -Force
        $cfg | Add-Member -NotePropertyName modello            -NotePropertyValue 'gemini-3.6-flash' -Force
        $cfg | Add-Member -NotePropertyName api_base           -NotePropertyValue '' -Force
        $cfg | Add-Member -NotePropertyName modalita_ai        -NotePropertyValue 'auto' -Force
        $cfg | Add-Member -NotePropertyName gemini_model_scelto -NotePropertyValue 'gemini-3.6-flash' -Force
        $cfg | Add-Member -NotePropertyName gemini_model_fallbacks -Force -NotePropertyValue @(
            'gemini-flash-latest', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite')

        $cfg | Add-Member -NotePropertyName motore -Force -NotePropertyValue ([pscustomobject]@{
            primario = 'gemini'; secondario = 'deepseek'; stretto = $true
            ripiego_solo_su_errore = $true; etichetta_ripiego = $true })

        $cfg | Add-Member -NotePropertyName memoria -Force -NotePropertyValue ([pscustomobject]@{
            salvataggio = 'manuale'; salva_fine_turno = $false; consolidamento_automatico = $false })

        $cfg | Add-Member -NotePropertyName gemini_sicurezza -Force -NotePropertyValue ([pscustomobject]@{
            attivo = $true; soglia = 'BLOCK_ONLY_HIGH'
            categorie = @('HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_DANGEROUS_CONTENT') })

        if (-not ($cfg.PSObject.Properties.Name -contains 'orchestrazione') -or -not $cfg.orchestrazione) {
            $cfg | Add-Member -NotePropertyName orchestrazione -NotePropertyValue ([pscustomobject]@{}) -Force
        }
        $cfg.orchestrazione | Add-Member -NotePropertyName attivo          -NotePropertyValue $false   -Force
        $cfg.orchestrazione | Add-Member -NotePropertyName giudice         -NotePropertyValue 'elenco' -Force
        $cfg.orchestrazione | Add-Member -NotePropertyName rispetta_scelta -NotePropertyValue $true    -Force

        ($cfg | ConvertTo-Json -Depth 12) | Set-Content -LiteralPath $cp -Encoding UTF8
        Bene '     config.json aggiornato'
    } catch {
        Male ('     config.json NON aggiornato: ' + $_.Exception.Message)
        Male '     I file di codice sono a posto: ZAP parte lo stesso, ma Gemini va scelto a mano.'
    }
}

# --- 4. VERIFICA FINALE con il parser di PowerShell -----------------------
Riga '  4. Verifica: ogni file .ps1 deve essere caricabile'
$guasti = 0
foreach ($f in @(Get-ChildItem -Path $Destino -Filter '*.ps1' -Recurse -File)) {
    $tok = $null
    $err = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tok, [ref]$err)
    if ($err -and $err.Count -gt 0) {
        $guasti++
        Male ('     ERRORE in ' + $f.FullName + ' riga ' + $err[0].Extent.StartLineNumber + ': ' + $err[0].Message)
    }
}
# controllo mirato: la "f" di "function" non deve mai mancare
$decapitate = @(Select-String -Path (Join-Path $Destino 'brain\*.ps1') -Pattern '^\s*unction ' -ErrorAction SilentlyContinue)
if ($decapitate.Count -gt 0) {
    $guasti += $decapitate.Count
    foreach ($d in $decapitate) { Male ('     funzione decapitata: ' + $d.Filename + ' riga ' + $d.LineNumber) }
}

if ($guasti -eq 0) {
    Bene '     nessun errore: tutti i file si caricano'
    Riga '  5. Controllo config'
    $residui = @(Select-String -Path $cp -Pattern 'ollama' -SimpleMatch -ErrorAction SilentlyContinue)
    if ($residui.Count -eq 0) { Bene '     nessun riferimento al motore locale' }
    else { Male '     restano riferimenti al motore locale: apri config.json e togli "ollama"' }
    Write-Host ''
    Write-Host '  FATTO. Ora:' -ForegroundColor Green
    Write-Host '   - chiudi ZAP se e'' aperto, poi rilancia AVVIA.bat' -ForegroundColor Gray
    Write-Host '   - apri INTELLIGENZE AI e controlla che sia selezionato gemini' -ForegroundColor Gray
    Write-Host ('   - se qualcosa non va, il backup e'' in: ' + $backup) -ForegroundColor Gray
    Write-Host ''
    exit 0
} else {
    Male ('     TROVATI ' + $guasti + ' PROBLEMI: annullo la modifica')
    Ripristina
    Write-Host ''
    Male '  Installazione annullata: ZAP e'' rimasto esattamente come prima.'
    Write-Host ('  Il backup completo e'' comunque in: ' + $backup) -ForegroundColor Gray
    Write-Host ''
    exit 1
}
