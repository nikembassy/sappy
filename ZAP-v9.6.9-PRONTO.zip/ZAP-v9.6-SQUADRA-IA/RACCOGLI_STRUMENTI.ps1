﻿# RACCOGLI_STRUMENTI.ps1 -- inventario degli strumenti di pentest presenti su questo PC.
#
# Perche' esiste: per costruire la cassetta degli attrezzi della modalita' GHOST non posso
# inventare quali programmi hai. Questo script NON esegue nulla di invasivo: guarda soltanto
# cosa c'e' (percorsi, versioni, distro WSL, moduli PowerShell) e scrive due file:
#
#     documentazione\strumenti.json   <- questo me lo passi tu (e' quello che serve a me)
#     documentazione\strumenti.txt    <- versione leggibile da te
#
# Non serve l'amministratore. Non tocca la rete. Non installa niente.
# Solo caratteri ASCII: Windows PowerShell 5.1 lo legge senza ambiguita'.

$ErrorActionPreference = 'Continue'
$base = $PSScriptRoot
if (-not $base) { $base = (Get-Location).Path }

$outDir = Join-Path $base 'documentazione'
if (-not (Test-Path -LiteralPath $outDir)) { [void][System.IO.Directory]::CreateDirectory($outDir) }
$enc = New-Object System.Text.UTF8Encoding($false)

$info = [ordered]@{
    raccolto_il    = (Get-Date -Format 'o')
    sistema        = ''
    versione_ps    = $PSVersionTable.PSVersion.ToString()
    edizione_ps    = [string]$PSVersionTable.PSEdition
    amministratore = $false
    wsl            = @()
    strumenti      = @()
    moduli_ps      = @()
    cartelle       = @()
    rete_locale    = @()
}

function Scrivi {
    param([string]$Testo)
    Write-Host $Testo
}

Scrivi ''
Scrivi '============================================================'
Scrivi '  ZAP - inventario strumenti (per la cassetta degli attrezzi)'
Scrivi '============================================================'
Scrivi ''

# --- sistema ---
try {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    if ($os) { $info.sistema = ([string]$os.Caption).Trim() + ' ' + ([string]$os.Version).Trim() }
} catch { }
try {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $pr = New-Object System.Security.Principal.WindowsPrincipal($id)
    $info.amministratore = $pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
} catch { }
Scrivi ('Sistema   : ' + $info.sistema)
Scrivi ('PowerShell: ' + $info.versione_ps + ' (' + $info.edizione_ps + ')')
Scrivi ('Admin     : ' + $(if ($info.amministratore) { 'si' } else { 'no' }))

# --- rete locale (serve a capire il perimetro) ---
try {
    foreach ($ip in @(Get-CimInstance Win32_NetworkAdapterConfiguration -ErrorAction SilentlyContinue |
                      Where-Object { $_.IPEnabled } | ForEach-Object { $_.IPAddress })) {
        if ($ip -and (([string]$ip) -notlike '*:*')) { $info.rete_locale += [string]$ip }
    }
} catch { }
if ($info.rete_locale.Count -gt 0) { Scrivi ('Rete      : ' + ($info.rete_locale -join ', ')) }

# --- WSL e Kali ---
Scrivi ''
Scrivi '--- WSL ---'
$wslPresente = $false
try { $wslPresente = [bool](Get-Command wsl.exe -ErrorAction SilentlyContinue) } catch { $wslPresente = $false }

if ($wslPresente) {
    Scrivi 'wsl.exe trovato'
    try {
        $distro = & wsl.exe -l -q 2>$null
        if ($distro) {
            foreach ($d in @($distro)) {
                $nome = ([string]$d).Replace("`0", '').Trim()
                if ($nome) { $info.wsl += $nome }
            }
        }
    } catch { }
    if ($info.wsl.Count -gt 0) { Scrivi ('distro: ' + ($info.wsl -join ', ')) } else { Scrivi 'distro: nessuna' }
} else {
    Scrivi 'wsl.exe NON trovato (niente Kali via WSL)'
}
Scrivi ''

# --- strumenti ---
$lista = @(
    'nmap','sqlmap','nikto','gobuster','ffuf','dirb','wpscan','whatweb','wafw00f','nuclei',
    'subfinder','amass','masscan','hydra','john','hashcat','msfconsole','msfvenom','searchsploit',
    'responder','netexec','crackmapexec','bloodhound','aircrack-ng','airodump-ng','bettercap',
    'tcpdump','tshark','wireshark','burpsuite','burp','zap','mitmproxy','openssl','curl','nc',
    'netcat','socat','python','python3','pip','pip3','go','git','docker','jq','wget','tar','7z'
)

Scrivi '--- strumenti su Windows ---'
foreach ($t in $lista) {
    $perc = $null
    try {
        $cmd = Get-Command $t -ErrorAction SilentlyContinue
        if ($cmd) { $perc = [string]$cmd.Source }
    } catch { }
    if (-not $perc) {
        foreach ($cart in @("$env:ProgramFiles\Nmap", "$env:ProgramFiles\Wireshark", 'C:\Tools', 'C:\ProgramData\chocolatey\bin')) {
            if (-not $cart -or -not (Test-Path -LiteralPath $cart)) { continue }
            $trovato = Get-ChildItem -LiteralPath $cart -Filter ($t + '.exe') -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($trovato) { $perc = $trovato.FullName; break }
        }
    }
    if ($perc) {
        $info.strumenti += [ordered]@{ nome = $t; dove = 'windows'; percorso = $perc }
        Scrivi ('  [OK]     ' + $t + '  ->  ' + $perc)
    }
}

# --- strumenti dentro WSL (una sola chiamata per distro) ---
if ($wslPresente -and $info.wsl.Count -gt 0) {
    Scrivi ''
    Scrivi '--- strumenti dentro WSL ---'
    $listaSh = ($lista | ForEach-Object { [string]$_ }) -join ' '
    $comando = ('for t in ' + $listaSh + '; do p=$(command -v $t 2>/dev/null); if [ -n "$p" ]; then echo "$t|$p"; fi; done')
    foreach ($d in $info.wsl) {
        try {
            $uscita = & wsl.exe -d $d -e sh -lc $comando 2>$null
            foreach ($riga in @($uscita)) {
                $r = ([string]$riga).Replace("`0", '').Trim()
                if (-not $r -or $r -notmatch '\|') { continue }
                $pz = $r.Split('|')
                $info.strumenti += [ordered]@{ nome = $pz[0]; dove = ('wsl:' + $d); percorso = $pz[1] }
                Scrivi ('  [OK]     ' + $pz[0] + '  ->  ' + $d + ':' + $pz[1])
            }
        } catch {
            Scrivi ('  [WARN]   non riesco a interrogare la distro ' + $d)
        }
    }
}

# --- moduli PowerShell utili ---
Scrivi ''
Scrivi '--- moduli PowerShell ---'
foreach ($m in @('ActiveDirectory','AzureAD','ExchangeOnlineManagement','Pester','PowerShellGet','PSReadLine','Az','Microsoft.Graph')) {
    $ok = $false
    try { $ok = [bool](Get-Module -ListAvailable -Name $m -ErrorAction SilentlyContinue) } catch { }
    if ($ok) {
        $info.moduli_ps += $m
        Scrivi ('  [OK]     ' + $m)
    }
}

# --- cartelle dove di solito tieni gli strumenti ---
Scrivi ''
Scrivi '--- cartelle personali ---'
foreach ($c in @('C:\Tools', 'C:\tool', "$env:USERPROFILE\Tools", "$env:USERPROFILE\Desktop\strumenti",
                 "$env:USERPROFILE\Desktop\Strumenti", "$env:USERPROFILE\Downloads\strumenti",
                 "$env:USERPROFILE\pentest", "$env:USERPROFILE\Desktop\pentest")) {
    if ($c -and (Test-Path -LiteralPath $c)) {
        $info.cartelle += $c
        Scrivi ('  [OK]     ' + $c)
    }
}

# --- scrivo i due file ---
$percJson = Join-Path $outDir 'strumenti.json'
$percTxt  = Join-Path $outDir 'strumenti.txt'
try {
    [System.IO.File]::WriteAllText($percJson, (ConvertTo-Json -InputObject $info -Depth 8), $enc)
} catch {
    Scrivi ('ERRORE scrivendo il JSON: ' + $_.Exception.Message)
}

$righe = @()
$righe += 'ZAP - INVENTARIO STRUMENTI'
$righe += ('Raccolto il: ' + $info.raccolto_il)
$righe += ('Sistema    : ' + $info.sistema)
$righe += ('PowerShell : ' + $info.versione_ps + ' (' + $info.edizione_ps + ')')
$righe += ('Admin      : ' + $(if ($info.amministratore) { 'si' } else { 'no' }))
$righe += ('WSL        : ' + $(if ($info.wsl.Count) { ($info.wsl -join ', ') } else { 'nessuna' }))
$righe += ('Rete       : ' + ($info.rete_locale -join ', '))
$righe += ''
$righe += ('STRUMENTI TROVATI (' + $info.strumenti.Count + ')')
foreach ($s in $info.strumenti) { $righe += ('  ' + $s.dove + ' | ' + $s.nome + ' -> ' + $s.percorso) }
$righe += ''
$righe += ('MODULI POWERSHELL: ' + $(if ($info.moduli_ps.Count) { ($info.moduli_ps -join ', ') } else { 'nessuno' }))
$righe += ('CARTELLE: ' + $(if ($info.cartelle.Count) { ($info.cartelle -join ', ') } else { 'nessuna' }))
$righe += ''
$righe += 'Da mandare a ZAP: il file strumenti.json'
try { [System.IO.File]::WriteAllText($percTxt, (($righe -join "`r`n") + "`r`n"), $enc) } catch { }

Scrivi ''
Scrivi '============================================================'
Scrivi ('  Strumenti trovati: ' + $info.strumenti.Count)
Scrivi ('  File da consegnare: ' + $percJson)
Scrivi '============================================================'
Scrivi ''
