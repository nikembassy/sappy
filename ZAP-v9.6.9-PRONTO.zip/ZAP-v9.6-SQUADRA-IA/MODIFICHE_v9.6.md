# ZAP v9.6 — file toccati

| file | righe 9.5 | righe 9.6 | delta |
|---|---:|---:|---:|
| `brain/provider_ai.ps1` | 247 | 244 | -3 |
| `brain/llm.ps1` | 921 | 943 | +22 |
| `brain/orchestra.ps1` | 560 | 590 | +30 |
| `brain/agent.ps1` | 381 | 387 | +6 |
| `brain/memoria_v9.ps1` | 662 | 671 | +9 |
| `brain/tools.ps1` | 2106 | 2040 | -66 |
| `brain/intelligenze_ui.ps1` | 383 | 382 | -1 |
| `AVVIA.ps1` | 3946 | 3946 | +0 |
| `INSTALLA.ps1` | 259 | 211 | -48 |

## Cosa fa ognuno

- **`config.json`** — via `provider_ai.ollama`; `provider`/`modello` = Gemini 3.6 Flash;
  `api_base` svuotato (era `localhost:11434`); nuovi blocchi `motore`, `memoria`,
  `gemini_sicurezza`; `orchestrazione.attivo = false`, `giudice = "elenco"`.
- **`brain/provider_ai.ps1`** — registro senza Ollama; `Resolve-AiProvider` riscritto
  (scelta esplicita = lucchetto, poi catena primario→secondario); `Get-ProviderAlternativo`
  limitato al secondario; nuovo `Get-MotoreCatena`.
- **`brain/llm.ps1`** — `Invoke-Chat` riscritto: un tentativo, ripiego dichiarato;
  nuove `Invoke-ChatSuProvider`, `Invoke-OpenAiCompat`, `Add-EtichettaRipiego`;
  `safetySettings` su Gemini.
- **`brain/orchestra.ps1`** — spenta di fabbrica; `Test-OrchestraAttiva` rispetta la
  scelta; modalità `elenco` (ognuno risponde per sé).
- **`brain/agent.ps1`** — salvataggio memoria a fine turno solo se `memoria.salvataggio = "auto"`.
- **`brain/memoria_v9.ps1`** — nuova `Test-MemoriaAuto`.
- **`brain/tools.ps1`** — rimossi gli strumenti `model_status` e `pull_model`,
  la funzione `Get-OllamaModels` e il download locale; `Start-ModelPull` ora verifica
  il servizio configurato.
- **`brain/intelligenze_ui.ps1`**, **`AVVIA.ps1`** — niente riferimenti al motore locale;
  default della casella servizi = `gemini`.
- **`INSTALLA.ps1`** — i passi 3 e 4 installano solo cloud (Gemini + DeepSeek).
